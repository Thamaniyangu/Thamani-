import { PermissionsAndroid, Platform } from 'react-native';
import SmsAndroid from 'react-native-get-sms-android';
import client from '../api/client';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ============================================================
// REQUEST PERMISSIONS
// ============================================================
export const requestSMSPermissions = async () => {
    if (Platform.OS !== 'android') return false;

    try {
        const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.READ_SMS,
            PermissionsAndroid.PERMISSIONS.RECEIVE_SMS,
        ]);

        return (
            granted['android.permission.READ_SMS'] === PermissionsAndroid.RESULTS.GRANTED &&
            granted['android.permission.RECEIVE_SMS'] === PermissionsAndroid.RESULTS.GRANTED
        );
    } catch (err) {
        return false;
    }
};

// ============================================================
// PROCESS SMS
// ============================================================
const processSMS = async (sms) => {
    const text = sms.body.toLowerCase();

    // Check if it's a payment SMS
    const isPayment =
        text.includes('you have received') ||
        text.includes('umepokea') ||
        text.includes('m-pesa') ||
        text.includes('tigo pesa') ||
        text.includes('airtel money');

    if (!isPayment) return;

    // Extract amount
    const amountMatch =
        text.match(/(?:tzs|tshs?)\s*([\d,]+)/i) ||
        text.match(/([\d,]+)\s*(?:tzs|tshs?)/i);

    if (!amountMatch) return;

    const amount = parseFloat(amountMatch[1].replace(/,/g, ''));
    if (isNaN(amount) || amount <= 0) return;

    // Send to backend
    const deviceId = await AsyncStorage.getItem('device_id');

    try {
        await client.post('/api/plugins/iot/data', {
            type: 'sms_payment',
            data: {
                text: sms.body,
                amount,
                sender: sms.address,
                transactionId: sms._id,
                receivedAt: sms.date,
            },
        }, {
            headers: { 'X-Device-Id': deviceId },
        });

        console.log('✅ SMS processed:', amount);
    } catch (err) {
        console.error('SMS processing failed:', err);
    }
};

// ============================================================
// START LISTENER
// ============================================================
export const startSMSListener = async () => {
    const granted = await requestSMSPermissions();
    if (!granted) {
        console.log('SMS permissions not granted');
        return;
    }

    // Listen to inbox
    SmsAndroid.list(
        JSON.stringify({
            box: 'inbox',
            maxCount: 20,
            minDate: Date.now() - 10 * 60 * 1000,
        }),
        (fail) => console.error('SMS list failed:', fail),
        async (count, smsList) => {
            const messages = JSON.parse(smsList);
            for (const msg of messages) {
                await processSMS(msg);
            }
        }
    );

    // Set up real-time listener for new SMS
    // Note: This requires additional native setup
};

export const stopSMSListener = () => {
    // Stop listening
    // Note: Requires native implementation
};