// React Native - SMS Listener
import { PermissionsAndroid, Platform } from 'react-native';
import SmsAndroid from 'react-native-get-sms-android';
import axios from 'axios';

// ============================================================
// REQUEST SMS PERMISSIONS
// ============================================================
export const requestSMSPermissions = async () => {
    if (Platform.OS !== 'android') return false;

    try {
        const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.READ_SMS,
            PermissionsAndroid.PERMISSIONS.RECEIVE_SMS
        ]);

        return granted['android.permission.READ_SMS'] === PermissionsAndroid.RESULTS.GRANTED &&
               granted['android.permission.RECEIVE_SMS'] === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
        return false;
    }
};

// ============================================================
// START SMS LISTENER
// ============================================================
export const startSMSListener = (userId, deviceId, apiUrl, token) => {
    // Listen for new SMS
    SmsAndroid.autoSend(
        userId,
        (success) => console.log('SMS listening started:', success),
        async (fail) => console.error('SMS listener failed:', fail)
    );

    // Custom listener for specific SMS
    SmsAndroid.list(
        JSON.stringify({
            box: 'inbox',
            maxCount: 10,
            minDate: Date.now() - 5 * 60 * 1000 // Last 5 minutes
        }),
        (fail) => console.error('SMS list failed:', fail),
        async (count, smsList) => {
            const messages = JSON.parse(smsList);

            for (const msg of messages) {
                await processSMSMessage(msg, userId, deviceId, apiUrl, token);
            }
        }
    );
};

// ============================================================
// PROCESS SMS MESSAGE
// ============================================================
const processSMSMessage = async (sms, userId, deviceId, apiUrl, token) => {
    const text = sms.body.toLowerCase();

    // Check if it's a payment SMS
    const isPayment = 
        text.includes('you have received') ||
        text.includes('umepokea') ||
        text.includes('m-pesa') ||
        text.includes('tigo pesa') ||
        text.includes('airtel money');

    if (!isPayment) return;

    // Extract amount (regex)
    const amountMatch = text.match(/(?:tzs|tshs?)\s*([\d,]+)/i) || 
                        text.match(/([\d,]+)\s*(?:tzs|tshs?)/i);

    if (!amountMatch) return;

    const amount = parseFloat(amountMatch[1].replace(/,/g, ''));

    if (isNaN(amount) || amount <= 0) return;

    // Send to backend
    try {
        await axios.post(`${apiUrl}/api/iot/data`, {
            type: 'sms_payment',
            data: {
                text: sms.body,
                amount,
                sender: sms.address,
                transactionId: sms._id,
                receivedAt: sms.date
            }
        }, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'X-Device-Id': deviceId,
                'X-Signature': generateSignature(sms.body, userId)
            }
        });

        console.log('SMS processed successfully');
    } catch (err) {
        console.error('Failed to process SMS:', err);
    }
};

// ============================================================
// GENERATE SIGNATURE
// ============================================================
const generateSignature = (data, userId) => {
    const crypto = require('crypto-js');
    const secret = 'THAMANI_IOT_SECRET_KEY';
    return crypto.HmacSHA256(data + userId, secret).toString();
};