import messaging from '@react-native-firebase/messaging';
import notifee, { AndroidImportance } from '@notifee/react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../api/client';

// ============================================================
// REQUEST PERMISSION
// ============================================================
export const requestPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
        authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
        authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
        console.log('Push notification permission granted');
    }

    return enabled;
};

// ============================================================
// GET FCM TOKEN
// ============================================================
export const getFCMToken = async () => {
    try {
        const token = await messaging().getToken();
        await AsyncStorage.setItem('fcm_token', token);
        return token;
    } catch (err) {
        console.error('FCM token error:', err);
        return null;
    }
};

// ============================================================
// REGISTER WITH BACKEND
// ============================================================
export const registerWithBackend = async (fcmToken) => {
    try {
        await client.post('/api/push/register', {
            token: fcmToken,
            platform: 'mobile',
        });
    } catch (err) {
        console.error('Register FCM error:', err);
    }
};

// ============================================================
// FOREGROUND NOTIFICATIONS
// ============================================================
export const setupForegroundHandler = () => {
    return messaging().onMessage(async (remoteMessage) => {
        await notifee.displayNotification({
            title: remoteMessage.notification.title,
            body: remoteMessage.notification.body,
            android: {
                channelId: 'default',
                importance: AndroidImportance.HIGH,
                color: '#0D6B6B',
            },
        });
    });
};

// ============================================================
// BACKGROUND HANDLER
// ============================================================
export const setupBackgroundHandler = () => {
    messaging().setBackgroundMessageHandler(async (remoteMessage) => {
        console.log('Background message:', remoteMessage);
    });
};

// ============================================================
// CREATE CHANNEL
// ============================================================
export const createNotificationChannel = async () => {
    await notifee.createChannel({
        id: 'default',
        name: 'Default Channel',
        importance: AndroidImportance.HIGH,
        sound: 'default',
    });
};

// ============================================================
// INITIALIZE
// ============================================================
export const initializeNotifications = async () => {
    const granted = await requestPermission();
    if (!granted) return;

    await createNotificationChannel();
    const token = await getFCMToken();

    if (token) {
        await registerWithBackend(token);
    }

    setupForegroundHandler();

    // Handle token refresh
    messaging().onTokenRefresh(async (newToken) => {
        await AsyncStorage.setItem('fcm_token', newToken);
        await registerWithBackend(newToken);
    });
};