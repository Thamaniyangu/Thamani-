import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import io from 'socket.io-client';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

const ChatScreen = ({ route }) => {
    const { user, token } = useAuth();
    const { roomId, roomName } = route.params || {};
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [socket, setSocket] = useState(null);
    const flatListRef = useRef();

    useEffect(() => {
        // Load messages
        loadMessages();

        // Connect socket
        const newSocket = io('https://api.thamaniyangu.com', {
            query: { userId: user.id },
            transports: ['websocket'],
        });

        newSocket.on('connect', () => {
            newSocket.emit('join-room', roomId);
        });

        newSocket.on('new-message', (message) => {
            if (message.room_id === roomId) {
                setMessages((prev) => [...prev, message]);
                flatListRef.current?.scrollToEnd();
            }
        });

        setSocket(newSocket);

        return () => newSocket.disconnect();
    }, [roomId]);

    const loadMessages = async () => {
        try {
            const res = await client.get(`/api/chat/rooms/${roomId}/messages`);
            setMessages(res.data.reverse());
        } catch (err) {
            console.error(err);
        }
    };

    const sendMessage = async () => {
        if (!newMessage.trim()) return;

        try {
            const res = await client.post(`/api/chat/rooms/${roomId}/messages`, {
                text: newMessage,
                type: 'text',
            });

            socket?.emit('send-message', {
                roomId,
                message: res.data,
            });

            setNewMessage('');
        } catch (err) {
            console.error(err);
        }
    };

    const renderMessage = ({ item }) => {
        const isMine = item.sender_id === user.id;

        return (
            <View
                style={[
                    styles.messageBubble,
                    isMine ? styles.myMessage : styles.theirMessage,
                ]}
            >
                {!isMine && (
                    <Text style={styles.senderName}>{item.sender_name}</Text>
                )}
                <Text style={[styles.messageText, isMine && styles.myMessageText]}>
                    {item.text}
                </Text>
                <Text style={[styles.timeText, isMine && styles.myTimeText]}>
                    {new Date(item.created_at).toLocaleTimeString('sw-TZ', {
                        hour: '2-digit',
                        minute: '2-digit',
                    })}
                </Text>
            </View>
        );
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            keyboardVerticalOffset={80}
        >
            <FlatList
                ref={flatListRef}
                data={messages}
                renderItem={renderMessage}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.messagesList}
                onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
            />

            <View style={styles.inputBar}>
                <TextInput
                    style={styles.input}
                    placeholder="Andika ujumbe..."
                    value={newMessage}
                    onChangeText={setNewMessage}
                    multiline
                />
                <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
                    <Icon name="paper-plane" size={20} color="white" />
                </TouchableOpacity>
            </View>
        </KeyboardAvoidingView>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8F9FA' },
    messagesList: { padding: 12, gap: 8 },
    messageBubble: {
        maxWidth: '80%',
        padding: 12,
        borderRadius: 16,
        marginBottom: 4,
    },
    myMessage: {
        alignSelf: 'flex-end',
        backgroundColor: '#0D6B6B',
        borderBottomRightRadius: 4,
    },
    theirMessage: {
        alignSelf: 'flex-start',
        backgroundColor: 'white',
        borderBottomLeftRadius: 4,
    },
    senderName: { fontSize: 11, fontWeight: 'bold', color: '#0D6B6B', marginBottom: 4 },
    messageText: { fontSize: 15, color: '#1A1A1A' },
    myMessageText: { color: 'white' },
    timeText: { fontSize: 10, color: '#9CA3AF', marginTop: 4, alignSelf: 'flex-end' },
    myTimeText: { color: 'rgba(255,255,255,0.7)' },
    inputBar: {
        flexDirection: 'row',
        padding: 12,
        backgroundColor: 'white',
        borderTopWidth: 1,
        borderTopColor: '#E5E7EB',
        alignItems: 'flex-end',
    },
    input: {
        flex: 1,
        backgroundColor: '#F3F4F6',
        borderRadius: 24,
        paddingHorizontal: 16,
        paddingVertical: 10,
        maxHeight: 100,
        fontSize: 15,
    },
    sendButton: {
        backgroundColor: '#0D6B6B',
        width: 44,
        height: 44,
        borderRadius: 22,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8,
    },
});

export default ChatScreen;