import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    RefreshControl
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

const DashboardScreen = ({ navigation }) => {
    const { user } = useAuth();
    const [stats, setStats] = useState(null);
    const [refreshing, setRefreshing] = useState(false);

    const loadStats = async () => {
        try {
            const res = await client.get('/api/contributions/stats');
            setStats(res.data);
        } catch (err) {
            console.error(err);
        } finally {
            setRefreshing(false);
        }
    };

    useEffect(() => {
        loadStats();
    }, []);

    const quickActions = [
        { icon: 'wallet', label: 'Michango', screen: 'Contributions', color: '#0D6B6B' },
        { icon: 'comments', label: 'Chat', screen: 'Chat', color: '#3B82F6' },
        { icon: 'robot', label: 'AI', screen: 'AI', color: '#8B5CF6' },
        { icon: 'video', label: 'Video', screen: 'Video', color: '#EC4899' },
    ];

    return (
        <ScrollView
            style={styles.container}
            refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={loadStats} />
            }
        >
            {/* Header */}
            <View style={styles.header}>
                <Text style={styles.greeting}>Karibu, {user?.first_name}! 👋</Text>
                <Text style={styles.memberId}>{user?.member_id}</Text>
            </View>

            {/* Stats Cards */}
            <View style={styles.statsRow}>
                <StatCard
                    icon="coins"
                    value={`TZS ${(stats?.totals?.total_amount || 0).toLocaleString()}`}
                    label="Michango"
                    color="#10B981"
                />
                <StatCard
                    icon="chart-line"
                    value="0"
                    label="Mikopo"
                    color="#F59E0B"
                />
            </View>

            {/* Quick Actions */}
            <Text style={styles.sectionTitle}>Vitendo vya Haraka</Text>
            <View style={styles.actionsGrid}>
                {quickActions.map((action, idx) => (
                    <TouchableOpacity
                        key={idx}
                        style={[styles.actionButton, { backgroundColor: action.color }]}
                        onPress={() => navigation.navigate(action.screen)}
                    >
                        <Icon name={action.icon} size={32} color="white" />
                        <Text style={styles.actionLabel}>{action.label}</Text>
                    </TouchableOpacity>
                ))}
            </View>

            {/* Recent Activity */}
            <Text style={styles.sectionTitle}>Shughuli za Hivi Karibuni</Text>
            <View style={styles.activityList}>
                <Text style={styles.emptyText}>Hakuna shughuli bado</Text>
            </View>
        </ScrollView>
    );
};

const StatCard = ({ icon, value, label, color }) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
        <Icon name={icon} size={24} color={color} />
        <Text style={styles.statValue}>{value}</Text>
        <Text style={styles.statLabel}>{label}</Text>
    </View>
);

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8F9FA' },
    header: {
        backgroundColor: '#0D6B6B',
        padding: 24,
        paddingTop: 60,
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
    },
    greeting: { fontSize: 24, fontWeight: 'bold', color: 'white' },
    memberId: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 4 },
    statsRow: {
        flexDirection: 'row',
        padding: 16,
        gap: 12,
        marginTop: -20,
    },
    statCard: {
        flex: 1,
        backgroundColor: 'white',
        padding: 16,
        borderRadius: 16,
        borderLeftWidth: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 4,
    },
    statValue: { fontSize: 18, fontWeight: 'bold', marginTop: 8 },
    statLabel: { fontSize: 12, color: '#6B7280', marginTop: 2 },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        paddingHorizontal: 16,
        marginTop: 24,
        marginBottom: 12,
    },
    actionsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingHorizontal: 16,
        gap: 12,
    },
    actionButton: {
        width: '47%',
        padding: 20,
        borderRadius: 16,
        alignItems: 'center',
        gap: 8,
    },
    actionLabel: { color: 'white', fontWeight: 'bold' },
    activityList: {
        backgroundColor: 'white',
        marginHorizontal: 16,
        borderRadius: 16,
        padding: 24,
        alignItems: 'center',
    },
    emptyText: { color: '#9CA3AF' },
});

export default DashboardScreen;