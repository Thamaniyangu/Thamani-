module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: { extend: { colors: { gold: { 400: '#D4AF37', 500: '#C5A028', 600: '#B8941E' } } } },
  plugins: [],
};