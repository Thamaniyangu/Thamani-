import MwenyekitiAIDashboard from './pages/MwenyekitiAIDashboard';

// Ndani ya Routes:
<Route path="ai-admin" element={<MwenyekitiAIDashboard />} />