import WhatsAppSettings from './pages/WhatsAppSettings';

<Route path="whatsapp" element={<WhatsAppSettings />} />