// Ongeza imports
import VideoCallPage from './pages/VideoCallPage';
import Chat from './pages/Chat';
import AIBuddy from './pages/AIBuddy';
import Settings from './pages/Settings';
import ThemeSettings from './pages/ThemeSettings';
import WhatsAppSettings from './pages/WhatsAppSettings';
import ApplicationsList from './pages/ApplicationsList';
import BackupSettings from './pages/BackupSettings';

// Kwenye Routes ndani ya /dashboard:
<Route path="video" element={<VideoCallPage />} />
<Route path="chat" element={<Chat />} />
<Route path="ai-buddy" element={<AIBuddy />} />
<Route path="settings" element={<Settings />} />
<Route path="themes" element={<ThemeSettings />} />
<Route path="whatsapp" element={<WhatsAppSettings />} />
<Route path="applications" element={<ApplicationsList />} />
<Route path="backup" element={<BackupSettings />} />