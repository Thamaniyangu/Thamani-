import { DarkModeProvider } from './context/DarkModeContext';
import { LanguageProvider } from './context/LanguageContext';

function App() {
    return (
        <AuthProvider>
            <DarkModeProvider>
                <LanguageProvider>
                    <BrowserRouter>
                        <Toaster position="top-right" />
                        <AppContent />
                    </BrowserRouter>
                </LanguageProvider>
            </DarkModeProvider>
        </AuthProvider>
    );
}