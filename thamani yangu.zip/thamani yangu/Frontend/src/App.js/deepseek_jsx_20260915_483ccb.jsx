import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { AIProfilesProvider } from './context/AIProfilesContext';
import { PluginProvider } from './context/PluginContext';
import { DarkModeProvider } from './context/DarkModeContext';
import { LanguageProvider } from './context/LanguageContext';

// Common pages
import Login from './pages/Login';
import Signup from './pages/Signup';
import JoinPage from './pages/JoinPage';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Contributions from './pages/Contributions';
import MembershipFees from './pages/MembershipFees';
import ReceiptViewer from './pages/ReceiptViewer';
import IdCardViewer from './pages/IdCardViewer';
import Chat from './pages/Chat';
import AIBuddy from './pages/AIBuddy';
import VideoCallPage from './pages/VideoCallPage';
import SupportChats from './pages/SupportChats';
import Settings from './pages/Settings';
import CompleteChange from './pages/CompleteChange';
import ApplicationsList from './pages/ApplicationsList';
import Documents from './pages/Documents';

// Super Admin pages (Mwenyekiti pekee)
import AIProfileSettings from './pages/AIProfileSettings';
import ThemeSettings from './pages/ThemeSettings';
import WhatsAppSettings from './pages/WhatsAppSettings';
import BackupSettings from './pages/BackupSettings';
import AITrainingDashboard from './pages/AITrainingDashboard';
import PluginManager from './pages/PluginManager';

// Super Admin Plugins (Mwenyekiti pekee)
import SIPClient from './plugins/sip-voice/SIPClient';
import CampaignList from './plugins/marketing-automation/CampaignList';
import AnalyticsDashboard from './plugins/advanced-analytics/AnalyticsDashboard';

import ProtectedRoute from './components/ProtectedRoute';
import MwenyekitiRoute from './components/MwenyekitiRoute'; // NEW
import { Toaster } from 'react-hot-toast';

function AppContent() {
    const { user } = useAuth();
    return (
        <PluginProvider token={localStorage.getItem('token')}>
            <SocketProvider userId={user?.id}>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/join" element={<JoinPage />} />
                    <Route path="/complete-change" element={<CompleteChange />} />

                    <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>}>
                        {/* Common - Wote */}
                        <Route index element={<div className="text-center text-2xl">Karibu!</div>} />
                        <Route path="contributions" element={<Contributions />} />
                        <Route path="membership" element={<MembershipFees />} />
                        <Route path="receipts" element={<ReceiptViewer />} />
                        <Route path="id-card" element={<IdCardViewer />} />
                        <Route path="chat" element={<Chat />} />
                        <Route path="ai-buddy" element={<AIBuddy />} />
                        <Route path="video" element={<VideoCallPage />} />
                        <Route path="settings" element={<Settings />} />

                        {/* Viongozi wote */}
                        <Route path="documents" element={<Documents />} />
                        <Route path="support" element={<SupportChats />} />
                        <Route path="applications" element={<ApplicationsList />} />

                        {/* =========================================== */}
                        {/* SUPER ADMIN - MWENYEKITI PEKEE               */}
                        {/* =========================================== */}
                        
                        {/* AI Profile Settings */}
                        <Route path="ai-profiles" element={
                            <MwenyekitiRoute>
                                <AIProfileSettings />
                            </MwenyekitiRoute>
                        } />

                        {/* Theme Settings */}
                        <Route path="themes" element={
                            <MwenyekitiRoute>
                                <ThemeSettings />
                            </MwenyekitiRoute>
                        } />

                        {/* WhatsApp */}
                        <Route path="whatsapp" element={
                            <MwenyekitiRoute>
                                <WhatsAppSettings />
                            </MwenyekitiRoute>
                        } />

                        {/* Backup */}
                        <Route path="backup" element={
                            <MwenyekitiRoute>
                                <BackupSettings />
                            </MwenyekitiRoute>
                        } />

                        {/* AI Training */}
                        <Route path="ai-training" element={
                            <MwenyekitiRoute>
                                <AITrainingDashboard />
                            </MwenyekitiRoute>
                        } />

                        {/* Plugin Manager */}
                        <Route path="plugins" element={
                            <MwenyekitiRoute>
                                <PluginManager />
                            </MwenyekitiRoute>
                        } />

                        {/* =========================================== */}
                        {/* SUPER ADMIN PLUGINS (Mwenyekiti pekee)      */}
                        {/* =========================================== */}

                        {/* SIP Voice */}
                        <Route path="sip-voice" element={
                            <MwenyekitiRoute>
                                <SIPClient />
                            </MwenyekitiRoute>
                        } />

                        {/* Marketing Automation */}
                        <Route path="marketing" element={
                            <MwenyekitiRoute>
                                <CampaignList />
                            </MwenyekitiRoute>
                        } />

                        {/* Advanced Analytics */}
                        <Route path="advanced-analytics" element={
                            <MwenyekitiRoute>
                                <AnalyticsDashboard />
                            </MwenyekitiRoute>
                        } />
                    </Route>

                    <Route path="*" element={<Navigate to="/" />} />
                </Routes>
            </SocketProvider>
        </PluginProvider>
    );
}

function App() {
    return (
        <AuthProvider>
            <DarkModeProvider>
                <LanguageProvider>
                    <BrowserRouter>
                        <Toaster position="top-right" />
                        <AppContent />
                    </BrowserRouter>
                </LanguageProvider>
            </DarkModeProvider>
        </AuthProvider>
    );
}

export default App;