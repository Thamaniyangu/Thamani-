{user?.role === 'mwenyekiti' && (
    <Link to="/dashboard/ai-admin" className="flex items-center gap-3 p-3 rounded hover:bg-teal-700 transition">
        <FaRobot /> AI Admin
    </Link>
)}