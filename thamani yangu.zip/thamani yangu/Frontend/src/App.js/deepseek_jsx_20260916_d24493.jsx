import { AIProfilesProvider } from './context/AIProfilesContext';
import AIProfileSettings from './pages/AIProfileSettings';

function AppContent() {
    const { user } = useAuth();
    return (
        <AIProfilesProvider>
            <SocketProvider userId={user?.id}>
                <Routes>
                    {/* ... existing routes ... */}
                    <Route path="/dashboard/settings" element={<Settings />} />
                    {/* Mwenyekiti pekee */}
                    <Route path="/dashboard/ai-profiles" element={<AIProfileSettings />} />
                </Routes>
            </SocketProvider>
        </AIProfilesProvider>
    );
}