import FinancialAdvisorDashboard from './pages/FinancialAdvisorDashboard';

<Route path="financial-advisor" element={<FinancialAdvisorDashboard />} />