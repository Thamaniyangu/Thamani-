import WhatsAppSettings from './pages/WhatsAppSettings';

// Kwenye Routes ndani ya /dashboard:
<Route path="whatsapp" element={<WhatsAppSettings />} />