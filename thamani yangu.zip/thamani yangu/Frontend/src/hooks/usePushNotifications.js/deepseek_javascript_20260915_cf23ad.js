import { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const urlBase64ToUint8Array = (base64String) => {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
};

const usePushNotifications = (token) => {
    const [isSupported, setIsSupported] = useState(false);
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [permission, setPermission] = useState(Notification?.permission || 'default');

    useEffect(() => {
        const checkSupport = async () => {
            const supported = 'serviceWorker' in navigator && 
                              'PushManager' in window && 
                              'Notification' in window;
            setIsSupported(supported);

            if (supported) {
                const reg = await navigator.serviceWorker.ready;
                const sub = await reg.pushManager.getSubscription();
                setIsSubscribed(!!sub);
                setPermission(Notification.permission);
            }
        };

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js').then(() => checkSupport());
        }
    }, []);

    const subscribe = async () => {
        if (!isSupported) {
            toast.error('Push notifications hazijaungwa mkono');
            return false;
        }

        try {
            const permission = await Notification.requestPermission();
            setPermission(permission);

            if (permission !== 'granted') {
                toast.error('Ruhusa imekataliwa');
                return false;
            }

            const reg = await navigator.serviceWorker.ready;
            const vapidRes = await axios.get('/api/push/vapid-key');
            const publicKey = vapidRes.data.publicKey;

            const subscription = await reg.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(publicKey)
            });

            await axios.post('/api/push/subscribe', {
                subscription: subscription.toJSON(),
                deviceInfo: navigator.userAgent
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            setIsSubscribed(true);
            toast.success('Arifa zimewashwa!');
            return true;
        } catch (err) {
            console.error('Subscribe error:', err);
            toast.error('Imeshindwa kuwasha arifa');
            return false;
        }
    };

    const unsubscribe = async () => {
        try {
            const reg = await navigator.serviceWorker.ready;
            const sub = await reg.pushManager.getSubscription();

            if (sub) {
                await axios.post('/api/push/unsubscribe', {
                    endpoint: sub.endpoint
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                await sub.unsubscribe();
                setIsSubscribed(false);
                toast.success('Arifa zimezimwa');
            }
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const testNotification = async () => {
        await axios.post('/api/push/send-test', {}, {
            headers: { Authorization: `Bearer ${token}` }
        });
        toast.success('Notification imetumwa!');
    };

    return {
        isSupported,
        isSubscribed,
        permission,
        subscribe,
        unsubscribe,
        testNotification
    };
};

export default usePushNotifications;