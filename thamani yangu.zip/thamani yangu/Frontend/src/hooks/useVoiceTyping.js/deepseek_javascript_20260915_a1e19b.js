import { useState, useEffect, useRef } from 'react';

const useVoiceTyping = (options = {}) => {
    const { language = 'sw-KE', continuous = true } = options;
    const [isSupported, setIsSupported] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const [transcript, setTranscript] = useState('');
    const [interim, setInterim] = useState('');
    const [error, setError] = useState(null);
    const recognitionRef = useRef(null);

    useEffect(() => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            setIsSupported(false);
            return;
        }

        setIsSupported(true);
        const recognition = new SpeechRecognition();
        recognition.continuous = continuous;
        recognition.interimResults = true;
        recognition.lang = language;
        recognition.maxAlternatives = 1;

        recognition.onresult = (event) => {
            let finalTranscript = '';
            let interimTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; i++) {
                const result = event.results[i];
                if (result.isFinal) {
                    finalTranscript += result[0].transcript;
                } else {
                    interimTranscript += result[0].transcript;
                }
            }

            if (finalTranscript) {
                setTranscript(prev => prev + finalTranscript + ' ');
            }
            setInterim(interimTranscript);
        };

        recognition.onerror = (event) => {
            setError(event.error);
            if (event.error === 'not-allowed') {
                setIsListening(false);
            }
        };

        recognition.onend = () => {
            if (isListening && continuous) {
                try { recognition.start(); } catch (e) {}
            } else {
                setIsListening(false);
            }
        };

        recognitionRef.current = recognition;

        return () => {
            if (recognitionRef.current) {
                recognitionRef.current.stop();
            }
        };
    }, [language, continuous, isListening]);

    const start = () => {
        if (!recognitionRef.current) return;
        setError(null);
        try {
            recognitionRef.current.start();
            setIsListening(true);
        } catch (e) {
            if (e.message.includes('already started')) {
                recognitionRef.current.stop();
                setTimeout(() => {
                    recognitionRef.current.start();
                    setIsListening(true);
                }, 100);
            }
        }
    };

    const stop = () => {
        if (recognitionRef.current) {
            try { recognitionRef.current.stop(); } catch (e) {}
        }
        setIsListening(false);
    };

    const toggle = () => {
        if (isListening) stop();
        else start();
    };

    const reset = () => {
        setTranscript('');
        setInterim('');
    };

    return {
        isSupported,
        isListening,
        transcript,
        interim,
        fullText: transcript + interim,
        error,
        start,
        stop,
        toggle,
        reset
    };
};

export default useVoiceTyping;