import { useState, useRef, useCallback } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const useMeetingRecording = (meetingId, token) => {
    const [isRecording, setIsRecording] = useState(false);
    const [recordingId, setRecordingId] = useState(null);
    const [duration, setDuration] = useState(0);
    const mediaRecorderRef = useRef(null);
    const chunksRef = useRef([]);
    const timerRef = useRef(null);
    const startTimeRef = useRef(null);

    const startRecording = useCallback(async (stream) => {
        try {
            // Create recording in DB
            const res = await axios.post('/api/recordings/start', {
                meetingId
            }, { headers: { Authorization: `Bearer ${token}` } });

            const recId = res.data.recordingId;
            setRecordingId(recId);

            // Setup MediaRecorder
            const options = { mimeType: 'video/webm;codecs=vp9,opus' };
            let recorder;
            
            try {
                recorder = new MediaRecorder(stream, options);
            } catch (e) {
                // Fallback
                recorder = new MediaRecorder(stream);
            }

            recorder.ondataavailable = async (e) => {
                if (e.data.size > 0) {
                    chunksRef.current.push(e.data);
                    
                    // Upload chunk
                    const formData = new FormData();
                    formData.append('chunk', e.data, `chunk-${Date.now()}.webm`);
                    
                    try {
                        await axios.post(
                            `/api/recordings/${recId}/chunk`,
                            formData,
                            { headers: { 
                                Authorization: `Bearer ${token}`,
                                'Content-Type': 'multipart/form-data'
                            }}
                        );
                    } catch (err) {
                        console.error('Chunk upload error:', err);
                    }
                }
            };

            recorder.start(5000); // Chunk every 5 seconds
            mediaRecorderRef.current = recorder;
            setIsRecording(true);
            startTimeRef.current = Date.now();
            setDuration(0);

            // Timer
            timerRef.current = setInterval(() => {
                setDuration(Math.floor((Date.now() - startTimeRef.current) / 1000));
            }, 1000);

            toast.success('Recording imeanza!');
        } catch (err) {
            toast.error('Imeshindwa kuanza recording');
            throw err;
        }
    }, [meetingId, token]);

    const stopRecording = useCallback(async () => {
        if (!mediaRecorderRef.current) return;

        return new Promise((resolve) => {
            mediaRecorderRef.current.onstop = async () => {
                const finalDuration = Math.floor((Date.now() - startTimeRef.current) / 1000);

                try {
                    const res = await axios.post(
                        `/api/recordings/${recordingId}/stop`,
                        { duration: finalDuration },
                        { headers: { Authorization: `Bearer ${token}` }}
                    );

                    setIsRecording(false);
                    if (timerRef.current) clearInterval(timerRef.current);
                    
                    toast.success('Recording imehifadhiwa!');
                    resolve(res.data);
                } catch (err) {
                    toast.error('Imeshindwa kuhifadhi recording');
                    resolve(null);
                }
            };

            mediaRecorderRef.current.stop();
            if (mediaRecorderRef.current.stream) {
                mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
            }
        });
    }, [recordingId, token]);

    const formatDuration = (seconds) => {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    return {
        isRecording,
        recordingId,
        duration,
        formattedDuration: formatDuration(duration),
        startRecording,
        stopRecording
    };
};

export default useMeetingRecording;