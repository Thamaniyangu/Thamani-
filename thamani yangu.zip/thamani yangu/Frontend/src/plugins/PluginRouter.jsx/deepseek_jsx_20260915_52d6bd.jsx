const PLUGIN_COMPONENTS = {
    'my-new-feature': {
        path: '/dashboard/my-feature',
        component: lazy(() => import('../../plugins/my-feature/Dashboard'))
    }
};