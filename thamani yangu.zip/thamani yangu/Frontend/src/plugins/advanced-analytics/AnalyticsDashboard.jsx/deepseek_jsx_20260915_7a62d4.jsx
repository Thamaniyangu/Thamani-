import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Icons } from '../../components/Icon';
import { useAuth } from '../../context/AuthContext';

const AnalyticsDashboard = () => {
    const { token, user } = useAuth();
    const [data, setData] = useState(null);
    const [predictions, setPredictions] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [dash, pred] = await Promise.all([
                axios.get('/api/plugins/analytics/dashboard', {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get('/api/plugins/analytics/predictions', {
                    headers: { Authorization: `Bearer ${token}` }
                })
            ]);
            setData(dash.data);
            setPredictions(pred.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div className="p-6 text-center">Inapakia...</div>;
    if (!data) return <div className="p-6 text-center">Hakuna data</div>;

    const COLORS = ['#0D6B6B', '#D4AF37', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444'];

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center gap-4">
                    <Icons.chart size="4x" />
                    <div>
                        <h1 className="text-3xl font-bold">Advanced Analytics</h1>
                        <p className="opacity-90">Uchambuzi wa kina + Utabiri wa AI</p>
                    </div>
                </div>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <KPICard
                    label="Michango (30d)"
                    value={`TZS ${(data.last30?.reduce((s, d) => s + parseFloat(d.total_contributions || 0), 0) || 0).toLocaleString()}`}
                    icon={Icons.money}
                    color="from-green-500 to-emerald-600"
                />
                <KPICard
                    label="Wanachama Hai"
                    value={data.today?.active_members || 0}
                    icon={Icons.users}
                    color="from-blue-500 to-indigo-600"
                />
                <KPICard
                    label="Wako Hatarini"
                    value={data.atRisk?.length || 0}
                    icon={Icons.warning}
                    color="from-yellow-500 to-orange-600"
                />
                <KPICard
                    label="Anomalies"
                    value={data.anomalies?.length || 0}
                    icon={Icons.fire}
                    color="from-red-500 to-pink-600"
                />
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Contributions trend */}
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-lg mb-4">Mwenendo wa Michango (Siku 30)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={data.last30 || []}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="stat_date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line 
                                type="monotone" 
                                dataKey="total_contributions" 
                                stroke="#0D6B6B" 
                                strokeWidth={2}
                                name="Michango"
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Segments */}
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-lg mb-4">Mgawanyo wa Wanachama</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={data.segments || []}
                                dataKey="count"
                                nameKey="segment"
                                cx="50%"
                                cy="50%"
                                outerRadius={100}
                                label
                            >
                                {(data.segments || []).map((entry, index) => (
                                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Predictions */}
            {predictions?.contributions && (
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                        <Icons.chart /> Utabiri wa Michango (Miezi 6)
                        {predictions.contributions.trend && (
                            <span className={`text-sm px-2 py-1 rounded ${
                                predictions.contributions.trend === 'increasing' ? 'bg-green-100 text-green-700' :
                                predictions.contributions.trend === 'decreasing' ? 'bg-red-100 text-red-700' :
                                'bg-gray-100 text-gray-700'
                            }`}>
                                {predictions.contributions.trend === 'increasing' ? '📈 Inaongezeka' :
                                 predictions.contributions.trend === 'decreasing' ? '📉 Inapungua' : '➡️ Stable'}
                            </span>
                        )}
                    </h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={predictions.contributions.predictions || []}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="predicted" fill="#D4AF37" name="Utabiri" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            )}

            {/* At-Risk Members */}
            {data.atRisk?.length > 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-red-600">
                        <Icons.warning /> Wanachama Wako Hatarini ({data.atRisk.length})
                    </h3>
                    <div className="space-y-2">
                        {data.atRisk.map(m => (
                            <div key={m.id} className="flex items-center justify-between p-3 bg-red-50 rounded-xl">
                                <div>
                                    <p className="font-bold">{m.first_name} {m.last_name}</p>
                                    <p className="text-xs text-gray-500">{m.member_id} • {m.phone}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-red-600 font-bold">
                                        {parseFloat(m.risk_score).toFixed(1)}% Risk
                                    </p>
                                    <p className="text-xs text-gray-500">{m.segment}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Anomalies */}
            {data.anomalies?.length > 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-orange-600">
                        <Icons.fire /> Anomalies Zilizogundulika
                    </h3>
                    <div className="space-y-2">
                        {data.anomalies.map(a => (
                            <div key={a.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-xl">
                                <div>
                                    <p className="font-bold">{a.description}</p>
                                    <p className="text-xs text-gray-500">
                                        {new Date(a.detected_at).toLocaleString('sw-TZ')}
                                    </p>
                                </div>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                    a.severity === 'high' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                                }`}>
                                    {a.severity}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

const KPICard = ({ label, value, icon: Icon, color }) => (
    <div className={`bg-gradient-to-br ${color} rounded-2xl p-6 text-white shadow-lg`}>
        <Icon size="2x" className="mb-3 opacity-80" />
        <p className="text-sm opacity-90">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
    </div>
);

export default AnalyticsDashboard;