// frontend/src/plugins/my-feature/Dashboard.jsx
import React from 'react';

export default function MyFeatureDashboard() {
    return (
        <div className="p-6">
            <h1>Kipengele Changu Kipya</h1>
            {/* Your feature */}
        </div>
    );
}