import React, { useState, useEffect, useRef } from 'react';
import JsSIP from 'jssip';
import axios from 'axios';
import toast from 'react-hot-toast';
import { Icons } from '../../components/Icon';
import { useAuth } from '../../context/AuthContext';

const SIPClient = () => {
    const { token, user } = useAuth();
    const [ua, setUA] = useState(null);
    const [registered, setRegistered] = useState(false);
    const [currentCall, setCurrentCall] = useState(null);
    const [incomingCall, setIncomingCall] = useState(null);
    const [callDuration, setCallDuration] = useState(0);
    const [callHistory, setCallHistory] = useState([]);
    const [targetUser, setTargetUser] = useState('');
    const remoteAudioRef = useRef();

    // Initialize SIP client
    useEffect(() => {
        initSIP();
        loadHistory();
    }, []);

    const initSIP = async () => {
        try {
            const res = await axios.get('/api/plugins/sip/sip/credentials', {
                headers: { Authorization: `Bearer ${token}` }
            });

            const { sip_username, sip_password, sip_domain, wss_url } = res.data;

            const socket = new JsSIP.WebSocketInterface(wss_url);
            const configuration = {
                sockets: [socket],
                uri: `sip:${sip_username}@${sip_domain}`,
                password: sip_password,
                register: true
            };

            const newUA = new JsSIP.UA(configuration);

            newUA.on('registered', () => {
                setRegistered(true);
                toast.success('SIP imeunganishwa');
            });

            newUA.on('unregistered', () => setRegistered(false));
            newUA.on('registrationFailed', () => toast.error('SIP imeshindwa'));

            newUA.on('newRTCSession', (data) => {
                const { originator, session } = data;

                if (originator === 'remote') {
                    setIncomingCall(session);
                    toast.custom((t) => (
                        <div className="bg-white p-4 rounded-xl shadow-2xl">
                            <p className="font-bold">Simu inaingia...</p>
                            <div className="flex gap-2 mt-2">
                                <button
                                    onClick={() => acceptCall(session)}
                                    className="bg-green-500 text-white px-4 py-2 rounded-lg"
                                >
                                    Pokea
                                </button>
                                <button
                                    onClick={() => rejectCall(session)}
                                    className="bg-red-500 text-white px-4 py-2 rounded-lg"
                                >
                                    Kataa
                                </button>
                            </div>
                        </div>
                    ), { duration: 30000 });
                } else {
                    setCurrentCall(session);
                    setupCallEvents(session);
                }
            });

            newUA.start();
            setUA(newUA);
        } catch (err) {
            console.error('SIP init error:', err);
            toast.error('Imeshindwa kuanzisha SIP');
        }
    };

    const setupCallEvents = (session) => {
        let timer;
        const startTime = Date.now();

        session.on('accepted', () => {
            toast.success('Simu imepokelewa');
            timer = setInterval(() => {
                setCallDuration(Math.floor((Date.now() - startTime) / 1000));
            }, 1000);

            const pc = session.connection;
            pc.addEventListener('track', (event) => {
                if (remoteAudioRef.current) {
                    remoteAudioRef.current.srcObject = event.streams[0];
                }
            });
        });

        session.on('ended', () => {
            clearInterval(timer);
            setCurrentCall(null);
            setCallDuration(0);
            toast.info('Simu imeisha');
        });

        session.on('failed', () => {
            clearInterval(timer);
            setCurrentCall(null);
            setCallDuration(0);
            toast.error('Simu imeshindwa');
        });
    };

    const makeCall = async () => {
        if (!registered) return toast.error('SIP haijaunganishwa');
        if (!targetUser) return toast.error('Ingiza Member ID');

        try {
            const session = ua.call(`sip:thm${targetUser}@${ua._configuration.uri.host}`, {
                mediaConstraints: { audio: true, video: false },
                pcConfig: {
                    iceServers: [
                        { urls: 'stun:stun.l.google.com:19302' }
                    ]
                }
            });

            setCurrentCall(session);
            setupCallEvents(session);
        } catch (err) {
            console.error('Call error:', err);
            toast.error('Imeshindwa kupiga');
        }
    };

    const acceptCall = (session) => {
        session.answer({
            mediaConstraints: { audio: true, video: false }
        });
        setCurrentCall(session);
        setIncomingCall(null);
        setupCallEvents(session);
    };

    const rejectCall = (session) => {
        session.terminate();
        setIncomingCall(null);
    };

    const endCall = () => {
        if (currentCall) {
            currentCall.terminate();
            setCurrentCall(null);
            setCallDuration(0);
        }
    };

    const formatDuration = (seconds) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    const loadHistory = async () => {
        try {
            const res = await axios.get('/api/plugins/sip/calls/history', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setCallHistory(res.data);
        } catch (err) {}
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <Icons.phone size="4x" />
                        <div>
                            <h1 className="text-3xl font-bold">Simu za Sauti (SIP)</h1>
                            <p className="opacity-90">
                                {registered ? '🟢 Imeunganishwa' : '🔴 Haijaunganishwa'}
                            </p>
                        </div>
                    </div>
                    {currentCall && (
                        <div className="bg-white/20 px-4 py-2 rounded-xl">
                            <p className="text-sm">Muda</p>
                            <p className="text-2xl font-mono font-bold">
                                {formatDuration(callDuration)}
                            </p>
                        </div>
                    )}
                </div>
            </div>

            {/* Active Call */}
            {currentCall && (
                <div className="bg-gradient-to-r from-green-500 to-emerald-600 
                    p-6 rounded-2xl text-white shadow-2xl text-center">
                    <Icons.phone size="4x" className="mx-auto mb-3 animate-pulse" />
                    <p className="text-xl font-bold mb-4">Simu inaendelea...</p>
                    <button
                        onClick={endCall}
                        className="bg-red-500 hover:bg-red-600 text-white 
                            px-8 py-3 rounded-full font-bold 
                            flex items-center gap-2 mx-auto"
                    >
                        <Icons.phone className="rotate-[135deg]" /> Kata Simu
                    </button>
                </div>
            )}

            {/* Make Call */}
            {!currentCall && !incomingCall && (
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                        <Icons.phone /> Piga Simu
                    </h3>
                    <div className="flex gap-3">
                        <input
                            type="text"
                            value={targetUser}
                            onChange={(e) => setTargetUser(e.target.value)}
                            placeholder="Member ID (mfano: TYM-2026-001)"
                            className="flex-1 p-3 border rounded-xl"
                        />
                        <button
                            onClick={makeCall}
                            className="bg-green-600 text-white px-6 py-3 rounded-xl 
                                font-bold flex items-center gap-2 hover:bg-green-700"
                        >
                            <Icons.phone /> Piga
                        </button>
                    </div>
                </div>
            )}

            {/* Call History */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                    <Icons.clock /> Historia ya Simu
                </h3>
                {callHistory.length === 0 ? (
                    <p className="text-center text-gray-400 py-8">Hakuna simu bado</p>
                ) : (
                    <div className="space-y-2">
                        {callHistory.map(call => (
                            <div key={call.id} className="flex items-center 
                                justify-between p-3 bg-gray-50 rounded-xl">
                                <div className="flex items-center gap-3">
                                    <div className={`w-10 h-10 rounded-full flex items-center 
                                        justify-center ${call.status === 'ended' ? 'bg-green-100' : 'bg-yellow-100'}`}>
                                        <Icons.phone className={call.status === 'ended' ? 'text-green-600' : 'text-yellow-600'} />
                                    </div>
                                    <div>
                                        <p className="font-medium">
                                            {call.caller_first_name} → {call.receiver_first_name}
                                        </p>
                                        <p className="text-xs text-gray-500">
                                            {new Date(call.started_at).toLocaleString('sw-TZ')}
                                        </p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold">{call.duration_seconds}s</p>
                                    <p className="text-xs text-gray-500">{call.status}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Hidden audio element */}
            <audio ref={remoteAudioRef} autoPlay />
        </div>
    );
};

export default SIPClient;