import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const ReceiptViewer = () => {
    const { token } = useAuth();
    const [receiptNumber, setReceiptNumber] = useState('');

    const downloadReceipt = async () => {
        if (!receiptNumber) return toast.error('Ingiza namba ya risiti');
        try {
            const res = await axios.get(`/api/receipts/${receiptNumber}`, {
                headers: { Authorization: `Bearer ${token}` },
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `receipt-${receiptNumber}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            toast.success('Inapakuliwa...');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow max-w-md mx-auto">
            <h2 className="text-xl font-bold text-teal-600 mb-4">Pakua Risiti</h2>
            <div className="flex gap-2">
                <input className="flex-1 border p-2 rounded" placeholder="RCT-12345" value={receiptNumber} onChange={(e) => setReceiptNumber(e.target.value)} />
                <button onClick={downloadReceipt} className="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700">Pakua</button>
            </div>
        </div>
    );
};

export default ReceiptViewer;