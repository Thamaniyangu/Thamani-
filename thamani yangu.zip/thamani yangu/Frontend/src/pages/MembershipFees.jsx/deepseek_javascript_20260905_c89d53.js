import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const MembershipFees = () => {
    const { token, user } = useAuth();
    const [fees, setFees] = useState([]);
    const [newFee, setNewFee] = useState({ user_id: '', period: '2025-2026', amount: '' });

    useEffect(() => {
        const fetchFees = async () => {
            const res = await axios.get('/api/membership-fees', { headers: { Authorization: `Bearer ${token}` } });
            setFees(res.data);
        };
        fetchFees();
    }, [token]);

    const addFee = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/api/membership-fees', newFee, { headers: { Authorization: `Bearer ${token}` } });
            toast.success('Ada imeongezwa');
            setNewFee({ user_id: '', period: '2025-2026', amount: '' });
        } catch (err) { toast.error(err.response?.data?.error); }
    };

    const payFee = async (id) => {
        try {
            await axios.put(`/api/membership-fees/${id}/pay`, {}, { headers: { Authorization: `Bearer ${token}` } });
            toast.success('Ada imelipwa!');
        } catch (err) { toast.error('Hitilafu'); }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
            <h2 className="text-2xl font-bold text-teal-600 mb-4">Ada za Uanachama</h2>
            {user.role !== 'mwanachama' && (
                <form onSubmit={addFee} className="bg-gray-100 dark:bg-gray-700 p-4 rounded mb-4 flex gap-4 flex-wrap">
                    <input className="border p-2 rounded" placeholder="User ID" value={newFee.user_id} onChange={(e) => setNewFee({...newFee, user_id: e.target.value})} />
                    <input className="border p-2 rounded" placeholder="Period" value={newFee.period} onChange={(e) => setNewFee({...newFee, period: e.target.value})} />
                    <input className="border p-2 rounded" placeholder="Amount" type="number" value={newFee.amount} onChange={(e) => setNewFee({...newFee, amount: e.target.value})} />
                    <button type="submit" className="bg-teal-600 text-white px-4 py-2 rounded">Weka</button>
                </form>
            )}
            <table className="w-full border"><thead><tr className="bg-gray-200"><th>Mwanachama</th><th>Kipindi</th><th>Kiasi</th><th>Hali</th><th>Kitendo</th></tr></thead>
            <tbody>{fees.map(f => (
                <tr key={f.id} className="border-b"><td>{f.users?.first_name} {f.users?.last_name}</td><td>{f.period}</td><td>TZS {f.amount}</td><td>{f.status}</td>
                    <td>{f.status === 'unpaid' && user.role !== 'mwanachama' && <button onClick={() => payFee(f.id)} className="bg-green-500 text-white px-3 py-1 rounded text-sm">Lipa</button>}</td>
                </tr>
            ))}</tbody></table>
        </div>
    );
};

export default MembershipFees;