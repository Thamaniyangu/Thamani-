import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const IoTDashboard = () => {
    const { user, token } = useAuth();
    const [devices, setDevices] = useState([]);
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [devicesRes, statsRes] = await Promise.all([
                axios.get('/api/iot/devices', {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get('/api/iot/stats', {
                    headers: { Authorization: `Bearer ${token}` }
                })
            ]);

            setDevices(devicesRes.data);
            setStats(statsRes.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const registerDevice = async (type) => {
        const deviceId = `THM-${user.id.slice(0, 8)}-${type}-${Date.now()}`;
        
        try {
            await axios.post('/api/iot/register', {
                deviceId,
                deviceType: type,
                deviceInfo: {
                    name: `${type} ya ${user.first_name}`,
                    platform: navigator.platform
                }
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            toast.success('Kifaa kimewekwa!');
            fetchData();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const deviceTypes = [
        { type: 'sms_forwarder', name: 'SMS Auto-Forward', icon: Icons.message, color: 'bg-blue-500' },
        { type: 'smart_watch', name: 'Smart Watch', icon: Icons.clock, color: 'bg-purple-500' },
        { type: 'pos_terminal', name: 'POS Terminal', icon: Icons.wallet, color: 'bg-green-500' },
        { type: 'smart_meter', name: 'Smart Meter', icon: Icons.lightning, color: 'bg-yellow-500' },
        { type: 'vehicle_tracker', name: 'Vehicle Tracker', icon: Icons.location, color: 'bg-red-500' }
    ];

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-cyan-500 to-blue-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center gap-3">
                    <Icons.lightning size="3x" />
                    <div>
                        <h1 className="text-3xl font-bold">IoT Smart Savings</h1>
                        <p className="opacity-90">
                            Weka akiba kiotomatiki kupitia vifaa vyako
                        </p>
                    </div>
                </div>
            </div>

            {/* Stats */}
            {stats && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-2xl p-6 shadow-lg">
                        <p className="text-sm text-gray-500">Jumla ya Akiba (IoT)</p>
                        <p className="text-3xl font-bold text-cyan-600">
                            TZS {(stats.totalSaved || 0).toLocaleString()}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                            Siku 30 zilizopita
                        </p>
                    </div>
                    <div className="bg-white rounded-2xl p-6 shadow-lg">
                        <p className="text-sm text-gray-500">Vifaa Vinavyotumika</p>
                        <p className="text-3xl font-bold text-blue-600">
                            {devices.filter(d => d.status === 'active').length}
                        </p>
                    </div>
                    <div className="bg-white rounded-2xl p-6 shadow-lg">
                        <p className="text-sm text-gray-500">Miamala ya IoT</p>
                        <p className="text-3xl font-bold text-purple-600">
                            {stats.bySource?.reduce((sum, s) => sum + s.transactions, 0) || 0}
                        </p>
                    </div>
                </div>
            )}

            {/* Register Device */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                    <Icons.plus /> Weka Kifaa Kipya
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    {deviceTypes.map(dt => {
                        const Icon = dt.icon;
                        return (
                            <button
                                key={dt.type}
                                onClick={() => registerDevice(dt.type)}
                                className={`${dt.color} text-white p-4 rounded-xl 
                                    hover:scale-105 transition flex flex-col 
                                    items-center gap-2`}
                            >
                                <Icon size="2x" />
                                <span className="text-xs font-bold text-center">
                                    {dt.name}
                                </span>
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Devices List */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                    <Icons.settings /> Vifaa Vyako ({devices.length})
                </h3>

                {loading ? (
                    <div className="text-center py-8">
                        <Icons.loading size="2x" />
                    </div>
                ) : devices.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                        <Icons.lightning size="5x" className="mx-auto mb-3 opacity-30" />
                        <p>Hakuna vifaa bado</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {devices.map(device => (
                            <div key={device.id} className="border rounded-xl p-4 
                                flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className={`w-12 h-12 rounded-xl flex items-center 
                                        justify-center ${device.status === 'active' ? 'bg-green-100' : 'bg-gray-100'}`}>
                                        <Icons.lightning className={device.status === 'active' ? 'text-green-600' : 'text-gray-400'} size="lg" />
                                    </div>
                                    <div>
                                        <p className="font-bold">
                                            {JSON.parse(device.device_info || '{}').name || device.device_type}
                                        </p>
                                        <p className="text-xs text-gray-500 font-mono">
                                            {device.device_id}
                                        </p>
                                        {device.last_sync_at && (
                                            <p className="text-xs text-gray-400">
                                                Sync ya mwisho: {new Date(device.last_sync_at).toLocaleString('sw-TZ')}
                                            </p>
                                        )}
                                    </div>
                                </div>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                    device.status === 'active' 
                                        ? 'bg-green-100 text-green-700'
                                        : 'bg-gray-100 text-gray-500'
                                }`}>
                                    {device.status}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* How It Works */}
            <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-2xl p-6 border-2 border-cyan-200">
                <h3 className="font-bold mb-4 flex items-center gap-2">
                    <Icons.info className="text-cyan-600" />
                    Jinsi IoT Smart Savings Inavyofanya Kazi
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-xl p-4">
                        <div className="w-10 h-10 bg-blue-500 rounded-full 
                            flex items-center justify-center text-white font-bold mb-2">
                            1
                        </div>
                        <p className="font-bold mb-1">Unganisha Kifaa</p>
                        <p className="text-sm text-gray-500">
                            Chagua aina ya kifaa na uunganishe na mfumo
                        </p>
                    </div>
                    <div className="bg-white rounded-xl p-4">
                        <div className="w-10 h-10 bg-green-500 rounded-full 
                            flex items-center justify-center text-white font-bold mb-2">
                            2
                        </div>
                        <p className="font-bold mb-1">Akiba Kiotomatiki</p>
                        <p className="text-sm text-gray-500">
                            Mfumo unarekodi akiba kutoka kwa vifaa vyako
                        </p>
                    </div>
                    <div className="bg-white rounded-xl p-4">
                        <div className="w-10 h-10 bg-purple-500 rounded-full 
                            flex items-center justify-center text-white font-bold mb-2">
                            3
                        </div>
                        <p className="font-bold mb-1">Fuatilia</p>
                        <p className="text-sm text-gray-500">
                            Ona akiba inaongezeka kwenye dashboard yako
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default IoTDashboard;