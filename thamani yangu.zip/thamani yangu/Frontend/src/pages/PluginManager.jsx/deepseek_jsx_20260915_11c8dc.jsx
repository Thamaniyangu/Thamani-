import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const PluginManager = () => {
    const { token } = useAuth();
    const [plugins, setPlugins] = useState([]);
    const [flags, setFlags] = useState([]);
    const [loading, setLoading] = useState(true);
    const [processing, setProcessing] = useState(null);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [p, f] = await Promise.all([
                axios.get('/api/plugins', {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get('/api/plugins/flags', {
                    headers: { Authorization: `Bearer ${token}` }
                })
            ]);
            setPlugins(p.data);
            setFlags(f.data);
        } catch (err) {
            toast.error('Imeshindwa kupata data');
        } finally {
            setLoading(false);
        }
    };

    const togglePlugin = async (name, enabled) => {
        setProcessing(name);
        try {
            const action = enabled ? 'disable' : 'enable';
            await axios.post(`/api/plugins/${name}/${action}`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success(`Plugin ime${enabled ? 'zimwa' : 'washwa'}!`);
            loadData();
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setProcessing(null);
        }
    };

    const toggleFlag = async (key) => {
        try {
            await axios.post(`/api/plugins/flags/${key}/toggle`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Flag imebadilishwa');
            loadData();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    if (loading) return <div className="p-6 text-center">Inapakia...</div>;

    const pluginInfo = {
        'sip-voice': {
            name: 'SIP Voice Calls',
            description: 'Simu za sauti kwa kikundi',
            icon: Icons.phone,
            color: 'from-blue-500 to-indigo-600'
        },
        'marketing-automation': {
            name: 'Marketing Automation',
            description: 'Campaigns za kiotomatiki',
            icon: Icons.magic,
            color: 'from-pink-500 to-purple-600'
        },
        'advanced-analytics': {
            name: 'Advanced Analytics',
            description: 'Uchambuzi wa kina',
            icon: Icons.chart,
            color: 'from-indigo-500 to-cyan-600'
        }
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center gap-3">
                    <Icons.settings size="3x" />
                    <div>
                        <h1 className="text-3xl font-bold">Plugin Manager</h1>
                        <p className="opacity-90">
                            Washa au zima features za mfumo
                        </p>
                        <p className="text-sm mt-1 flex items-center gap-1">
                            <Icons.crown /> Mwenyekiti pekee
                        </p>
                    </div>
                </div>
            </div>

            {/* Plugins */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {plugins.map(plugin => {
                    const info = pluginInfo[plugin.name] || {
                        name: plugin.name,
                        description: plugin.description,
                        icon: Icons.puzzle,
                        color: 'from-gray-500 to-gray-700'
                    };
                    const Icon = info.icon;

                    return (
                        <div key={plugin.name} className={`bg-gradient-to-br ${info.color} 
                            rounded-2xl p-6 text-white shadow-xl`}>
                            <div className="flex items-start justify-between mb-4">
                                <Icon size="2x" />
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                    plugin.enabled 
                                        ? 'bg-green-400 text-green-900' 
                                        : 'bg-gray-400 text-gray-900'
                                }`}>
                                    {plugin.enabled ? '🟢 Active' : '⚪ Inactive'}
                                </span>
                            </div>

                            <h3 className="font-bold text-lg mb-1">{info.name}</h3>
                            <p className="text-sm opacity-90 mb-4">{info.description}</p>

                            <div className="text-xs opacity-75 mb-4">
                                <p>Version: {plugin.version}</p>
                                <p>Author: {plugin.author}</p>
                            </div>

                            <button
                                onClick={() => togglePlugin(plugin.name, plugin.enabled)}
                                disabled={processing === plugin.name}
                                className={`w-full py-2 rounded-lg font-bold transition ${
                                    plugin.enabled
                                        ? 'bg-red-500 hover:bg-red-600'
                                        : 'bg-white text-gray-800 hover:bg-gray-100'
                                } ${processing === plugin.name ? 'opacity-50' : ''}`}
                            >
                                {processing === plugin.name ? (
                                    <Icons.loading className="mx-auto" />
                                ) : plugin.enabled ? (
                                    <><Icons.times className="inline mr-1" /> Zima</>
                                ) : (
                                    <><Icons.check className="inline mr-1" /> Washa</>
                                )}
                            </button>
                        </div>
                    );
                })}
            </div>

            {/* Feature Flags */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                    <Icons.lightning className="text-yellow-500" />
                    Feature Flags
                </h3>
                <p className="text-sm text-gray-500 mb-4">
                    Washa/zima vipengele vidogo bila ku-restart server
                </p>

                {flags.length === 0 ? (
                    <p className="text-center text-gray-400 py-6">
                        Hakuna feature flags
                    </p>
                ) : (
                    <div className="space-y-2">
                        {flags.map(flag => (
                            <div key={flag.flag_key} className="flex items-center 
                                justify-between p-3 bg-gray-50 rounded-xl">
                                <div>
                                    <p className="font-medium font-mono text-sm">
                                        {flag.flag_key}
                                    </p>
                                    {flag.description && (
                                        <p className="text-xs text-gray-500">
                                            {flag.description}
                                        </p>
                                    )}
                                </div>
                                <button
                                    onClick={() => toggleFlag(flag.flag_key)}
                                    className={`w-12 h-6 rounded-full transition relative ${
                                        flag.enabled ? 'bg-green-500' : 'bg-gray-300'
                                    }`}
                                >
                                    <span className={`absolute top-0.5 w-5 h-5 bg-white 
                                        rounded-full shadow transition-all ${
                                        flag.enabled ? 'left-6' : 'left-0.5'
                                    }`}></span>
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Info */}
            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-6">
                <h3 className="font-bold mb-3 flex items-center gap-2 text-yellow-800">
                    <Icons.info /> Kumbuka
                </h3>
                <ul className="text-sm space-y-1 text-yellow-800">
                    <li>• Plugin zote zinaonekana kwa <strong>Mwenyekiti PEKEE</strong></li>
                    <li>• Ukizima plugin, wote wanaikosa (including wewe)</li>
                    <li>• Feature flags zinaweza kuwashwa/zimwa bila restart</li>
                    <li>• Mabadiliko yote yanarekodiwa kwenye audit logs</li>
                </ul>
            </div>
        </div>
    );
};

export default PluginManager;