import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const ApplicationsList = () => {
    const { token, user } = useAuth();
    const [applications, setApplications] = useState([]);
    const [filter, setFilter] = useState('pending');
    const [loading, setLoading] = useState(true);
    const [selectedApp, setSelectedApp] = useState(null);

    useEffect(() => {
        fetchApplications();
    }, [filter]);

    const fetchApplications = async () => {
        setLoading(true);
        try {
            const res = await axios.get(`/api/applications?status=${filter}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setApplications(res.data);
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    const handleReview = async (id, action) => {
        if (!window.confirm(`Una uhakika wa ${action === 'approve' ? 'kukubali' : 'kukataa'}?`)) return;

        try {
            await axios.put(`/api/applications/${id}/review`, {
                action,
                notes: action === 'reject' ? 'Haikidhi vigezo vyetu.' : ''
            }, { headers: { Authorization: `Bearer ${token}` } });

            toast.success(`Imefanikiwa!`);
            fetchApplications();
            setSelectedApp(null);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const getStatusBadge = (status) => {
        const styles = {
            pending: 'bg-yellow-100 text-yellow-700',
            approved: 'bg-green-100 text-green-700',
            rejected: 'bg-red-100 text-red-700'
        };
        return (
            <span className={`text-xs px-3 py-1 rounded-full font-bold ${styles[status] || 'bg-gray-100'}`}>
                {status}
            </span>
        );
    };

    if (!['mwenyekiti', 'katibu'].includes(user?.role)) {
        return (
            <div className="text-center py-12 text-gray-500">
                <Icons.lock size="3x" className="mx-auto mb-4 opacity-30" />
                <p>Mwenyekiti na Katibu pekee wanaweza kufikia</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-secondary)] 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <Icons.user size="4x" />
                        <div>
                            <h1 className="text-3xl font-bold">Maombi ya Uanachama</h1>
                            <p className="opacity-90">
                                {applications.length} maombi ya {filter}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-2xl shadow-lg p-4">
                <div className="flex gap-2 flex-wrap">
                    {['pending', 'approved', 'rejected'].map(f => (
                        <button
                            key={f}
                            onClick={() => setFilter(f)}
                            className={`px-4 py-2 rounded-xl font-bold capitalize transition ${
                                filter === f
                                    ? 'bg-[var(--color-primary)] text-white'
                                    : 'bg-gray-100 hover:bg-gray-200'
                            }`}
                        >
                            {f === 'pending' ? 'Inasubiri' :
                             f === 'approved' ? 'Zilizokubaliwa' : 'Zilizokataliwa'}
                        </button>
                    ))}
                </div>
            </div>

            {/* Applications */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                {loading ? (
                    <div className="text-center py-12">
                        <Icons.loading size="3x" className="text-[var(--color-primary)]" />
                    </div>
                ) : applications.length === 0 ? (
                    <div className="text-center py-12 text-gray-400">
                        <Icons.file size="5x" className="mx-auto mb-4 opacity-30" />
                        <p className="text-lg">Hakuna maombi</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {applications.map(app => (
                            <div key={app.id} className="border rounded-2xl p-5 
                                hover:shadow-lg transition">
                                <div className="flex items-start justify-between flex-wrap gap-4">
                                    <div className="flex items-start gap-4">
                                        <div className="w-14 h-14 rounded-full bg-[var(--color-primary)]/10 
                                            flex items-center justify-center">
                                            <Icons.user size="2x" className="text-[var(--color-primary)]" />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-bold">
                                                {app.first_name} {app.middle_name} {app.last_name}
                                            </h3>
                                            <div className="flex flex-wrap gap-3 mt-2 text-sm text-gray-600">
                                                <span>
                                                    <Icons.message className="inline mr-1" />
                                                    {app.email}
                                                </span>
                                                <span>
                                                    <Icons.phone className="inline mr-1" />
                                                    {app.phone}
                                                </span>
                                                {app.whatsapp_number && (
                                                    <span>
                                                        <Icons.whatsapp className="inline mr-1 text-green-600" />
                                                        {app.whatsapp_number}
                                                    </span>
                                                )}
                                            </div>
                                            <p className="text-xs text-gray-400 mt-2">
                                                <Icons.clock className="inline mr-1" />
                                                {new Date(app.created_at).toLocaleString('sw-TZ')}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 flex-wrap">
                                        {getStatusBadge(app.status)}
                                        {app.status === 'pending' && (
                                            <>
                                                <button
                                                    onClick={() => handleReview(app.id, 'approve')}
                                                    className="bg-green-500 text-white px-4 py-2 
                                                        rounded-xl font-bold hover:bg-green-600 
                                                        flex items-center gap-2"
                                                >
                                                    <Icons.check /> Kubali
                                                </button>
                                                <button
                                                    onClick={() => handleReview(app.id, 'reject')}
                                                    className="bg-red-500 text-white px-4 py-2 
                                                        rounded-xl font-bold hover:bg-red-600 
                                                        flex items-center gap-2"
                                                >
                                                    <Icons.times /> Kataa
                                                </button>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default ApplicationsList;