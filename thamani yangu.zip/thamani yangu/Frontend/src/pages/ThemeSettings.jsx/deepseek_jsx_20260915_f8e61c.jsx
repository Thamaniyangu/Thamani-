import React, { useState, useEffect } from 'react';
import { useTheme, THEME_PRESETS } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { FaPalette, FaCheck, FaUndo } from 'react-icons/fa';

const ThemeSettings = () => {
    const { user } = useAuth();
    const {
        themes,
        activeArea,
        setActiveArea,
        setThemeForArea,
        getThemeForArea,
        applyPreset,
        resetTheme
    } = useTheme();

    const [areas, setAreas] = useState([
        { id: 'global', name: 'Global', icon: '🌍' },
        { id: 'dashboard', name: 'Dashboard', icon: '📊' },
        { id: 'chat', name: 'Mazungumzo', icon: '💬' },
        { id: 'contributions', name: 'Michango', icon: '💰' },
        { id: 'membership', name: 'Ada', icon: '📋' },
        { id: 'documents', name: 'Nyaraka', icon: '📄' },
        { id: 'ai-buddy', name: 'AI Buddy', icon: '🤖' },
        { id: 'video', name: 'Mikutano', icon: '🎥' }
    ]);

    const [editingArea, setEditingArea] = useState('global');
    const [currentTheme, setCurrentTheme] = useState(getThemeForArea('global'));

    useEffect(() => {
        setCurrentTheme(getThemeForArea(editingArea));
    }, [editingArea, themes]);

    const handleColorChange = (key, value) => {
        setCurrentTheme(prev => ({ ...prev, [key]: value }));
    };

    const handleSave = async () => {
        await setThemeForArea(editingArea, currentTheme);
        toast.success(`Theme ya ${editingArea} imehifadhiwa!`);
    };

    const handleReset = async () => {
        if (!window.confirm('Rejesha theme ya eneo hili?')) return;
        await resetTheme(editingArea);
        setCurrentTheme(getThemeForArea('global'));
        toast.success('Imerejeshwa');
    };

    const handlePreset = async (presetKey) => {
        await applyPreset(editingArea, presetKey);
        setCurrentTheme(THEME_PRESETS[presetKey].colors);
        toast.success(`Preset ${THEME_PRESETS[presetKey].name} imetumika`);
    };

    const colorFields = [
        { key: 'primary', label: 'Rangi Kuu' },
        { key: 'secondary', label: 'Rangi ya Pili' },
        { key: 'accent', label: 'Rangi ya Mapambo' },
        { key: 'background', label: 'Mandharinyuma' },
        { key: 'surface', label: 'Uso wa Kadi' },
        { key: 'text', label: 'Maandishi' },
        { key: 'textMuted', label: 'Maandishi Hafifu' },
        { key: 'success', label: 'Mafanikio' },
        { key: 'warning', label: 'Tahadhari' },
        { key: 'error', label: 'Hitilafu' }
    ];

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-secondary)] p-6 rounded-xl text-white">
                <div className="flex items-center gap-3">
                    <FaPalette className="text-4xl" />
                    <div>
                        <h1 className="text-3xl font-bold">Mipangilio ya Rangi</h1>
                        <p className="opacity-90">
                            Badilisha rangi za kila eneo la mfumo kulingana na mapendeleo yako
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Areas Sidebar */}
                <div className="bg-white rounded-xl shadow p-4">
                    <h3 className="font-bold mb-3 text-gray-700">Eneo</h3>
                    <div className="space-y-1">
                        {areas.map(area => (
                            <button
                                key={area.id}
                                onClick={() => setEditingArea(area.id)}
                                className={`w-full text-left p-2 rounded transition ${
                                    editingArea === area.id
                                        ? 'bg-[var(--color-primary)] text-white'
                                        : 'hover:bg-gray-100'
                                }`}
                            >
                                <span className="mr-2">{area.icon}</span>
                                {area.name}
                                {themes[area.id] && (
                                    <FaCheck className="inline ml-2 text-xs" />
                                )}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Color Editor */}
                <div className="lg:col-span-3 space-y-6">
                    {/* Presets */}
                    <div className="bg-white rounded-xl shadow p-4">
                        <h3 className="font-bold mb-3">Presets</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {Object.entries(THEME_PRESETS).map(([key, preset]) => (
                                <button
                                    key={key}
                                    onClick={() => handlePreset(key)}
                                    className="p-3 rounded-lg border-2 hover:border-[var(--color-primary)] transition text-left"
                                >
                                    <div className="flex gap-1 mb-2">
                                        <div className="w-6 h-6 rounded" style={{ backgroundColor: preset.colors.primary }} />
                                        <div className="w-6 h-6 rounded" style={{ backgroundColor: preset.colors.secondary }} />
                                        <div className="w-6 h-6 rounded" style={{ backgroundColor: preset.colors.accent }} />
                                    </div>
                                    <p className="text-sm font-medium">{preset.name}</p>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Color Pickers */}
                    <div className="bg-white rounded-xl shadow p-4">
                        <h3 className="font-bold mb-3">Rangi za {areas.find(a => a.id === editingArea)?.name}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {colorFields.map(field => (
                                <div key={field.key} className="flex items-center gap-3">
                                    <input
                                        type="color"
                                        value={currentTheme[field.key] || '#000000'}
                                        onChange={(e) => handleColorChange(field.key, e.target.value)}
                                        className="w-12 h-12 rounded cursor-pointer border"
                                    />
                                    <div className="flex-1">
                                        <label className="text-sm font-medium block">
                                            {field.label}
                                        </label>
                                        <input
                                            type="text"
                                            value={currentTheme[field.key] || ''}
                                            onChange={(e) => handleColorChange(field.key, e.target.value)}
                                            className="w-full text-xs p-1 border rounded font-mono"
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Preview */}
                    <div className="bg-white rounded-xl shadow p-4">
                        <h3 className="font-bold mb-3">Preview</h3>
                        <div
                            className="rounded-xl p-6"
                            style={{
                                backgroundColor: currentTheme.background || '#fff',
                                color: currentTheme.text || '#000'
                            }}
                        >
                            <div
                                className="p-4 rounded-lg mb-3"
                                style={{ backgroundColor: currentTheme.surface || '#fff' }}
                            >
                                <h4 className="font-bold mb-2">Kadi ya Mfano</h4>
                                <p style={{ color: currentTheme.textMuted }}>Maandishi hafifu</p>
                                <div className="flex gap-2 mt-3">
                                    <button
                                        className="px-4 py-2 rounded text-white"
                                        style={{ backgroundColor: currentTheme.primary }}
                                    >
                                        Kitufe Kuu
                                    </button>
                                    <button
                                        className="px-4 py-2 rounded text-white"
                                        style={{ backgroundColor: currentTheme.secondary }}
                                    >
                                        Kitufe cha Pili
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3">
                        <button
                            onClick={handleSave}
                            className="flex-1 py-3 rounded-xl text-white font-bold flex items-center justify-center gap-2"
                            style={{ backgroundColor: currentTheme.primary }}
                        >
                            <FaCheck /> Hifadhi Rangi
                        </button>
                        <button
                            onClick={handleReset}
                            className="px-6 py-3 rounded-xl bg-gray-200 hover:bg-gray-300 flex items-center gap-2"
                        >
                            <FaUndo /> Rejesha
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ThemeSettings;