import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const AITrainingDashboard = () => {
    const { user, token } = useAuth();
    const [datasets, setDatasets] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [models, setModels] = useState([]);
    const [activeTab, setActiveTab] = useState('datasets');

    useEffect(() => {
        if (user?.role === 'mwenyekiti') loadAll();
    }, [user]);

    const loadAll = async () => {
        const headers = { Authorization: `Bearer ${token}` };
        const [d, j, m] = await Promise.all([
            axios.get('/api/ai-training/datasets', { headers }),
            axios.get('/api/ai-training/jobs', { headers }),
            axios.get('/api/ai-training/models', { headers })
        ]);
        setDatasets(d.data);
        setJobs(j.data);
        setModels(m.data);
    };

    const collectData = async () => {
        try {
            const res = await axios.post('/api/ai-training/datasets/collect', {
                name: `dataset-${Date.now()}`,
                daysBack: 90
            }, { headers: { Authorization: `Bearer ${token}` } });

            toast.success(`Dataset imeundwa: ${res.data.stats.total} samples`);
            loadAll();
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    const startTraining = async (datasetId) => {
        try {
            const res = await axios.post('/api/ai-training/train', {
                datasetId,
                epochs: 3
            }, { headers: { Authorization: `Bearer ${token}` } });

            toast.success('Mafunzo yameanza!');
            loadAll();
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    const deployModel = async (modelId) => {
        if (!window.confirm('Deploy model hii?')) return;
        try {
            await axios.post(`/api/ai-training/models/${modelId}/deploy`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Model imepelekwa!');
            loadAll();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    if (user?.role !== 'mwenyekiti') {
        return <div className="p-6 text-center">Ni Mwenyekiti pekee</div>;
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <Icons.brain size="4x" />
                        <div>
                            <h1 className="text-3xl font-bold">AI Training</h1>
                            <p className="opacity-90">
                                Fundisha model yetu ya Kiswahili
                            </p>
                        </div>
                    </div>
                    <button
                        onClick={collectData}
                        className="bg-white text-purple-600 px-6 py-3 rounded-xl 
                            font-bold hover:bg-gray-100 flex items-center gap-2"
                    >
                        <Icons.plus /> Collect Data
                    </button>
                </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <StatCard label="Datasets" value={datasets.length} icon={Icons.file} color="blue" />
                <StatCard label="Training Jobs" value={jobs.length} icon={Icons.settings} color="purple" />
                <StatCard label="Models" value={models.length} icon={Icons.brain} color="pink" />
                <StatCard 
                    label="Deployed" 
                    value={models.filter(m => m.deployed).length} 
                    icon={Icons.check}
                    color="green"
                />
            </div>

            {/* Tabs */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="flex border-b">
                    {[
                        { id: 'datasets', label: 'Datasets', icon: Icons.file },
                        { id: 'jobs', label: 'Training Jobs', icon: Icons.settings },
                        { id: 'models', label: 'Models', icon: Icons.brain }
                    ].map(tab => {
                        const Icon = tab.icon;
                        return (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`flex-1 py-4 font-bold flex items-center 
                                    justify-center gap-2 transition ${
                                    activeTab === tab.id
                                        ? 'border-b-4 border-purple-600 text-purple-600'
                                        : 'text-gray-500 hover:bg-gray-50'
                                }`}
                            >
                                <Icon /> {tab.label}
                            </button>
                        );
                    })}
                </div>

                <div className="p-6">
                    {activeTab === 'datasets' && (
                        <DatasetsTab datasets={datasets} onTrain={startTraining} />
                    )}
                    {activeTab === 'jobs' && <JobsTab jobs={jobs} />}
                    {activeTab === 'models' && (
                        <ModelsTab models={models} onDeploy={deployModel} token={token} />
                    )}
                </div>
            </div>
        </div>
    );
};

const StatCard = ({ label, value, icon: Icon, color }) => (
    <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className={`w-12 h-12 rounded-xl bg-${color}-100 flex items-center 
            justify-center mb-3`}>
            <Icon className={`text-${color}-600`} size="lg" />
        </div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="text-3xl font-bold">{value}</p>
    </div>
);

const DatasetsTab = ({ datasets, onTrain }) => (
    <div className="space-y-3">
        {datasets.map(d => (
            <div key={d.id} className="border rounded-xl p-4 flex items-center 
                justify-between">
                <div>
                    <p className="font-bold">{d.name}</p>
                    <p className="text-sm text-gray-500">
                        {d.total_samples} samples • Created {new Date(d.created_at).toLocaleDateString()}
                    </p>
                </div>
                <button
                    onClick={() => onTrain(d.id)}
                    className="bg-purple-600 text-white px-4 py-2 rounded-lg 
                        hover:bg-purple-700 font-bold"
                >
                    <Icons.play className="inline mr-1" /> Train
                </button>
            </div>
        ))}
    </div>
);

const JobsTab = ({ jobs }) => (
    <div className="space-y-3">
        {jobs.map(j => (
            <div key={j.id} className="border rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                    <p className="font-bold">{j.model_name}</p>
                    <StatusBadge status={j.status} />
                </div>
                {j.status === 'training' && (
                    <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                            className="bg-purple-600 h-2 rounded-full transition-all"
                            style={{ width: `${j.progress}%` }}
                        ></div>
                    </div>
                )}
                {j.error_message && (
                    <p className="text-red-500 text-sm mt-2">{j.error_message}</p>
                )}
            </div>
        ))}
    </div>
);

const ModelsTab = ({ models, onDeploy, token }) => (
    <div className="space-y-3">
        {models.map(m => (
            <div key={m.id} className="border rounded-xl p-4 flex items-center 
                justify-between">
                <div>
                    <p className="font-bold flex items-center gap-2">
                        {m.version}
                        {m.deployed && (
                            <span className="bg-green-100 text-green-700 px-2 py-1 
                                rounded-full text-xs">
                                🟢 Live
                            </span>
                        )}
                    </p>
                    <p className="text-sm text-gray-500">
                        {m.size_mb} MB
                    </p>
                </div>
                {!m.deployed && (
                    <button
                        onClick={() => onDeploy(m.id)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg 
                            hover:bg-green-700 font-bold"
                    >
                        Deploy
                    </button>
                )}
            </div>
        ))}
    </div>
);

const StatusBadge = ({ status }) => {
    const styles = {
        pending: 'bg-yellow-100 text-yellow-700',
        training: 'bg-blue-100 text-blue-700',
        completed: 'bg-green-100 text-green-700',
        failed: 'bg-red-100 text-red-700'
    };
    return (
        <span className={`px-3 py-1 rounded-full text-xs font-bold ${styles[status]}`}>
            {status}
        </span>
    );
};

export default AITrainingDashboard;