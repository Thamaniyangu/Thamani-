import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import logo from '../assets/logo_transparent.png';

const CompleteChange = () => {
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token');
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [completed, setCompleted] = useState(false);

    useEffect(() => {
        if (!token) {
            toast.error('Hakuna token');
            navigate('/login');
        }
    }, [token, navigate]);

    const handleComplete = async () => {
        setLoading(true);
        try {
            await axios.post(`/api/profile/complete/${token}`);
            toast.success('Mabadiliko yamekamilika!');
            setCompleted(true);
            setTimeout(() => navigate('/login'), 3000);
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-700 to-yellow-500">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl w-96 text-center">
                <img src={logo} alt="THAMANI YANGU" className="h-16 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-teal-600 mb-4">Kamilisha Mabadiliko</h2>
                {completed ? (
                    <p className="text-green-600">Mabadiliko yamekamilika! Unaweza kuingia tena.</p>
                ) : (
                    <>
                        <p className="text-gray-600 mb-4">
                            Bonyeza kitufe hapa chini kukamilisha mabadiliko ya email au namba ya simu.
                            <br />
                            <span className="text-xs text-gray-400">Token inaisha muda baada ya siku 2.</span>
                        </p>
                        <button
                            onClick={handleComplete}
                            disabled={loading}
                            className="w-full bg-gradient-to-r from-teal-600 to-yellow-500 text-white py-2 rounded hover:opacity-90 disabled:opacity-50"
                        >
                            {loading ? 'Inakamilisha...' : 'Kamilisha Mabadiliko'}
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};

export default CompleteChange;