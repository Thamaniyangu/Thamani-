import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import SupportChatModal from '../components/SupportChatModal';
import logo from '../assets/logo_transparent.png';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [showSupportChat, setShowSupportChat] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await login(username, password);
            toast.success('Karibu tena!');
            navigate('/dashboard');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Login failed');
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-teal-700 via-teal-500 to-yellow-500">
            <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
                <img src={logo} alt="Logo" className="w-96 h-96 object-contain" />
            </div>
            <div className="relative z-10 bg-white/95 backdrop-blur-sm p-8 rounded-2xl shadow-2xl w-96 border border-teal-200">
                <div className="text-center mb-6">
                    <img src={logo} alt="THAMANI YANGU" className="h-16 mx-auto mb-2" />
                    <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-yellow-600">THAMANI YANGU</h2>
                    <p className="text-gray-500 text-sm">Ingia kwenye akaunti yako</p>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">Username / Member ID / Email</label>
                        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="e.g., TYM-2026-001 or email" required />
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500" required />
                    </div>
                    <div className="text-right mb-4"><a href="#" className="text-sm text-teal-600 hover:underline">Umesahau password?</a></div>
                    <button type="submit" className="w-full bg-gradient-to-r from-teal-600 to-yellow-500 text-white py-2 rounded-md hover:opacity-90 transition shadow-lg">Ingia</button>
                </form>
                <div className="mt-6 text-center text-sm text-gray-600">
                    <p>Kwa msaada wowote, <button onClick={() => setShowSupportChat(true)} className="text-teal-600 font-semibold hover:underline focus:outline-none">bonyeza hapa</button></p>
                    <p className="text-xs text-gray-400 mt-1">Mawasiliano: +255700000000 | thamaniyangu@gmail.com</p>
                    <p className="text-xs text-gray-400 mt-2">Barua pepe zote ni NO-REPLY.</p>
                </div>
            </div>
            {showSupportChat && <SupportChatModal onClose={() => setShowSupportChat(false)} />}
        </div>
    );
};

export default Login;