import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Icons } from '../components/Icon';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';

const Settings = () => {
    const { user, token } = useAuth();
    const { getThemeForArea } = useTheme();
    const theme = getThemeForArea('global');

    const [whatsappNumber, setWhatsappNumber] = useState('');
    const [preferences, setPreferences] = useState({
        meeting: true,
        external_meeting: true,
        financial_report: true,
        announcement: true,
        advice: true,
        reminder: true
    });
    const [profilePhoto, setProfilePhoto] = useState(null);
    const [requests, setRequests] = useState([]);
    const [showChangeModal, setShowChangeModal] = useState(false);
    const [changeForm, setChangeForm] = useState({
        request_type: 'both',
        new_email: '',
        new_phone: '',
        reason: ''
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchWhatsApp();
        fetchRequests();
    }, [token]);

    const fetchWhatsApp = async () => {
        try {
            const res = await axios.get('/api/users/whatsapp/preferences', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.data.whatsapp_number) setWhatsappNumber(res.data.whatsapp_number);
            if (res.data.preferences) setPreferences(res.data.preferences);
        } catch (err) {}
    };

    const fetchRequests = async () => {
        try {
            const res = await axios.get('/api/profile/requests', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setRequests(res.data);
        } catch (err) {}
    };

    const saveWhatsApp = async () => {
        setLoading(true);
        try {
            await axios.put('/api/users/whatsapp/preferences', {
                whatsapp_number: whatsappNumber,
                preferences
            }, { headers: { Authorization: `Bearer ${token}` } });
            toast.success('Mipangilio imehifadhiwa!');
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    const handleProfilePhoto = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('photo', file);

        try {
            const res = await axios.post('/api/users/profile-photo', formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'multipart/form-data'
                }
            });
            setProfilePhoto(res.data.url);
            toast.success('Picha imewekwa!');
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const submitChangeRequest = async (e) => {
        e.preventDefault();
        if (changeForm.reason.length < 10) {
            toast.error('Sababu angalau herufi 10');
            return;
        }

        try {
            await axios.post('/api/profile/request', changeForm, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Ombi limetumwa!');
            setShowChangeModal(false);
            setChangeForm({ request_type: 'both', new_email: '', new_phone: '', reason: '' });
            fetchRequests();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const prefLabels = {
        meeting: 'Mikutano ya ndani',
        external_meeting: 'Mikutano ya nje',
        financial_report: 'Ripoti za kifedha',
        announcement: 'Matangazo',
        advice: 'Ushauri',
        reminder: 'Vikumbusho vya mikutano'
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-secondary)] 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center gap-3">
                    <Icons.settings size="3x" />
                    <div>
                        <h1 className="text-3xl font-bold">Mipangilio</h1>
                        <p className="opacity-90">Dhibiti akaunti na mapendeleo yako</p>
                    </div>
                </div>
            </div>

            {/* Profile Photo */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Icons.user /> Picha ya Wasifu
                </h2>
                <div className="flex items-center gap-4">
                    <div className="w-24 h-24 rounded-full overflow-hidden bg-[var(--color-primary)]/10 
                        flex items-center justify-center">
                        {profilePhoto || user?.profile_photo_url ? (
                            <img 
                                src={profilePhoto || user.profile_photo_url} 
                                alt="Profile" 
                                className="w-full h-full object-cover"
                            />
                        ) : (
                            <Icons.user size="3x" className="text-[var(--color-primary)]" />
                        )}
                    </div>
                    <label className="cursor-pointer bg-[var(--color-primary)] text-white 
                        px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2">
                        <Icons.upload /> Badilisha Picha
                        <input
                            type="file"
                            accept="image/*"
                            onChange={handleProfilePhoto}
                            className="hidden"
                        />
                    </label>
                </div>
            </div>

            {/* WhatsApp Settings */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Icons.whatsapp className="text-green-600" /> WhatsApp
                </h2>
                <p className="text-sm text-gray-500 mb-4">
                    Weka namba yako ya WhatsApp na uchague arifa unazotaka kupokea
                </p>

                <div className="space-y-4">
                    <div>
                        <label className="block font-medium mb-2">Namba ya WhatsApp</label>
                        <input
                            type="tel"
                            value={whatsappNumber}
                            onChange={(e) => setWhatsappNumber(e.target.value)}
                            placeholder="255700000000"
                            className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-green-500"
                        />
                    </div>

                    <div>
                        <label className="block font-medium mb-2">
                            <Icons.bell className="inline mr-2" /> Arifa unazotaka
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {Object.entries(prefLabels).map(([key, label]) => (
                                <label key={key} className="flex items-center gap-3 p-3 
                                    bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100">
                                    <input
                                        type="checkbox"
                                        checked={preferences[key] !== false}
                                        onChange={() => setPreferences(prev => ({
                                            ...prev, [key]: !prev[key]
                                        }))}
                                        className="w-5 h-5 text-green-600 rounded"
                                    />
                                    <span className="font-medium">{label}</span>
                                </label>
                            ))}
                        </div>
                    </div>

                    <button
                        onClick={saveWhatsApp}
                        disabled={loading}
                        className="w-full bg-green-600 text-white py-3 rounded-xl 
                            font-bold hover:bg-green-700 disabled:opacity-50 
                            flex items-center justify-center gap-2"
                    >
                        {loading ? <Icons.loading /> : <Icons.save />}
                        Hifadhi Mipangilio
                    </button>
                </div>
            </div>

            {/* Change Request */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Icons.edit /> Omba Mabadiliko
                </h2>
                <p className="text-sm text-gray-500 mb-4">
                    Badilisha email au namba yako ya simu
                </p>

                <button
                    onClick={() => setShowChangeModal(true)}
                    className="bg-[var(--color-primary)] text-white px-6 py-3 
                        rounded-xl font-bold hover:opacity-90 flex items-center gap-2"
                >
                    <Icons.plus /> Omba Mabadiliko
                </button>

                {/* History */}
                {requests.length > 0 && (
                    <div className="mt-6">
                        <h3 className="font-bold mb-3">Historia ya Maombi</h3>
                        <div className="space-y-2">
                            {requests.map(req => (
                                <div key={req.id} className="border rounded-xl p-4">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <p className="font-medium capitalize">
                                                Aina: {req.request_type}
                                            </p>
                                            <p className="text-sm text-gray-500">
                                                Sababu: {req.reason}
                                            </p>
                                        </div>
                                        <span className={`text-xs px-2 py-1 rounded-full ${
                                            req.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                                            req.status === 'approved' ? 'bg-green-100 text-green-700' :
                                            req.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                                            'bg-red-100 text-red-700'
                                        }`}>
                                            {req.status}
                                        </span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {/* Leader Tools */}
            {user?.role === 'mwenyekiti' && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl 
                    shadow-lg p-6 border-2 border-purple-200">
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-purple-700">
                        <Icons.crown /> Zana za Mwenyekiti
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <Link
                            to="/dashboard/ai-profiles"
                            className="flex items-center gap-3 p-4 bg-white rounded-xl 
                                hover:shadow-lg transition border border-purple-100"
                        >
                            <Icons.robot className="text-purple-600" size="2x" />
                            <div>
                                <p className="font-bold">Picha za AI</p>
                                <p className="text-xs text-gray-500">
                                    Weka picha za AI zote 3
                                </p>
                            </div>
                        </Link>
                        <Link
                            to="/dashboard/themes"
                            className="flex items-center gap-3 p-4 bg-white rounded-xl 
                                hover:shadow-lg transition border border-purple-100"
                        >
                            <Icons.palette className="text-purple-600" size="2x" />
                            <div>
                                <p className="font-bold">Rangi za Mfumo</p>
                                <p className="text-xs text-gray-500">
                                    Badilisha rangi za kila eneo
                                </p>
                            </div>
                        </Link>
                        <Link
                            to="/dashboard/whatsapp"
                            className="flex items-center gap-3 p-4 bg-white rounded-xl 
                                hover:shadow-lg transition border border-purple-100"
                        >
                            <Icons.whatsapp className="text-green-600" size="2x" />
                            <div>
                                <p className="font-bold">WhatsApp ya Mfumo</p>
                                <p className="text-xs text-gray-500">
                                    Unganisha WhatsApp
                                </p>
                            </div>
                        </Link>
                        <Link
                            to="/dashboard/backup"
                            className="flex items-center gap-3 p-4 bg-white rounded-xl 
                                hover:shadow-lg transition border border-purple-100"
                        >
                            <Icons.save className="text-blue-600" size="2x" />
                            <div>
                                <p className="font-bold">Backup</p>
                                <p className="text-xs text-gray-500">
                                    Backup ya database
                                </p>
                            </div>
                        </Link>
                    </div>
                </div>
            )}

            {/* Change Request Modal */}
            {showChangeModal && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6">
                        <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                            <Icons.edit /> Omba Mabadiliko
                        </h3>
                        <form onSubmit={submitChangeRequest} className="space-y-4">
                            <div>
                                <label className="block font-medium mb-1">Aina</label>
                                <select
                                    value={changeForm.request_type}
                                    onChange={(e) => setChangeForm({...changeForm, request_type: e.target.value})}
                                    className="w-full p-3 border rounded-xl"
                                >
                                    <option value="email">Barua Pepe</option>
                                    <option value="phone">Namba ya Simu</option>
                                    <option value="both">Zote mbili</option>
                                </select>
                            </div>

                            {(changeForm.request_type === 'email' || changeForm.request_type === 'both') && (
                                <div>
                                    <label className="block font-medium mb-1">Email mpya</label>
                                    <input
                                        type="email"
                                        value={changeForm.new_email}
                                        onChange={(e) => setChangeForm({...changeForm, new_email: e.target.value})}
                                        className="w-full p-3 border rounded-xl"
                                        required
                                    />
                                </div>
                            )}

                            {(changeForm.request_type === 'phone' || changeForm.request_type === 'both') && (
                                <div>
                                    <label className="block font-medium mb-1">Namba mpya</label>
                                    <input
                                        type="tel"
                                        value={changeForm.new_phone}
                                        onChange={(e) => setChangeForm({...changeForm, new_phone: e.target.value})}
                                        className="w-full p-3 border rounded-xl"
                                        required
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block font-medium mb-1">Sababu</label>
                                <textarea
                                    value={changeForm.reason}
                                    onChange={(e) => setChangeForm({...changeForm, reason: e.target.value})}
                                    className="w-full p-3 border rounded-xl"
                                    rows="3"
                                    required
                                    placeholder="Eleza sababu..."
                                />
                            </div>

                            <div className="flex gap-2">
                                <button
                                    type="submit"
                                    className="flex-1 bg-[var(--color-primary)] text-white py-3 rounded-xl font-bold"
                                >
                                    Tuma Ombi
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setShowChangeModal(false)}
                                    className="px-6 bg-gray-200 rounded-xl font-bold"
                                >
                                    Ghairi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Settings;