import { Link } from 'react-router-dom';

// Kwenye mipangilio ya Mwenyekiti:
{user?.role === 'mwenyekiti' && (
    <div className="mb-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200">
        <h3 className="font-bold text-purple-700 mb-2">🎨 Picha za Wasifu wa AI</h3>
        <p className="text-sm text-gray-600 mb-3">
            Weka picha za wasifu kwa AI zote 3. Picha zitakazoonekana kwa watumiaji wote.
        </p>
        <Link
            to="/dashboard/ai-profiles"
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition inline-flex items-center gap-2"
        >
            ⚙️ Simamia Picha za AI
        </Link>
    </div>
)}