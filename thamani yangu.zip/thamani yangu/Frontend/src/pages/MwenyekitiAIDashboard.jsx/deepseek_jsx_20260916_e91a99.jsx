import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { FaRobot, FaChartBar, FaCheckCircle, FaTimesCircle } from 'react-icons/fa';

const MwenyekitiAIDashboard = () => {
    const { token, user } = useAuth();
    const [stats, setStats] = useState(null);
    const [providers, setProviders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user?.role !== 'mwenyekiti') return;
        fetchData();
    }, [user]);

    const fetchData = async () => {
        try {
            const [statsRes, providersRes] = await Promise.all([
                axios.get('/api/ai/usage-stats', { headers: { Authorization: `Bearer ${token}` } }),
                axios.get('/api/ai/providers', { headers: { Authorization: `Bearer ${token}` } })
            ]);
            setStats(statsRes.data);
            setProviders(providersRes.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    if (user?.role !== 'mwenyekiti') {
        return <div className="p-6 text-center text-gray-500">Huna ruhusa ya kuona ukurasa huu</div>;
    }

    if (loading) return <div className="p-6">Inapakia...</div>;

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow space-y-6">
            <div className="flex items-center gap-3">
                <FaRobot className="text-3xl text-teal-600" />
                <div>
                    <h2 className="text-2xl font-bold text-teal-600">AI Usage Dashboard</h2>
                    <p className="text-sm text-gray-500">Mwenyekiti pekee anaweza kuona taarifa hii</p>
                </div>
            </div>

            {/* Total Requests */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-teal-50 dark:bg-teal-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Jumla ya Maombi</p>
                    <p className="text-3xl font-bold text-teal-600">{stats?.totalRequests || 0}</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">AI Zinazotumika</p>
                    <p className="text-3xl font-bold text-purple-600">
                        {Object.keys(stats?.byProvider || {}).length}
                    </p>
                </div>
                <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Watumiaji</p>
                    <p className="text-3xl font-bold text-yellow-600">
                        {Object.keys(stats?.byRole || {}).length} roles
                    </p>
                </div>
            </div>

            {/* Usage by Provider */}
            <div>
                <h3 className="font-bold text-lg mb-3">📊 Matumizi kwa AI Provider</h3>
                <div className="space-y-2">
                    {Object.entries(stats?.byProvider || {})
                        .sort((a, b) => b[1] - a[1])
                        .map(([provider, count]) => (
                            <div key={provider} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                                <span className="font-medium">{provider}</span>
                                <span className="text-sm text-gray-500">{count} maombi</span>
                            </div>
                        ))}
                </div>
            </div>

            {/* Provider Status */}
            <div>
                <h3 className="font-bold text-lg mb-3">🔧 Hali ya AI Providers</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {providers.map((p) => (
                        <div key={p.name} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded">
                            <div>
                                <p className="font-medium">{p.name}</p>
                                <p className="text-xs text-gray-500">
                                    Priority: {p.priority} {p.supportsSwahili && '• 🇹🇿 Kiswahili'}
                                    {p.isLocal && ' • Local'}
                                </p>
                            </div>
                            {p.hasApiKey === 'yes' || p.hasApiKey === 'local' ? (
                                <FaCheckCircle className="text-green-500" />
                            ) : (
                                <FaTimesCircle className="text-gray-300" />
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default MwenyekitiAIDashboard;