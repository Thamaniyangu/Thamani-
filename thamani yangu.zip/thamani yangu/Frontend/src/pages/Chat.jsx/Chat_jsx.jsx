import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import toast from 'react-hot-toast';
import { FaRobot } from 'react-icons/fa';
import AITagSuggestions from '../components/AITagSuggestions';
import ChatMessage from '../components/ChatMessage';

const Chat = () => {
    const { token, user } = useAuth();
    const { socket } = useSocket();
    const [rooms, setRooms] = useState([]);
    const [currentRoom, setCurrentRoom] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [aiTyping, setAiTyping] = useState(false);
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);

    // ... (load rooms, messages, socket listeners) ...

    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !currentRoom) return;

        // Check if AI tag
        const hasAITag = /\@(ai|finance|leadership|buddy)/i.test(newMessage);

        const userMsg = {
            id: Date.now().toString(),
            sender_id: user.id,
            sender_name: `${user.first_name} ${user.last_name}`,
            text: newMessage,
            created_at: new Date().toISOString()
        };

        setMessages(prev => [...prev, userMsg]);
        setNewMessage('');

        try {
            await axios.post(
                `/api/chat/rooms/${currentRoom.id}/messages`,
                { text: userMsg.text, type: 'text' },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            // Show AI typing indicator if AI tag
            if (hasAITag) {
                setAiTyping(true);
                // AI response will come via socket
                setTimeout(() => setAiTyping(false), 15000);
            }
        } catch (err) {
            toast.error('Failed to send message');
        }
    };

    // Handle AI suggestion selection
    const handleAISelect = (tag) => {
        setNewMessage(prev => `${tag}${prev}`);
        inputRef.current?.focus();
    };

    return (
        <div className="flex h-full bg-gray-100 dark:bg-gray-900 rounded-xl overflow-hidden">
            {/* Room List */}
            <div className="w-64 bg-white dark:bg-gray-800 border-r">
                {/* ... rooms list ... */}
            </div>

            {/* Chat Window */}
            <div className="flex-1 flex flex-col bg-white dark:bg-gray-800">
                {/* Header */}
                <div className="p-3 border-b bg-gray-50 dark:bg-gray-700 flex justify-between items-center">
                    <h4 className="font-semibold">{currentRoom?.name || 'Chagua mazungumzo'}</h4>
                    <AITagSuggestions
                        onSelect={handleAISelect}
                        roomType={currentRoom?.type}
                        userRole={user?.role}
                    />
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                    {messages.map((msg) => (
                        <ChatMessage
                            key={msg.id}
                            message={msg}
                            isMine={msg.sender_id === user.id}
                            currentUserRole={user?.role}
                        />
                    ))}
                    {aiTyping && (
                        <div className="flex items-center gap-2 text-teal-600 text-sm">
                            <FaRobot className="animate-pulse" />
                            <span>THAMANI AI anaandika...</span>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <form onSubmit={sendMessage} className="p-3 bg-gray-50 dark:bg-gray-700 border-t flex gap-2">
                    <input
                        ref={inputRef}
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Andika ujumbe... tumia @AI, @Finance, au @Leadership"
                        className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-gray-800 dark:border-gray-600"
                    />
                    <button type="submit" className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700">
                        Tuma
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Chat;