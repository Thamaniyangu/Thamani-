import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useTheme } from '../context/ThemeContext';
import { Icons } from '../components/Icon';
import ChatMessage from '../components/ChatMessage';
import AITagSuggestions from '../components/AITagSuggestions';
import toast from 'react-hot-toast';

const Chat = () => {
    const { user, token } = useAuth();
    const { socket, onlineUsers } = useSocket();
    const { getThemeForArea } = useTheme();
    const theme = getThemeForArea('chat');

    const [rooms, setRooms] = useState([]);
    const [currentRoom, setCurrentRoom] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [aiTyping, setAiTyping] = useState(false);
    const [showEmoji, setShowEmoji] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);

    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);
    const fileInputRef = useRef(null);

    // Load rooms
    useEffect(() => {
        const loadRooms = async () => {
            try {
                const res = await axios.get('/api/chat/rooms', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setRooms(res.data);
                if (res.data.length > 0 && !currentRoom) {
                    setCurrentRoom(res.data[0]);
                }
            } catch (err) {
                toast.error('Imeshindwa kupata mazungumzo');
            }
        };
        loadRooms();
    }, [token]);

    // Load messages
    useEffect(() => {
        if (!currentRoom) return;

        const loadMessages = async () => {
            try {
                const res = await axios.get(`/api/chat/rooms/${currentRoom.id}/messages`, {
                    headers: { Authorization: `Bearer ${token}` },
                    params: { limit: 50 }
                });
                setMessages(res.data);
            } catch (err) {
                toast.error('Imeshindwa kupata ujumbe');
            }
        };
        loadMessages();

        if (socket) socket.emit('join-room', currentRoom.id);
        return () => { if (socket) socket.emit('leave-room', currentRoom.id); };
    }, [currentRoom, token, socket]);

    // Socket listeners
    useEffect(() => {
        if (!socket) return;

        socket.on('new-message', (msg) => {
            if (msg.roomId === currentRoom?.id || msg.room_id === currentRoom?.id) {
                setMessages(prev => [...prev, msg]);
                if (msg.is_ai) setAiTyping(false);
            }
        });

        socket.on('user-typing', ({ userId, isTyping }) => {
            if (userId !== user.id) setIsTyping(isTyping);
        });

        return () => {
            socket.off('new-message');
            socket.off('user-typing');
        };
    }, [socket, currentRoom, user.id]);

    // Auto-scroll
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    // Send message
    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() && !selectedFile) return;
        if (!currentRoom) return;

        const hasAITag = /@(ai|finance|leader|buddy)/i.test(newMessage);

        const tempMsg = {
            id: `temp-${Date.now()}`,
            sender_id: user.id,
            sender_name: `${user.first_name} ${user.last_name}`,
            text: newMessage,
            created_at: new Date().toISOString()
        };

        setMessages(prev => [...prev, tempMsg]);
        const messageText = newMessage;
        setNewMessage('');

        try {
            await axios.post(
                `/api/chat/rooms/${currentRoom.id}/messages`,
                { text: messageText, type: 'text' },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (hasAITag) setAiTyping(true);
        } catch (err) {
            toast.error('Imeshindwa kutuma');
        }
    };

    const handleTyping = (e) => {
        setNewMessage(e.target.value);
        if (socket && currentRoom) {
            socket.emit('typing', { roomId: currentRoom.id, userId: user.id, isTyping: true });
            clearTimeout(window.typingTimeout);
            window.typingTimeout = setTimeout(() => {
                socket.emit('typing', { roomId: currentRoom.id, userId: user.id, isTyping: false });
            }, 2000);
        }
    };

    const emojis = ['😊', '😂', '❤️', '👍', '🎉', '🔥', '💰', '🙏', '🤝', '👏', '🌟', '✨'];

    const filteredRooms = rooms.filter(r => 
        r.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="flex h-[calc(100vh-120px)] bg-white rounded-2xl shadow-2xl overflow-hidden"
            style={{ backgroundColor: theme.surface }}>
            
            {/* Rooms Sidebar */}
            <div className="w-80 border-r flex flex-col" style={{ borderColor: theme.textMuted + '20' }}>
                {/* Search */}
                <div className="p-4 border-b" style={{ borderColor: theme.textMuted + '20' }}>
                    <div className="relative">
                        <Icons.search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Tafuta mazungumzo..."
                            className="w-full pl-10 pr-4 py-2 border rounded-xl focus:ring-2 focus:ring-[var(--color-primary)]"
                        />
                    </div>
                </div>

                {/* Rooms List */}
                <div className="flex-1 overflow-y-auto">
                    {filteredRooms.map(room => {
                        const isActive = currentRoom?.id === room.id;
                        const roomIcon = 
                            room.type === 'community' ? Icons.globe :
                            room.type === 'leaders_only' ? Icons.crown :
                            room.type === 'members_only' ? Icons.users :
                            Icons.lock;

                        return (
                            <div
                                key={room.id}
                                onClick={() => setCurrentRoom(room)}
                                className={`p-4 cursor-pointer border-b transition ${
                                    isActive 
                                        ? 'bg-[var(--color-primary)] text-white border-transparent' 
                                        : 'hover:bg-gray-50'
                                }`}
                                style={{ borderColor: theme.textMuted + '10' }}
                            >
                                <div className="flex items-center gap-3">
                                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                        isActive ? 'bg-white/20' : 'bg-[var(--color-primary)]/10'
                                    }`}>
                                        <roomIcon size="lg" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="font-bold truncate">
                                            {room.name || room.type}
                                        </p>
                                        <p className={`text-xs truncate ${isActive ? 'text-white/70' : 'text-gray-500'}`}>
                                            {room.last_message?.text || 'Hakuna ujumbe'}
                                        </p>
                                    </div>
                                    {room.unread_count > 0 && (
                                        <span className="bg-red-500 text-white text-xs w-6 h-6 rounded-full 
                                            flex items-center justify-center font-bold">
                                            {room.unread_count}
                                        </span>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Chat Window */}
            <div className="flex-1 flex flex-col">
                {currentRoom ? (
                    <>
                        {/* Header */}
                        <div className="p-4 border-b flex items-center justify-between"
                            style={{ borderColor: theme.textMuted + '20' }}>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-[var(--color-primary)] 
                                    flex items-center justify-center text-white">
                                    <Icons.chat />
                                </div>
                                <div>
                                    <h3 className="font-bold" style={{ color: theme.text }}>
                                        {currentRoom.name || currentRoom.type}
                                    </h3>
                                    <p className="text-xs text-gray-500 flex items-center gap-1">
                                        <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                        {onlineUsers.length} mtandaoni
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <AITagSuggestions
                                    onSelect={(tag) => {
                                        setNewMessage(tag);
                                        inputRef.current?.focus();
                                    }}
                                    roomType={currentRoom.type}
                                    userRole={user.role}
                                />
                                <button className="p-2 hover:bg-gray-100 rounded-lg">
                                    <Icons.search />
                                </button>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-3"
                            style={{ backgroundColor: theme.background }}>
                            {messages.map((msg, idx) => (
                                <ChatMessage
                                    key={msg.id || idx}
                                    message={msg}
                                    isMine={msg.sender_id === user.id}
                                    currentUserRole={user.role}
                                />
                            ))}

                            {isTyping && (
                                <div className="flex items-center gap-2 text-gray-500 text-sm">
                                    <Icons.loading />
                                    <span>Mtu anaandika...</span>
                                </div>
                            )}

                            {aiTyping && (
                                <div className="flex items-center gap-2 text-[var(--color-primary)] text-sm">
                                    <Icons.robot className="animate-pulse" />
                                    <span>THAMANI AI anaandika...</span>
                                </div>
                            )}

                            <div ref={messagesEndRef} />
                        </div>

                        {/* Emoji Picker */}
                        {showEmoji && (
                            <div className="p-3 border-t flex flex-wrap gap-2"
                                style={{ borderColor: theme.textMuted + '20' }}>
                                {emojis.map(e => (
                                    <button
                                        key={e}
                                        onClick={() => {
                                            setNewMessage(prev => prev + e);
                                            setShowEmoji(false);
                                            inputRef.current?.focus();
                                        }}
                                        className="text-2xl hover:scale-125 transition"
                                    >
                                        {e}
                                    </button>
                                ))}
                            </div>
                        )}

                        {/* Input */}
                        <form onSubmit={sendMessage} className="p-4 border-t flex items-center gap-2"
                            style={{ borderColor: theme.textMuted + '20' }}>
                            <button
                                type="button"
                                onClick={() => setShowEmoji(!showEmoji)}
                                className="p-3 hover:bg-gray-100 rounded-full"
                            >
                                <Icons.sparkles size="lg" />
                            </button>
                            <input
                                ref={inputRef}
                                type="text"
                                value={newMessage}
                                onChange={handleTyping}
                                placeholder="Andika ujumbe... (@AI, @Finance, @leader)"
                                className="flex-1 p-3 border rounded-xl focus:ring-2 focus:ring-[var(--color-primary)]"
                            />
                            <button
                                type="submit"
                                className="p-3 bg-gradient-to-r from-[var(--color-primary)] 
                                    to-[var(--color-secondary)] text-white rounded-xl 
                                    hover:opacity-90 transition"
                            >
                                <Icons.arrowRight size="lg" />
                            </button>
                        </form>
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-400">
                        <div className="text-center">
                            <Icons.chat size="5x" className="mb-4 opacity-30" />
                            <p>Chagua mazungumzo kuanza</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Chat;