import React, { useState, useEffect, useRef } from 'react';
import Peer from 'peerjs';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useTheme } from '../context/ThemeContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const VideoCallPage = () => {
    const { user, token } = useAuth();
    const { socket } = useSocket();
    const { getThemeForArea } = useTheme();
    const theme = getThemeForArea('video');

    const [peer, setPeer] = useState(null);
    const [localStream, setLocalStream] = useState(null);
    const [remoteStreams, setRemoteStreams] = useState({});
    const [isMuted, setIsMuted] = useState(false);
    const [isVideoOff, setIsVideoOff] = useState(false);
    const [isScreenSharing, setIsScreenSharing] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [participants, setParticipants] = useState([]);
    const [callId, setCallId] = useState(null);
    const [isCallActive, setIsCallActive] = useState(false);
    const [incomingCall, setIncomingCall] = useState(null);
    const [targetUserId, setTargetUserId] = useState('');
    const [callTitle, setCallTitle] = useState('Mkutano wa Video');

    const localVideoRef = useRef();
    const remoteVideoRefs = useRef({});
    const peerConnections = useRef({});

    // Initialize PeerJS
    useEffect(() => {
        if (!user) return;

        const newPeer = new Peer(user.id, {
            host: 'localhost',
            port: 9000,
            path: '/peerjs',
            debug: 1
        });

        newPeer.on('open', (id) => {
            console.log('PeerJS connected:', id);
        });

        newPeer.on('call', (call) => {
            // Incoming call
            if (!localStream) {
                toast.error('Kamera haipo');
                return;
            }

            call.answer(localStream);
            call.on('stream', (remoteStream) => {
                setRemoteStreams(prev => ({ ...prev, [call.peer]: remoteStream }));
                setIsCallActive(true);
            });

            peerConnections.current[call.peer] = call;
        });

        newPeer.on('error', (err) => {
            console.error('PeerJS error:', err);
        });

        setPeer(newPeer);

        return () => newPeer.destroy();
    }, [user]);

    // Socket listeners
    useEffect(() => {
        if (!socket) return;

        const handleIncomingCall = ({ callId, from, fromName, title }) => {
            setIncomingCall({ callId, from, fromName, title });
            toast.custom((t) => (
                <div className="bg-white p-4 rounded-xl shadow-2xl flex items-center gap-4">
                    <div className="w-12 h-12 bg-[var(--color-primary)] rounded-full flex items-center justify-center text-white">
                        <Icons.video size="lg" />
                    </div>
                    <div className="flex-1">
                        <p className="font-bold">{fromName}</p>
                        <p className="text-sm text-gray-500">{title}</p>
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={() => { acceptCall(callId, from); toast.dismiss(t.id); }}
                            className="bg-green-500 text-white p-2 rounded-full"
                        >
                            <Icons.phone />
                        </button>
                        <button
                            onClick={() => { rejectCall(callId, from); toast.dismiss(t.id); }}
                            className="bg-red-500 text-white p-2 rounded-full"
                        >
                            <Icons.times />
                        </button>
                    </div>
                </div>
            ), { duration: 30000 });
        };

        socket.on('incoming-call', handleIncomingCall);
        socket.on('call-ended', () => {
            endCall();
            toast.info('Mkutano umefungwa na mwenzio');
        });

        return () => {
            socket.off('incoming-call');
            socket.off('call-ended');
        };
    }, [socket]);

    // Start local stream
    const startLocalStream = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { width: 1280, height: 720 },
                audio: true
            });
            setLocalStream(stream);
            if (localVideoRef.current) {
                localVideoRef.current.srcObject = stream;
            }
            return stream;
        } catch (err) {
            toast.error('Imeshindwa kupata kamera: ' + err.message);
            throw err;
        }
    };

    // Start call
    const startCall = async () => {
        if (!targetUserId) return toast.error('Ingiza Member ID');

        try {
            const stream = localStream || await startLocalStream();

            // Create call record
            const res = await axios.post('/api/video/calls', {
                type: 'private',
                participants: [targetUserId],
                title: callTitle
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            setCallId(res.data.id);

            // Call user
            const call = peer.call(targetUserId, stream);
            call.on('stream', (remoteStream) => {
                setRemoteStreams(prev => ({ ...prev, [targetUserId]: remoteStream }));
                setIsCallActive(true);
            });

            peerConnections.current[targetUserId] = call;
            setIsCallActive(true);

            // Notify
            if (socket) {
                socket.emit('call-user', {
                    toUserId: targetUserId,
                    callData: { callId: res.data.id, title: callTitle }
                });
            }

            toast.success('Mkutano umeanzishwa');
        } catch (err) {
            toast.error('Hitilafu: ' + err.message);
        }
    };

    const acceptCall = async (incomingCallId, fromUserId) => {
        try {
            const stream = localStream || await startLocalStream();
            setCallId(incomingCallId);
            setIncomingCall(null);
            setIsCallActive(true);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const rejectCall = (incomingCallId, fromUserId) => {
        if (socket) {
            socket.emit('call-rejected', { toUserId: fromUserId, callId: incomingCallId });
        }
        setIncomingCall(null);
    };

    const endCall = async () => {
        // Stop all streams
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
            setLocalStream(null);
        }

        // Close all peer connections
        Object.values(peerConnections.current).forEach(pc => {
            try { pc.close(); } catch (e) {}
        });
        peerConnections.current = {};

        setRemoteStreams({});
        setIsCallActive(false);

        if (callId && token) {
            try {
                await axios.put(`/api/video/calls/${callId}/end`, {}, {
                    headers: { Authorization: `Bearer ${token}` }
                });
            } catch (e) {}
        }

        toast.info('Mkutano umefungwa');
    };

    const toggleMute = () => {
        if (localStream) {
            localStream.getAudioTracks().forEach(t => t.enabled = !t.enabled);
            setIsMuted(!isMuted);
        }
    };

    const toggleVideo = () => {
        if (localStream) {
            localStream.getVideoTracks().forEach(t => t.enabled = !t.enabled);
            setIsVideoOff(!isVideoOff);
        }
    };

    const toggleScreenShare = async () => {
        try {
            if (!isScreenSharing) {
                const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                if (localVideoRef.current) {
                    localVideoRef.current.srcObject = screenStream;
                }
                setIsScreenSharing(true);
            } else {
                if (localStream && localVideoRef.current) {
                    localVideoRef.current.srcObject = localStream;
                }
                setIsScreenSharing(false);
            }
        } catch (err) {
            toast.error('Imeshindwa kushare skrini');
        }
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-[var(--color-primary)] to-[var(--color-secondary)] 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-3">
                        <Icons.video size="3x" />
                        <div>
                            <h1 className="text-3xl font-bold">Mikutano ya Video</h1>
                            <p className="opacity-90">WebRTC + PeerJS (Self-hosted)</p>
                        </div>
                    </div>
                    {isCallActive && (
                        <div className="flex items-center gap-2 bg-red-500/30 px-3 py-1 rounded-full">
                            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                            <span className="text-sm font-bold">LIVE</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Content */}
            {!isCallActive ? (
                <div className="bg-white rounded-2xl shadow-lg p-6" style={{ backgroundColor: theme.surface }}>
                    <h2 className="text-xl font-bold mb-4" style={{ color: theme.text }}>
                        <Icons.phone className="inline mr-2" /> Anzisha Mkutano
                    </h2>

                    <div className="space-y-4 max-w-md">
                        <div>
                            <label className="block text-sm font-medium mb-1">Member ID ya mwenzio</label>
                            <input
                                type="text"
                                value={targetUserId}
                                onChange={(e) => setTargetUserId(e.target.value)}
                                placeholder="TYM-2026-XXX"
                                className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-[var(--color-primary)]"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Kichwa cha mkutano</label>
                            <input
                                type="text"
                                value={callTitle}
                                onChange={(e) => setCallTitle(e.target.value)}
                                className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-[var(--color-primary)]"
                            />
                        </div>
                        <button
                            onClick={startCall}
                            className="w-full bg-gradient-to-r from-[var(--color-primary)] 
                                to-[var(--color-secondary)] text-white py-3 rounded-xl 
                                hover:opacity-90 font-bold flex items-center justify-center gap-2"
                        >
                            <Icons.video /> Anzisha Mkutano
                        </button>
                    </div>
                </div>
            ) : (
                <div className="space-y-4">
                    {/* Video Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Local video */}
                        <div className="relative bg-black rounded-2xl overflow-hidden shadow-2xl aspect-video">
                            <video
                                ref={localVideoRef}
                                autoPlay
                                muted
                                className="w-full h-full object-cover"
                            />
                            <div className="absolute bottom-3 left-3 bg-black/50 text-white 
                                px-3 py-1 rounded-full text-sm flex items-center gap-2">
                                <Icons.user /> Wewe
                            </div>
                            {isMuted && (
                                <div className="absolute top-3 right-3 bg-red-500 text-white 
                                    p-2 rounded-full">
                                    <Icons.micSlash />
                                </div>
                            )}
                        </div>

                        {/* Remote videos */}
                        {Object.entries(remoteStreams).map(([peerId, stream]) => (
                            <div key={peerId} className="relative bg-black rounded-2xl overflow-hidden shadow-2xl aspect-video">
                                <video
                                    ref={el => {
                                        if (el) el.srcObject = stream;
                                        remoteVideoRefs.current[peerId] = el;
                                    }}
                                    autoPlay
                                    className="w-full h-full object-cover"
                                />
                                <div className="absolute bottom-3 left-3 bg-black/50 text-white 
                                    px-3 py-1 rounded-full text-sm">
                                    Mshiriki
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Controls */}
                    <div className="bg-white rounded-2xl shadow-lg p-4 flex flex-wrap items-center justify-center gap-3"
                        style={{ backgroundColor: theme.surface }}>
                        <button
                            onClick={toggleMute}
                            className={`p-4 rounded-full transition ${isMuted ? 'bg-red-500' : 'bg-gray-200'}`}
                        >
                            {isMuted ? <Icons.micSlash size="lg" /> : <Icons.mic size="lg" />}
                        </button>
                        <button
                            onClick={toggleVideo}
                            className={`p-4 rounded-full transition ${isVideoOff ? 'bg-red-500' : 'bg-gray-200'}`}
                        >
                            {isVideoOff ? <Icons.times size="lg" /> : <Icons.camera size="lg" />}
                        </button>
                        <button
                            onClick={toggleScreenShare}
                            className={`p-4 rounded-full transition ${isScreenSharing ? 'bg-green-500 text-white' : 'bg-gray-200'}`}
                        >
                            <Icons.screen size="lg" />
                        </button>
                        <button
                            onClick={endCall}
                            className="p-4 rounded-full bg-red-500 text-white hover:bg-red-600 transition"
                        >
                            <Icons.phone className="rotate-[135deg]" size="lg" />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default VideoCallPage;