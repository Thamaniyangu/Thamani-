import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import toast from 'react-hot-toast';
import { FaWhatsapp, FaCheckCircle, FaTimesCircle, FaSync, FaSignOutAlt, FaPaperPlane } from 'react-icons/fa';

const WhatsAppSettings = () => {
    const { token, user } = useAuth();
    const { socket } = useSocket();
    const [status, setStatus] = useState(null);
    const [loading, setLoading] = useState(true);
    const [testPhone, setTestPhone] = useState('');
    const [testMessage, setTestMessage] = useState('Habari! Hii ni test message kutoka THAMANI YANGU.');
    const [sending, setSending] = useState(false);

    useEffect(() => {
        if (user?.role !== 'mwenyekiti') return;
        fetchStatus();

        // Listen for QR updates
        if (socket) {
            socket.on('whatsapp-qr', ({ qr }) => {
                setStatus(prev => ({ ...prev, qrCode: qr, hasQR: true }));
            });
            socket.on('whatsapp-status', (data) => {
                fetchStatus();
                if (data.status === 'connected') {
                    toast.success('WhatsApp imeunganishwa!');
                }
            });
        }

        return () => {
            if (socket) {
                socket.off('whatsapp-qr');
                socket.off('whatsapp-status');
            }
        };
    }, [user, socket]);

    const fetchStatus = async () => {
        try {
            const res = await axios.get('/api/whatsapp/status', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setStatus(res.data);
        } catch (err) {
            toast.error('Hitilafu kupata status');
        } finally {
            setLoading(false);
        }
    };

    const handleStart = async () => {
        try {
            await axios.post('/api/whatsapp/start', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('WhatsApp inaanzisha...');
            setTimeout(fetchStatus, 2000);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleLogout = async () => {
        if (!window.confirm('Je, una uhakika wa kutoka kwenye WhatsApp?')) return;
        try {
            await axios.post('/api/whatsapp/logout', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('WhatsApp imetolewa');
            fetchStatus();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleRestart = async () => {
        try {
            await axios.post('/api/whatsapp/restart', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('WhatsApp inaanzisha upya...');
            setTimeout(fetchStatus, 3000);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleTestSend = async () => {
        if (!testPhone || !testMessage) return toast.error('Jaza namba na ujumbe');
        setSending(true);
        try {
            await axios.post('/api/whatsapp/test-send', {
                phone: testPhone,
                message: testMessage
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Ujumbe umetumwa!');
        } catch (err) {
            toast.error('Hitilafu kutuma');
        } finally {
            setSending(false);
        }
    };

    if (user?.role !== 'mwenyekiti') {
        return <div className="p-6 text-center text-gray-500">Ni Mwenyekiti pekee</div>;
    }

    if (loading) return <div className="p-6">Inapakia...</div>;

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <FaWhatsapp className="text-4xl text-green-600" />
                    <div>
                        <h2 className="text-2xl font-bold text-teal-600">WhatsApp ya Mfumo</h2>
                        <p className="text-sm text-gray-500">Unganisha WhatsApp yako na mfumo</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {status?.connected ? (
                        <span className="flex items-center gap-2 text-green-600 font-medium">
                            <FaCheckCircle /> Imeunganishwa
                        </span>
                    ) : (
                        <span className="flex items-center gap-2 text-red-600 font-medium">
                            <FaTimesCircle /> Haijaunganishwa
                        </span>
                    )}
                </div>
            </div>

            {/* Status Info */}
            {status?.connected && (
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200">
                    <p className="text-sm">
                        <strong>Namba:</strong> +{status.phoneNumber}
                    </p>
                    <p className="text-sm">
                        <strong>Hali:</strong> {status.status}
                    </p>
                    <p className="text-sm">
                        <strong>Queue:</strong> {status.queueSize} ujumbe
                    </p>
                </div>
            )}

            {/* QR Code Display */}
            {status?.hasQR && !status?.connected && (
                <div className="text-center space-y-4">
                    <div className="bg-white p-4 rounded-lg inline-block border-4 border-green-500">
                        <img 
                            src={status.qrCode} 
                            alt="WhatsApp QR Code" 
                            className="w-64 h-64"
                        />
                    </div>
                    <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                        <p className="font-bold text-yellow-700 mb-2">📱 Jinsi ya Kuskana:</p>
                        <ol className="text-sm text-left space-y-1 max-w-md mx-auto">
                            <li>1. Fungua WhatsApp kwenye simu yako</li>
                            <li>2. Nenda Settings → Linked Devices</li>
                            <li>3. Bonyeza "Link a Device"</li>
                            <li>4. Skana QR code hapo juu</li>
                        </ol>
                    </div>
                </div>
            )}

            {/* Connection Status */}
            {!status?.connected && !status?.hasQR && (
                <div className="text-center py-8">
                    <FaWhatsapp className="text-6xl text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">WhatsApp haijaunganishwa. Bonyeza kitufe hapa chini kuanzisha.</p>
                </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
                {!status?.connected && (
                    <button
                        onClick={handleStart}
                        className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 flex items-center justify-center gap-2"
                    >
                        <FaWhatsapp /> Anzisha WhatsApp
                    </button>
                )}

                {status?.connected && (
                    <>
                        <button
                            onClick={handleRestart}
                            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
                        >
                            <FaSync /> Anzisha Upya
                        </button>
                        <button
                            onClick={handleLogout}
                            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 flex items-center gap-2"
                        >
                            <FaSignOutAlt /> Toka kwenye WhatsApp
                        </button>
                    </>
                )}
            </div>

            {/* Test Send */}
            {status?.connected && (
                <div className="border-t pt-4">
                    <h3 className="font-bold mb-3">🧪 Jaribu Kutuma Ujumbe</h3>
                    <div className="space-y-2">
                        <input
                            type="tel"
                            placeholder="Namba (mfano: 255700000000)"
                            value={testPhone}
                            onChange={(e) => setTestPhone(e.target.value)}
                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 dark:bg-gray-700"
                        />
                        <textarea
                            placeholder="Ujumbe"
                            value={testMessage}
                            onChange={(e) => setTestMessage(e.target.value)}
                            rows="3"
                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-green-500 dark:bg-gray-700"
                        />
                        <button
                            onClick={handleTestSend}
                            disabled={sending}
                            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
                        >
                            <FaPaperPlane /> {sending ? 'Inatuma...' : 'Tuma Ujumbe'}
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WhatsAppSettings;