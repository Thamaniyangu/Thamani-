import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const WhatsAppSettings = () => {
    const { token, user } = useAuth();
    const { socket } = useSocket();
    const [status, setStatus] = useState(null);
    const [loading, setLoading] = useState(true);
    const [testPhone, setTestPhone] = useState('');
    const [testMessage, setTestMessage] = useState('Habari! Hii ni test message kutoka THAMANI YANGU.');
    const [sending, setSending] = useState(false);

    useEffect(() => {
        if (user?.role !== 'mwenyekiti') return;
        fetchStatus();

        if (socket) {
            socket.on('whatsapp-qr', ({ qr }) => {
                setStatus(prev => ({ ...prev, qrCode: qr, hasQR: true }));
            });
            socket.on('whatsapp-status', () => {
                fetchStatus();
            });
            return () => {
                socket.off('whatsapp-qr');
                socket.off('whatsapp-status');
            };
        }
    }, [user, socket]);

    const fetchStatus = async () => {
        try {
            const res = await axios.get('/api/whatsapp/status', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setStatus(res.data);
        } catch (err) {}
        finally { setLoading(false); }
    };

    const handleStart = async () => {
        try {
            await axios.post('/api/whatsapp/start', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('WhatsApp inaanzisha...');
            setTimeout(fetchStatus, 2000);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleLogout = async () => {
        if (!window.confirm('Toka kwenye WhatsApp?')) return;
        try {
            await axios.post('/api/whatsapp/logout', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('WhatsApp imetolewa');
            fetchStatus();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleRestart = async () => {
        try {
            await axios.post('/api/whatsapp/restart', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Inaanzisha upya...');
            setTimeout(fetchStatus, 3000);
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const handleTestSend = async () => {
        if (!testPhone || !testMessage) return toast.error('Jaza taarifa');
        setSending(true);
        try {
            await axios.post('/api/whatsapp/test-send', {
                phone: testPhone, message: testMessage
            }, { headers: { Authorization: `Bearer ${token}` } });
            toast.success('Ujumbe umetumwa!');
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setSending(false);
        }
    };

    if (user?.role !== 'mwenyekiti') {
        return (
            <div className="text-center py-12 text-gray-500">
                <Icons.lock size="3x" className="mx-auto mb-4 opacity-30" />
                <p>Mwenyekiti pekee anaweza kufikia ukurasa huu</p>
            </div>
        );
    }

    if (loading) return <div className="text-center py-12"><Icons.loading size="2x" /></div>;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-600 to-green-700 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <Icons.whatsapp size="4x" />
                        <div>
                            <h1 className="text-3xl font-bold">WhatsApp ya Mfumo</h1>
                            <p className="opacity-90">Self-hosted, BURE, 100% control</p>
                        </div>
                    </div>
                    <div>
                        {status?.connected ? (
                            <span className="bg-white/20 px-4 py-2 rounded-full flex items-center gap-2">
                                <Icons.check /> Imeunganishwa
                            </span>
                        ) : (
                            <span className="bg-red-500/30 px-4 py-2 rounded-full flex items-center gap-2">
                                <Icons.times /> Haijaunganishwa
                            </span>
                        )}
                    </div>
                </div>
            </div>

            {/* Status Info */}
            {status?.connected && (
                <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <p className="text-sm text-gray-500">Namba</p>
                            <p className="font-bold text-lg">+{status.phoneNumber}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Hali</p>
                            <p className="font-bold capitalize">{status.status}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Ujumbe kwenye Queue</p>
                            <p className="font-bold">{status.queueSize}</p>
                        </div>
                    </div>
                </div>
            )}

            {/* QR Code */}
            {status?.hasQR && !status?.connected && (
                <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
                    <h3 className="text-2xl font-bold mb-4">
                        <Icons.qrcode className="inline mr-2" />
                        Skana QR Code
                    </h3>
                    <div className="inline-block p-4 bg-white border-4 border-green-500 rounded-2xl shadow-2xl">
                        <img src={status.qrCode} alt="QR" className="w-72 h-72" />
                    </div>
                    <div className="mt-6 max-w-md mx-auto bg-yellow-50 p-6 rounded-xl 
                        border border-yellow-200 text-left">
                        <p className="font-bold mb-3">📱 Jinsi ya Kuskana:</p>
                        <ol className="space-y-2 text-sm">
                            <li>1. Fungua WhatsApp kwenye simu yako</li>
                            <li>2. Nenda <strong>Settings</strong> → <strong>Linked Devices</strong></li>
                            <li>3. Bonyeza <strong>"Link a Device"</strong></li>
                            <li>4. Skana QR code hapo juu</li>
                        </ol>
                    </div>
                </div>
            )}

            {/* Not Connected */}
            {!status?.connected && !status?.hasQR && (
                <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                    <Icons.whatsapp size="5x" className="mx-auto mb-4 text-gray-300" />
                    <h3 className="text-xl font-bold mb-2">WhatsApp haijaunganishwa</h3>
                    <p className="text-gray-500 mb-6">Bonyeza kitufe hapa chini kuanzisha</p>
                </div>
            )}

            {/* Actions */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="font-bold mb-4">Vitendo</h3>
                <div className="flex flex-wrap gap-3">
                    {!status?.connected && (
                        <button
                            onClick={handleStart}
                            className="bg-green-600 text-white px-6 py-3 rounded-xl 
                                font-bold flex items-center gap-2 hover:bg-green-700"
                        >
                            <Icons.play /> Anzisha WhatsApp
                        </button>
                    )}
                    {status?.connected && (
                        <>
                            <button
                                onClick={handleRestart}
                                className="bg-blue-600 text-white px-6 py-3 rounded-xl 
                                    font-bold flex items-center gap-2 hover:bg-blue-700"
                            >
                                <Icons.undo /> Anzisha Upya
                            </button>
                            <button
                                onClick={handleLogout}
                                className="bg-red-600 text-white px-6 py-3 rounded-xl 
                                    font-bold flex items-center gap-2 hover:bg-red-700"
                            >
                                <Icons.logout /> Toka
                            </button>
                        </>
                    )}
                </div>
            </div>

            {/* Test Send */}
            {status?.connected && (
                <div className="bg-white rounded-2xl shadow-lg p-6">
                    <h3 className="font-bold mb-4">
                        <Icons.magic className="inline mr-2" /> Jaribu Kutuma
                    </h3>
                    <div className="space-y-3">
                        <input
                            type="tel"
                            value={testPhone}
                            onChange={(e) => setTestPhone(e.target.value)}
                            placeholder="255700000000"
                            className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-green-500"
                        />
                        <textarea
                            value={testMessage}
                            onChange={(e) => setTestMessage(e.target.value)}
                            rows="3"
                            className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-green-500"
                        />
                        <button
                            onClick={handleTestSend}
                            disabled={sending}
                            className="w-full bg-green-600 text-white py-3 rounded-xl 
                                font-bold disabled:opacity-50 flex items-center justify-center gap-2"
                        >
                            {sending ? <Icons.loading /> : <Icons.arrowRight />}
                            Tuma Ujumbe
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WhatsAppSettings;