import React from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const IdCardViewer = () => {
    const { token, user } = useAuth();

    const downloadMyCard = async () => {
        try {
            const res = await axios.get('/api/id-card', {
                headers: { Authorization: `Bearer ${token}` },
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `id-card-${user.member_id}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            toast.success('Kadi inapakuliwa...');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow text-center">
            <h2 className="text-2xl font-bold text-teal-600 mb-4">Kitambulisho Changu</h2>
            <div className="bg-gradient-to-r from-yellow-100 to-yellow-300 p-4 rounded-lg shadow-lg inline-block border-4 border-yellow-600">
                <p className="font-bold">THAMANI YANGU M-KOBA</p>
                <p className="text-sm">{user?.member_id}</p>
                <p className="text-sm">{user?.first_name} {user?.last_name}</p>
            </div>
            <div className="mt-4"><button onClick={downloadMyCard} className="bg-yellow-600 text-white px-6 py-2 rounded hover:bg-yellow-700">⬇ Pakua Kadi (PDF)</button></div>
        </div>
    );
};

export default IdCardViewer;