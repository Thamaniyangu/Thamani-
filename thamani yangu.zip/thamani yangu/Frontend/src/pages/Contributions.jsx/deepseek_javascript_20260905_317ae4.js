import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const Contributions = () => {
    const { token } = useAuth();
    const [rows, setRows] = useState([{ userId: '', type: 'hisa', amount: '' }]);

    const addRow = () => setRows([...rows, { userId: '', type: 'hisa', amount: '' }]);
    const handleChange = (idx, field, value) => {
        const newRows = [...rows];
        newRows[idx][field] = value;
        setRows(newRows);
    };

    const submit = async (e) => {
        e.preventDefault();
        const contributions = rows.filter(r => r.userId && r.amount);
        if (!contributions.length) return toast.error('Jaza angalau mstari mmoja');
        try {
            const res = await axios.post('/api/contributions', { contributions }, { headers: { Authorization: `Bearer ${token}` } });
            toast.success(`Michango ${res.data.receipts.length} imehifadhiwa!`);
            setRows([{ userId: '', type: 'hisa', amount: '' }]);
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
            <h2 className="text-2xl font-bold text-teal-600 mb-4">Kurekodi Michango</h2>
            <form onSubmit={submit}>
                <table className="w-full border-collapse">
                    <thead><tr className="bg-gray-200 dark:bg-gray-700"><th className="p-2">Mwanachama ID</th><th>Aina</th><th>Kiasi (TZS)</th></tr></thead>
                    <tbody>
                        {rows.map((row, idx) => (
                            <tr key={idx}>
                                <td><input className="w-full p-1 border rounded" value={row.userId} onChange={(e) => handleChange(idx, 'userId', e.target.value)} /></td>
                                <td><select className="w-full p-1 border rounded" value={row.type} onChange={(e) => handleChange(idx, 'type', e.target.value)}>
                                    <option value="hisa">Hisa</option><option value="jamii">Jamii</option><option value="faini">Faini</option><option value="marejesho">Marejesho</option>
                                </select></td>
                                <td><input type="number" className="w-full p-1 border rounded" value={row.amount} onChange={(e) => handleChange(idx, 'amount', e.target.value)} /></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <button type="button" onClick={addRow} className="mt-2 bg-gray-500 text-white px-4 py-1 rounded">+ Ongeza Mstari</button>
                <button type="submit" className="ml-2 bg-teal-600 text-white px-4 py-1 rounded">Hifadhi</button>
            </form>
        </div>
    );
};

export default Contributions;