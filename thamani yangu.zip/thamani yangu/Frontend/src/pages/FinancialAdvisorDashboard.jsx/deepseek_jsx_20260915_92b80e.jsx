import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Icons } from '../components/Icon';
import AIAvatar from '../components/AIAvatar';
import toast from 'react-hot-toast';

const FinancialAdvisorDashboard = () => {
    const { user, token } = useAuth();
    const { getThemeForArea } = useTheme();
    const theme = getThemeForArea('ai-buddy');

    const [schedules, setSchedules] = useState([]);
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState(null);
    const [loading, setLoading] = useState(false);
    const [todayTraining, setTodayTraining] = useState(null);

    const isLeader = ['mwenyekiti', 'katibu', 'mhazini'].includes(user?.role);

    useEffect(() => {
        fetchSchedules();
        checkTodayTraining();
    }, []);

    const fetchSchedules = async () => {
        try {
            const res = await axios.get('/api/financial-advisor/schedules', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setSchedules(res.data);
        } catch (err) {}
    };

    const checkTodayTraining = () => {
        const today = new Date().toISOString().split('T')[0];
        const todaySched = schedules.find(s => 
            s.scheduled_date === today && s.status === 'approved'
        );
        setTodayTraining(todaySched);
    };

    const generateSchedule = async () => {
        setLoading(true);
        try {
            await axios.post('/api/financial-advisor/generate', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Ratiba imetumwa kwa viongozi!');
            fetchSchedules();
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    const approveSchedule = async (scheduleId) => {
        try {
            await axios.put(`/api/financial-advisor/schedules/${scheduleId}/approve`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Imekubaliwa!');
            fetchSchedules();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const askQuestion = async (e) => {
        e.preventDefault();
        if (!question.trim()) return;

        setLoading(true);
        setAnswer(null);

        try {
            const res = await axios.post('/api/financial-advisor/ask', {
                question
            }, { headers: { Authorization: `Bearer ${token}` } });

            setAnswer(res.data);
            setQuestion('');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="relative overflow-hidden rounded-3xl p-8 shadow-2xl"
                style={{
                    background: `linear-gradient(135deg, #10B981, #0D6B6B)`
                }}>
                <div className="absolute inset-0 opacity-10">
                    <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -mr-32 -mt-32"></div>
                </div>
                <div className="relative z-10 flex items-center gap-6">
                    <AIAvatar aiType="financial" size="xl" />
                    <div className="text-white">
                        <h1 className="text-4xl font-bold mb-2">THAMANI FINANCIAL ADVISOR</h1>
                        <p className="text-lg opacity-90">
                            Mshauri wako wa kifedha - Mafunzo ya kila wiki
                        </p>
                    </div>
                </div>
            </div>

            {/* Today's Training */}
            {todayTraining && (
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-6 shadow-2xl text-white">
                    <div className="flex items-center gap-3 mb-3">
                        <Icons.fire size="2x" className="animate-pulse" />
                        <h2 className="text-2xl font-bold">📚 Mafunzo ya Leo!</h2>
                    </div>
                    <h3 className="text-3xl font-bold mb-2">{todayTraining.topic}</h3>
                    <p className="text-lg mb-4">{todayTraining.description}</p>
                    <p className="text-sm opacity-90">
                        <Icons.clock className="inline mr-1" />
                        Saa {todayTraining.scheduled_time?.slice(0, 5)} • {todayTraining.day_of_week}
                    </p>
                </div>
            )}

            {/* Ask Question */}
            {todayTraining && (
                <div className="bg-white rounded-2xl shadow-lg p-6">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <Icons.message /> Uliza Swali Kuhusu Mafunzo ya Leo
                    </h3>
                    <form onSubmit={askQuestion} className="space-y-3">
                        <textarea
                            value={question}
                            onChange={(e) => setQuestion(e.target.value)}
                            placeholder={`Uliza kuhusu "${todayTraining.topic}"...`}
                            className="w-full p-4 border rounded-xl focus:ring-2 
                                focus:ring-emerald-500 min-h-[100px]"
                        />
                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 
                                text-white py-3 rounded-xl font-bold 
                                hover:opacity-90 disabled:opacity-50 flex 
                                items-center justify-center gap-2"
                        >
                            {loading ? <Icons.loading /> : <Icons.arrowRight />}
                            Tuma Swali
                        </button>
                    </form>

                    {answer && (
                        <div className="mt-4 p-4 bg-emerald-50 rounded-xl border-2 border-emerald-200">
                            <p className="text-sm font-bold text-emerald-700 mb-2">
                                <Icons.robot className="inline mr-1" />
                                {answer.provider}
                            </p>
                            <p className="whitespace-pre-wrap">{answer.answer}</p>
                        </div>
                    )}
                </div>
            )}

            {/* Generate Schedule (Mwenyekiti) */}
            {user?.role === 'mwenyekiti' && (
                <div className="bg-white rounded-2xl shadow-lg p-6">
                    <div className="flex items-center justify-between flex-wrap gap-3">
                        <div>
                            <h3 className="text-xl font-bold">📅 Ratiba ya Mafunzo</h3>
                            <p className="text-sm text-gray-500">
                                Unda ratiba ya mwezi mzima
                            </p>
                        </div>
                        <button
                            onClick={generateSchedule}
                            disabled={loading}
                            className="bg-gradient-to-r from-purple-500 to-pink-500 
                                text-white px-6 py-3 rounded-xl font-bold 
                                hover:opacity-90 disabled:opacity-50 
                                flex items-center gap-2"
                        >
                            {loading ? <Icons.loading /> : <Icons.magic />}
                            Unda Ratiba Mpya
                        </button>
                    </div>
                </div>
            )}

            {/* Schedules List */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Icons.calendar /> Ratiba za Mafunzo ({schedules.length})
                </h3>

                {schedules.length === 0 ? (
                    <div className="text-center py-12 text-gray-400">
                        <Icons.calendar size="5x" className="mx-auto mb-4 opacity-30" />
                        <p>Hakuna ratiba bado</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {schedules.map(s => (
                            <div key={s.id} className="border rounded-xl p-4 
                                flex items-center justify-between flex-wrap gap-3
                                hover:shadow-lg transition">
                                <div className="flex items-start gap-3">
                                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br 
                                        from-emerald-400 to-teal-600 flex items-center 
                                        justify-center text-white font-bold text-lg">
                                        W{s.week_number}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg">{s.topic}</h4>
                                        <p className="text-sm text-gray-500 mb-1">
                                            {s.description}
                                        </p>
                                        <p className="text-xs text-gray-400">
                                            <Icons.calendar className="inline mr-1" />
                                            {new Date(s.scheduled_date).toLocaleDateString('sw-TZ', {
                                                weekday: 'long',
                                                day: 'numeric',
                                                month: 'long'
                                            })}
                                            <Icons.clock className="inline ml-3 mr-1" />
                                            {s.scheduled_time?.slice(0, 5)}
                                        </p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    {s.status === 'approved' ? (
                                        <span className="bg-green-100 text-green-700 px-3 py-1 
                                            rounded-full text-sm font-bold flex items-center gap-1">
                                            <Icons.check /> Imekubaliwa
                                        </span>
                                    ) : (
                                        <span className="bg-yellow-100 text-yellow-700 px-3 py-1 
                                            rounded-full text-sm font-bold flex items-center gap-1">
                                            <Icons.clock /> Inasubiri
                                        </span>
                                    )}

                                    {isLeader && s.status === 'pending' && (
                                        <button
                                            onClick={() => approveSchedule(s.id)}
                                            className="bg-green-500 text-white px-4 py-2 
                                                rounded-lg font-bold flex items-center gap-2
                                                hover:bg-green-600"
                                        >
                                            <Icons.check /> Kubali
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default FinancialAdvisorDashboard;