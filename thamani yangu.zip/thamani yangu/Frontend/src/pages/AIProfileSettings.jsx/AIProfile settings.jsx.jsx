import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAIProfiles } from '../context/AIProfilesContext';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaRobot, FaChartLine, FaCrown, FaUpload, FaTrash, FaCheck } from 'react-icons/fa';
import AIAvatar from '../components/AIAvatar';

const AIProfileSettings = () => {
    const { token, user } = useAuth();
    const { profiles } = useAIProfiles();
    const [uploading, setUploading] = useState(null);

    if (user?.role !== 'mwenyekiti') {
        return <div className="p-6 text-center text-gray-500">Ni Mwenyekiti pekee anayeweza kufikia ukurasa huu</div>;
    }

    const aiList = [
        {
            id: 'ai-buddy',
            type: 'buddy',
            name: 'THAMANI AI BUDDY',
            description: 'Msaidizi wa jumla - jamii, utamaduni, masuala ya jumla',
            icon: <FaRobot className="text-2xl" />,
            color: 'teal'
        },
        {
            id: 'ai-financial',
            type: 'financial',
            name: 'THAMANI FINANCIAL ADVISOR',
            description: 'Mshauri wa kifedha - akiba, mikopo, riba, bajeti',
            icon: <FaChartLine className="text-2xl" />,
            color: 'green'
        },
        {
            id: 'ai-leadership',
            type: 'leadership',
            name: 'THAMANI LEADERSHIP MENTOR',
            description: 'Mshauri wa uongozi - maamuzi, majukumu (viongozi pekee)',
            icon: <FaCrown className="text-2xl" />,
            color: 'yellow'
        }
    ];

    const handleUpload = async (aiId, file) => {
        if (!file) return;

        // Validate size
        if (file.size > 5 * 1024 * 1024) {
            toast.error('Picha ni kubwa sana (max 5MB)');
            return;
        }

        setUploading(aiId);
        try {
            const formData = new FormData();
            formData.append('photo', file);

            const res = await axios.post(
                `/api/ai-profiles/${aiId}/photo`,
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'multipart/form-data'
                    }
                }
            );

            toast.success('Picha imewekwa!');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setUploading(null);
        }
    };

    const handleDelete = async (aiId) => {
        if (!window.confirm('Je, una uhakika wa kufuta picha hii?')) return;

        try {
            await axios.delete(`/api/ai-profiles/${aiId}/photo`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Picha imefutwa');
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
            <div className="mb-6">
                <h2 className="text-2xl font-bold text-teal-600 flex items-center gap-2">
                    🎨 Picha za Wasifu wa AI
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                    Weka picha za wasifu kwa AI zote 3. Picha hizi zitaonekana kwa watumiaji wote
                    badala ya avatar/icon.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {aiList.map((ai) => {
                    const profile = profiles[ai.id];
                    const hasPhoto = !!profile?.photo_url;

                    return (
                        <div key={ai.id} className="border rounded-xl p-4 bg-gray-50 dark:bg-gray-700">
                            {/* Preview */}
                            <div className="flex flex-col items-center mb-4">
                                {hasPhoto ? (
                                    <img
                                        src={profile.photo_url}
                                        alt={ai.name}
                                        className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                                    />
                                ) : (
                                    <div className={`w-24 h-24 rounded-full flex items-center justify-center text-white shadow-lg bg-${ai.color}-600`}>
                                        {ai.icon}
                                    </div>
                                )}
                                <p className="font-bold text-sm mt-3 text-center">{ai.name}</p>
                                <p className="text-xs text-gray-500 text-center mt-1">{ai.description}</p>
                            </div>

                            {/* Actions */}
                            <div className="space-y-2">
                                {/* Upload Button */}
                                <label className={`cursor-pointer w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition ${
                                    uploading === ai.id
                                        ? 'bg-gray-300 cursor-not-allowed'
                                        : 'bg-teal-600 hover:bg-teal-700 text-white'
                                }`}>
                                    <FaUpload />
                                    {uploading === ai.id ? 'Inapakia...' : (hasPhoto ? 'Badilisha Picha' : 'Weka Picha')}
                                    <input
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        disabled={uploading === ai.id}
                                        onChange={(e) => {
                                            if (e.target.files[0]) {
                                                handleUpload(ai.id, e.target.files[0]);
                                            }
                                            e.target.value = '';
                                        }}
                                    />
                                </label>

                                {/* Delete Button */}
                                {hasPhoto && (
                                    <button
                                        onClick={() => handleDelete(ai.id)}
                                        className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white transition"
                                    >
                                        <FaTrash /> Ondoa Picha
                                    </button>
                                )}
                            </div>

                            {/* Status */}
                            <div className="mt-3 text-xs text-center">
                                {hasPhoto ? (
                                    <span className="text-green-600 flex items-center justify-center gap-1">
                                        <FaCheck /> Picha imewekwa
                                    </span>
                                ) : (
                                    <span className="text-gray-400">HaijawEKWA - inatumia icon</span>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Preview Section */}
            <div className="mt-8 p-4 bg-gradient-to-r from-teal-50 to-yellow-50 dark:from-teal-900/20 dark:to-yellow-900/20 rounded-lg border border-teal-200">
                <h3 className="font-bold text-teal-600 mb-3">👁️ Preview: Jinsi itakavyoonekana</h3>
                <div className="flex items-center gap-4 flex-wrap">
                    <div className="text-center">
                        <AIAvatar aiType="buddy" size="lg" />
                        <p className="text-xs mt-2 text-gray-600">AI Buddy</p>
                    </div>
                    <div className="text-center">
                        <AIAvatar aiType="financial" size="lg" />
                        <p className="text-xs mt-2 text-gray-600">Financial</p>
                    </div>
                    <div className="text-center">
                        <AIAvatar aiType="leadership" size="lg" />
                        <p className="text-xs mt-2 text-gray-600">Leadership</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AIProfileSettings;