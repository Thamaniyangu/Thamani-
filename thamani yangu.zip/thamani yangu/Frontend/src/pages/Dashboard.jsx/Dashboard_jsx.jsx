import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import { Icons } from '../components/Icon';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import axios from 'axios';
import CountUp from 'react-countup';

const Dashboard = () => {
    const { user, token } = useAuth();
    const { getThemeForArea } = useTheme();
    const navigate = useNavigate();
    const [stats, setStats] = useState({
        totalContributions: 0,
        totalLoans: 0,
        members: 0,
        points: 0
    });
    const [loading, setLoading] = useState(true);
    const [currentTime, setCurrentTime] = useState(new Date());

    const theme = getThemeForArea('dashboard');

    useEffect(() => {
        // Live clock
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const [contribRes, userRes] = await Promise.all([
                    axios.get('/api/contributions/stats', {
                        headers: { Authorization: `Bearer ${token}` }
                    }).catch(() => ({ data: { totals: { total_amount: 0, total_count: 0 } } })),
                    axios.get('/api/auth/me', {
                        headers: { Authorization: `Bearer ${token}` }
                    }).catch(() => ({ data: {} }))
                ]);

                setStats({
                    totalContributions: contribRes.data.totals?.total_amount || 0,
                    totalLoans: 0,
                    members: userRes.data.total_members || 1,
                    points: userRes.data.points || 0
                });
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, [token]);

    const statCards = [
        {
            label: 'Jumla ya Michango',
            value: stats.totalContributions,
            icon: Icons.money,
            color: 'from-emerald-500 to-teal-600',
            prefix: 'TZS '
        },
        {
            label: 'Mikopo',
            value: stats.totalLoans,
            icon: Icons.chart,
            color: 'from-blue-500 to-indigo-600',
            prefix: 'TZS '
        },
        {
            label: 'Wanachama',
            value: stats.members,
            icon: Icons.users,
            color: 'from-purple-500 to-pink-600',
            prefix: ''
        },
        {
            label: 'Pointi Zako',
            value: stats.points,
            icon: Icons.trophy,
            color: 'from-amber-500 to-orange-600',
            prefix: ''
        }
    ];

    const quickActions = [
        { label: 'Rekodi Mchango', icon: Icons.money, path: '/dashboard/contributions', color: 'bg-teal-500' },
        { label: 'Chat', icon: Icons.chat, path: '/dashboard/chat', color: 'bg-blue-500' },
        { label: 'AI Buddy', icon: Icons.robot, path: '/dashboard/ai-buddy', color: 'bg-purple-500' },
        { label: 'Video', icon: Icons.video, path: '/dashboard/video', color: 'bg-pink-500' },
        { label: 'Risiti', icon: Icons.receipt, path: '/dashboard/receipts', color: 'bg-green-500' },
        { label: 'Msaada', icon: Icons.support, path: '/dashboard/support', color: 'bg-red-500' }
    ];

    return (
        <div className="flex min-h-screen" style={{ backgroundColor: theme.background }}>
            <Sidebar />

            <div className="flex-1 ml-72 p-6 overflow-y-auto">
                {/* ============================================================ */}
                {/* WELCOME BANNER (Premium VVIP) */}
                {/* ============================================================ */}
                <div className="relative overflow-hidden rounded-3xl p-8 mb-6 shadow-2xl"
                    style={{ 
                        background: `linear-gradient(135deg, ${theme.primary}, ${theme.secondary})`
                    }}>
                    {/* Background Pattern */}
                    <div className="absolute inset-0 opacity-10">
                        <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -mr-32 -mt-32"></div>
                        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full -ml-32 -mb-32"></div>
                    </div>

                    <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
                        <div>
                            <p className="text-white/80 text-sm mb-1 flex items-center gap-2">
                                <Icons.sun /> {currentTime.toLocaleDateString('sw-TZ', { 
                                    weekday: 'long', 
                                    day: 'numeric', 
                                    month: 'long', 
                                    year: 'numeric' 
                                })}
                            </p>
                            <h1 className="text-4xl font-bold text-white mb-2">
                                Karibu, {user?.first_name}! 👋
                            </h1>
                            <p className="text-white/90 flex items-center gap-2">
                                {user?.role === 'mwenyekiti' && <Icons.crown />}
                                {user?.role === 'katibu' && <Icons.file />}
                                {user?.role === 'mhazini' && <Icons.wallet />}
                                <span className="capitalize">{user?.role}</span>
                                <span className="text-white/60">•</span>
                                <span className="font-mono text-sm">{user?.member_id}</span>
                            </p>
                        </div>

                        <div className="text-right">
                            <p className="text-white/80 text-sm mb-1 flex items-center gap-2 justify-end">
                                <Icons.clock /> Sasa
                            </p>
                            <p className="text-4xl font-mono font-bold text-white">
                                {currentTime.toLocaleTimeString('sw-TZ', { 
                                    hour: '2-digit', 
                                    minute: '2-digit',
                                    second: '2-digit'
                                })}
                            </p>
                        </div>
                    </div>
                </div>

                {/* ============================================================ */}
                {/* STAT CARDS */}
                {/* ============================================================ */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    {statCards.map((card, idx) => {
                        const IconComponent = card.icon;
                        return (
                            <div
                                key={idx}
                                className="relative overflow-hidden rounded-2xl p-5 shadow-lg 
                                    hover:shadow-2xl transition-all duration-300 
                                    transform hover:-translate-y-1 cursor-pointer group"
                                style={{ backgroundColor: theme.surface }}
                            >
                                <div className="absolute top-0 right-0 w-24 h-24 opacity-5 
                                    bg-gradient-to-br from-gray-900 to-gray-700 rounded-full 
                                    -mr-8 -mt-8 group-hover:scale-150 transition-transform duration-500">
                                </div>

                                <div className="flex items-start justify-between mb-3">
                                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${card.color} 
                                        flex items-center justify-center text-white shadow-lg`}>
                                        <IconComponent size="lg" />
                                    </div>
                                </div>

                                <p className="text-sm mb-1" style={{ color: theme.textMuted }}>
                                    {card.label}
                                </p>
                                <p className="text-2xl font-bold" style={{ color: theme.text }}>
                                    {card.prefix}
                                    <CountUp 
                                        end={card.value} 
                                        duration={2} 
                                        separator="," 
                                        prefix={card.prefix}
                                    />
                                </p>
                            </div>
                        );
                    })}
                </div>

                {/* ============================================================ */}
                {/* QUICK ACTIONS */}
                {/* ============================================================ */}
                <div className="rounded-2xl p-6 mb-6 shadow-lg" style={{ backgroundColor: theme.surface }}>
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2"
                        style={{ color: theme.text }}>
                        <Icons.lightning className="text-yellow-500" /> Vitendo vya Haraka
                    </h2>

                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                        {quickActions.map((action, idx) => {
                            const IconComponent = action.icon;
                            return (
                                <button
                                    key={idx}
                                    onClick={() => navigate(action.path)}
                                    className={`${action.color} text-white p-4 rounded-xl 
                                        hover:scale-105 transition-all duration-300 
                                        shadow-lg hover:shadow-2xl group`}
                                >
                                    <div className="flex flex-col items-center gap-2">
                                        <IconComponent size="2x" className="group-hover:animate-bounce" />
                                        <span className="text-xs font-medium text-center">
                                            {action.label}
                                        </span>
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* ============================================================ */}
                {/* TICKER (Announcements) */}
                {/* ============================================================ */}
                <div className="rounded-2xl p-4 mb-6 shadow-lg overflow-hidden relative"
                    style={{ backgroundColor: theme.surface }}>
                    <div className="flex items-center gap-3">
                        <span className="bg-red-500 text-white px-3 py-1 rounded-full 
                            text-xs font-bold flex items-center gap-1 animate-pulse whitespace-nowrap">
                            <Icons.bell /> TANGAZO
                        </span>
                        <div className="flex-1 overflow-hidden">
                            <div className="animate-marquee whitespace-nowrap" style={{ color: theme.text }}>
                                📢 Karibu kwenye mfumo mpya wa THAMANI YANGU v5.0! • 
                                💡 Mafunzo ya kifedha kila wiki • 
                                🎉 Hongera kwa wanachama wote wanaoshiriki!
                            </div>
                        </div>
                    </div>
                </div>

                {/* ============================================================ */}
                {/* MAIN CONTENT */}
                {/* ============================================================ */}
                <div>
                    <Outlet />
                </div>
            </div>

            {/* ============================================================ */}
            {/* MARQUEE ANIMATION */}
            {/* ============================================================ */}
            <style jsx>{`
                @keyframes marquee {
                    0% { transform: translateX(100%); }
                    100% { transform: translateX(-100%); }
                }
                .animate-marquee {
                    display: inline-block;
                    animation: marquee 30s linear infinite;
                }
            `}</style>
        </div>
    );
};

export default Dashboard;