import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import logo from '../assets/logo_transparent.png';

const Signup = () => {
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token');
    const navigate = useNavigate();
    const [form, setForm] = useState({
        email: '', first_name: '', middle_name: '', last_name: '', phone: '',
        region: '', district: '', ward_street: '',
        emergency_contact_name1: '', emergency_contact_name2: '',
        emergency_relationship: '', emergency_phone: '',
        emergency_region: '', emergency_district: '', emergency_ward_street: '',
        profile_photo_url: ''
    });
    const [loading, setLoading] = useState(false);
    const [tokenValid, setTokenValid] = useState(true);

    useEffect(() => {
        if (!token) { setTokenValid(false); toast.error('Hakuna token'); }
    }, [token]);

    const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!token) return toast.error('Token haipo');
        setLoading(true);
        try {
            const res = await axios.post(`/api/auth/signup/${token}`, form);
            toast.success('Usajili umefanikiwa!');
            navigate('/login', { state: { member_id: res.data.member_id, defaultPassword: res.data.defaultPassword } });
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    if (!tokenValid) return <div className="min-h-screen flex items-center justify-center">Token batili</div>;

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-700 to-yellow-500 p-4">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl w-full max-w-2xl">
                <div className="text-center mb-6"><img src={logo} alt="THAMANI YANGU" className="h-12 mx-auto mb-2" /><h2 className="text-2xl font-bold text-teal-600">Kamilisha Usajili</h2></div>
                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label className="block text-sm font-medium text-gray-700">Barua Pepe</label><input type="email" name="email" value={form.email} onChange={handleChange} className="w-full p-2 border rounded bg-gray-100 cursor-not-allowed" readOnly required /><p className="text-xs text-gray-400">Email imetolewa na token</p></div>
                    <div><label className="block text-sm font-medium text-gray-700">Jina la Kwanza</label><input type="text" name="first_name" value={form.first_name} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" required /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Jina la Kati</label><input type="text" name="middle_name" value={form.middle_name} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Jina la Mwisho</label><input type="text" name="last_name" value={form.last_name} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" required /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Namba ya Simu</label><input type="tel" name="phone" value={form.phone} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" required /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Mkoa</label><input type="text" name="region" value={form.region} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Wilaya</label><input type="text" name="district" value={form.district} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Kata / Mtaa</label><input type="text" name="ward_street" value={form.ward_street} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div className="md:col-span-2 mt-2"><h3 className="font-semibold text-gray-700">Mtu wa Karibu (Dharura)</h3></div>
                    <div><label className="block text-sm font-medium text-gray-700">Jina la Kwanza (Dharura)</label><input type="text" name="emergency_contact_name1" value={form.emergency_contact_name1} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Jina la Mwisho (Dharura)</label><input type="text" name="emergency_contact_name2" value={form.emergency_contact_name2} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Uhusiano</label><input type="text" name="emergency_relationship" value={form.emergency_relationship} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Namba ya Simu (Dharura)</label><input type="tel" name="emergency_phone" value={form.emergency_phone} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Mkoa (Dharura)</label><input type="text" name="emergency_region" value={form.emergency_region} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div><label className="block text-sm font-medium text-gray-700">Wilaya (Dharura)</label><input type="text" name="emergency_district" value={form.emergency_district} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700">Kata/Mtaa (Dharura)</label><input type="text" name="emergency_ward_street" value={form.emergency_ward_street} onChange={handleChange} className="w-full p-2 border rounded focus:ring-2 focus:ring-teal-500" /></div>
                    <div className="md:col-span-2 mt-4"><button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-teal-600 to-yellow-500 text-white py-2 rounded hover:opacity-90 disabled:opacity-50">{loading ? 'Inasajili...' : 'Sajili'}</button></div>
                </form>
            </div>
        </div>
    );
};

export default Signup;