import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaSave, FaDownload, FaShare, FaPrint, FaFileExcel, FaFileWord, FaFilePdf, FaTimes, FaWater, FaSpinner } from 'react-icons/fa';

const WordEditor = ({ content, onChange }) => {
    const editorRef = useRef(null);
    useEffect(() => {
        if (editorRef.current && content !== editorRef.current.innerHTML) {
            editorRef.current.innerHTML = content || '';
        }
    }, [content]);
    const handleInput = () => {
        if (onChange) onChange(editorRef.current.innerHTML);
    };
    const execCommand = (command, value = null) => {
        document.execCommand(command, false, value);
        editorRef.current.focus();
        handleInput();
    };
    return (
        <div className="word-editor border rounded-lg bg-white dark:bg-gray-800">
            <div className="toolbar flex flex-wrap gap-1 p-2 border-b bg-gray-50 dark:bg-gray-700">
                <button onClick={() => execCommand('bold')} className="px-2 py-1 hover:bg-gray-200 rounded"><b>B</b></button>
                <button onClick={() => execCommand('italic')} className="px-2 py-1 hover:bg-gray-200 rounded"><i>I</i></button>
                <button onClick={() => execCommand('underline')} className="px-2 py-1 hover:bg-gray-200 rounded"><u>U</u></button>
                <button onClick={() => execCommand('strikeThrough')} className="px-2 py-1 hover:bg-gray-200 rounded"><s>S</s></button>
                <span className="w-px h-6 bg-gray-300 mx-1"></span>
                <select onChange={(e) => execCommand('fontSize', e.target.value)} className="px-1 py-1 border rounded text-sm">
                    <option value="1">Small</option><option value="3" selected>Normal</option>
                    <option value="5">Large</option><option value="7">Huge</option>
                </select>
                <select onChange={(e) => execCommand('foreColor', e.target.value)} className="px-1 py-1 border rounded text-sm">
                    <option value="#000">Black</option><option value="#f00">Red</option>
                    <option value="#0f0">Green</option><option value="#00f">Blue</option>
                    <option value="#D4AF37">Gold</option><option value="#0D6B6B">Teal</option>
                </select>
                <span className="w-px h-6 bg-gray-300 mx-1"></span>
                <button onClick={() => execCommand('insertOrderedList')} className="px-2 py-1 hover:bg-gray-200 rounded">1.</button>
                <button onClick={() => execCommand('insertUnorderedList')} className="px-2 py-1 hover:bg-gray-200 rounded">•</button>
                <button onClick={() => execCommand('insertHorizontalRule')} className="px-2 py-1 hover:bg-gray-200 rounded">—</button>
                <span className="w-px h-6 bg-gray-300 mx-1"></span>
                <button onClick={() => execCommand('justifyLeft')} className="px-2 py-1 hover:bg-gray-200 rounded">≡</button>
                <button onClick={() => execCommand('justifyCenter')} className="px-2 py-1 hover:bg-gray-200 rounded">≡</button>
                <button onClick={() => execCommand('justifyRight')} className="px-2 py-1 hover:bg-gray-200 rounded">≡</button>
                <button onClick={() => execCommand('justifyFull')} className="px-2 py-1 hover:bg-gray-200 rounded">≡</button>
                <span className="w-px h-6 bg-gray-300 mx-1"></span>
                <button onClick={() => execCommand('createLink', prompt('URL:'))} className="px-2 py-1 hover:bg-gray-200 rounded">🔗</button>
                <button onClick={() => execCommand('insertImage', prompt('Image URL:'))} className="px-2 py-1 hover:bg-gray-200 rounded">🖼️</button>
                <button onClick={() => execCommand('insertTable')} className="px-2 py-1 hover:bg-gray-200 rounded">▦</button>
            </div>
            <div ref={editorRef} contentEditable onInput={handleInput} className="p-4 min-h-[300px] outline-none focus:ring-2 focus:ring-teal-300" dangerouslySetInnerHTML={{ __html: content || '' }} />
        </div>
    );
};

const ExcelEditor = ({ content, onChange }) => {
    return (
        <div className="excel-editor">
            <textarea value={content} onChange={(e) => onChange(e.target.value)}
                placeholder='Andika data kama JSON: [{"Jina":"John","Kiasi":1000}]'
                className="w-full h-64 p-3 border rounded font-mono text-sm focus:ring-2 focus:ring-teal-500 dark:bg-gray-700 dark:border-gray-600" />
            <p className="text-xs text-gray-400 mt-1">Data itabadilishwa kuwa Excel.</p>
        </div>
    );
};

const DocumentEditor = ({ document, onClose, onSave, token }) => {
    const [title, setTitle] = useState(document?.title || '');
    const [documentName, setDocumentName] = useState(document?.document_name || '');
    const [content, setContent] = useState(document?.content || '');
    const [type, setType] = useState(document?.type || 'word');
    const [loading, setLoading] = useState(false);
    const [shareList, setShareList] = useState(document?.share_with || []);
    const [allLeaders, setAllLeaders] = useState([]);
    const [saving, setSaving] = useState(false);
    const [lastSaved, setLastSaved] = useState(document?.last_auto_save_at || null);
    const autoSaveInterval = useRef(null);
    const docId = document?.id;

    useEffect(() => {
        const loadLeaders = async () => {
            try {
                const { data } = await supabase.from('users').select('id, first_name, last_name').in('role', ['mwenyekiti', 'katibu', 'mhazini']);
                setAllLeaders(data || []);
            } catch(e) {}
        };
        loadLeaders();
    }, []);

    useEffect(() => {
        if (docId) {
            const initialTimeout = setTimeout(() => handleAutoSave(), 5000);
            autoSaveInterval.current = setInterval(() => handleAutoSave(), 30000);
            return () => {
                clearTimeout(initialTimeout);
                if (autoSaveInterval.current) clearInterval(autoSaveInterval.current);
            };
        }
    }, [docId, content, title, documentName]);

    const handleAutoSave = async () => {
        if (!docId || saving) return;
        setSaving(true);
        try {
            await axios.put(`/api/documents/${docId}/autosave`, {
                content, title, document_name: documentName,
                metadata: { ...(document?.metadata || {}), lastAutoSave: new Date().toISOString() }
            }, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
            setLastSaved(new Date().toISOString());
        } catch(e) { console.error('Auto-save error:', e); }
        finally { setSaving(false); }
    };

    const handleSave = async () => {
        if (!docId) {
            setLoading(true);
            try {
                const res = await axios.post('/api/documents', {
                    title, document_name: documentName || title || 'Untitled', content, type,
                    metadata: { created_at: new Date().toISOString() }
                }, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
                toast.success('Hati imeundwa!');
                if (onSave) onSave(res.data);
                window.location.reload();
            } catch(e) { toast.error(e.response?.data?.error || 'Hitilafu'); }
            finally { setLoading(false); }
            return;
        }
        setLoading(true);
        try {
            await axios.put(`/api/documents/${docId}`, {
                title, document_name: documentName || title, content,
                metadata: document?.metadata || {}, status: 'published'
            }, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
            toast.success('Hati imehifadhiwa');
            if (onSave) onSave();
        } catch(e) { toast.error(e.response?.data?.error || 'Hitilafu'); }
        finally { setLoading(false); }
    };

    const handleDownload = async (format) => {
        if (!docId) { toast.error('Hifadhi hati kwanza'); return; }
        try {
            const res = await axios.get(`/api/documents/${docId}/download?format=${format}`, {
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement('a');
            link.href = url;
            const ext = format === 'excel' ? 'xlsx' : format === 'word' ? 'docx' : 'pdf';
            link.setAttribute('download', `${documentName || title || 'document'}.${ext}`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            toast.success(`Inapakuliwa kama ${format.toUpperCase()}`);
        } catch(e) { toast.error('Hitilafu kupakua'); }
    };

    const toggleShare = (userId) => {
        if (shareList.includes(userId)) setShareList(shareList.filter(id => id !== userId));
        else setShareList([...shareList, userId]);
    };

    const handleShare = async () => {
        if (!shareList.length) { toast.error('Chagua angalau kiongozi mmoja'); return; }
        if (!docId) { toast.error('Hifadhi hati kwanza'); return; }
        try {
            await axios.put(`/api/documents/${docId}/share`, { share_with: shareList }, {
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });
            toast.success('Hati imeshirikiwa');
        } catch(e) { toast.error(e.response?.data?.error || 'Hitilafu'); }
    };

    const handlePrint = async () => {
        if (!docId) { toast.error('Hifadhi hati kwanza'); return; }
        try {
            const res = await axios.get(`/api/documents/${docId}/download?format=pdf`, {
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const win = window.open(url, '_blank');
            if (win) win.print();
        } catch(e) { toast.error('Hitilafu kuchapisha'); }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-6xl max-h-[95vh] flex flex-col">
                <div className="flex flex-wrap items-center justify-between p-4 border-b bg-gradient-to-r from-teal-50 to-yellow-50 rounded-t-2xl">
                    <div className="flex flex-wrap items-center gap-3">
                        <button onClick={onClose} className="text-gray-500 hover:text-gray-700"><FaTimes size={24} /></button>
                        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Kichwa cha hati..." className="text-xl font-bold bg-transparent border-b-2 border-transparent focus:border-teal-500 outline-none min-w-[200px]" />
                        <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-400">Jina la faili:</span>
                            <input type="text" value={documentName} onChange={(e) => setDocumentName(e.target.value)} placeholder="jina_la_faili" className="bg-transparent border-b focus:border-teal-500 outline-none text-sm" />
                            <span className="text-sm text-gray-400">.{type === 'excel' ? 'xlsx' : 'docx'}</span>
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                        <button onClick={() => setType('excel')} className={`px-3 py-1 rounded ${type === 'excel' ? 'bg-green-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}><FaFileExcel className="inline mr-1" /> Excel</button>
                        <button onClick={() => setType('word')} className={`px-3 py-1 rounded ${type === 'word' ? 'bg-blue-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}><FaFileWord className="inline mr-1" /> Word</button>
                        {saving && <FaSpinner className="animate-spin text-teal-500" />}
                        {lastSaved && <span className="text-xs text-gray-400">Auto-save: {new Date(lastSaved).toLocaleTimeString()}</span>}
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                    {type === 'word' ? <WordEditor content={content} onChange={setContent} /> : <ExcelEditor content={content} onChange={setContent} />}
                </div>
                <div className="p-4 border-t flex flex-wrap items-center justify-between gap-2 bg-gray-50 dark:bg-gray-700 rounded-b-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                        <button onClick={handleSave} disabled={loading} className="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700 disabled:opacity-50 flex items-center gap-2"><FaSave /> {loading ? 'Inahifadhi...' : 'Hifadhi'}</button>
                        {docId && (
                            <>
                                <button onClick={() => handleDownload('excel')} className="bg-green-600 text-white px-3 py-2 rounded hover:bg-green-700 flex items-center gap-1"><FaFileExcel /> Excel</button>
                                <button onClick={() => handleDownload('word')} className="bg-blue-600 text-white px-3 py-2 rounded hover:bg-blue-700 flex items-center gap-1"><FaFileWord /> Word</button>
                                <button onClick={() => handleDownload('pdf')} className="bg-red-600 text-white px-3 py-2 rounded hover:bg-red-700 flex items-center gap-1"><FaFilePdf /> PDF</button>
                                <button onClick={handlePrint} className="bg-gray-600 text-white px-3 py-2 rounded hover:bg-gray-700 flex items-center gap-1"><FaPrint /> Chapisha</button>
                            </>
                        )}
                    </div>
                    {docId && (
                        <div className="flex flex-wrap items-center gap-2">
                            <button onClick={handleShare} className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 flex items-center gap-2"><FaShare /> Shiriki</button>
                            <div className="flex flex-wrap items-center gap-1">
                                {allLeaders.map(leader => (
                                    <button key={leader.id} onClick={() => toggleShare(leader.id)} className={`text-xs px-2 py-1 rounded ${shareList.includes(leader.id) ? 'bg-teal-500 text-white' : 'bg-gray-200 dark:bg-gray-600 hover:bg-gray-300'}`}>{leader.first_name}</button>
                                ))}
                            </div>
                            <div className="text-xs text-gray-400 ml-2"><FaWater className="inline text-blue-500" /> Watermark automatic</div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DocumentEditor;