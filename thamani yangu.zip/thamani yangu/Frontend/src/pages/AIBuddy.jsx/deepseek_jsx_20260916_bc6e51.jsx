import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import {
    FaRobot, FaImage, FaVideo, FaPaperPlane, FaSpinner,
    FaUpload, FaDownload, FaTimes, FaFile, FaMicrophone
} from 'react-icons/fa';
import { saveAIAttachment, getAIAttachments, getCacheStats, autoCleanup } from '../lib/indexedDB';

const AIBuddy = () => {
    const { token, user } = useAuth();
    const [activeTab, setActiveTab] = useState('chat'); // 'chat', 'image', 'video'

    // Chat state
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [chatLoading, setChatLoading] = useState(false);

    // Image state
    const [imagePrompt, setImagePrompt] = useState('');
    const [imageLoading, setImageLoading] = useState(false);
    const [imagePreview, setImagePreview] = useState(null);
    const [imageFilename, setImageFilename] = useState('');

    // Video state
    const [videoPrompt, setVideoPrompt] = useState('');
    const [videoLoading, setVideoLoading] = useState(false);
    const [videoPreview, setVideoPreview] = useState(null);
    const [videoFilename, setVideoFilename] = useState('');

    // Media analysis state
    const [uploadedFile, setUploadedFile] = useState(null);
    const [analysisPrompt, setAnalysisPrompt] = useState('');
    const [analysisLoading, setAnalysisLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState(null);

    // Cache stats
    const [cacheStats, setCacheStats] = useState({ totalSize: 0, totalCount: 0 });

    const messagesEndRef = useRef(null);
    const fileInputRef = useRef(null);

    useEffect(() => {
        // Load chat history
        loadChatHistory();
        // Load cache stats
        loadCacheStats();
        // Auto-cleanup on mount
        autoCleanup(500, 30);
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const loadChatHistory = async () => {
        try {
            const res = await axios.get('/api/ai/history', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.data.messages) {
                setMessages(res.data.messages);
            }
        } catch (err) { /* ignore */ }
    };

    const loadCacheStats = async () => {
        const stats = await getCacheStats();
        setCacheStats(stats);
    };

    // ============================================================
    // CHAT
    // ============================================================
    const sendChatMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        const userMsg = { role: 'user', content: newMessage, timestamp: new Date().toISOString() };
        setMessages(prev => [...prev, userMsg]);
        setNewMessage('');
        setChatLoading(true);

        try {
            const res = await axios.post('/api/ai/chat', {
                message: userMsg.content
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            if (res.data.success) {
                setMessages(prev => [...prev, {
                    role: 'assistant',
                    content: res.data.response,
                    provider: res.data.provider,
                    timestamp: new Date().toISOString()
                }]);
            } else {
                toast.error(res.data.error);
            }
        } catch (err) {
            toast.error('Hitilafu: ' + (err.response?.data?.error || err.message));
        } finally {
            setChatLoading(false);
        }
    };

    // ============================================================
    // IMAGE GENERATION
    // ============================================================
    const generateImage = async (e) => {
        e.preventDefault();
        if (!imagePrompt.trim()) return;

        setImageLoading(true);
        setImagePreview(null);

        try {
            const res = await axios.post('/api/media/generate-image', {
                prompt: imagePrompt
            }, {
                headers: { Authorization: `Bearer ${token}` },
                timeout: 120000
            });

            if (res.data.success) {
                setImagePreview(res.data.image);
                setImageFilename(res.data.filename);
                toast.success(`Imetengenezwa na ${res.data.provider}!`);
            }
        } catch (err) {
            toast.error(err.response?.data?.error || 'Imeshindwa');
        } finally {
            setImageLoading(false);
        }
    };

    const downloadImage = async () => {
        if (!imagePreview) return;

        // Convert base64 to blob
        const byteString = atob(imagePreview.split(',')[1]);
        const mimeString = imagePreview.split(',')[0].split(':')[1].split(';')[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mimeString });

        // Save to IndexedDB
        await saveAIAttachment({
            blob,
            userId: user.id,
            conversationId: 'ai-buddy',
            type: 'image',
            mimeType: mimeString,
            filename: imageFilename
        });

        // Download
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = imageFilename;
        link.click();
        URL.revokeObjectURL(url);

        toast.success('Imepakuliwa na kuhifadhiwa kwenye kifaa!');
        loadCacheStats();
    };

    // ============================================================
    // VIDEO GENERATION
    // ============================================================
    const generateVideo = async (e) => {
        e.preventDefault();
        if (!videoPrompt.trim()) return;

        setVideoLoading(true);
        setVideoPreview(null);

        try {
            const res = await axios.post('/api/media/generate-video', {
                prompt: videoPrompt
            }, {
                headers: { Authorization: `Bearer ${token}` },
                timeout: 180000
            });

            if (res.data.success) {
                setVideoPreview(res.data.video);
                setVideoFilename(res.data.filename);
                toast.success(`Imetengenezwa na ${res.data.provider}!`);
            }
        } catch (err) {
            toast.error(err.response?.data?.error || 'Imeshindwa');
        } finally {
            setVideoLoading(false);
        }
    };

    const downloadVideo = async () => {
        if (!videoPreview) return;

        const byteString = atob(videoPreview.split(',')[1]);
        const mimeString = videoPreview.split(',')[0].split(':')[1].split(';')[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mimeString });

        await saveAIAttachment({
            blob,
            userId: user.id,
            conversationId: 'ai-buddy',
            type: 'video',
            mimeType: mimeString,
            filename: videoFilename
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = videoFilename;
        link.click();
        URL.revokeObjectURL(url);

        toast.success('Imepakuliwa!');
        loadCacheStats();
    };

    // ============================================================
    // MEDIA ANALYSIS
    // ============================================================
    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Check size (max 50MB)
        if (file.size > 50 * 1024 * 1024) {
            toast.error('Faili ni kubwa sana (max 50MB)');
            return;
        }

        setUploadedFile(file);
        // Save to IndexedDB
        await saveAIAttachment({
            blob: file,
            userId: user.id,
            conversationId: 'ai-buddy-media',
            type: file.type.startsWith('image') ? 'image' :
                  file.type.startsWith('video') ? 'video' :
                  file.type.startsWith('audio') ? 'audio' : 'document',
            mimeType: file.type,
            filename: file.name
        });
        loadCacheStats();
        toast.success('Faili imepakiwa (kwenye kifaa chako)');
    };

    const analyzeMedia = async () => {
        if (!uploadedFile || !analysisPrompt.trim()) {
            toast.error('Tafadhali chagua faili na ueleze');
            return;
        }

        setAnalysisLoading(true);
        setAnalysisResult(null);

        try {
            const formData = new FormData();
            formData.append('file', uploadedFile);
            formData.append('prompt', analysisPrompt);
            formData.append('mediaType',
                uploadedFile.type.startsWith('image') ? 'image' :
                uploadedFile.type.startsWith('video') ? 'video' :
                uploadedFile.type.startsWith('audio') ? 'audio' : 'document'
            );

            const res = await axios.post('/api/media/analyze', formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'multipart/form-data'
                },
                timeout: 180000
            });

            setAnalysisResult(res.data.analysis);
            toast.success('Uchambuzi umekamilika!');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Imeshindwa');
        } finally {
            setAnalysisLoading(false);
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow">
            {/* Tabs Header */}
            <div className="flex border-b border-gray-200 dark:border-gray-700">
                <button
                    onClick={() => setActiveTab('chat')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'chat'
                            ? 'border-b-2 border-teal-600 text-teal-600'
                            : 'text-gray-500 hover:text-teal-600'
                    }`}
                >
                    <FaRobot /> Mazungumzo
                </button>
                <button
                    onClick={() => setActiveTab('image')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'image'
                            ? 'border-b-2 border-purple-600 text-purple-600'
                            : 'text-gray-500 hover:text-purple-600'
                    }`}
                >
                    <FaImage /> Tengeneza Picha
                </button>
                <button
                    onClick={() => setActiveTab('video')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'video'
                            ? 'border-b-2 border-orange-600 text-orange-600'
                            : 'text-gray-500 hover:text-orange-600'
                    }`}
                >
                    <FaVideo /> Tengeneza Video
                </button>
            </div>

            {/* Cache Stats Bar */}
            <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 text-xs text-gray-500 flex justify-between">
                <span>💾 Cache: {(cacheStats.totalSize / 1024 / 1024).toFixed(2)} MB ({cacheStats.totalCount} files)</span>
                <span>🗄️ Supabase: Hifadhi inalindwa</span>
            </div>

            {/* ============================================================ */}
            {/* TAB 1: CHAT */}
            {/* ============================================================ */}
            {activeTab === 'chat' && (
                <div className="flex flex-col h-[600px]">
                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {messages.length === 0 && (
                            <div className="text-center text-gray-400 py-8">
                                <FaRobot size={48} className="mx-auto mb-2 opacity-30" />
                                <p>Anza mazungumzo na THAMANI AI BUDDY</p>
                                <p className="text-xs">Itajibu kwa Kiswahili na Kiingereza</p>
                            </div>
                        )}
                        {messages.map((msg, idx) => (
                            <div
                                key={idx}
                                className={`max-w-3xl p-3 rounded-lg ${
                                    msg.role === 'user'
                                        ? 'bg-teal-500 text-white ml-auto'
                                        : 'bg-gray-100 dark:bg-gray-700'
                                }`}
                            >
                                {msg.role === 'assistant' && msg.provider && (
                                    <p className="text-xs text-teal-600 font-bold mb-1">
                                        🤖 {msg.provider}
                                    </p>
                                )}
                                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                        ))}
                        {chatLoading && (
                            <div className="flex items-center gap-2 text-gray-400">
                                <FaSpinner className="animate-spin" />
                                <span className="text-sm">Inatafuta jibu...</span>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <form onSubmit={sendChatMessage} className="p-3 border-t flex gap-2">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            placeholder="Uliza kitu..."
                            className="flex-1 p-2 border rounded-lg focus:ring-2 focus:ring-teal-500 dark:bg-gray-700"
                            disabled={chatLoading}
                        />
                        <button
                            type="submit"
                            disabled={chatLoading}
                            className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 disabled:opacity-50"
                        >
                            <FaPaperPlane />
                        </button>
                    </form>

                    {/* Media Analysis Section */}
                    <div className="border-t p-3 bg-gray-50 dark:bg-gray-700">
                        <p className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">
                            📎 Chambua Media (Picha, Video, Audio, Document)
                        </p>
                        <div className="flex gap-2 flex-wrap">
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={handleFileUpload}
                                accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.zip"
                                className="hidden"
                            />
                            <button
                                onClick={() => fileInputRef.current.click()}
                                className="bg-gray-200 dark:bg-gray-600 px-3 py-2 rounded text-sm hover:bg-gray-300 flex items-center gap-2"
                            >
                                <FaUpload /> Chagua Faili
                            </button>
                            {uploadedFile && (
                                <span className="text-xs text-green-600 flex items-center gap-1">
                                    ✓ {uploadedFile.name} ({(uploadedFile.size / 1024).toFixed(0)} KB)
                                </span>
                            )}
                        </div>
                        {uploadedFile && (
                            <div className="mt-2 flex gap-2">
                                <input
                                    type="text"
                                    value={analysisPrompt}
                                    onChange={(e) => setAnalysisPrompt(e.target.value)}
                                    placeholder="Eleza unataka AI ifanye nini na faili hili..."
                                    className="flex-1 p-2 border rounded text-sm dark:bg-gray-600"
                                />
                                <button
                                    onClick={analyzeMedia}
                                    disabled={analysisLoading}
                                    className="bg-teal-600 text-white px-3 py-2 rounded text-sm hover:bg-teal-700 disabled:opacity-50 flex items-center gap-1"
                                >
                                    {analysisLoading ? <FaSpinner className="animate-spin" /> : 'Chambua'}
                                </button>
                            </div>
                        )}
                        {analysisResult && (
                            <div className="mt-2 p-3 bg-white dark:bg-gray-600 rounded border text-sm whitespace-pre-wrap max-h-40 overflow-y-auto">
                                {analysisResult}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* ============================================================ */}
            {/* TAB 2: IMAGE GENERATION */}
            {/* ============================================================ */}
            {activeTab === 'image' && (
                <div className="p-6">
                    <h3 className="text-xl font-bold text-purple-600 mb-4">🎨 Tengeneza Picha</h3>

                    {!imagePreview ? (
                        <form onSubmit={generateImage} className="space-y-4">
                            <textarea
                                value={imagePrompt}
                                onChange={(e) => setImagePrompt(e.target.value)}
                                placeholder="Eleza picha unayotaka... (mfano: kikundi cha wanachama wakiwa kwenye mkutano wa THAMANI YANGU)"
                                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 dark:bg-gray-700"
                                rows="4"
                                required
                            />
                            <button
                                type="submit"
                                disabled={imageLoading}
                                className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center gap-2"
                            >
                                {imageLoading ? (
                                    <><FaSpinner className="animate-spin" /> Inatengeneza picha...</>
                                ) : (
                                    <><FaImage /> Tengeneza Picha</>
                                )}
                            </button>
                            <p className="text-xs text-gray-400 text-center">
                                💡 Picha haitahifadhiwa kwenye mfumo. Itakuwa preview pekee.
                            </p>
                        </form>
                    ) : (
                        <div className="space-y-4">
                            <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3">
                                <p className="text-xs text-gray-500 mb-2">Preview (haijahifadhiwa):</p>
                                <img src={imagePreview} alt="Generated" className="w-full rounded-lg" />
                            </div>
                            <div className="flex gap-2">
                                <button
                                    onClick={downloadImage}
                                    className="flex-1 bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 flex items-center justify-center gap-2"
                                >
                                    <FaDownload /> Pakua kwenye Kifaa
                                </button>
                                <button
                                    onClick={() => { setImagePreview(null); setImagePrompt(''); }}
                                    className="bg-gray-300 dark:bg-gray-600 px-4 py-2 rounded-lg hover:bg-gray-400"
                                >
                                    <FaTimes /> Tengeneza Nyingine
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* ============================================================ */}
            {/* TAB 3: VIDEO GENERATION */}
            {/* ============================================================ */}
            {activeTab === 'video' && (
                <div className="p-6">
                    <h3 className="text-xl font-bold text-orange-600 mb-4">🎬 Tengeneza Video</h3>

                    {!videoPreview ? (
                        <form onSubmit={generateVideo} className="space-y-4">
                            <textarea
                                value={videoPrompt}
                                onChange={(e) => setVideoPrompt(e.target.value)}
                                placeholder="Eleza video unayotaka... (mfano: video fupi ya michango ikihesabiwa)"
                                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-orange-500 dark:bg-gray-700"
                                rows="4"
                                required
                            />
                            <button
                                type="submit"
                                disabled={videoLoading}
                                className="w-full bg-orange-600 text-white py-3 rounded-lg hover:bg-orange-700 disabled:opacity-50 flex items-center justify-center gap-2"
                            >
                                {videoLoading ? (
                                    <><FaSpinner className="animate-spin" /> Inatengeneza video (inaweza kuchukua dakika 2)...</>
                                ) : (
                                    <><FaVideo /> Tengeneza Video</>
                                )}
                            </button>
                            <p className="text-xs text-gray-400 text-center">
                                💡 Video haitahifadhiwa kwenye mfumo. Itakuwa preview pekee.
                            </p>
                        </form>
                    ) : (
                        <div className="space-y-4">
                            <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3">
                                <p className="text-xs text-gray-500 mb-2">Preview (haijahifadhiwa):</p>
                                <video src={videoPreview} controls autoPlay loop className="w-full rounded-lg" />
                            </div>
                            <div className="flex gap-2">
                                <button
                                    onClick={downloadVideo}
                                    className="flex-1 bg-orange-600 text-white py-2 rounded-lg hover:bg-orange-700 flex items-center justify-center gap-2"
                                >
                                    <FaDownload /> Pakua kwenye Kifaa
                                </button>
                                <button
                                    onClick={() => { setVideoPreview(null); setVideoPrompt(''); }}
                                    className="bg-gray-300 dark:bg-gray-600 px-4 py-2 rounded-lg hover:bg-gray-400"
                                >
                                    <FaTimes /> Tengeneza Nyingine
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default AIBuddy;