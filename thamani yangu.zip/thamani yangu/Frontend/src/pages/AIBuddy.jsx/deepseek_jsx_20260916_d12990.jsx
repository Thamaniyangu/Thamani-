import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import {
    FaRobot, FaImage, FaVideo, FaPaperPlane, FaSpinner,
    FaUpload, FaDownload, FaTimes, FaFile, FaMicrophone
} from 'react-icons/fa';
import { saveAIAttachment, getAIAttachments, getCacheStats, autoCleanup } from '../lib/indexedDB';

const AIBuddy = () => {
    const { token, user } = useAuth();
    const [activeTab, setActiveTab] = useState('chat');

    // Chat state
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [chatLoading, setChatLoading] = useState(false);

    // ... image/video/analysis states ...

    const messagesEndRef = useRef(null);
    const fileInputRef = useRef(null);

    // ============================================================
    // CHECK IF USER IS MWENYEKITI (to show provider)
    // ============================================================
    const isMwenyekiti = user?.role === 'mwenyekiti';

    // ============================================================
    // CHAT
    // ============================================================
    const sendChatMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        const userMsg = { role: 'user', content: newMessage, timestamp: new Date().toISOString() };
        setMessages(prev => [...prev, userMsg]);
        setNewMessage('');
        setChatLoading(true);

        try {
            const res = await axios.post('/api/ai/chat', {
                message: userMsg.content
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            if (res.data.success) {
                setMessages(prev => [...prev, {
                    role: 'assistant',
                    content: res.data.response,
                    // Provider inaonekana tu kwa Mwenyekiti
                    provider: isMwenyekiti ? res.data.provider : null,
                    timestamp: new Date().toISOString()
                }]);
            } else {
                toast.error(res.data.error);
            }
        } catch (err) {
            toast.error('Hitilafu: ' + (err.response?.data?.error || err.message));
        } finally {
            setChatLoading(false);
        }
    };

    // ============================================================
    // IMAGE/VIDEO GENERATION - Provider pia inafichwa kwa Mwenyekiti tu
    // ============================================================
    const generateImage = async (e) => {
        e.preventDefault();
        if (!imagePrompt.trim()) return;

        setImageLoading(true);
        setImagePreview(null);

        try {
            const res = await axios.post('/api/media/generate-image', {
                prompt: imagePrompt
            }, {
                headers: { Authorization: `Bearer ${token}` },
                timeout: 120000
            });

            if (res.data.success) {
                setImagePreview(res.data.image);
                setImageFilename(res.data.filename);
                
                // Provider inaonekana tu kwa Mwenyekiti
                if (isMwenyekiti && res.data.provider) {
                    setImageProvider(res.data.provider);
                }
                
                toast.success('Imetengenezwa!');
            }
        } catch (err) {
            toast.error(err.response?.data?.error || 'Imeshindwa');
        } finally {
            setImageLoading(false);
        }
    };

    // ... sawa kwa video ...

    return (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow">
            {/* Header - Provider inaonekana kwa Mwenyekiti tu */}
            <div className="bg-gradient-to-r from-teal-600 to-yellow-500 p-4 text-white rounded-t-xl">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-2xl font-bold">🤖 THAMANI AI BUDDY</h2>
                        <p className="text-sm opacity-90">Msaidizi wako wa akili bandia</p>
                    </div>
                    {isMwenyekiti && (
                        <div className="text-xs bg-black/20 px-3 py-1 rounded">
                            🔧 Admin Mode
                        </div>
                    )}
                </div>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-gray-200 dark:border-gray-700">
                <button
                    onClick={() => setActiveTab('chat')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'chat'
                            ? 'border-b-2 border-teal-600 text-teal-600'
                            : 'text-gray-500 hover:text-teal-600'
                    }`}
                >
                    <FaRobot /> Mazungumzo
                </button>
                <button
                    onClick={() => setActiveTab('image')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'image'
                            ? 'border-b-2 border-purple-600 text-purple-600'
                            : 'text-gray-500 hover:text-purple-600'
                    }`}
                >
                    <FaImage /> Tengeneza Picha
                </button>
                <button
                    onClick={() => setActiveTab('video')}
                    className={`flex-1 py-3 px-4 font-medium transition flex items-center justify-center gap-2 ${
                        activeTab === 'video'
                            ? 'border-b-2 border-orange-600 text-orange-600'
                            : 'text-gray-500 hover:text-orange-600'
                    }`}
                >
                    <FaVideo /> Tengeneza Video
                </button>
            </div>

            {/* ============================================================ */}
            {/* TAB 1: CHAT */}
            {/* ============================================================ */}
            {activeTab === 'chat' && (
                <div className="flex flex-col h-[600px]">
                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {messages.length === 0 && (
                            <div className="text-center text-gray-400 py-8">
                                <FaRobot size={48} className="mx-auto mb-2 opacity-30" />
                                <p>Anza mazungumzo na THAMANI AI BUDDY</p>
                                <p className="text-xs">Itajibu kwa Kiswahili na Kiingereza</p>
                            </div>
                        )}
                        {messages.map((msg, idx) => (
                            <div
                                key={idx}
                                className={`max-w-3xl p-3 rounded-lg ${
                                    msg.role === 'user'
                                        ? 'bg-teal-500 text-white ml-auto'
                                        : 'bg-gray-100 dark:bg-gray-700'
                                }`}
                            >
                                {/* Provider inaonekana tu kwa Mwenyekiti */}
                                {msg.role === 'assistant' && msg.provider && isMwenyekiti && (
                                    <p className="text-xs text-purple-600 font-bold mb-1">
                                        🔧 [{msg.provider}]
                                    </p>
                                )}
                                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                        ))}
                        {chatLoading && (
                            <div className="flex items-center gap-2 text-gray-400">
                                <FaSpinner className="animate-spin" />
                                <span className="text-sm">Inatafuta jibu...</span>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <form onSubmit={sendChatMessage} className="p-3 border-t flex gap-2">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            placeholder="Uliza kitu..."
                            className="flex-1 p-2 border rounded-lg focus:ring-2 focus:ring-teal-500 dark:bg-gray-700"
                            disabled={chatLoading}
                        />
                        <button
                            type="submit"
                            disabled={chatLoading}
                            className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 disabled:opacity-50"
                        >
                            <FaPaperPlane />
                        </button>
                    </form>

                    {/* Media Analysis Section */}
                    <div className="border-t p-3 bg-gray-50 dark:bg-gray-700">
                        <p className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">
                            📎 Chambua Media (Picha, Video, Audio, Document)
                        </p>
                        {/* ... (same as before) ... */}
                    </div>
                </div>
            )}

            {/* ============================================================ */}
            {/* TAB 2: IMAGE GENERATION */}
            {/* ============================================================ */}
            {activeTab === 'image' && (
                <div className="p-6">
                    <h3 className="text-xl font-bold text-purple-600 mb-4">🎨 Tengeneza Picha</h3>
                    {/* ... (same as before, but provider inaonekana kwa Mwenyekiti pekee) ... */}
                    {imagePreview && isMwenyekiti && (
                        <p className="text-xs text-purple-600 text-center">
                            🔧 Provider: {imageProvider || 'unknown'}
                        </p>
                    )}
                </div>
            )}

            {/* ============================================================ */}
            {/* TAB 3: VIDEO GENERATION */}
            {/* ============================================================ */}
            {activeTab === 'video' && (
                <div className="p-6">
                    <h3 className="text-xl font-bold text-orange-600 mb-4">🎬 Tengeneza Video</h3>
                    {/* ... (same as before) ... */}
                </div>
            )}
        </div>
    );
};

export default AIBuddy;