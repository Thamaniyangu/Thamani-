import AIAvatar from '../components/AIAvatar';

// Kwenye header ya AI Buddy:
<div className="bg-gradient-to-r from-teal-600 to-yellow-500 p-4 text-white rounded-t-xl">
    <div className="flex items-center gap-4">
        <AIAvatar aiType="buddy" size="lg" />
        <div>
            <h2 className="text-2xl font-bold">🤖 THAMANI AI BUDDY</h2>
            <p className="text-sm opacity-90">Msaidizi wako wa akili bandia</p>
        </div>
    </div>
</div>