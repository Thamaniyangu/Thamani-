import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Icons } from '../components/Icon';
import toast from 'react-hot-toast';

const BackupSettings = () => {
    const { token, user } = useAuth();
    const [backups, setBackups] = useState([]);
    const [loading, setLoading] = useState(false);
    const [creating, setCreating] = useState(false);

    useEffect(() => {
        if (user?.role === 'mwenyekiti') loadBackups();
    }, [user]);

    const loadBackups = async () => {
        try {
            const res = await axios.get('/api/backup/list', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setBackups(res.data);
        } catch (err) {}
    };

    const createBackup = async () => {
        setCreating(true);
        try {
            await axios.post('/api/backup/create', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Backup imeundwa!');
            loadBackups();
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setCreating(false);
        }
    };

    const downloadBackup = (filename) => {
        window.open(`/api/backup/download/${filename}?token=${token}`, '_blank');
    };

    const restoreBackup = async (filename) => {
        if (!window.confirm(`RESTORE ${filename}? Hii itabadilisha data yote!`)) return;
        if (!window.confirm('Una uhakika kabisa??')) return;

        try {
            await axios.post('/api/backup/restore', { filename }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Database imerejeshwa!');
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    if (user?.role !== 'mwenyekiti') {
        return (
            <div className="text-center py-12 text-gray-500">
                <Icons.lock size="3x" className="mx-auto mb-4 opacity-30" />
                <p>Mwenyekiti pekee</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 
                p-6 rounded-2xl text-white shadow-2xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <Icons.save size="4x" />
                        <div>
                            <h1 className="text-3xl font-bold">Backup na Recovery</h1>
                            <p className="opacity-90">Hifadhi database kwa usalama</p>
                        </div>
                    </div>
                    <button
                        onClick={createBackup}
                        disabled={creating}
                        className="bg-white text-blue-600 px-6 py-3 rounded-xl 
                            font-bold flex items-center gap-2 hover:bg-gray-100 
                            disabled:opacity-50"
                    >
                        {creating ? <Icons.loading /> : <Icons.plus />}
                        Unda Backup Mpya
                    </button>
                </div>
            </div>

            {/* Backups List */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
                    <Icons.file /> Backups ({backups.length})
                </h3>

                {backups.length === 0 ? (
                    <div className="text-center py-12 text-gray-400">
                        <Icons.file size="5x" className="mx-auto mb-4 opacity-30" />
                        <p>Hakuna backups bado</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {backups.map((b, idx) => (
                            <div key={idx} className="border rounded-xl p-4 
                                flex items-center justify-between flex-wrap gap-3">
                                <div className="flex items-center gap-3">
                                    <div className="w-12 h-12 rounded-xl bg-blue-100 
                                        flex items-center justify-center">
                                        <Icons.save className="text-blue-600" size="lg" />
                                    </div>
                                    <div>
                                        <p className="font-mono text-sm">{b.filename}</p>
                                        <p className="text-xs text-gray-500">
                                            {b.sizeMB} MB • {new Date(b.createdAt).toLocaleString('sw-TZ')}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => downloadBackup(b.filename)}
                                        className="bg-green-500 text-white px-4 py-2 
                                            rounded-lg flex items-center gap-2 
                                            hover:bg-green-600"
                                    >
                                        <Icons.download /> Pakua
                                    </button>
                                    <button
                                        onClick={() => restoreBackup(b.filename)}
                                        className="bg-yellow-500 text-white px-4 py-2 
                                            rounded-lg flex items-center gap-2 
                                            hover:bg-yellow-600"
                                    >
                                        <Icons.undo /> Restore
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Info */}
            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-6">
                <h3 className="font-bold mb-3 flex items-center gap-2 text-yellow-800">
                    <Icons.info /> Maelezo
                </h3>
                <ul className="text-sm space-y-1 text-yellow-800">
                    <li>• Backup inafanyika <strong>kila siku saa 2 usiku</strong> kiotomatiki</li>
                    <li>• Backups 30 za mwisho zinahifadhiwa</li>
                    <li>• Backups ni faili za <strong>.sql</strong> - unaweza kuhamisha popote</li>
                    <li>• <strong>Restore</strong> itabadilisha data YOTE</li>
                </ul>
            </div>
        </div>
    );
};

export default BackupSettings;