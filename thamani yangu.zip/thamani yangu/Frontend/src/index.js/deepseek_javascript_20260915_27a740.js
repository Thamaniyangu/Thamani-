import { initSentry, ErrorBoundary } from './lib/sentry';

initSentry();

root.render(
    <ErrorBoundary fallback={<div>Kuna hitilafu. Tafadhali refresh.</div>}>
        <App />
    </ErrorBoundary>
);