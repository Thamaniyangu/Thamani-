import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext();

export const SocketProvider = ({ children, userId }) => {
    const [socket, setSocket] = useState(null);
    const [onlineUsers, setOnlineUsers] = useState([]);

    useEffect(() => {
        if (!userId) return;
        const newSocket = io('http://localhost:5000', { query: { userId } });
        setSocket(newSocket);
        newSocket.on('user-online', ({ userId }) => setOnlineUsers(prev => [...new Set([...prev, userId])]));
        newSocket.on('user-offline', ({ userId }) => setOnlineUsers(prev => prev.filter(id => id !== userId)));
        return () => newSocket.disconnect();
    }, [userId]);

    return (
        <SocketContext.Provider value={{ socket, onlineUsers }}>
            {children}
        </SocketContext.Provider>
    );
};

export const useSocket = () => useContext(SocketContext);