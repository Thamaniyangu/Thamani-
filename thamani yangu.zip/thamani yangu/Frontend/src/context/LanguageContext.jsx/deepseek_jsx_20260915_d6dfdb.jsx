import React, { createContext, useContext, useState, useEffect } from 'react';
import translations from '../lib/i18n';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
    const [language, setLanguage] = useState(() => {
        return localStorage.getItem('language') || 'sw';
    });

    const t = (key) => {
        return translations[language]?.[key] || translations.sw[key] || key;
    };

    const changeLanguage = (lang) => {
        setLanguage(lang);
        localStorage.setItem('language', lang);
        document.documentElement.lang = lang;
    };

    return (
        <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>
            {children}
        </LanguageContext.Provider>
    );
};

export const useLanguage = () => {
    const context = useContext(LanguageContext);
    if (!context) {
        return { t: (key) => key, language: 'sw', setLanguage: () => {} };
    }
    return context;
};