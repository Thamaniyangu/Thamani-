import React, { createContext, useContext, useState, useEffect } from 'react';

const DarkModeContext = createContext();

export const DarkModeProvider = ({ children }) => {
    const [mode, setMode] = useState(() => {
        return localStorage.getItem('darkMode') || 'auto';
    });

    const [isDark, setIsDark] = useState(false);

    useEffect(() => {
        const applyMode = () => {
            let shouldBeDark = false;

            if (mode === 'dark') {
                shouldBeDark = true;
            } else if (mode === 'light') {
                shouldBeDark = false;
            } else {
                // Auto: detect by time OR system preference
                const hour = new Date().getHours();
                const isNightTime = hour >= 18 || hour < 6;
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                shouldBeDark = isNightTime || prefersDark;
            }

            setIsDark(shouldBeDark);
            document.documentElement.classList.toggle('dark', shouldBeDark);
        };

        applyMode();
        localStorage.setItem('darkMode', mode);

        // Auto-update every minute
        if (mode === 'auto') {
            const interval = setInterval(applyMode, 60000);
            return () => clearInterval(interval);
        }
    }, [mode]);

    return (
        <DarkModeContext.Provider value={{ mode, setMode, isDark }}>
            {children}
        </DarkModeContext.Provider>
    );
};

export const useDarkMode = () => useContext(DarkModeContext);