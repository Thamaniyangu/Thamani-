import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { useSocket } from './SocketContext';

const AIProfilesContext = createContext();

export const AIProfilesProvider = ({ children }) => {
    const { socket } = useSocket();
    const [profiles, setProfiles] = useState({
        'ai-buddy': { name: 'THAMANI AI BUDDY', photo_url: null },
        'ai-financial': { name: 'THAMANI FINANCIAL ADVISOR', photo_url: null },
        'ai-leadership': { name: 'THAMANI LEADERSHIP MENTOR', photo_url: null }
    });

    // Load AI profiles
    useEffect(() => {
        const loadProfiles = async () => {
            try {
                const res = await axios.get('/api/ai-profiles');
                const map = {};
                for (const p of res.data) {
                    map[p.id] = p;
                }
                setProfiles(prev => ({ ...prev, ...map }));
            } catch (err) {
                console.warn('Failed to load AI profiles:', err);
            }
        };
        loadProfiles();
    }, []);

    // Listen for updates via socket
    useEffect(() => {
        if (!socket) return;

        const handleUpdate = ({ aiId, photo_url }) => {
            setProfiles(prev => ({
                ...prev,
                [aiId]: { ...prev[aiId], photo_url }
            }));
        };

        socket.on('ai-profile-updated', handleUpdate);
        return () => socket.off('ai-profile-updated', handleUpdate);
    }, [socket]);

    // Helper: get AI profile by type
    const getAIProfile = (aiType) => {
        const map = {
            'buddy': 'ai-buddy',
            'financial': 'ai-financial',
            'leadership': 'ai-leadership'
        };
        return profiles[map[aiType]] || profiles['ai-buddy'];
    };

    return (
        <AIProfilesContext.Provider value={{ profiles, getAIProfile }}>
            {children}
        </AIProfilesContext.Provider>
    );
};

export const useAIProfiles = () => useContext(AIProfilesContext);