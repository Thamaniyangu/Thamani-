import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const PluginContext = createContext();

export const PluginProvider = ({ children, token }) => {
    const [plugins, setPlugins] = useState([]);
    const [features, setFeatures] = useState({});

    useEffect(() => {
        if (!token) return;
        loadPlugins();
    }, [token]);

    const loadPlugins = async () => {
        try {
            const res = await axios.get('/api/plugins', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setPlugins(res.data);
            
            // Build features map
            const featuresMap = {};
            res.data.forEach(p => {
                if (p.enabled) {
                    featuresMap[p.name] = p;
                }
            });
            setFeatures(featuresMap);
        } catch (err) {
            console.error('Failed to load plugins:', err);
        }
    };

    const isPluginEnabled = (pluginName) => {
        return features[pluginName] !== undefined;
    };

    const getPlugin = (pluginName) => {
        return features[pluginName];
    };

    return (
        <PluginContext.Provider value={{
            plugins,
            features,
            isPluginEnabled,
            getPlugin,
            reload: loadPlugins
        }}>
            {children}
        </PluginContext.Provider>
    );
};

export const usePlugins = () => useContext(PluginContext);