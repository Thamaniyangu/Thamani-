import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const ThemeContext = createContext();

// ============================================================
// DEFAULT THEMES (Logo-based colors)
// ============================================================
const LOGO_THEME = {
    primary: '#0D6B6B',
    secondary: '#D4AF37',
    accent: '#F5E5C0',
    background: '#F8F9FA',
    surface: '#FFFFFF',
    text: '#1A1A1A',
    textMuted: '#6B7280',
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444'
};

// ============================================================
// PRESETS (for quick selection)
// ============================================================
export const THEME_PRESETS = {
    'logo': {
        name: 'THAMANI (Logo)',
        colors: LOGO_THEME
    },
    'ocean': {
        name: 'Ocean Blue',
        colors: {
            primary: '#0369A1',
            secondary: '#06B6D4',
            accent: '#E0F2FE',
            background: '#F0F9FF',
            surface: '#FFFFFF',
            text: '#0C4A6E',
            textMuted: '#64748B',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#EF4444'
        }
    },
    'sunset': {
        name: 'Sunset Orange',
        colors: {
            primary: '#EA580C',
            secondary: '#F59E0B',
            accent: '#FEF3C7',
            background: '#FFFBEB',
            surface: '#FFFFFF',
            text: '#7C2D12',
            textMuted: '#78716C',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#DC2626'
        }
    },
    'forest': {
        name: 'Forest Green',
        colors: {
            primary: '#15803D',
            secondary: '#84CC16',
            accent: '#DCFCE7',
            background: '#F0FDF4',
            surface: '#FFFFFF',
            text: '#14532D',
            textMuted: '#6B7280',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#EF4444'
        }
    },
    'royal': {
        name: 'Royal Purple',
        colors: {
            primary: '#7C3AED',
            secondary: '#EC4899',
            accent: '#F3E8FF',
            background: '#FAF5FF',
            surface: '#FFFFFF',
            text: '#3B0764',
            textMuted: '#6B7280',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#EF4444'
        }
    },
    'midnight': {
        name: 'Midnight Dark',
        colors: {
            primary: '#14B8A6',
            secondary: '#D4AF37',
            accent: '#1F2937',
            background: '#0F172A',
            surface: '#1E293B',
            text: '#F1F5F9',
            textMuted: '#94A3B8',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#EF4444'
        }
    }
};

// ============================================================
// PROVIDER
// ============================================================
export const ThemeProvider = ({ children }) => {
    const { token, user } = useAuth();
    const [themes, setThemes] = useState({ global: LOGO_THEME });
    const [activeArea, setActiveArea] = useState('global');

    // Load user themes
    useEffect(() => {
        if (!user || !token) {
            applyThemeToDOM(LOGO_THEME);
            return;
        }

        const loadThemes = async () => {
            try {
                const res = await axios.get('/api/themes', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const loadedThemes = res.data || {};
                
                if (!loadedThemes.global) {
                    loadedThemes.global = LOGO_THEME;
                }
                
                setThemes(loadedThemes);
                applyThemeToDOM(loadedThemes.global);
            } catch (err) {
                console.warn('Failed to load themes, using default');
                setThemes({ global: LOGO_THEME });
                applyThemeToDOM(LOGO_THEME);
            }
        };

        loadThemes();
    }, [user, token]);

    // ============================================================
    // APPLY THEME TO DOM (CSS Variables)
    // ============================================================
    const applyThemeToDOM = (theme) => {
        const root = document.documentElement;
        Object.entries(theme).forEach(([key, value]) => {
            root.style.setProperty(`--color-${key}`, value);
        });
    };

    // ============================================================
    // SET THEME FOR AREA
    // ============================================================
    const setThemeForArea = async (area, themeColors) => {
        try {
            // Update local state
            setThemes(prev => ({ ...prev, [area]: themeColors }));

            // Apply to DOM if it's the active area
            if (area === activeArea || area === 'global') {
                applyThemeToDOM(themeColors);
            }

            // Save to backend
            if (token) {
                await axios.post('/api/themes/save', {
                    area,
                    theme: themeColors
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });
            }

            // Save to IndexedDB for offline
            saveToIndexedDB(`theme-${area}`, themeColors);
        } catch (err) {
            console.error('Failed to save theme:', err);
        }
    };

    // ============================================================
    // GET THEME FOR AREA
    // ============================================================
    const getThemeForArea = (area) => {
        return themes[area] || themes.global || LOGO_THEME;
    };

    // ============================================================
    // APPLY PRESET
    // ============================================================
    const applyPreset = async (area, presetKey) => {
        const preset = THEME_PRESETS[presetKey];
        if (!preset) return;
        await setThemeForArea(area, preset.colors);
    };

    // ============================================================
    // RESET THEME
    // ============================================================
    const resetTheme = async (area) => {
        if (token) {
            await axios.delete(`/api/themes/${area}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
        }
        setThemes(prev => {
            const newThemes = { ...prev };
            delete newThemes[area];
            return newThemes;
        });
        if (area === activeArea) {
            applyThemeToDOM(LOGO_THEME);
        }
    };

    // ============================================================
    // CHANGE ACTIVE AREA
    // ============================================================
    const changeActiveArea = (area) => {
        setActiveArea(area);
        const theme = getThemeForArea(area);
        applyThemeToDOM(theme);
    };

    return (
        <ThemeContext.Provider value={{
            themes,
            activeArea,
            setActiveArea: changeActiveArea,
            setThemeForArea,
            getThemeForArea,
            applyPreset,
            resetTheme,
            presets: THEME_PRESETS
        }}>
            {children}
        </ThemeContext.Provider>
    );
};

// ============================================================
// INDEXEDDB HELPER
// ============================================================
const saveToIndexedDB = async (key, value) => {
    try {
        const db = await openDB();
        const tx = db.transaction('settings', 'readwrite');
        tx.objectStore('settings').put({ key, value });
    } catch (err) {
        // Ignore
    }
};

const openDB = () => {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open('thamani_cache', 1);
        req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains('settings')) {
                db.createObjectStore('settings', { keyPath: 'key' });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
};

export const useTheme = () => useContext(ThemeContext);