import React from 'react';

// ============================================================
// FONT AWESOME ICON COMPONENT
// ============================================================
const Icon = ({ 
    name,           // 'user', 'home', 'bell', etc. (bila 'fa-')
    style = 'solid', // 'solid', 'regular', 'brands'
    size = 'md',    // 'xs', 'sm', 'md', 'lg', 'xl', '2x'
    className = '',
    color = 'currentColor',
    spin = false,
    pulse = false,
    ...props 
}) => {
    const styleMap = {
        solid: 'fas',
        regular: 'far',
        brands: 'fab',
        duotone: 'fad',
        light: 'fal'
    };

    const sizeMap = {
        xs: 'fa-xs',
        sm: 'fa-sm',
        md: '',
        lg: 'fa-lg',
        xl: 'fa-xl',
        '2x': 'fa-2x',
        '3x': 'fa-3x',
        '4x': 'fa-4x',
        '5x': 'fa-5x'
    };

    const classes = [
        styleMap[style] || 'fas',
        `fa-${name}`,
        sizeMap[size] || '',
        spin ? 'fa-spin' : '',
        pulse ? 'fa-pulse' : '',
        className
    ].filter(Boolean).join(' ');

    return (
        <i 
            className={classes} 
            style={{ color }} 
            {...props}
        />
    );
};

export default Icon;

// ============================================================
// PREDEFINED ICON SETS (kwa urahisi)
// ============================================================
export const Icons = {
    // Navigation
    home: (props) => <Icon name="home" {...props} />,
    dashboard: (props) => <Icon name="chart-pie" {...props} />,
    users: (props) => <Icon name="users" {...props} />,
    user: (props) => <Icon name="user" {...props} />,
    settings: (props) => <Icon name="cog" {...props} />,
    logout: (props) => <Icon name="sign-out-alt" {...props} />,

    // Money
    money: (props) => <Icon name="money-bill-wave" {...props} />,
    wallet: (props) => <Icon name="wallet" {...props} />,
    coins: (props) => <Icon name="coins" {...props} />,
    chart: (props) => <Icon name="chart-line" {...props} />,
    receipt: (props) => <Icon name="receipt" {...props} />,
    idCard: (props) => <Icon name="id-card" {...props} />,

    // Communication
    chat: (props) => <Icon name="comments" {...props} />,
    message: (props) => <Icon name="comment-dots" {...props} />,
    video: (props) => <Icon name="video" {...props} />,
    phone: (props) => <Icon name="phone" {...props} />,
    bell: (props) => <Icon name="bell" {...props} />,
    support: (props) => <Icon name="headset" {...props} />,

    // Files
    file: (props) => <Icon name="file" {...props} />,
    folder: (props) => <Icon name="folder" {...props} />,
    upload: (props) => <Icon name="cloud-upload-alt" {...props} />,
    download: (props) => <Icon name="download" {...props} />,
    share: (props) => <Icon name="share-alt" {...props} />,
    print: (props) => <Icon name="print" {...props} />,

    // AI
    robot: (props) => <Icon name="robot" {...props} />,
    brain: (props) => <Icon name="brain" {...props} />,
    sparkles: (props) => <Icon name="sparkles" {...props} />,
    magic: (props) => <Icon name="wand-magic-sparkles" {...props} />,

    // Actions
    save: (props) => <Icon name="save" {...props} />,
    edit: (props) => <Icon name="pen" {...props} />,
    trash: (props) => <Icon name="trash" {...props} />,
    plus: (props) => <Icon name="plus" {...props} />,
    check: (props) => <Icon name="check" {...props} />,
    times: (props) => <Icon name="times" {...props} />,
    search: (props) => <Icon name="search" {...props} />,
    filter: (props) => <Icon name="filter" {...props} />,

    // Social
    whatsapp: (props) => <Icon name="whatsapp" style="brands" {...props} />,
    facebook: (props) => <Icon name="facebook" style="brands" {...props} />,
    twitter: (props) => <Icon name="twitter" style="brands" {...props} />,
    instagram: (props) => <Icon name="instagram" style="brands" {...props} />,
    youtube: (props) => <Icon name="youtube" style="brands" {...props} />,
    google: (props) => <Icon name="google" style="brands" {...props} />,

    // Status
    loading: (props) => <Icon name="spinner" spin {...props} />,
    success: (props) => <Icon name="check-circle" {...props} />,
    warning: (props) => <Icon name="exclamation-triangle" {...props} />,
    error: (props) => <Icon name="times-circle" {...props} />,
    info: (props) => <Icon name="info-circle" {...props} />,

    // Premium
    crown: (props) => <Icon name="crown" {...props} />,
    star: (props) => <Icon name="star" {...props} />,
    trophy: (props) => <Icon name="trophy" {...props} />,
    gem: (props) => <Icon name="gem" {...props} />,
    fire: (props) => <Icon name="fire" {...props} />,

    // Arrows
    arrowRight: (props) => <Icon name="arrow-right" {...props} />,
    arrowLeft: (props) => <Icon name="arrow-left" {...props} />,
    arrowUp: (props) => <Icon name="arrow-up" {...props} />,
    arrowDown: (props) => <Icon name="arrow-down" {...props} />,
    chevronRight: (props) => <Icon name="chevron-right" {...props} />,
    chevronLeft: (props) => <Icon name="chevron-left" {...props} />,
    chevronDown: (props) => <Icon name="chevron-down" {...props} />,

    // Misc
    moon: (props) => <Icon name="moon" {...props} />,
    sun: (props) => <Icon name="sun" {...props} />,
    palette: (props) => <Icon name="palette" {...props} />,
    globe: (props) => <Icon name="globe" {...props} />,
    lock: (props) => <Icon name="lock" {...props} />,
    shield: (props) => <Icon name="shield-halved" {...props} />,
    eye: (props) => <Icon name="eye" {...props} />,
    eyeSlash: (props) => <Icon name="eye-slash" {...props} />,
    copy: (props) => <Icon name="copy" {...props} />,
    link: (props) => <Icon name="link" {...props} />,
    qrcode: (props) => <Icon name="qrcode" {...props} />,
    location: (props) => <Icon name="location-dot" {...props} />,
    calendar: (props) => <Icon name="calendar" {...props} />,
    clock: (props) => <Icon name="clock" {...props} />,
    play: (props) => <Icon name="play" {...props} />,
    pause: (props) => <Icon name="pause" {...props} />,
    stop: (props) => <Icon name="stop" {...props} />,
    record: (props) => <Icon name="circle" {...props} />,
    mic: (props) => <Icon name="microphone" {...props} />,
    micSlash: (props) => <Icon name="microphone-slash" {...props} />,
    camera: (props) => <Icon name="camera" {...props} />,
    screen: (props) => <Icon name="display" {...props} />,
    expand: (props) => <Icon name="expand" {...props} />,
    compress: (props) => <Icon name="compress" {...props} />,
    heart: (props) => <Icon name="heart" {...props} />,
    thumbsUp: (props) => <Icon name="thumbs-up" {...props} />,
    flag: (props) => <Icon name="flag" {...props} />,
    award: (props) => <Icon name="award" {...props} />,
    medal: (props) => <Icon name="medal" {...props} />,
    gift: (props) => <Icon name="gift" {...props} />,
    rocket: (props) => <Icon name="rocket" {...props} />,
    lightning: (props) => <Icon name="bolt" {...props} />,
    language: (props) => <Icon name="language" {...props} />,
};