import React, { useState, useEffect } from 'react';
import { FaRobot, FaChartLine, FaCrown } from 'react-icons/fa';

const AITagSuggestions = ({ onSelect, roomType, userRole }) => {
    const [show, setShow] = useState(false);
    const [query, setQuery] = useState('');

    const isLeader = ['mwenyekiti', 'katibu', 'mhazini'].includes(userRole);
    const isLeadersRoom = roomType === 'leaders_only';

    const suggestions = [
        {
            tag: '@AI',
            name: 'THAMANI AI BUDDY',
            description: 'Masuala ya jamii, utamaduni, jumla',
            icon: <FaRobot />,
            color: 'text-teal-600'
        },
        {
            tag: '@Finance',
            name: 'THAMANI FINANCIAL ADVISOR',
            description: 'Akiba, mikopo, riba, bajeti',
            icon: <FaChartLine />,
            color: 'text-green-600'
        },
        ...(isLeader && isLeadersRoom ? [{
            tag: '@Leadership',
            name: 'THAMANI LEADERSHIP MENTOR',
            description: 'Uongozi, maamuzi, majukumu',
            icon: <FaCrown />,
            color: 'text-yellow-600'
        }] : [])
    ];

    return (
        <div className="relative">
            <button
                onClick={() => setShow(!show)}
                className="text-xs text-teal-600 hover:text-teal-800 flex items-center gap-1"
            >
                <FaRobot className="text-xs" />
                Tumia AI
            </button>

            {show && (
                <div className="absolute bottom-full mb-2 left-0 bg-white dark:bg-gray-800 rounded-lg shadow-2xl border border-gray-200 dark:border-gray-700 p-3 w-72 z-50">
                    <p className="text-xs font-bold mb-2 text-gray-500">Chagua AI:</p>
                    <div className="space-y-1">
                        {suggestions.map((s) => (
                            <button
                                key={s.tag}
                                onClick={() => {
                                    onSelect(s.tag + ' ');
                                    setShow(false);
                                }}
                                className="w-full text-left p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition flex items-start gap-2"
                            >
                                <span className={`${s.color} mt-1`}>{s.icon}</span>
                                <div>
                                    <p className="text-sm font-medium">{s.name}</p>
                                    <p className="text-xs text-gray-500">{s.description}</p>
                                    <p className="text-xs text-teal-600 font-mono mt-1">{s.tag}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                    {!isLeadersRoom && isLeader && (
                        <p className="text-xs text-gray-400 mt-2 pt-2 border-t">
                            💡 @Leadership inapatikana kwenye Leaders Chatroom pekee.
                        </p>
                    )}
                </div>
            )}
        </div>
    );
};

export default AITagSuggestions;