import React, { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import { usePlugins } from '../context/PluginContext';

// Plugin registry - kila plugin ina-export component yake
const PLUGIN_COMPONENTS = {
    'iot-savings': {
        path: '/dashboard/iot',
        component: lazy(() => import('../../plugins/iot-savings/Dashboard'))
    },
    'blockchain': {
        path: '/dashboard/blockchain',
        component: lazy(() => import('../../plugins/blockchain/Dashboard'))
    },
    'analytics': {
        path: '/dashboard/analytics',
        component: lazy(() => import('../../plugins/analytics/Dashboard'))
    },
    'marketing': {
        path: '/dashboard/marketing',
        component: lazy(() => import('../../plugins/marketing/Dashboard'))
    },
    'sip-calls': {
        path: '/dashboard/calls',
        component: lazy(() => import('../../plugins/sip-calls/Dashboard'))
    }
};

const PluginRouter = () => {
    const { isPluginEnabled } = usePlugins();

    return (
        <Suspense fallback={<div className="p-6 text-center">Inapakia plugin...</div>}>
            <Routes>
                {Object.entries(PLUGIN_COMPONENTS).map(([pluginName, config]) => {
                    if (!isPluginEnabled(pluginName)) return null;
                    
                    const Component = config.component;
                    return (
                        <Route
                            key={pluginName}
                            path={config.path}
                            element={<Component />}
                        />
                    );
                })}
            </Routes>
        </Suspense>
    );
};

export default PluginRouter;