import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Icons } from './Icon';
import toast from 'react-hot-toast';

const SupportChatModal = ({ onClose }) => {
    const [visitorName, setVisitorName] = useState('');
    const [chatId, setChatId] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [mediaRecorder, setMediaRecorder] = useState(null);
    const [isMinimized, setIsMinimized] = useState(false);
    const [isMaximized, setIsMaximized] = useState(false);

    const messagesEndRef = useRef(null);
    const fileInputRef = useRef(null);

    const startChat = async () => {
        if (!visitorName.trim()) return toast.error('Jina linahitajika');

        setLoading(true);
        try {
            const res = await axios.post('/api/support/chats', {
                visitor_name: visitorName
            });
            setChatId(res.data.id);
            pollMessages(res.data.id);
            toast.success('Chat imeanzishwa!');
        } catch (err) {
            toast.error('Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    const pollMessages = (id) => {
        const interval = setInterval(async () => {
            try {
                const res = await axios.get(`/api/support/chats/${id}/messages`);
                setMessages(res.data);
            } catch (e) {}
        }, 3000);
        window.supportPoll = interval;
    };

    useEffect(() => {
        return () => {
            if (window.supportPoll) clearInterval(window.supportPoll);
            if (chatId) axios.put(`/api/support/chats/${chatId}/close`).catch(() => {});
        };
    }, [chatId]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !chatId) return;

        try {
            const res = await axios.post(`/api/support/chats/${chatId}/messages`, {
                text: newMessage, type: 'text'
            });
            setMessages(prev => [...prev, res.data]);
            setNewMessage('');
        } catch (err) {
            toast.error('Imeshindwa kutuma');
        }
    };

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file || !chatId) return;

        if (file.size > 5 * 1024 * 1024) {
            toast.error('Faili kubwa sana (max 5MB)');
            return;
        }

        const reader = new FileReader();
        reader.onload = async (event) => {
            const base64 = event.target.result.split(',')[1];
            try {
                const res = await axios.post(`/api/support/chats/${chatId}/messages`, {
                    text: file.name, type: 'image',
                    file_base64: base64, file_name: file.name
                });
                setMessages(prev => [...prev, res.data]);
                toast.success('Picha imetumwa');
            } catch (err) {
                toast.error('Hitilafu');
            }
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const recorder = new MediaRecorder(stream);
            setMediaRecorder(recorder);
            recorder.start();
            setIsRecording(true);

            recorder.ondataavailable = async (event) => {
                if (event.data.size > 0 && event.data.size < 2 * 1024 * 1024) {
                    const reader = new FileReader();
                    reader.onload = async (e) => {
                        const base64 = e.target.result.split(',')[1];
                        try {
                            await axios.post(`/api/support/chats/${chatId}/messages`, {
                                text: 'Voice note', type: 'voice',
                                file_base64: base64, file_name: `voice-${Date.now()}.webm`
                            });
                            toast.success('Voice note imetumwa');
                        } catch (err) {}
                    };
                    reader.readAsDataURL(event.data);
                }
            };
        } catch (err) {
            toast.error('Imeshindwa kuanza recording');
        }
    };

    const stopRecording = () => {
        if (mediaRecorder) {
            mediaRecorder.stop();
            setIsRecording(false);
            mediaRecorder.stream.getTracks().forEach(t => t.stop());
        }
    };

    if (isMinimized) {
        return (
            <div
                onClick={() => setIsMinimized(false)}
                className="fixed bottom-4 right-4 bg-[var(--color-primary)] text-white 
                    px-6 py-3 rounded-full shadow-2xl cursor-pointer 
                    flex items-center gap-2 hover:scale-105 transition z-50"
            >
                <Icons.support size="lg" />
                <span className="font-bold">Msaada</span>
                {messages.length > 0 && (
                    <span className="bg-red-500 text-white text-xs w-5 h-5 rounded-full 
                        flex items-center justify-center">
                        {messages.length}
                    </span>
                )}
            </div>
        );
    }

    const chatWindowClasses = isMaximized
        ? 'fixed inset-4 w-auto h-auto'
        : 'fixed bottom-4 right-4 w-96 h-[600px]';

    return (
        <div className={`${chatWindowClasses} bg-white rounded-2xl shadow-2xl 
            flex flex-col z-50 overflow-hidden animate-fadeIn`}>
            
            {/* Header */}
            <div className="bg-gradient-to-r from-[var(--color-primary)] 
                to-[var(--color-secondary)] p-4 text-white">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                            <Icons.support size="lg" />
                        </div>
                        <div>
                            <h3 className="font-bold">Msaada</h3>
                            <p className="text-xs opacity-90">
                                {chatId ? 'Tuko hapa kukusaidia' : 'Karibu!'}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-1">
                        <button
                            onClick={() => setIsMinimized(true)}
                            className="p-2 hover:bg-white/20 rounded-lg"
                        >
                            <Icons.chevronDown />
                        </button>
                        <button
                            onClick={() => setIsMaximized(!isMaximized)}
                            className="p-2 hover:bg-white/20 rounded-lg"
                        >
                            {isMaximized ? <Icons.compress /> : <Icons.expand />}
                        </button>
                        <button
                            onClick={onClose}
                            className="p-2 hover:bg-red-500 rounded-lg"
                        >
                            <Icons.times />
                        </button>
                    </div>
                </div>
            </div>

            {/* Body */}
            {!chatId ? (
                <div className="flex-1 p-6 flex flex-col justify-center">
                    <div className="text-center mb-6">
                        <div className="w-20 h-20 bg-[var(--color-primary)]/10 rounded-full 
                            flex items-center justify-center mx-auto mb-4">
                            <Icons.support size="3x" className="text-[var(--color-primary)]" />
                        </div>
                        <h3 className="text-xl font-bold mb-2">Wasiliana na Viongozi</h3>
                        <p className="text-gray-500 text-sm">
                            Jaza jina lako kuanza mazungumzo
                        </p>
                    </div>

                    <input
                        type="text"
                        value={visitorName}
                        onChange={(e) => setVisitorName(e.target.value)}
                        placeholder="Jina lako kamili"
                        className="w-full p-3 border rounded-xl mb-3 focus:ring-2 
                            focus:ring-[var(--color-primary)]"
                    />

                    <button
                        onClick={startChat}
                        disabled={loading}
                        className="w-full bg-gradient-to-r from-[var(--color-primary)] 
                            to-[var(--color-secondary)] text-white py-3 rounded-xl 
                            font-bold hover:opacity-90 disabled:opacity-50 flex 
                            items-center justify-center gap-2"
                    >
                        {loading ? <Icons.loading /> : <Icons.chat />}
                        Anza Mazungumzo
                    </button>

                    <p className="text-xs text-gray-400 text-center mt-3">
                        <Icons.lock className="inline mr-1" />
                        Mazungumzo yatabaki kwa siku 5 tu
                    </p>
                </div>
            ) : (
                <>
                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
                        {messages.map((msg, idx) => (
                            <div
                                key={idx}
                                className={`flex ${msg.sender_type === 'visitor' ? 'justify-end' : 'justify-start'}`}
                            >
                                <div className={`max-w-[80%] p-3 rounded-2xl ${
                                    msg.sender_type === 'visitor'
                                        ? 'bg-[var(--color-primary)] text-white rounded-br-none'
                                        : 'bg-white shadow rounded-bl-none'
                                }`}>
                                    <p className="text-xs font-bold mb-1 opacity-75">
                                        {msg.sender_name}
                                    </p>
                                    {msg.type === 'text' && <p>{msg.text}</p>}
                                    {msg.type === 'image' && (
                                        <img src={msg.file_url} alt="" className="rounded-lg max-w-full" />
                                    )}
                                    {msg.type === 'voice' && (
                                        <audio controls src={msg.file_url} className="w-full" />
                                    )}
                                    <p className="text-xs opacity-60 mt-1">
                                        {new Date(msg.created_at).toLocaleTimeString('sw-TZ', {
                                            hour: '2-digit', minute: '2-digit'
                                        })}
                                    </p>
                                </div>
                            </div>
                        ))}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <div className="p-3 border-t flex items-center gap-2">
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileUpload}
                            className="hidden"
                            accept="image/*"
                        />
                        <button
                            onClick={() => fileInputRef.current.click()}
                            className="p-2 text-[var(--color-primary)] hover:bg-gray-100 rounded-lg"
                        >
                            <Icons.camera size="lg" />
                        </button>
                        <button
                            onMouseDown={startRecording}
                            onMouseUp={stopRecording}
                            onTouchStart={startRecording}
                            onTouchEnd={stopRecording}
                            className={`p-2 rounded-lg ${isRecording ? 'text-red-500 bg-red-50' : 'text-[var(--color-primary)] hover:bg-gray-100'}`}
                        >
                            <Icons.mic size="lg" />
                        </button>
                        <form onSubmit={sendMessage} className="flex-1 flex gap-2">
                            <input
                                type="text"
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Andika ujumbe..."
                                className="flex-1 p-2 border rounded-xl focus:ring-2 
                                    focus:ring-[var(--color-primary)]"
                            />
                            <button
                                type="submit"
                                className="p-2 bg-[var(--color-primary)] text-white rounded-xl"
                            >
                                <Icons.arrowRight />
                            </button>
                        </form>
                    </div>
                </>
            )}
        </div>
    );
};

export default SupportChatModal;