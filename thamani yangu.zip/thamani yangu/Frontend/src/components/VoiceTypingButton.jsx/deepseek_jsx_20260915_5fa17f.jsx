import React, { useState } from 'react';
import { Icons } from './Icon';
import useVoiceTyping from '../hooks/useVoiceTyping';

const VoiceTypingButton = ({ onResult, language = 'sw-KE' }) => {
    const [showLangMenu, setShowLangMenu] = useState(false);
    const [selectedLang, setSelectedLang] = useState(language);

    const {
        isSupported,
        isListening,
        transcript,
        interim,
        fullText,
        toggle,
        reset
    } = useVoiceTyping({ language: selectedLang });

    React.useEffect(() => {
        if (onResult && (transcript || interim)) {
            onResult(fullText);
        }
    }, [fullText, onResult]);

    const languages = [
        { code: 'sw-KE', name: '🇰🇪 Kiswahili' },
        { code: 'en-US', name: '🇺🇸 English (US)' },
        { code: 'en-GB', name: '🇬🇧 English (UK)' },
        { code: 'ar-SA', name: '🇸🇦 العربية' },
        { code: 'fr-FR', name: '🇫🇷 Français' }
    ];

    if (!isSupported) return null;

    return (
        <div className="relative">
            <button
                type="button"
                onClick={toggle}
                className={`p-3 rounded-full transition relative ${
                    isListening
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-gray-100 hover:bg-gray-200'
                }`}
                title={isListening ? 'Sikiliza...' : 'Anza kuandika kwa sauti'}
            >
                {isListening ? <Icons.micSlash /> : <Icons.mic />}
                {isListening && (
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></span>
                )}
            </button>

            {/* Language selector */}
            <button
                type="button"
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="absolute -bottom-1 -right-1 bg-blue-500 text-white 
                    text-xs rounded-full w-5 h-5 flex items-center justify-center"
            >
                <Icons.globe size="xs" />
            </button>

            {showLangMenu && (
                <div className="absolute bottom-full mb-2 left-0 bg-white 
                    rounded-lg shadow-2xl border p-2 min-w-[180px] z-50">
                    {languages.map(lang => (
                        <button
                            key={lang.code}
                            type="button"
                            onClick={() => {
                                setSelectedLang(lang.code);
                                setShowLangMenu(false);
                                reset();
                            }}
                            className={`w-full text-left p-2 rounded text-sm 
                                hover:bg-gray-100 ${
                                selectedLang === lang.code ? 'bg-blue-50' : ''
                            }`}
                        >
                            {lang.name}
                        </button>
                    ))}
                </div>
            )}

            {isListening && (
                <div className="absolute bottom-full mb-2 left-0 bg-red-500 text-white 
                    px-3 py-1 rounded-full text-xs whitespace-nowrap animate-pulse">
                    🎤 Nasikiliza...
                </div>
            )}
        </div>
    );
};

export default VoiceTypingButton;