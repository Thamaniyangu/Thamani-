import React, { useState } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaImage, FaVideo, FaDownload, FaTimes, FaSpinner } from 'react-icons/fa';
import { useAuth } from '../context/AuthContext';

const MediaGenerator = () => {
    const { token } = useAuth();
    const [mediaType, setMediaType] = useState('image'); // 'image' | 'video'
    const [prompt, setPrompt] = useState('');
    const [loading, setLoading] = useState(false);
    const [preview, setPreview] = useState(null);
    const [filename, setFilename] = useState('');

    const handleGenerate = async (e) => {
        e.preventDefault();
        if (!prompt.trim()) {
            toast.error('Tafadhali weka maelezo');
            return;
        }

        setLoading(true);
        setPreview(null);

        try {
            const endpoint = mediaType === 'image' ? '/api/media/generate-image' : '/api/media/generate-video';
            const res = await axios.post(endpoint, { prompt }, {
                headers: { Authorization: `Bearer ${token}` },
                timeout: 120000 // 2 minutes for video
            });

            if (res.data.success) {
                setPreview(res.data[mediaType]); // image or video base64
                setFilename(res.data.filename);
                toast.success(`Picha/Video imetengenezwa na ${res.data.provider}!`);
            }
        } catch (err) {
            toast.error(err.response?.data?.error || 'Imeshindwa kutengeneza');
        } finally {
            setLoading(false);
        }
    };

    const handleDownload = () => {
        if (!preview) return;

        // Convert base64 to blob
        const byteString = atob(preview.split(',')[1]);
        const mimeString = preview.split(',')[0].split(':')[1].split(';')[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mimeString });

        // Download
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);

        toast.success('Imepakuliwa kwenye kifaa chako!');
    };

    const handleClose = () => {
        setPreview(null);
        setPrompt('');
        setFilename('');
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow p-6">
            <h3 className="text-xl font-bold text-teal-600 mb-4">🎨 Tengeneza Picha/Video</h3>

            {/* Media Type Toggle */}
            <div className="flex gap-2 mb-4">
                <button
                    onClick={() => setMediaType('image')}
                    className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 ${mediaType === 'image' ? 'bg-teal-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}
                >
                    <FaImage /> Picha
                </button>
                <button
                    onClick={() => setMediaType('video')}
                    className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 ${mediaType === 'video' ? 'bg-purple-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}
                >
                    <FaVideo /> Video
                </button>
            </div>

            {/* Prompt Input */}
            {!preview ? (
                <form onSubmit={handleGenerate} className="space-y-4">
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={mediaType === 'image' 
                            ? 'Eleza picha unayotaka... (mfano: picha ya kikundi cha wanachama wakiwa kwenye mkutano)' 
                            : 'Eleza video unayotaka... (mfano: video ya michango ikihesabiwa)'}
                        className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-500 dark:bg-gray-700 dark:border-gray-600"
                        rows="3"
                        required
                    />
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-teal-600 text-white py-3 rounded-lg hover:bg-teal-700 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {loading ? (
                            <><FaSpinner className="animate-spin" /> Inatengeneza...</>
                        ) : (
                            <>Tengeneza {mediaType === 'image' ? 'Picha' : 'Video'}</>
                        )}
                    </button>
                    {mediaType === 'video' && (
                        <p className="text-xs text-gray-400 text-center">
                            ⏱️ Video inaweza kuchukua hadi dakika 2 kutengenezwa
                        </p>
                    )}
                </form>
            ) : (
                <div className="space-y-4">
                    {/* Preview */}
                    <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-2">
                        <p className="text-xs text-gray-500 mb-2">Preview (haijahifadhiwa kwenye database):</p>
                        {mediaType === 'image' ? (
                            <img src={preview} alt="Preview" className="w-full rounded-lg" />
                        ) : (
                            <video src={preview} controls autoPlay loop className="w-full rounded-lg" />
                        )}
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                        <button
                            onClick={handleDownload}
                            className="flex-1 bg-teal-600 text-white py-2 rounded-lg hover:bg-teal-700 flex items-center justify-center gap-2"
                        >
                            <FaDownload /> Pakua kwenye Kifaa
                        </button>
                        <button
                            onClick={handleClose}
                            className="bg-gray-300 dark:bg-gray-600 px-4 py-2 rounded-lg hover:bg-gray-400"
                        >
                            <FaTimes /> Funga
                        </button>
                    </div>

                    <p className="text-xs text-gray-400 text-center">
                        💾 Picha/Video haijahifadhiwa kwenye mfumo. Iko kwenye kifaa chako pekee.
                    </p>
                </div>
            )}
        </div>
    );
};

export default MediaGenerator;