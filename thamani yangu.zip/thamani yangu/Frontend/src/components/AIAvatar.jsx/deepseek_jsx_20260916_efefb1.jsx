import React from 'react';
import { FaRobot, FaChartLine, FaCrown } from 'react-icons/fa';
import { useAIProfiles } from '../context/AIProfilesContext';

const AIAvatar = ({ aiType, size = 'md', className = '' }) => {
    const { getAIProfile } = useAIProfiles();
    const profile = getAIProfile(aiType);

    const sizes = {
        xs: 'w-6 h-6 text-xs',
        sm: 'w-8 h-8 text-sm',
        md: 'w-10 h-10 text-base',
        lg: 'w-16 h-16 text-xl',
        xl: 'w-24 h-24 text-3xl'
    };

    const colors = {
        buddy: 'bg-teal-600',
        financial: 'bg-green-600',
        leadership: 'bg-yellow-600'
    };

    const icons = {
        buddy: <FaRobot />,
        financial: <FaChartLine />,
        leadership: <FaCrown />
    };

    // If photo exists, show photo
    if (profile?.photo_url) {
        return (
            <img
                src={profile.photo_url}
                alt={profile.name}
                className={`${sizes[size]} rounded-full object-cover border-2 border-white shadow-md ${className}`}
                onError={(e) => {
                    // If photo fails, fallback to icon
                    e.target.style.display = 'none';
                }}
            />
        );
    }

    // Fallback to icon
    return (
        <div className={`${sizes[size]} ${colors[aiType] || colors.buddy} rounded-full flex items-center justify-center text-white shadow-md ${className}`}>
            {icons[aiType] || icons.buddy}
        </div>
    );
};

export default AIAvatar;