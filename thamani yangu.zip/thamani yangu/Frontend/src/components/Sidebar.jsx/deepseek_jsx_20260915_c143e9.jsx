import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Icons } from './Icon';
import { useAuth } from '../context/AuthContext';
import { usePlugins } from '../context/PluginContext';
import axios from 'axios';

const Sidebar = () => {
    const { user, logout } = useAuth();
    const { isPluginEnabled } = usePlugins();
    const location = useLocation();
    const [supportUnread, setSupportUnread] = useState(0);
    const [superAdminOpen, setSuperAdminOpen] = useState(false);

    const isMwenyekiti = user?.role === 'mwenyekiti';

    // ============================================================
    // MENU ITEMS - Common (Wote)
    // ============================================================
    const commonMenuItems = [
        { path: '/dashboard', icon: Icons.home, label: 'Mwanzo' },
        { path: '/dashboard/contributions', icon: Icons.money, label: 'Michango' },
        { path: '/dashboard/membership', icon: Icons.coins, label: 'Ada' },
        { path: '/dashboard/receipts', icon: Icons.receipt, label: 'Risiti' },
        { path: '/dashboard/id-card', icon: Icons.idCard, label: 'Kitambulisho' },
        { path: '/dashboard/chat', icon: Icons.chat, label: 'Mazungumzo' },
        { path: '/dashboard/ai-buddy', icon: Icons.robot, label: 'AI Buddy' },
        { path: '/dashboard/video', icon: Icons.video, label: 'Video' }
    ];

    // ============================================================
    // LEADER MENU (Viongozi wote: Mwenyekiti, Katibu, Mhazini)
    // ============================================================
    const leaderMenuItems = [
        { path: '/dashboard/documents', icon: Icons.file, label: 'Nyaraka' },
        { 
            path: '/dashboard/support', 
            icon: Icons.support, 
            label: 'Msaada', 
            badge: supportUnread 
        },
        { path: '/dashboard/applications', icon: Icons.user, label: 'Maombi' }
    ];

    // ============================================================
    // SUPER ADMIN MENU - MWENYEKITI PEKEE
    // ============================================================
    const superAdminMenuItems = [
        {
            path: '/dashboard/sip-voice',
            icon: Icons.phone,
            label: 'Simu za Sauti (SIP)',
            plugin: 'sip-voice',
            description: 'Simu za sauti kwa mfumo wote'
        },
        {
            path: '/dashboard/marketing',
            icon: Icons.magic,
            label: 'Marketing Automation',
            plugin: 'marketing-automation',
            description: 'Campaigns za kiotomatiki'
        },
        {
            path: '/dashboard/advanced-analytics',
            icon: Icons.chart,
            label: 'Advanced Analytics',
            plugin: 'advanced-analytics',
            description: 'Uchambuzi wa kina + ML'
        },
        {
            path: '/dashboard/ai-training',
            icon: Icons.brain,
            label: 'AI Training',
            description: 'Fundisha AI ya Kiswahili'
        },
        {
            path: '/dashboard/plugins',
            icon: Icons.settings,
            label: 'Plugin Manager',
            description: 'Washa/Zima plugins'
        }
    ];

    useEffect(() => {
        if (isMwenyekiti) {
            const fetchUnread = async () => {
                try {
                    const res = await axios.get('/api/support/chats', {
                        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                    });
                    setSupportUnread(res.data.filter(c => c.unread_count > 0).length);
                } catch (e) {}
            };
            fetchUnread();
            const interval = setInterval(fetchUnread, 10000);
            return () => clearInterval(interval);
        }
    }, [isMwenyekiti]);

    const isActive = (path) => location.pathname === path;

    const MenuItem = ({ item, onClick }) => {
        const Icon = item.icon;
        return (
            <Link
                to={item.path}
                onClick={onClick}
                className={`flex items-center gap-3 p-3 rounded-xl transition ${
                    isActive(item.path)
                        ? 'bg-white/20 shadow-lg border-l-4 border-[var(--color-secondary)]'
                        : 'hover:bg-white/10'
                }`}
            >
                <div className="relative">
                    <Icon size="lg" />
                    {item.badge > 0 && (
                        <span className="absolute -top-2 -right-2 bg-red-500 text-white 
                            text-xs w-5 h-5 rounded-full flex items-center justify-center 
                            font-bold animate-pulse">
                            {item.badge}
                        </span>
                    )}
                </div>
                <span className="font-medium flex-1 text-sm">{item.label}</span>
            </Link>
        );
    };

    return (
        <div className="w-72 bg-gradient-to-b from-[var(--color-primary)] 
            to-[var(--color-primary)]/90 text-white p-4 flex flex-col 
            shadow-2xl h-screen fixed left-0 top-0 z-40 overflow-y-auto">
            
            {/* Logo */}
            <div className="flex items-center gap-3 mb-6 px-2">
                <div className="w-12 h-12 bg-[var(--color-secondary)] rounded-xl 
                    flex items-center justify-center font-bold text-[var(--color-primary)] 
                    text-2xl shadow-lg">
                    <Icons.gem />
                </div>
                <div>
                    <h1 className="text-lg font-bold">THAMANI YANGU</h1>
                    <p className="text-xs opacity-75">M-KOBA</p>
                </div>
            </div>

            {/* User Info */}
            <div className="mb-4 p-3 bg-white/10 rounded-xl">
                <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-[var(--color-secondary)] rounded-full 
                        flex items-center justify-center font-bold text-[var(--color-primary)]">
                        {user?.first_name?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">
                            {user?.first_name} {user?.last_name}
                        </p>
                        <p className="text-xs opacity-75 capitalize flex items-center gap-1">
                            {isMwenyekiti && <Icons.crown className="text-yellow-300" />}
                            {user?.role}
                        </p>
                    </div>
                </div>
            </div>

            {/* Common Menu */}
            <nav className="space-y-1 mb-4">
                {commonMenuItems.map((item, idx) => (
                    <MenuItem key={idx} item={item} />
                ))}
            </nav>

            {/* Leader Menu - Viongozi wote */}
            {['mwenyekiti', 'katibu', 'mhazini'].includes(user?.role) && (
                <>
                    <div className="text-xs uppercase opacity-50 px-3 mb-2 mt-2">
                        Viongozi
                    </div>
                    <nav className="space-y-1 mb-4">
                        {leaderMenuItems.map((item, idx) => (
                            <MenuItem key={idx} item={item} />
                        ))}
                    </nav>
                </>
            )}

            {/* ============================================================ */}
            {/* SUPER ADMIN - MWENYEKITI PEKEE                               */}
            {/* ============================================================ */}
            {isMwenyekiti && (
                <div className="mt-2 mb-4 border-t border-white/20 pt-4">
                    <button
                        onClick={() => setSuperAdminOpen(!superAdminOpen)}
                        className="w-full flex items-center justify-between p-3 
                            bg-gradient-to-r from-yellow-500/30 to-yellow-600/30 
                            rounded-xl hover:from-yellow-500/40 hover:to-yellow-600/40 
                            transition border border-yellow-400/50"
                    >
                        <div className="flex items-center gap-2">
                            <Icons.crown className="text-yellow-300" size="lg" />
                            <span className="font-bold text-sm">Super Admin</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <span className="text-xs bg-yellow-500 text-yellow-900 
                                px-2 py-0.5 rounded-full font-bold">
                                👑
                            </span>
                            {superAdminOpen 
                                ? <Icons.chevronUp /> 
                                : <Icons.chevronDown />}
                        </div>
                    </button>

                    {superAdminOpen && (
                        <nav className="space-y-1 mt-3 animate-slideIn">
                            {superAdminMenuItems.map((item, idx) => {
                                // Check if plugin enabled (for plugin items)
                                if (item.plugin && !isPluginEnabled(item.plugin)) {
                                    return null;
                                }

                                const Icon = item.icon;
                                return (
                                    <Link
                                        key={idx}
                                        to={item.path}
                                        className={`flex items-center gap-3 p-3 rounded-xl 
                                            transition text-sm ${
                                            isActive(item.path)
                                                ? 'bg-yellow-500/30 border-l-4 border-yellow-400'
                                                : 'hover:bg-white/10'
                                        }`}
                                        title={item.description}
                                    >
                                        <Icon size="md" className="text-yellow-300" />
                                        <span className="font-medium flex-1">
                                            {item.label}
                                        </span>
                                    </Link>
                                );
                            })}
                        </nav>
                    )}
                </div>
            )}

            {/* Settings - Wote */}
            <nav className="space-y-1 mt-auto pt-4 border-t border-white/20">
                <MenuItem item={{ path: '/dashboard/settings', icon: Icons.settings, label: 'Mipangilio' }} />
                <button
                    onClick={logout}
                    className="w-full flex items-center justify-center gap-2 
                        text-sm bg-red-500/20 hover:bg-red-500/40 text-red-100 
                        py-2 rounded-lg transition mt-2"
                >
                    <Icons.logout /> Toka
                </button>
            </nav>
        </div>
    );
};

export default Sidebar;