import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Icons } from './Icon';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const Sidebar = () => {
    const { user, logout } = useAuth();
    const location = useLocation();
    const [supportUnread, setSupportUnread] = useState(0);
    const [isCollapsed, setIsCollapsed] = useState(false);

    useEffect(() => {
        if (user && ['mwenyekiti', 'katibu', 'mhazini'].includes(user.role)) {
            const fetchUnread = async () => {
                try {
                    const res = await axios.get('/api/support/chats', {
                        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                    });
                    setSupportUnread(res.data.filter(c => c.unread_count > 0).length);
                } catch (e) {}
            };
            fetchUnread();
            const interval = setInterval(fetchUnread, 10000);
            return () => clearInterval(interval);
        }
    }, [user]);

    const isActive = (path) => location.pathname === path;

    const menuItems = [
        { path: '/dashboard', icon: Icons.home, label: 'Mwanzo', roles: null },
        { path: '/dashboard/contributions', icon: Icons.money, label: 'Michango', roles: null },
        { path: '/dashboard/membership', icon: Icons.coins, label: 'Ada', roles: null },
        { path: '/dashboard/receipts', icon: Icons.receipt, label: 'Risiti', roles: null },
        { path: '/dashboard/id-card', icon: Icons.idCard, label: 'Kitambulisho', roles: null },
        { path: '/dashboard/chat', icon: Icons.chat, label: 'Mazungumzo', roles: null },
        { path: '/dashboard/ai-buddy', icon: Icons.robot, label: 'AI Buddy', roles: null },
        { path: '/dashboard/video', icon: Icons.video, label: 'Video', roles: null },
        { path: '/dashboard/documents', icon: Icons.file, label: 'Nyaraka', roles: ['mwenyekiti', 'katibu', 'mhazini'] },
        { path: '/dashboard/whatsapp', icon: Icons.whatsapp, label: 'WhatsApp', roles: ['mwenyekiti'] },
        { path: '/dashboard/support', icon: Icons.support, label: 'Msaada', roles: ['mwenyekiti', 'katibu', 'mhazini'], badge: supportUnread },
        { path: '/dashboard/applications', icon: Icons.user, label: 'Maombi', roles: ['mwenyekiti', 'katibu'] },
        { path: '/dashboard/themes', icon: Icons.palette, label: 'Rangi', roles: null },
        { path: '/dashboard/settings', icon: Icons.settings, label: 'Mipangilio', roles: null }
    ];

    return (
        <div className={`${isCollapsed ? 'w-20' : 'w-72'} transition-all duration-300 
            bg-gradient-to-b from-[var(--color-primary)] to-[var(--color-primary)]/90 
            text-white p-4 flex flex-col shadow-2xl h-screen fixed left-0 top-0 z-40`}>
            
            {/* Logo */}
            <div className="flex items-center justify-between mb-8 px-2">
                {!isCollapsed && (
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-[var(--color-secondary)] rounded-xl 
                            flex items-center justify-center font-bold text-[var(--color-primary)] 
                            text-2xl shadow-lg">
                            <Icons.gem />
                        </div>
                        <div>
                            <h1 className="text-lg font-bold">THAMANI YANGU</h1>
                            <p className="text-xs opacity-75">M-KOBA</p>
                        </div>
                    </div>
                )}
                <button
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="p-2 rounded-lg hover:bg-white/10 transition"
                >
                    {isCollapsed ? <Icons.chevronRight /> : <Icons.chevronLeft />}
                </button>
            </div>

            {/* Navigation */}
            <nav className="flex-1 space-y-1 overflow-y-auto">
                {menuItems.map((item, idx) => {
                    if (item.roles && !item.roles.includes(user?.role)) return null;
                    const IconComponent = item.icon;
                    const active = isActive(item.path);

                    return (
                        <Link
                            key={idx}
                            to={item.path}
                            className={`flex items-center gap-3 p-3 rounded-xl transition-all 
                                ${active 
                                    ? 'bg-white/20 shadow-lg scale-105 border-l-4 border-[var(--color-secondary)]' 
                                    : 'hover:bg-white/10'}`}
                            title={isCollapsed ? item.label : ''}
                        >
                            <div className="relative">
                                <IconComponent size="lg" />
                                {item.badge > 0 && (
                                    <span className="absolute -top-2 -right-2 bg-red-500 text-white 
                                        text-xs w-5 h-5 rounded-full flex items-center justify-center 
                                        font-bold shadow-lg animate-pulse">
                                        {item.badge}
                                    </span>
                                )}
                            </div>
                            {!isCollapsed && (
                                <span className="font-medium flex-1">{item.label}</span>
                            )}
                        </Link>
                    );
                })}
            </nav>

            {/* User Info */}
            <div className="border-t border-white/20 pt-4 mt-4">
                {!isCollapsed ? (
                    <>
                        <div className="flex items-center gap-3 mb-3 px-2">
                            <div className="w-10 h-10 bg-[var(--color-secondary)] rounded-full 
                                flex items-center justify-center font-bold text-[var(--color-primary)]">
                                {user?.first_name?.charAt(0) || 'U'}
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="font-semibold text-sm truncate">
                                    {user?.first_name} {user?.last_name}
                                </p>
                                <p className="text-xs opacity-75 capitalize flex items-center gap-1">
                                    {user?.role === 'mwenyekiti' && <Icons.crown className="text-yellow-300" />}
                                    {user?.role}
                                </p>
                            </div>
                        </div>
                        <button
                            onClick={logout}
                            className="w-full flex items-center justify-center gap-2 
                                text-sm bg-red-500/20 hover:bg-red-500/40 text-red-100 
                                py-2 rounded-lg transition"
                        >
                            <Icons.logout /> Toka
                        </button>
                    </>
                ) : (
                    <button
                        onClick={logout}
                        className="w-full p-3 rounded-lg hover:bg-red-500/40 transition text-red-100"
                        title="Toka"
                    >
                        <Icons.logout size="lg" />
                    </button>
                )}
            </div>
        </div>
    );
};

export default Sidebar;