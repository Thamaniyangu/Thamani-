// Ongeza kwenye menuItems:
{ path: '/dashboard/video', icon: Icons.video, label: 'Video', roles: null },
{ path: '/dashboard/applications', icon: Icons.user, label: 'Maombi', roles: ['mwenyekiti', 'katibu'] },
{ path: '/dashboard/themes', icon: Icons.palette, label: 'Rangi', roles: ['mwenyekiti'] },
{ path: '/dashboard/whatsapp', icon: Icons.whatsapp, label: 'WhatsApp', roles: ['mwenyekiti'] },
{ path: '/dashboard/backup', icon: Icons.save, label: 'Backup', roles: ['mwenyekiti'] },