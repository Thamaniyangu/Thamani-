import AIAvatar from './AIAvatar';

// Kwenye menu ya AI:
<Link to="/dashboard/ai-buddy" className="flex items-center gap-3 p-3 rounded hover:bg-teal-700 transition">
    <AIAvatar aiType="buddy" size="xs" />
    <span>AI Buddy</span>
</Link>
<Link to="/dashboard/financial-advisor" className="flex items-center gap-3 p-3 rounded hover:bg-teal-700 transition">
    <AIAvatar aiType="financial" size="xs" />
    <span>Financial Advisor</span>
</Link>
{['mwenyekiti', 'katibu', 'mhazini'].includes(user?.role) && (
    <Link to="/dashboard/leadership-mentor" className="flex items-center gap-3 p-3 rounded hover:bg-teal-700 transition">
        <AIAvatar aiType="leadership" size="xs" />
        <span>Leadership Mentor</span>
    </Link>
)}