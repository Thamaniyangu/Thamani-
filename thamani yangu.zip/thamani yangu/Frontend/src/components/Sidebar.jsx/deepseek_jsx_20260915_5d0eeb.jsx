import { FaWhatsapp } from 'react-icons/fa';

// Kwenye menu:
{user?.role === 'mwenyekiti' && (
    <Link 
        to="/dashboard/whatsapp" 
        className="flex items-center gap-3 p-3 rounded hover:bg-teal-700 transition"
    >
        <FaWhatsapp /> WhatsApp
    </Link>
)}