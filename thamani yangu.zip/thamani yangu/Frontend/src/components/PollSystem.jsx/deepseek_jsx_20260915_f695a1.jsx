import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSocket } from '../context/SocketContext';
import { Icons } from './Icon';
import toast from 'react-hot-toast';

const PollSystem = ({ meetingId, isHost, token }) => {
    const { socket } = useSocket();
    const [polls, setPolls] = useState([]);
    const [showCreate, setShowCreate] = useState(false);
    const [newPoll, setNewPoll] = useState({
        question: '',
        options: ['', ''],
        allowMultiple: false,
        isAnonymous: true,
        durationMinutes: 5
    });

    useEffect(() => {
        fetchPolls();

        if (socket) {
            socket.on('poll-created', (poll) => {
                setPolls(prev => [poll, ...prev]);
            });
            socket.on('poll-updated', (poll) => {
                setPolls(prev => prev.map(p => p.id === poll.id ? poll : p));
            });
            socket.on('poll-closed', (poll) => {
                setPolls(prev => prev.map(p => p.id === poll.id ? poll : p));
            });

            return () => {
                socket.off('poll-created');
                socket.off('poll-updated');
                socket.off('poll-closed');
            };
        }
    }, [socket, meetingId]);

    const fetchPolls = async () => {
        try {
            const res = await axios.get(`/api/polls/meeting/${meetingId}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setPolls(res.data);
        } catch (err) {}
    };

    const addOption = () => {
        setNewPoll(prev => ({ ...prev, options: [...prev.options, ''] }));
    };

    const updateOption = (idx, value) => {
        const opts = [...newPoll.options];
        opts[idx] = value;
        setNewPoll({ ...newPoll, options: opts });
    };

    const removeOption = (idx) => {
        if (newPoll.options.length <= 2) return;
        const opts = newPoll.options.filter((_, i) => i !== idx);
        setNewPoll({ ...newPoll, options: opts });
    };

    const createPoll = async () => {
        const validOptions = newPoll.options.filter(o => o.trim());
        if (!newPoll.question.trim()) return toast.error('Swali linahitajika');
        if (validOptions.length < 2) return toast.error('Chaguo 2+ zinahitajika');

        try {
            await axios.post('/api/polls', {
                meetingId,
                question: newPoll.question,
                options: validOptions,
                allowMultiple: newPoll.allowMultiple,
                isAnonymous: newPoll.isAnonymous,
                durationMinutes: newPoll.durationMinutes
            }, { headers: { Authorization: `Bearer ${token}` } });

            toast.success('Poll imeundwa!');
            setShowCreate(false);
            setNewPoll({ question: '', options: ['', ''], allowMultiple: false, isAnonymous: true, durationMinutes: 5 });
            fetchPolls();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const vote = async (pollId, optionIndex) => {
        try {
            await axios.post(`/api/polls/${pollId}/vote`, { optionIndex }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Kura yako imepokelewa!');
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    const closePoll = async (pollId) => {
        try {
            await axios.post(`/api/polls/${pollId}/close`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Poll imefungwa');
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg flex items-center gap-2">
                    <Icons.chart /> Polls ({polls.length})
                </h3>
                {isHost && (
                    <button
                        onClick={() => setShowCreate(!showCreate)}
                        className="bg-purple-600 text-white px-4 py-2 rounded-lg 
                            flex items-center gap-2 hover:bg-purple-700"
                    >
                        <Icons.plus /> Unda Poll
                    </button>
                )}
            </div>

            {showCreate && isHost && (
                <div className="bg-white rounded-xl p-4 shadow-lg border">
                    <h4 className="font-bold mb-3">Unda Poll</h4>
                    <input
                        type="text"
                        value={newPoll.question}
                        onChange={(e) => setNewPoll({...newPoll, question: e.target.value})}
                        placeholder="Swali (mfano: Tunapenda mkutano ujao lini?)"
                        className="w-full p-3 border rounded-lg mb-3"
                    />
                    
                    {newPoll.options.map((opt, idx) => (
                        <div key={idx} className="flex gap-2 mb-2">
                            <input
                                type="text"
                                value={opt}
                                onChange={(e) => updateOption(idx, e.target.value)}
                                placeholder={`Chaguo ${idx + 1}`}
                                className="flex-1 p-2 border rounded-lg"
                            />
                            {newPoll.options.length > 2 && (
                                <button
                                    onClick={() => removeOption(idx)}
                                    className="px-3 bg-red-500 text-white rounded-lg"
                                >
                                    <Icons.times />
                                </button>
                            )}
                        </div>
                    ))}

                    <button
                        onClick={addOption}
                        className="text-purple-600 text-sm mb-3 flex items-center gap-1"
                    >
                        <Icons.plus /> Ongeza chaguo
                    </button>

                    <div className="space-y-2 mb-3">
                        <label className="flex items-center gap-2">
                            <input
                                type="checkbox"
                                checked={newPoll.isAnonymous}
                                onChange={(e) => setNewPoll({...newPoll, isAnonymous: e.target.checked})}
                            />
                            <span className="text-sm">Kura za siri</span>
                        </label>
                        <div className="flex items-center gap-2">
                            <label className="text-sm">Muda (dakika):</label>
                            <input
                                type="number"
                                value={newPoll.durationMinutes}
                                onChange={(e) => setNewPoll({...newPoll, durationMinutes: parseInt(e.target.value)})}
                                className="w-20 p-2 border rounded"
                                min="1"
                                max="60"
                            />
                        </div>
                    </div>

                    <div className="flex gap-2">
                        <button
                            onClick={createPoll}
                            className="flex-1 bg-purple-600 text-white py-2 rounded-lg font-bold"
                        >
                            Unda
                        </button>
                        <button
                            onClick={() => setShowCreate(false)}
                            className="px-4 bg-gray-200 rounded-lg"
                        >
                            Ghairi
                        </button>
                    </div>
                </div>
            )}

            <div className="space-y-4">
                {polls.map(poll => {
                    const totalVotes = poll.total_votes || 0;
                    return (
                        <div key={poll.id} className="bg-white rounded-xl p-4 shadow border">
                            <div className="flex items-start justify-between mb-3">
                                <h4 className="font-bold flex-1">{poll.question}</h4>
                                {poll.status === 'active' ? (
                                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                                        Active
                                    </span>
                                ) : (
                                    <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                        Imefungwa
                                    </span>
                                )}
                            </div>

                            <div className="space-y-2">
                                {poll.options.map((option, idx) => {
                                    const votes = poll.votes?.[idx] || 0;
                                    const percent = totalVotes > 0 ? (votes / totalVotes * 100) : 0;
                                    return (
                                        <button
                                            key={idx}
                                            onClick={() => poll.status === 'active' && vote(poll.id, idx)}
                                            disabled={poll.status !== 'active'}
                                            className={`w-full text-left p-3 rounded-lg border 
                                                transition relative overflow-hidden 
                                                ${poll.status === 'active' ? 'hover:border-purple-500 cursor-pointer' : 'cursor-default'}`}
                                        >
                                            <div className="absolute inset-0 bg-purple-100" 
                                                style={{ width: `${percent}%`, opacity: 0.5 }}></div>
                                            <div className="relative flex justify-between">
                                                <span className="font-medium">{option}</span>
                                                <span className="text-sm text-gray-600">
                                                    {votes} ({percent.toFixed(1)}%)
                                                </span>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>

                            <div className="flex items-center justify-between mt-3 text-sm text-gray-500">
                                <span>
                                    <Icons.users className="inline mr-1" />
                                    {totalVotes} kura
                                </span>
                                {isHost && poll.status === 'active' && (
                                    <button
                                        onClick={() => closePoll(poll.id)}
                                        className="text-red-600 hover:underline"
                                    >
                                        Funga poll
                                    </button>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default PollSystem;