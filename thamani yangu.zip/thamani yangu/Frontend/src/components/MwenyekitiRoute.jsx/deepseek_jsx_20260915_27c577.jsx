import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Icons } from './Icon';

// ============================================================
// MWENYEKITI ROUTE GUARD
// Inaruhusu Mwenyekiti PEKEE kufikia feature
// ============================================================
const MwenyekitiRoute = ({ children }) => {
    const { user } = useAuth();

    if (!user) {
        return <Navigate to="/login" />;
    }

    if (user.role !== 'mwenyekiti') {
        return (
            <div className="min-h-[60vh] flex items-center justify-center p-6">
                <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md 
                    text-center border-2 border-red-200">
                    <div className="w-20 h-20 bg-red-100 rounded-full 
                        flex items-center justify-center mx-auto mb-4">
                        <Icons.lock size="3x" className="text-red-500" />
                    </div>
                    <h2 className="text-2xl font-bold text-red-600 mb-2">
                        Ufikiaji Umekataliwa
                    </h2>
                    <p className="text-gray-600 mb-4">
                        Kipengele hiki kinapatikana kwa <strong>Mwenyekiti</strong> pekee.
                    </p>
                    <p className="text-sm text-gray-400">
                        Wadhifa wako: <strong className="capitalize">{user.role}</strong>
                    </p>
                    <button
                        onClick={() => window.history.back()}
                        className="mt-6 bg-gray-200 hover:bg-gray-300 px-6 py-2 
                            rounded-lg font-medium"
                    >
                        ← Rudi Nyuma
                    </button>
                </div>
            </div>
        );
    }

    return children;
};

export default MwenyekitiRoute;