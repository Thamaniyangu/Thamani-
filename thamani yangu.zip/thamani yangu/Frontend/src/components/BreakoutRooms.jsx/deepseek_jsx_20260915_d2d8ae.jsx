import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Icons } from './Icon';
import toast from 'react-hot-toast';

const BreakoutRooms = ({ meetingId, participants, token, onJoin }) => {
    const [rooms, setRooms] = useState([]);
    const [showCreate, setShowCreate] = useState(false);
    const [newRoom, setNewRoom] = useState({
        name: '',
        maxParticipants: 10,
        assignedUsers: []
    });

    useEffect(() => {
        fetchRooms();
        const interval = setInterval(fetchRooms, 10000);
        return () => clearInterval(interval);
    }, [meetingId]);

    const fetchRooms = async () => {
        try {
            const res = await axios.get(`/api/breakout/meeting/${meetingId}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setRooms(res.data);
        } catch (err) {}
    };

    const createRoom = async () => {
        if (!newRoom.name.trim()) return toast.error('Jina linahitajika');

        try {
            await axios.post(`/api/breakout/meeting/${meetingId}`, newRoom, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Breakout imeundwa!');
            setShowCreate(false);
            setNewRoom({ name: '', maxParticipants: 10, assignedUsers: [] });
            fetchRooms();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const closeRoom = async (breakoutId) => {
        if (!window.confirm('Funga breakout hii?')) return;
        try {
            await axios.post(`/api/breakout/${breakoutId}/close`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Imefungwa');
            fetchRooms();
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const joinRoom = async (breakoutId) => {
        try {
            const res = await axios.post(`/api/breakout/${breakoutId}/join`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            onJoin(res.data);
            toast.success(`Umejiunga: ${res.data.name}`);
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        }
    };

    const toggleUser = (userId) => {
        setNewRoom(prev => ({
            ...prev,
            assignedUsers: prev.assignedUsers.includes(userId)
                ? prev.assignedUsers.filter(id => id !== userId)
                : [...prev.assignedUsers, userId]
        }));
    };

    return (
        <div className="space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg flex items-center gap-2">
                    <Icons.users /> Breakout Rooms ({rooms.length})
                </h3>
                <button
                    onClick={() => setShowCreate(!showCreate)}
                    className="bg-[var(--color-primary)] text-white px-4 py-2 
                        rounded-lg flex items-center gap-2 hover:opacity-90"
                >
                    <Icons.plus /> Unda
                </button>
            </div>

            {/* Create Form */}
            {showCreate && (
                <div className="bg-white rounded-xl p-4 shadow-lg border">
                    <h4 className="font-bold mb-3">Unda Breakout Mpya</h4>
                    <input
                        type="text"
                        value={newRoom.name}
                        onChange={(e) => setNewRoom({...newRoom, name: e.target.value})}
                        placeholder="Jina la breakout (mfano: Kikundi A)"
                        className="w-full p-3 border rounded-lg mb-3"
                    />
                    <input
                        type="number"
                        value={newRoom.maxParticipants}
                        onChange={(e) => setNewRoom({...newRoom, maxParticipants: parseInt(e.target.value)})}
                        placeholder="Max participants"
                        className="w-full p-3 border rounded-lg mb-3"
                    />
                    
                    <p className="font-medium mb-2">Chagua Washiriki:</p>
                    <div className="max-h-48 overflow-y-auto space-y-2 mb-3">
                        {participants.map(p => (
                            <label key={p.user_id} className="flex items-center gap-2 p-2 
                                hover:bg-gray-50 rounded cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={newRoom.assignedUsers.includes(p.user_id)}
                                    onChange={() => toggleUser(p.user_id)}
                                    className="w-4 h-4"
                                />
                                <span>{p.users?.first_name} {p.users?.last_name}</span>
                            </label>
                        ))}
                    </div>

                    <div className="flex gap-2">
                        <button
                            onClick={createRoom}
                            className="flex-1 bg-[var(--color-primary)] text-white py-2 
                                rounded-lg font-bold"
                        >
                            Unda
                        </button>
                        <button
                            onClick={() => setShowCreate(false)}
                            className="px-4 bg-gray-200 rounded-lg"
                        >
                            Ghairi
                        </button>
                    </div>
                </div>
            )}

            {/* Rooms List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {rooms.map(room => (
                    <div key={room.id} className="bg-white rounded-xl p-4 shadow border">
                        <div className="flex items-center justify-between mb-2">
                            <h4 className="font-bold">{room.name}</h4>
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                                {room.assigned_users.length} washiriki
                            </span>
                        </div>
                        <p className="text-xs text-gray-500 mb-3">
                            <Icons.user className="inline mr-1" />
                            {room.first_name} {room.last_name}
                        </p>
                        <div className="flex gap-2">
                            <button
                                onClick={() => joinRoom(room.id)}
                                className="flex-1 bg-green-500 text-white py-2 rounded-lg 
                                    font-bold flex items-center justify-center gap-2"
                            >
                                <Icons.arrowRight /> Jiunge
                            </button>
                            <button
                                onClick={() => closeRoom(room.id)}
                                className="px-4 bg-red-500 text-white rounded-lg"
                            >
                                <Icons.times />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BreakoutRooms;