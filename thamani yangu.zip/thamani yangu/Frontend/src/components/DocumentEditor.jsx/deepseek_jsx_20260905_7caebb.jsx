import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaTimes, FaPaperPlane, FaMicrophone, FaImage } from 'react-icons/fa';

const SupportChatModal = ({ onClose }) => {
    const [visitorName, setVisitorName] = useState('');
    const [chatId, setChatId] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(false);
    const [isVoiceRecording, setIsVoiceRecording] = useState(false);
    const [mediaRecorder, setMediaRecorder] = useState(null);
    const messagesEndRef = useRef(null);
    const fileInputRef = useRef(null);
    const chatContainerRef = useRef(null);

    // Prevent screenshot on chat (basic protection)
    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.style.userSelect = 'none';
            chatContainerRef.current.style.webkitUserSelect = 'none';
            chatContainerRef.current.addEventListener('contextmenu', e => e.preventDefault());
            // Disable key shortcuts for screenshot
            const handleKeyDown = (e) => {
                if ((e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'p' || e.key === 's')) ||
                    (e.metaKey && e.shiftKey && (e.key === 'i' || e.key === 'p' || e.key === 's'))) {
                    e.preventDefault();
                }
            };
            document.addEventListener('keydown', handleKeyDown);
            return () => document.removeEventListener('keydown', handleKeyDown);
        }
    }, [chatId]);

    // Create support chat
    const createChat = async () => {
        if (!visitorName.trim()) {
            toast.error('Tafadhali andika jina lako');
            return;
        }
        setLoading(true);
        try {
            const res = await axios.post('/api/support/chats', {
                visitor_name: visitorName
            });
            setChatId(res.data.id);
            toast.success('Chat imeanzishwa!');
            pollMessages(res.data.id);
        } catch (err) {
            toast.error(err.response?.data?.error || 'Hitilafu');
        } finally {
            setLoading(false);
        }
    };

    // Poll messages every 3 seconds
    const pollMessages = (id) => {
        const interval = setInterval(async () => {
            try {
                const res = await axios.get(`/api/support/chats/${id}/messages`);
                setMessages(res.data);
            } catch (err) {
                // ignore
            }
        }, 3000);
        window.supportPollInterval = interval;
    };

    // Cleanup on unmount and close chat
    useEffect(() => {
        return () => {
            if (window.supportPollInterval) {
                clearInterval(window.supportPollInterval);
            }
            // Close chat when leaving
            if (chatId) {
                axios.put(`/api/support/chats/${chatId}/close/visitor`)
                    .catch(() => {});
            }
        };
    }, [chatId]);

    // Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    // Send message (text)
    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !chatId) return;

        try {
            const res = await axios.post(`/api/support/chats/${chatId}/messages/visitor`, {
                text: newMessage,
                type: 'text'
            });
            setMessages(prev => [...prev, res.data]);
            setNewMessage('');
        } catch (err) {
            toast.error('Hitilafu kutuma ujumbe');
        }
    };

    // Send file (image)
    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file || !chatId) return;

        // Check file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            toast.error('Picha ni kubwa sana (max 5MB)');
            e.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = async (event) => {
            const base64 = event.target.result.split(',')[1];
            try {
                const res = await axios.post(`/api/support/chats/${chatId}/messages/visitor`, {
                    text: file.name,
                    type: 'image',
                    file_base64: base64,
                    file_name: file.name
                });
                setMessages(prev => [...prev, res.data]);
                toast.success('Picha imetumwa');
            } catch (err) {
                toast.error('Hitilafu kutuma picha');
            }
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    // Voice recording
    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const recorder = new MediaRecorder(stream);
            setMediaRecorder(recorder);
            recorder.start();
            setIsVoiceRecording(true);

            recorder.ondataavailable = async (event) => {
                if (event.data.size > 0) {
                    // Check size (max 2MB)
                    if (event.data.size > 2 * 1024 * 1024) {
                        toast.error('Voice note ni kubwa sana (max 2MB)');
                        return;
                    }
                    const reader = new FileReader();
                    reader.onload = async (e) => {
                        const base64 = e.target.result.split(',')[1];
                        try {
                            await axios.post(`/api/support/chats/${chatId}/messages/visitor`, {
                                text: 'Voice note',
                                type: 'voice',
                                file_base64: base64,
                                file_name: `voice-${Date.now()}.webm`
                            });
                            toast.success('Voice note imetumwa');
                        } catch (err) {
                            toast.error('Hitilafu kutuma voice note');
                        }
                    };
                    reader.readAsDataURL(event.data);
                }
            };
        } catch (err) {
            toast.error('Hitilafu kuanza recording');
        }
    };

    const stopRecording = () => {
        if (mediaRecorder) {
            mediaRecorder.stop();
            setIsVoiceRecording(false);
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
    };

    // Render create chat form
    if (!chatId) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md p-6 border border-teal-200">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-teal-600">Wasiliana na Viongozi</h3>
                        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                            <FaTimes size={24} />
                        </button>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">
                        Tafadhali jaza jina lako ili kuanza mazungumzo.
                        <br />
                        <span className="text-xs text-gray-400">Viongozi wote wataweza kuona ujumbe wako.</span>
                    </p>
                    <input
                        type="text"
                        placeholder="Jina lako kamili"
                        value={visitorName}
                        onChange={(e) => setVisitorName(e.target.value)}
                        className="w-full p-2 border rounded mb-4 focus:ring-2 focus:ring-teal-500"
                    />
                    <button
                        onClick={createChat}
                        disabled={loading}
                        className="w-full bg-gradient-to-r from-teal-600 to-yellow-500 text-white py-2 rounded hover:opacity-90 transition disabled:opacity-50"
                    >
                        {loading ? 'Inaunda...' : 'Anza Mazungumzo'}
                    </button>
                    <p className="text-xs text-gray-400 mt-2 text-center">
                        Mazungumzo yatabaki kwa siku 5 tu.
                    </p>
                </div>
            </div>
        );
    }

    // Render chat window
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" ref={chatContainerRef}>
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md flex flex-col max-h-[80vh] border border-teal-200">
                {/* Header */}
                <div className="flex justify-between items-center p-4 border-b bg-gradient-to-r from-teal-50 to-yellow-50 dark:from-gray-700 dark:to-gray-800 rounded-t-2xl">
                    <h3 className="text-lg font-bold text-teal-600">Msaada</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                        <FaTimes size={20} />
                    </button>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-gray-50 dark:bg-gray-900">
                    {messages.map((msg, idx) => (
                        <div
                            key={idx}
                            className={`max-w-xs p-3 rounded-lg ${
                                msg.sender_type === 'visitor'
                                    ? 'bg-teal-100 text-teal-800 ml-auto'
                                    : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white'
                            }`}
                        >
                            <p className="text-xs font-bold">{msg.sender_name}</p>
                            {msg.type === 'text' && <p>{msg.text}</p>}
                            {msg.type === 'image' && (
                                <img src={msg.file_url} alt="Image" className="max-w-full rounded" />
                            )}
                            {msg.type === 'voice' && (
                                <audio controls src={msg.file_url} className="w-full" />
                            )}
                            <p className="text-xs opacity-70 mt-1">
                                {new Date(msg.created_at).toLocaleTimeString()}
                            </p>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t flex gap-2 items-center bg-white dark:bg-gray-800 rounded-b-2xl">
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                        className="hidden"
                        accept="image/*"
                    />
                    <button
                        onClick={() => fileInputRef.current.click()}
                        className="text-teal-600 hover:text-teal-800"
                    >
                        <FaImage size={20} />
                    </button>
                    <button
                        onMouseDown={startRecording}
                        onMouseUp={stopRecording}
                        onTouchStart={startRecording}
                        onTouchEnd={stopRecording}
                        className={`${isVoiceRecording ? 'text-red-500' : 'text-teal-600'} hover:text-teal-800`}
                    >
                        <FaMicrophone size={20} />
                    </button>
                    <form onSubmit={sendMessage} className="flex-1 flex gap-2">
                        <input
                            type="text"
                            placeholder="Andika ujumbe..."
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            className="flex-1 p-2 border rounded focus:ring-2 focus:ring-teal-500 dark:bg-gray-700 dark:border-gray-600"
                        />
                        <button type="submit" className="bg-teal-600 text-white px-3 py-2 rounded hover:bg-teal-700">
                            <FaPaperPlane size={16} />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default SupportChatModal;