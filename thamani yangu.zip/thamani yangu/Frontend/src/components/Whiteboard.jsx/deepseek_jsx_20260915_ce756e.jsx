import React, { useRef, useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { useSocket } from '../context/SocketContext';
import { Icons } from './Icon';
import toast from 'react-hot-toast';

const Whiteboard = ({ meetingId, whiteboardId, token, readOnly = false }) => {
    const { socket } = useSocket();
    const canvasRef = useRef();
    const [ctx, setCtx] = useState(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [tool, setTool] = useState('pen');
    const [color, setColor] = useState('#000000');
    const [width, setWidth] = useState(2);
    const [strokes, setStrokes] = useState([]);
    const currentPointsRef = useRef([]);

    // Initialize canvas
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const context = canvas.getContext('2d');
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;

        context.fillStyle = 'white';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.lineCap = 'round';
        context.lineJoin = 'round';

        setCtx(context);
    }, []);

    // Load strokes
    useEffect(() => {
        if (!whiteboardId) return;

        const loadStrokes = async () => {
            try {
                const res = await axios.get(`/api/whiteboards/${whiteboardId}/strokes`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setStrokes(res.data);
                redrawAll(res.data);
            } catch (err) {}
        };

        loadStrokes();

        if (socket) {
            socket.emit('join-whiteboard', whiteboardId);

            socket.on('stroke-added', (stroke) => {
                setStrokes(prev => [...prev, stroke]);
                drawStroke(stroke);
            });

            socket.on('whiteboard-cleared', () => {
                clearCanvas();
                setStrokes([]);
            });

            socket.on('stroke-removed', ({ strokeId }) => {
                setStrokes(prev => prev.filter(s => s.id !== strokeId));
                redrawAll(strokes.filter(s => s.id !== strokeId));
            });

            return () => {
                socket.emit('leave-whiteboard', whiteboardId);
                socket.off('stroke-added');
                socket.off('whiteboard-cleared');
                socket.off('stroke-removed');
            };
        }
    }, [socket, whiteboardId, token]);

    const redrawAll = (strokesList) => {
        if (!ctx) return;
        clearCanvas();
        strokesList.forEach(stroke => drawStroke(stroke));
    };

    const clearCanvas = () => {
        if (!ctx) return;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    };

    const drawStroke = (stroke) => {
        if (!ctx) return;

        if (stroke.tool === 'eraser') {
            ctx.strokeStyle = 'white';
            ctx.lineWidth = (stroke.width || 2) * 5;
        } else {
            ctx.strokeStyle = stroke.color || '#000000';
            ctx.lineWidth = stroke.width || 2;
        }

        if (stroke.tool === 'text' && stroke.text) {
            ctx.fillStyle = stroke.color || '#000000';
            ctx.font = `${(stroke.width || 2) * 8}px Inter`;
            ctx.fillText(stroke.text, stroke.points[0].x, stroke.points[0].y);
            return;
        }

        if (stroke.points && stroke.points.length > 0) {
            ctx.beginPath();
            ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
            for (let i = 1; i < stroke.points.length; i++) {
                ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
            }
            ctx.stroke();
        }
    };

    const getCoordinates = (e) => {
        const rect = canvasRef.current.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    };

    const startDrawing = (e) => {
        if (readOnly) return;
        e.preventDefault();
        const coords = getCoordinates(e);
        currentPointsRef.current = [coords];
        setIsDrawing(true);

        ctx.beginPath();
        ctx.moveTo(coords.x, coords.y);
    };

    const draw = (e) => {
        if (!isDrawing || readOnly) return;
        e.preventDefault();
        const coords = getCoordinates(e);
        currentPointsRef.current.push(coords);

        if (tool === 'eraser') {
            ctx.strokeStyle = 'white';
            ctx.lineWidth = width * 5;
        } else {
            ctx.strokeStyle = color;
            ctx.lineWidth = width;
        }

        ctx.lineTo(coords.x, coords.y);
        ctx.stroke();
    };

    const stopDrawing = async (e) => {
        if (!isDrawing || readOnly) return;
        setIsDrawing(false);
        ctx.closePath();

        const points = currentPointsRef.current;
        if (points.length < 2) return;

        try {
            await axios.post(`/api/whiteboards/${whiteboardId}/stroke`, {
                tool, color, width, points
            }, { headers: { Authorization: `Bearer ${token}` } });
        } catch (err) {
            console.error('Save stroke error:', err);
        }

        currentPointsRef.current = [];
    };

    const undo = async () => {
        try {
            await axios.delete(`/api/whiteboards/${whiteboardId}/undo`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Umefuta');
        } catch (err) {
            toast.error('Hakuna kitu cha kufuta');
        }
    };

    const clearAll = async () => {
        if (!window.confirm('Futa kila kitu?')) return;
        try {
            await axios.delete(`/api/whiteboards/${whiteboardId}/clear`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            toast.success('Imefutwa');
        } catch (err) {
            toast.error('Hitilafu');
        }
    };

    const colors = ['#000000', '#EF4444', '#10B981', '#3B82F6', '#F59E0B', '#8B5CF6', '#EC4899', '#FFFFFF'];

    return (
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            {/* Toolbar */}
            <div className="bg-gray-100 p-3 flex items-center gap-2 flex-wrap border-b">
                {/* Tools */}
                <button
                    onClick={() => setTool('pen')}
                    className={`p-2 rounded-lg ${tool === 'pen' ? 'bg-[var(--color-primary)] text-white' : 'bg-white'}`}
                    title="Kalamu"
                >
                    <Icons.edit />
                </button>
                <button
                    onClick={() => setTool('eraser')}
                    className={`p-2 rounded-lg ${tool === 'eraser' ? 'bg-[var(--color-primary)] text-white' : 'bg-white'}`}
                    title="Kifutio"
                >
                    <Icons.times />
                </button>
                <button
                    onClick={undo}
                    className="p-2 rounded-lg bg-white"
                    title="Undo"
                >
                    <Icons.undo />
                </button>
                <button
                    onClick={clearAll}
                    className="p-2 rounded-lg bg-red-500 text-white"
                    title="Futa yote"
                >
                    <Icons.trash />
                </button>

                <div className="w-px h-6 bg-gray-300 mx-1"></div>

                {/* Colors */}
                <div className="flex gap-1">
                    {colors.map(c => (
                        <button
                            key={c}
                            onClick={() => { setColor(c); setTool('pen'); }}
                            className={`w-8 h-8 rounded-full border-2 ${color === c ? 'border-gray-800 scale-110' : 'border-gray-300'}`}
                            style={{ backgroundColor: c }}
                        />
                    ))}
                </div>

                <div className="w-px h-6 bg-gray-300 mx-1"></div>

                {/* Width */}
                <select
                    value={width}
                    onChange={(e) => setWidth(parseInt(e.target.value))}
                    className="p-2 border rounded-lg text-sm"
                >
                    <option value="1">Nyembamba</option>
                    <option value="2">Kawaida</option>
                    <option value="4">Nene</option>
                    <option value="8">Nene sana</option>
                </select>
            </div>

            {/* Canvas */}
            <div className="relative">
                <canvas
                    ref={canvasRef}
                    className="w-full h-[600px] cursor-crosshair touch-none"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                />
            </div>
        </div>
    );
};

export default Whiteboard;