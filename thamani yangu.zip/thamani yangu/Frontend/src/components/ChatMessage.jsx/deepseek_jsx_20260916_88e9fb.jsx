import React from 'react';
import { FaRobot, FaChartLine, FaCrown, FaCheckCircle } from 'react-icons/fa';

const ChatMessage = ({ message, isMine, currentUserRole }) => {
    const isAI = message.is_ai || message.sender_member_id === 'AI';

    // ============================================================
    // RENDER AI MESSAGE (Clean, formatted, respectful)
    // ============================================================
    if (isAI) {
        return (
            <div className="flex items-start gap-2 mb-3">
                {/* AI Avatar */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white flex-shrink-0 ${
                    message.sender_name?.includes('FINANCIAL') ? 'bg-green-600' :
                    message.sender_name?.includes('LEADERSHIP') ? 'bg-yellow-600' :
                    'bg-teal-600'
                }`}>
                    {message.sender_name?.includes('FINANCIAL') ? <FaChartLine /> :
                     message.sender_name?.includes('LEADERSHIP') ? <FaCrown /> :
                     <FaRobot />}
                </div>

                {/* AI Message Body */}
                <div className="flex-1 max-w-2xl">
                    {/* AI Name */}
                    <div className="flex items-center gap-2 mb-1">
                        <p className={`text-xs font-bold ${
                            message.sender_name?.includes('FINANCIAL') ? 'text-green-600' :
                            message.sender_name?.includes('LEADERSHIP') ? 'text-yellow-600' :
                            'text-teal-600'
                        }`}>
                            {message.sender_name}
                        </p>
                        {/* Provider (Mwenyekiti only) */}
                        {currentUserRole === 'mwenyekiti' && message.provider && (
                            <span className="text-xs text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                                🔧 {message.provider}
                            </span>
                        )}
                    </div>

                    {/* AI Response (formatted) */}
                    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 p-3 rounded-lg border-l-4 border-teal-500">
                        <div className="text-sm whitespace-pre-wrap leading-relaxed text-gray-800 dark:text-gray-200">
                            {formatAIResponse(message.text)}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // ============================================================
    // RENDER USER MESSAGE
    // ============================================================
    return (
        <div className={`flex items-start gap-2 mb-3 ${isMine ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 ${
                isMine ? 'bg-teal-600' : 'bg-gray-500'
            }`}>
                {message.sender_name?.charAt(0) || '?'}
            </div>
            <div className={`max-w-2xl ${isMine ? 'text-right' : ''}`}>
                <p className="text-xs text-gray-500 mb-1">
                    {message.sender_name} • {new Date(message.created_at).toLocaleTimeString('sw-TZ', { hour: '2-digit', minute: '2-digit' })}
                </p>
                <div className={`p-3 rounded-lg ${
                    isMine 
                        ? 'bg-teal-500 text-white' 
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}>
                    <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                </div>
            </div>
        </div>
    );
};

// ============================================================
// FORMAT AI RESPONSE (Markdown-like)
// ============================================================
function formatAIResponse(text) {
    if (!text) return '';
    
    // Convert **bold** to bold
    let formatted = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    
    // Convert lines starting with - or • to list items
    formatted = formatted.replace(/^[-•]\s+(.+)$/gm, '<li>$1</li>');
    
    // Wrap consecutive li elements in ul
    formatted = formatted.replace(/(<li>.*<\/li>)/s, '<ul class="list-disc pl-4 space-y-1">$1</ul>');
    
    // Convert numbered lines
    formatted = formatted.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');
    
    return <div dangerouslySetInnerHTML={{ __html: formatted }} />;
}

export default ChatMessage;