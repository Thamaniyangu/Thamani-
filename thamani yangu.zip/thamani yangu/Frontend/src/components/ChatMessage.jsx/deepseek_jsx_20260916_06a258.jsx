import React from 'react';
import { FaRobot, FaChartLine, FaCrown, FaExchangeAlt } from 'react-icons/fa';

const ChatMessage = ({ message, isMine, currentUserRole }) => {
    const isAI = message.is_ai || message.sender_member_id === 'AI';
    const isNotice = message.is_notice;

    // ============================================================
    // HANDOFF NOTICE (System message)
    // ============================================================
    if (isNotice) {
        return (
            <div className="flex justify-center my-2">
                <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-full px-4 py-1.5 flex items-center gap-2">
                    <FaExchangeAlt className="text-purple-600 text-xs" />
                    <p className="text-xs text-purple-700 dark:text-purple-300 italic">
                        {message.text}
                    </p>
                </div>
            </div>
        );
    }

    // ============================================================
    // AI MESSAGE
    // ============================================================
    if (isAI) {
        return (
            <div className="flex items-start gap-2 mb-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white flex-shrink-0 ${
                    message.sender_name?.includes('FINANCIAL') ? 'bg-green-600' :
                    message.sender_name?.includes('LEADERSHIP') ? 'bg-yellow-600' :
                    'bg-teal-600'
                }`}>
                    {message.sender_name?.includes('FINANCIAL') ? <FaChartLine /> :
                     message.sender_name?.includes('LEADERSHIP') ? <FaCrown /> :
                     <FaRobot />}
                </div>

                <div className="flex-1 max-w-2xl">
                    <div className="flex items-center gap-2 mb-1">
                        <p className={`text-xs font-bold ${
                            message.sender_name?.includes('FINANCIAL') ? 'text-green-600' :
                            message.sender_name?.includes('LEADERSHIP') ? 'text-yellow-600' :
                            'text-teal-600'
                        }`}>
                            {message.sender_name}
                        </p>
                        {currentUserRole === 'mwenyekiti' && message.provider && (
                            <span className="text-xs text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                                🔧 {message.provider}
                            </span>
                        )}
                    </div>

                    <div className={`p-3 rounded-lg border-l-4 ${
                        message.sender_name?.includes('FINANCIAL') ? 'bg-green-50 dark:bg-green-900/20 border-green-500' :
                        message.sender_name?.includes('LEADERSHIP') ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-500' :
                        'bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 border-teal-500'
                    }`}>
                        <div className="text-sm whitespace-pre-wrap leading-relaxed text-gray-800 dark:text-gray-200">
                            {formatAIResponse(message.text)}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // ============================================================
    // USER MESSAGE
    // ============================================================
    return (
        <div className={`flex items-start gap-2 mb-3 ${isMine ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 ${
                isMine ? 'bg-teal-600' : 'bg-gray-500'
            }`}>
                {message.sender_name?.charAt(0) || '?'}
            </div>
            <div className={`max-w-2xl ${isMine ? 'text-right' : ''}`}>
                <p className="text-xs text-gray-500 mb-1">
                    {message.sender_name} • {new Date(message.created_at).toLocaleTimeString('sw-TZ', { hour: '2-digit', minute: '2-digit' })}
                </p>
                <div className={`p-3 rounded-lg ${
                    isMine 
                        ? 'bg-teal-500 text-white' 
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}>
                    <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                </div>
            </div>
        </div>
    );
};

// ============================================================
// FORMAT AI RESPONSE
// ============================================================
function formatAIResponse(text) {
    if (!text) return '';
    let formatted = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/^[-•]\s+(.+)$/gm, '<li>$1</li>');
    formatted = formatted.replace(/(<li>.*<\/li>)/s, '<ul class="list-disc pl-4 space-y-1">$1</ul>');
    formatted = formatted.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');
    return <div dangerouslySetInnerHTML={{ __html: formatted }} />;
}

export default ChatMessage;