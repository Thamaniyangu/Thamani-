import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Icons } from './Icon';

const LanguageSwitcher = () => {
    const { language, setLanguage } = useLanguage();

    const languages = [
        { code: 'sw', name: 'Kiswahili', flag: '🇹🇿' },
        { code: 'en', name: 'English', flag: '🇬🇧' }
    ];

    return (
        <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 rounded-full p-1">
            {languages.map(lang => (
                <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className={`px-3 py-1.5 rounded-full text-sm font-medium transition flex items-center gap-2 ${
                        language === lang.code
                            ? 'bg-[var(--color-primary)] text-white'
                            : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                >
                    <span>{lang.flag}</span>
                    <span className="hidden md:inline">{lang.name}</span>
                </button>
            ))}
        </div>
    );
};

export default LanguageSwitcher;