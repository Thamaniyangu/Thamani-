import React from 'react';
import { useDarkMode } from '../context/DarkModeContext';
import { Icons } from './Icon';

const DarkModeToggle = () => {
    const { mode, setMode, isDark } = useDarkMode();

    const modes = [
        { value: 'light', icon: Icons.sun, label: 'Mwanga' },
        { value: 'auto', icon: Icons.globe, label: 'Auto' },
        { value: 'dark', icon: Icons.moon, label: 'Giza' }
    ];

    return (
        <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 rounded-full p-1">
            {modes.map(m => {
                const Icon = m.icon;
                return (
                    <button
                        key={m.value}
                        onClick={() => setMode(m.value)}
                        className={`p-2 rounded-full transition ${
                            mode === m.value
                                ? 'bg-[var(--color-primary)] text-white'
                                : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                        }`}
                        title={m.label}
                    >
                        <Icon size="sm" />
                    </button>
                );
            })}
        </div>
    );
};

export default DarkModeToggle;