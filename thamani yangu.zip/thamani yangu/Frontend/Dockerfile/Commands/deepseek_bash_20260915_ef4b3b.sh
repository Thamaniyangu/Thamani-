# Start
docker-compose up -d

# With monitoring
docker-compose --profile monitoring up -d

# Logs
docker-compose logs -f backend

# Stop
docker-compose down

# Rebuild
docker-compose up -d --build

# Database backup from Docker
docker exec thamani-mysql mysqldump -u root -p${MYSQL_ROOT_PASSWORD} thamani_yangu > backup.sql