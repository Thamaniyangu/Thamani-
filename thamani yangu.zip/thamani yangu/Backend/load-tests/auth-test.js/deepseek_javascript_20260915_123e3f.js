import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

const errorRate = new Rate('errors');

export const options = {
    stages: [
        { duration: '1m', target: 50 },   // Ramp up to 50
        { duration: '2m', target: 200 },  // Ramp up to 200
        { duration: '3m', target: 500 },  // Ramp up to 500
        { duration: '5m', target: 500 },  // Stay at 500
        { duration: '2m', target: 1000 }, // Spike to 1000
        { duration: '3m', target: 500 },  // Back to 500
        { duration: '2m', target: 0 },    // Ramp down
    ],
    thresholds: {
        http_req_duration: ['p(95)<500', 'p(99)<1000'],
        http_req_failed: ['rate<0.01'], // <1% errors
        errors: ['rate<0.01'],
    },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';

export function setup() {
    // Create test user
    const registerRes = http.post(`${BASE_URL}/api/auth/login`, JSON.stringify({
        username: 'TYM-2026-001',
        password: 'Thamani@001'
    }), {
        headers: { 'Content-Type': 'application/json' }
    });

    const token = registerRes.json('token');
    return { token };
}

export default function (data) {
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${data.token}`
    };

    // Test 1: Get user profile
    const meRes = http.get(`${BASE_URL}/api/auth/me`, { headers });
    check(meRes, {
        'me: status 200': (r) => r.status === 200,
    }) || errorRate.add(1);

    sleep(1);

    // Test 2: Get contributions
    const contribRes = http.get(`${BASE_URL}/api/contributions`, { headers });
    check(contribRes, {
        'contributions: status 200': (r) => r.status === 200,
    }) || errorRate.add(1);

    sleep(1);

    // Test 3: Get chat rooms
    const chatRes = http.get(`${BASE_URL}/api/chat/rooms`, { headers });
    check(chatRes, {
        'chat rooms: status 200': (r) => r.status === 200,
    }) || errorRate.add(1);

    sleep(2);
}