import http from 'k6/http';
import { check, sleep } from 'k6';
import ws from 'k6/ws';

export const options = {
    stages: [
        { duration: '30s', target: 100 },
        { duration: '2m', target: 500 },
        { duration: '5m', target: 500 },
        { duration: '30s', target: 0 },
    ],
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';
const WS_URL = __ENV.WS_URL || 'ws://localhost:5000';

export function setup() {
    const res = http.post(`${BASE_URL}/api/auth/login`, JSON.stringify({
        username: `TYM-2026-${String(__VU).padStart(3, '0')}`,
        password: 'Thamani@123'
    }), {
        headers: { 'Content-Type': 'application/json' }
    });

    return { token: res.json('token'), userId: res.json('user.id') };
}

export default function (data) {
    const url = `${WS_URL}/socket.io/?userId=${data.userId}&EIO=4&transport=websocket`;

    const res = ws.connect(url, {}, function (socket) {
        socket.on('open', () => {
            console.log('WebSocket connected');
            socket.send('40'); // Socket.io namespace connect
        });

        socket.on('message', (msg) => {
            // Handle messages
        });

        socket.on('close', () => {});

        // Send messages periodically
        for (let i = 0; i < 10; i++) {
            socket.setTimeout(() => {
                const event = JSON.stringify(['send-message', {
                    roomId: 'test-room-id',
                    message: { text: `Test message ${i}` }
                }]);
                socket.send(`42${event}`);
            }, i * 1000);
        }

        socket.setTimeout(() => socket.close(), 15000);
    });

    check(res, { 'WebSocket connected': (r) => r && r.status === 101 });
    sleep(1);
}