import http from 'k6/http';
import { check } from 'k6';

export const options = {
    scenarios: {
        spike: {
            executor: 'ramping-vus',
            startVUs: 0,
            stages: [
                { duration: '10s', target: 100 },
                { duration: '10s', target: 2000 }, // SPIKE!
                { duration: '1m', target: 2000 },
                { duration: '10s', target: 0 },
            ],
        },
    },
};

export default function () {
    const res = http.get('http://localhost:5000/health');
    check(res, {
        'health check OK': (r) => r.status === 200,
    });
}