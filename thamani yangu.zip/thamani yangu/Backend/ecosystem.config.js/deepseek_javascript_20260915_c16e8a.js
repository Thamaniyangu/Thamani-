module.exports = {
    apps: [
        {
            name: 'thamani-backend',
            script: './src/server.js',
            instances: 'max',        // Tumia cores zote
            exec_mode: 'cluster',     // Load balancing
            watch: false,
            max_memory_restart: '500M',
            env: {
                NODE_ENV: 'production',
                PORT: 5000
            },
            error_file: './logs/error.log',
            out_file: './logs/out.log',
            log_date_format: 'YYYY-MM-DD HH:mm:ss',
            merge_logs: true,
            autorestart: true,
            max_restarts: 10,
            restart_delay: 4000
        }
    ]
};