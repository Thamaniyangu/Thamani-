const cron = require('node-cron');
const campaignEngine = require('./services/campaignEngine');

module.exports = () => {
    // Process due journeys every minute
    cron.schedule('* * * * *', async () => {
        try {
            const count = await campaignEngine.processDueJourneys();
            if (count > 0) {
                console.log(`✅ Processed ${count} journeys`);
            }
        } catch (err) {
            console.error('Journey cron error:', err);
        }
    });

    // Birthday checker (daily at 8 AM)
    cron.schedule('0 8 * * *', async () => {
        const mysql = require('../../src/config/mysql');
        const users = await mysql.query(`
            SELECT id FROM users 
            WHERE DAY(date_of_birth) = DAY(NOW()) 
              AND MONTH(date_of_birth) = MONTH(NOW())
        `);
        for (const u of users) {
            await campaignEngine.processTrigger('birthday', u.id);
        }
        console.log(`🎂 Processed ${users.length} birthdays`);
    });

    // Inactive member checker (daily at midnight)
    cron.schedule('0 0 * * *', async () => {
        const mysql = require('../../src/config/mysql');
        const users = await mysql.query(`
            SELECT u.id FROM users u
            LEFT JOIN (
                SELECT user_id, MAX(created_at) as last_contribution
                FROM contributions
                GROUP BY user_id
            ) c ON u.id = c.user_id
            WHERE DATEDIFF(NOW(), COALESCE(c.last_contribution, u.created_at)) > 30
              AND u.status = 'active'
        `);
        for (const u of users) {
            await campaignEngine.processTrigger('inactive_30_days', u.id);
        }
        console.log(`💤 Processed ${users.length} inactive members`);
    });

    // Savings milestone checker (daily)
    cron.schedule('0 9 * * *', async () => {
        const mysql = require('../../src/config/mysql');
        const milestones = [50000, 100000, 500000, 1000000, 5000000, 10000000];
        for (const milestone of milestones) {
            const users = await mysql.query(`
                SELECT user_id, SUM(amount) as total
                FROM contributions
                WHERE type = 'hisa'
                GROUP BY user_id
                HAVING total >= ? AND total < ?
            `, [milestone, milestone * 1.5]);
            
            for (const u of users) {
                await campaignEngine.processTrigger('savings_milestone', u.user_id, {
                    milestone
                });
            }
        }
    });

    console.log('✅ Marketing Automation crons registered');
};