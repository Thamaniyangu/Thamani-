-- ============================================================
-- MARKETING AUTOMATION
-- ============================================================

-- Campaigns
CREATE TABLE IF NOT EXISTS ma_campaigns (
    id CHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    trigger_type VARCHAR(50) NOT NULL,
    trigger_config JSON,
    status VARCHAR(20) DEFAULT 'draft',
    goal VARCHAR(50),
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    total_sent INT DEFAULT 0,
    total_opened INT DEFAULT 0,
    total_clicked INT DEFAULT 0,
    total_converted INT DEFAULT 0,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_trigger_type (trigger_type),
    INDEX idx_created_at (created_at DESC)
) ENGINE=InnoDB;

-- Campaign steps (workflow)
CREATE TABLE IF NOT EXISTS ma_campaign_steps (
    id CHAR(36) PRIMARY KEY,
    campaign_id CHAR(36) NOT NULL,
    step_order INT NOT NULL,
    step_type VARCHAR(20) NOT NULL,
    delay_hours INT DEFAULT 0,
    condition_type VARCHAR(50),
    condition_config JSON,
    action_type VARCHAR(50) NOT NULL,
    action_config JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_campaign_id (campaign_id),
    INDEX idx_step_order (step_order),
    FOREIGN KEY (campaign_id) REFERENCES ma_campaigns(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Templates
CREATE TABLE IF NOT EXISTS ma_templates (
    id CHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    channel VARCHAR(20) NOT NULL,
    subject VARCHAR(255),
    content TEXT NOT NULL,
    variables JSON,
    category VARCHAR(50),
    is_default BOOLEAN DEFAULT FALSE,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_channel (channel),
    INDEX idx_category (category)
) ENGINE=InnoDB;

-- User journey (state per user)
CREATE TABLE IF NOT EXISTS ma_user_journeys (
    id CHAR(36) PRIMARY KEY,
    campaign_id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    current_step INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    next_action_at TIMESTAMP NULL,
    metadata JSON,
    UNIQUE KEY unique_user_campaign (campaign_id, user_id),
    INDEX idx_campaign_id (campaign_id),
    INDEX idx_user_id (user_id),
    INDEX idx_next_action (next_action_at),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- Sent messages (analytics)
CREATE TABLE IF NOT EXISTS ma_sent_messages (
    id CHAR(36) PRIMARY KEY,
    campaign_id CHAR(36),
    step_id CHAR(36),
    user_id CHAR(36) NOT NULL,
    channel VARCHAR(20) NOT NULL,
    subject VARCHAR(255),
    content TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    sent_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    opened_at TIMESTAMP NULL,
    clicked_at TIMESTAMP NULL,
    failed_reason TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_campaign_id (campaign_id),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_channel (channel),
    INDEX idx_sent_at (sent_at)
) ENGINE=InnoDB;

-- Email open tracking
CREATE TABLE IF NOT EXISTS ma_email_opens (
    id CHAR(36) PRIMARY KEY,
    message_id CHAR(36) NOT NULL,
    opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip VARCHAR(45),
    user_agent TEXT,
    INDEX idx_message_id (message_id)
) ENGINE=InnoDB;

-- Link clicks
CREATE TABLE IF NOT EXISTS ma_link_clicks (
    id CHAR(36) PRIMARY KEY,
    message_id CHAR(36) NOT NULL,
    link_url TEXT,
    clicked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip VARCHAR(45),
    user_agent TEXT,
    INDEX idx_message_id (message_id)
) ENGINE=InnoDB;