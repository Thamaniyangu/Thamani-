const mysql = require('../../../src/config/mysql');
const campaignEngine = require('../services/campaignEngine');
const defaultTemplates = require('../templates/default-templates');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE CAMPAIGN
// ============================================================
exports.createCampaign = async (req, res) => {
    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    const { name, description, trigger_type, trigger_config, goal, steps } = req.body;

    try {
        const id = uuidv4();
        await mysql.query(`
            INSERT INTO ma_campaigns 
            (id, name, description, trigger_type, trigger_config, goal, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?, 'draft', ?)
        `, [
            id, name, description || null, trigger_type,
            JSON.stringify(trigger_config || {}),
            goal || 'engagement',
            req.user.id
        ]);

        // Add steps
        if (steps && steps.length > 0) {
            for (const step of steps) {
                await mysql.query(`
                    INSERT INTO ma_campaign_steps 
                    (id, campaign_id, step_order, step_type, delay_hours, condition_type, condition_config, action_type, action_config)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    uuidv4(), id, step.step_order, step.step_type || 'message',
                    step.delay_hours || 0,
                    step.condition_type || null,
                    step.condition_config ? JSON.stringify(step.condition_config) : null,
                    step.action_type, JSON.stringify(step.action_config || {})
                ]);
            }
        }

        res.json({ id, message: 'Campaign imeundwa' });
    } catch (err) {
        console.error('Create campaign error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// ACTIVATE CAMPAIGN
// ============================================================
exports.activateCampaign = async (req, res) => {
    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    const { campaignId } = req.params;

    try {
        await mysql.query(`
            UPDATE ma_campaigns SET status = 'active', started_at = NOW() WHERE id = ?
        `, [campaignId]);

        res.json({ message: 'Campaign imewashwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// PAUSE CAMPAIGN
// ============================================================
exports.pauseCampaign = async (req, res) => {
    const { campaignId } = req.params;

    await mysql.query(`
        UPDATE ma_campaigns SET status = 'paused' WHERE id = ?
    `, [campaignId]);

    res.json({ message: 'Campaign imesimamishwa' });
};

// ============================================================
// LIST CAMPAIGNS
// ============================================================
exports.listCampaigns = async (req, res) => {
    const campaigns = await mysql.query(`
        SELECT c.*, u.first_name as creator_name,
            (SELECT COUNT(*) FROM ma_user_journeys WHERE campaign_id = c.id) as total_users,
            (SELECT COUNT(*) FROM ma_user_journeys WHERE campaign_id = c.id AND status = 'completed') as completed
        FROM ma_campaigns c
        LEFT JOIN users u ON c.created_by = u.id
        ORDER BY c.created_at DESC
    `);
    res.json(campaigns);
};

// ============================================================
// GET CAMPAIGN DETAILS
// ============================================================
exports.getCampaign = async (req, res) => {
    const { campaignId } = req.params;

    const campaign = await mysql.queryOne(`
        SELECT * FROM ma_campaigns WHERE id = ?
    `, [campaignId]);

    if (!campaign) return res.status(404).json({ error: 'Haipatikani' });

    const steps = await mysql.query(`
        SELECT * FROM ma_campaign_steps 
        WHERE campaign_id = ? ORDER BY step_order ASC
    `, [campaignId]);

    res.json({
        ...campaign,
        trigger_config: JSON.parse(campaign.trigger_config || '{}'),
        steps: steps.map(s => ({
            ...s,
            condition_config: s.condition_config ? JSON.parse(s.condition_config) : null,
            action_config: JSON.parse(s.action_config || '{}')
        }))
    });
};

// ============================================================
// SEED DEFAULT CAMPAIGNS
// ============================================================
exports.seedDefaultCampaigns = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const created = [];
        for (const template of defaultTemplates) {
            const { steps, ...campaignData } = template;
            const id = uuidv4();

            await mysql.query(`
                INSERT INTO ma_campaigns 
                (id, name, description, trigger_type, trigger_config, goal, status, created_by)
                VALUES (?, ?, ?, ?, ?, ?, 'draft', ?)
            `, [
                id, campaignData.name, campaignData.description,
                campaignData.trigger_type, JSON.stringify(campaignData.trigger_config),
                campaignData.goal, req.user.id
            ]);

            for (const step of steps) {
                await mysql.query(`
                    INSERT INTO ma_campaign_steps 
                    (id, campaign_id, step_order, step_type, delay_hours, condition_type, condition_config, action_type, action_config)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    uuidv4(), id, step.step_order, step.step_type,
                    step.delay_hours, step.condition_type || null,
                    step.condition_config ? JSON.stringify(step.condition_config) : null,
                    step.action_type, JSON.stringify(step.action_config)
                ]);
            }

            created.push({ id, name: campaignData.name });
        }

        res.json({ message: `${created.length} campaigns zimeundwa`, campaigns: created });
    } catch (err) {
        console.error('Seed campaigns error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CAMPAIGN STATS
// ============================================================
exports.getCampaignStats = async (req, res) => {
    const { campaignId } = req.params;

    const stats = await mysql.queryOne(`
        SELECT 
            COUNT(*) as total_users,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'stopped' THEN 1 ELSE 0 END) as stopped
        FROM ma_user_journeys WHERE campaign_id = ?
    `, [campaignId]);

    const messages = await mysql.queryOne(`
        SELECT 
            COUNT(*) as total_sent,
            SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN opened_at IS NOT NULL THEN 1 ELSE 0 END) as opened,
            SUM(CASE WHEN clicked_at IS NOT NULL THEN 1 ELSE 0 END) as clicked
        FROM ma_sent_messages WHERE campaign_id = ?
    `, [campaignId]);

    res.json({
        users: stats,
        messages
    });
};

// ============================================================
// TRIGGER CAMPAIGN MANUALLY
// ============================================================
exports.triggerCampaign = async (req, res) => {
    const { campaignId } = req.params;
    const { userId } = req.body;

    try {
        await campaignEngine.startJourney(campaignId, userId, { manual: true });
        res.json({ message: 'Campaign imeanzishwa kwa user' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};