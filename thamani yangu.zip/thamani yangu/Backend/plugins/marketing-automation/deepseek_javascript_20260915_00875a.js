// Mfano wa campaign
const welcomeCampaign = {
    name: 'Welcome Campaign',
    trigger: 'user_registered',
    steps: [
        {
            delay: 0,
            channel: 'email',
            template: 'welcome',
            condition: null
        },
        {
            delay: 1, // siku 1
            channel: 'sms',
            template: 'first_contribution_prompt',
            condition: 'user_contribution_count == 0'
        },
        {
            delay: 3,
            channel: 'email',
            template: 'how_to_save',
            condition: null
        },
        {
            delay: 7,
            channel: 'whatsapp',
            template: 'help_offer',
            condition: 'user_contribution_count == 0'
        },
        {
            delay: 30,
            channel: 'email',
            template: 'first_month_congrats',
            condition: null
        }
    ]
};