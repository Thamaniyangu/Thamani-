const express = require('express');
const campaignController = require('./controllers/campaignController');
const { authenticate } = require('../../src/middleware/auth');

const router = express.Router();

router.use(authenticate);

router.get('/campaigns', campaignController.listCampaigns);
router.post('/campaigns', campaignController.createCampaign);
router.get('/campaigns/:campaignId', campaignController.getCampaign);
router.post('/campaigns/:campaignId/activate', campaignController.activateCampaign);
router.post('/campaigns/:campaignId/pause', campaignController.pauseCampaign);
router.post('/campaigns/:campaignId/trigger', campaignController.triggerCampaign);
router.get('/campaigns/:campaignId/stats', campaignController.getCampaignStats);
router.post('/campaigns/seed', campaignController.seedDefaultCampaigns);

module.exports = router;