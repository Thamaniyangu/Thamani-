const mysql = require('../../../src/config/mysql');
const { v4: uuidv4 } = require('uuid');
const actionExecutor = require('./actionExecutor');
const conditionEvaluator = require('./conditionEvaluator');

// ============================================================
// 1. PROCESS TRIGGER (Event occurred)
// ============================================================
exports.processTrigger = async (triggerType, userId, triggerData = {}) => {
    console.log(`🎯 Trigger: ${triggerType} for user ${userId}`);

    try {
        // Find matching active campaigns
        const campaigns = await mysql.query(`
            SELECT * FROM ma_campaigns 
            WHERE trigger_type = ? AND status = 'active'
        `, [triggerType]);

        for (const campaign of campaigns) {
            // Check if user already in campaign
            const existing = await mysql.queryOne(`
                SELECT id, status FROM ma_user_journeys 
                WHERE campaign_id = ? AND user_id = ?
            `, [campaign.id, userId]);

            if (existing) {
                if (existing.status === 'active') {
                    console.log(`User ${userId} already in campaign ${campaign.id}`);
                    continue;
                }
                // Allow re-entry if completed
            }

            // Start journey
            await exports.startJourney(campaign.id, userId, triggerData);
        }
    } catch (err) {
        console.error('Process trigger error:', err);
    }
};

// ============================================================
// 2. START JOURNEY (User enters campaign)
// ============================================================
exports.startJourney = async (campaignId, userId, triggerData = {}) => {
    try {
        const journeyId = uuidv4();
        const firstStepTime = new Date(); // Send immediately or after delay

        await mysql.query(`
            INSERT INTO ma_user_journeys 
            (id, campaign_id, user_id, current_step, status, next_action_at, metadata)
            VALUES (?, ?, ?, 0, 'active', ?, ?)
            ON DUPLICATE KEY UPDATE
                status = 'active',
                current_step = 0,
                started_at = NOW(),
                next_action_at = VALUES(next_action_at)
        `, [
            journeyId,
            campaignId,
            userId,
            firstStepTime,
            JSON.stringify(triggerData)
        ]);

        console.log(`✅ Journey started: campaign=${campaignId}, user=${userId}`);
        return journeyId;
    } catch (err) {
        console.error('Start journey error:', err);
        throw err;
    }
};

// ============================================================
// 3. EXECUTE STEP FOR USER
// ============================================================
exports.executeStep = async (journeyId) => {
    try {
        const journey = await mysql.queryOne(`
            SELECT * FROM ma_user_journeys WHERE id = ?
        `, [journeyId]);

        if (!journey || journey.status !== 'active') return;

        const campaign = await mysql.queryOne(`
            SELECT * FROM ma_campaigns WHERE id = ?
        `, [journey.campaign_id]);

        // Get all steps for campaign
        const steps = await mysql.query(`
            SELECT * FROM ma_campaign_steps 
            WHERE campaign_id = ? 
            ORDER BY step_order ASC
        `, [journey.campaign_id]);

        if (journey.current_step >= steps.length) {
            // Journey complete
            await mysql.query(`
                UPDATE ma_user_journeys 
                SET status = 'completed', completed_at = NOW()
                WHERE id = ?
            `, [journeyId]);
            return;
        }

        const step = steps[journey.current_step];

        // Check condition
        if (step.condition_type) {
            const conditionMet = await conditionEvaluator.evaluate(
                journey.user_id,
                step.condition_type,
                step.condition_config ? JSON.parse(step.condition_config) : {}
            );

            if (!conditionMet) {
                console.log(`Condition not met for user ${journey.user_id}, skipping step`);
                // Move to next step
                await exports.advanceToNextStep(journeyId, journey.current_step, steps);
                return;
            }
        }

        // Execute action
        await actionExecutor.execute({
            userId: journey.user_id,
            channel: step.action_type,
            config: step.action_config ? JSON.parse(step.action_config) : {},
            campaignId: campaign.id,
            stepId: step.id,
            campaignName: campaign.name
        });

        // Update stats
        await mysql.query(`
            UPDATE ma_campaigns SET total_sent = total_sent + 1 WHERE id = ?
        `, [campaign.id]);

        // Advance to next step
        await exports.advanceToNextStep(journeyId, journey.current_step, steps);
    } catch (err) {
        console.error('Execute step error:', err);
    }
};

// ============================================================
// 4. ADVANCE TO NEXT STEP
// ============================================================
exports.advanceToNextStep = async (journeyId, currentStep, steps) => {
    const nextStepIndex = currentStep + 1;

    if (nextStepIndex >= steps.length) {
        // Complete journey
        await mysql.query(`
            UPDATE ma_user_journeys 
            SET status = 'completed', completed_at = NOW()
            WHERE id = ?
        `, [journeyId]);
        return;
    }

    const nextStep = steps[nextStepIndex];
    const nextActionAt = new Date(Date.now() + (nextStep.delay_hours || 0) * 60 * 60 * 1000);

    await mysql.query(`
        UPDATE ma_user_journeys 
        SET current_step = ?, next_action_at = ?
        WHERE id = ?
    `, [nextStepIndex, nextActionAt, journeyId]);
};

// ============================================================
// 5. PROCESS DUE JOURNEYS (Called by cron)
// ============================================================
exports.processDueJourneys = async () => {
    try {
        const due = await mysql.query(`
            SELECT id FROM ma_user_journeys 
            WHERE status = 'active' 
              AND next_action_at <= NOW()
            LIMIT 100
        `);

        console.log(`⏰ Processing ${due.length} due journeys`);

        for (const j of due) {
            await exports.executeStep(j.id);
        }

        return due.length;
    } catch (err) {
        console.error('Process due journeys error:', err);
        return 0;
    }
};

// ============================================================
// 6. STOP JOURNEY FOR USER
// ============================================================
exports.stopJourney = async (campaignId, userId, reason = 'stopped') => {
    await mysql.query(`
        UPDATE ma_user_journeys 
        SET status = ?
        WHERE campaign_id = ? AND user_id = ?
    `, [reason, campaignId, userId]);
};