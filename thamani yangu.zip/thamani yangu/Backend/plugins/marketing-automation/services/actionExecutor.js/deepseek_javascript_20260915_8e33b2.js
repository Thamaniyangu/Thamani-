const mysql = require('../../../src/config/mysql');
const { v4: uuidv4 } = require('uuid');
const { sendEmail } = require('../../../src/utils/email');
const { sendWhatsApp } = require('../../../src/utils/whatsapp');
const pushService = require('../../../src/services/pushService');

// ============================================================
// ACTION EXECUTOR
// ============================================================
exports.execute = async ({ userId, channel, config, campaignId, stepId, campaignName }) => {
    const messageId = uuidv4();

    try {
        // Get user
        const user = await mysql.queryOne(`
            SELECT * FROM users WHERE id = ?
        `, [userId]);

        if (!user) throw new Error('User haipatikani');

        // Render content
        const content = renderTemplate(config.content || '', { user, campaignName });
        const subject = renderTemplate(config.subject || '', { user, campaignName });

        // Create message record
        await mysql.query(`
            INSERT INTO ma_sent_messages 
            (id, campaign_id, step_id, user_id, channel, subject, content, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        `, [messageId, campaignId, stepId, userId, channel, subject || null, content]);

        // Execute based on channel
        let success = false;

        switch (channel) {
            case 'email':
                success = await executeEmail(user, subject, content);
                break;
            case 'sms':
                success = await executeSMS(user, content);
                break;
            case 'whatsapp':
                success = await executeWhatsApp(user, content);
                break;
            case 'push':
                success = await executePush(user, subject, content);
                break;
            case 'add_points':
                success = await executeAddPoints(user, config);
                break;
            case 'assign_task':
                success = await executeAssignTask(user, config);
                break;
            case 'send_notification':
                success = await executeNotification(user, subject, content);
                break;
            default:
                throw new Error('Channel haijulikani: ' + channel);
        }

        // Update status
        await mysql.query(`
            UPDATE ma_sent_messages 
            SET status = ?, sent_at = NOW()
            WHERE id = ?
        `, [success ? 'sent' : 'failed', messageId]);

        return success;
    } catch (err) {
        console.error('Action execute error:', err);
        await mysql.query(`
            UPDATE ma_sent_messages 
            SET status = 'failed', failed_reason = ?
            WHERE id = ?
        `, [err.message, messageId]);
        return false;
    }
};

// ============================================================
// CHANNEL EXECUTORS
// ============================================================
const executeEmail = async (user, subject, content) => {
    if (!user.email) return false;
    try {
        await sendEmail({
            to: user.email,
            subject: subject || 'Ujumbe kutoka THAMANI YANGU',
            html: content
        });
        return true;
    } catch (err) {
        console.error('Email error:', err);
        return false;
    }
};

const executeSMS = async (user, content) => {
    if (!user.phone) return false;
    // Implement SMS sending via local gateway
    console.log(`SMS to ${user.phone}: ${content}`);
    return true;
};

const executeWhatsApp = async (user, content) => {
    if (!user.whatsapp_number) return false;
    try {
        await sendWhatsApp({ to: user.whatsapp_number, message: content });
        return true;
    } catch (err) {
        return false;
    }
};

const executePush = async (user, subject, content) => {
    try {
        await pushService.sendToUser(user.id, {
            title: subject || 'THAMANI YANGU',
            body: content
        });
        return true;
    } catch (err) {
        return false;
    }
};

const executeAddPoints = async (user, config) => {
    const points = config.points || 10;
    await mysql.query(`
        UPDATE users SET points = points + ? WHERE id = ?
    `, [points, user.id]);
    return true;
};

const executeAssignTask = async (user, config) => {
    // Assign task to a leader
    const taskData = {
        assigned_to: config.leaderRole || 'katibu',
        user_id: user.id,
        task: config.task || 'Follow up with user',
        created_at: new Date()
    };
    console.log('Task assigned:', taskData);
    return true;
};

const executeNotification = async (user, subject, content) => {
    await mysql.query(`
        INSERT INTO notifications (id, user_id, title, message, created_at)
        VALUES (UUID(), ?, ?, ?, NOW())
    `, [user.id, subject, content]);
    return true;
};

// ============================================================
// TEMPLATE RENDERER
// ============================================================
const renderTemplate = (template, data) => {
    if (!template) return '';
    return template.replace(/\{\{([^}]+)\}\}/g, (match, path) => {
        const keys = path.trim().split('.');
        let value = data;
        for (const key of keys) {
            value = value?.[key];
            if (value === undefined) return match;
        }
        return value;
    });
};