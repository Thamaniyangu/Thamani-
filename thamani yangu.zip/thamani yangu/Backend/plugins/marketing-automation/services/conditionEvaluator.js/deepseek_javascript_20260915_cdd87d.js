const mysql = require('../../../src/config/mysql');

// ============================================================
// CONDITION EVALUATOR
// ============================================================
exports.evaluate = async (userId, conditionType, config = {}) => {
    try {
        switch (conditionType) {
            case 'has_contribution':
                return await hasContribution(userId, config);
            case 'contribution_count':
                return await contributionCountCondition(userId, config);
            case 'total_saved':
                return await totalSavedCondition(userId, config);
            case 'has_loan':
                return await hasLoan(userId, config);
            case 'days_since_last_contribution':
                return await daysSinceLastContribution(userId, config);
            case 'user_role':
                return await userRoleCondition(userId, config);
            case 'registration_age':
                return await registrationAgeCondition(userId, config);
            case 'has_unpaid_fees':
                return await hasUnpaidFees(userId, config);
            default:
                return true;
        }
    } catch (err) {
        console.error('Condition evaluate error:', err);
        return false;
    }
};

// ============================================================
// CONDITIONS
// ============================================================
const hasContribution = async (userId, config) => {
    const result = await mysql.queryOne(`
        SELECT COUNT(*) as count FROM contributions WHERE user_id = ?
    `, [userId]);
    return result.count > 0;
};

const contributionCountCondition = async (userId, config) => {
    const { operator = '>=', value = 1, daysBack } = config;
    let query = `SELECT COUNT(*) as count FROM contributions WHERE user_id = ?`;
    const params = [userId];

    if (daysBack) {
        query += ` AND created_at > DATE_SUB(NOW(), INTERVAL ? DAY)`;
        params.push(daysBack);
    }

    const result = await mysql.queryOne(query, params);
    return compare(result.count, operator, value);
};

const totalSavedCondition = async (userId, config) => {
    const { operator = '>=', value = 0 } = config;
    const result = await mysql.queryOne(`
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM contributions 
        WHERE user_id = ? AND type = 'hisa'
    `, [userId]);
    return compare(parseFloat(result.total), operator, value);
};

const hasLoan = async (userId, config) => {
    const { status = 'active' } = config;
    const result = await mysql.queryOne(`
        SELECT COUNT(*) as count FROM loans 
        WHERE user_id = ? AND status = ?
    `, [userId, status]);
    return result.count > 0;
};

const daysSinceLastContribution = async (userId, config) => {
    const { operator = '>', days = 30 } = config;
    const result = await mysql.queryOne(`
        SELECT DATEDIFF(NOW(), MAX(created_at)) as days 
        FROM contributions 
        WHERE user_id = ?
    `, [userId]);
    const daysSince = result.days || 999;
    return compare(daysSince, operator, days);
};

const userRoleCondition = async (userId, config) => {
    const { roles = ['mwanachama'] } = config;
    const user = await mysql.queryOne(`
        SELECT role FROM users WHERE id = ?
    `, [userId]);
    return roles.includes(user?.role);
};

const registrationAgeCondition = async (userId, config) => {
    const { operator = '>=', days = 7 } = config;
    const result = await mysql.queryOne(`
        SELECT DATEDIFF(NOW(), created_at) as days FROM users WHERE id = ?
    `, [userId]);
    return compare(result.days, operator, days);
};

const hasUnpaidFees = async (userId, config) => {
    const result = await mysql.queryOne(`
        SELECT COUNT(*) as count FROM membership_fees 
        WHERE user_id = ? AND status = 'unpaid'
    `, [userId]);
    return result.count > 0;
};

// ============================================================
// COMPARE HELPER
// ============================================================
const compare = (a, operator, b) => {
    switch (operator) {
        case '>': return a > b;
        case '>=': return a >= b;
        case '<': return a < b;
        case '<=': return a <= b;
        case '==': return a == b;
        case '!=': return a != b;
        default: return a >= b;
    }
};