module.exports = [
    // ============================================================
    // WELCOME CAMPAIGN
    // ============================================================
    {
        name: 'Welcome New Member',
        description: 'Karibisha wanachama wapya hatua kwa hatua',
        trigger_type: 'user_registered',
        trigger_config: {},
        goal: 'onboarding',
        steps: [
            {
                step_order: 0,
                step_type: 'message',
                delay_hours: 0,
                action_type: 'email',
                action_config: {
                    subject: 'Karibu THAMANI YANGU, {{user.first_name}}!',
                    content: `
                        <h1>Karibu {{user.first_name}}!</h1>
                        <p>Tunafurahi sana kuwa nawe kwenye kikundi chetu cha THAMANI YANGU.</p>
                        <p>Member ID yako ni: <strong>{{user.member_id}}</strong></p>
                        <p>Hii ni safari yetu ya pamoja ya kuweka akiba na kufanikiwa.</p>
                        <p><a href="https://thamaniyangu.com/dashboard">Ingia kwenye dashibodi yako</a></p>
                    `
                }
            },
            {
                step_order: 1,
                step_type: 'message',
                delay_hours: 24,
                condition_type: 'contribution_count',
                condition_config: { operator: '==', value: 0, daysBack: 1 },
                action_type: 'whatsapp',
                action_config: {
                    content: `Habari {{user.first_name}}! 👋\n\nBado hujafanya mchango wako wa kwanza. Tunaweza kukusaidia vipi?\n\nJibu "msaada" tukuwasiliane.`
                }
            },
            {
                step_order: 2,
                step_type: 'message',
                delay_hours: 72,
                condition_type: 'contribution_count',
                condition_config: { operator: '==', value: 0 },
                action_type: 'email',
                action_config: {
                    subject: 'Jinsi ya kuanza kuweka akiba',
                    content: `
                        <h2>Jinsi ya kuanza</h2>
                        <ol>
                            <li>Ingia kwenye dashibodi yako</li>
                            <li>Bonyeza "Michango"</li>
                            <li>Chagua aina ya mchango (Hisa, Jamii)</li>
                            <li>Weka kiasi na kuhifadhi</li>
                        </ol>
                    `
                }
            },
            {
                step_order: 3,
                step_type: 'message',
                delay_hours: 168, // siku 7
                condition_type: 'contribution_count',
                condition_config: { operator: '==', value: 0 },
                action_type: 'assign_task',
                action_config: {
                    leaderRole: 'katibu',
                    task: 'Follow up with new member who has not contributed'
                }
            },
            {
                step_order: 4,
                step_type: 'message',
                delay_hours: 720, // siku 30
                action_type: 'email',
                action_config: {
                    subject: 'Hongera kwa mwezi wako wa kwanza!',
                    content: `
                        <h2>Hongera, {{user.first_name}}!</h2>
                        <p>Umefikisha mwezi mmoja na THAMANI YANGU. Asante kwa kuwa mwanachama mwaminifu.</p>
                        <p>Angalia mafanikio yako kwenye dashibodi.</p>
                    `
                }
            }
        ]
    },

    // ============================================================
    // RE-ENGAGEMENT CAMPAIGN
    // ============================================================
    {
        name: 'Re-engagement',
        description: 'Warudishe wanachama waliokwama',
        trigger_type: 'inactive_30_days',
        trigger_config: {},
        goal: 'retention',
        steps: [
            {
                step_order: 0,
                step_type: 'message',
                delay_hours: 0,
                action_type: 'whatsapp',
                action_config: {
                    content: `Habari {{user.first_name}}! 👋\n\nTumekukumbuka! Hatujakuona kwa muda mrefu.\n\nKaribu tuchangie pamoja tena.\n\nJibu "hapana" kutoka kwenye arifa hizi.`
                }
            },
            {
                step_order: 1,
                step_type: 'message',
                delay_hours: 120, // siku 5
                condition_type: 'days_since_last_contribution',
                condition_config: { operator: '>', days: 35 },
                action_type: 'email',
                action_config: {
                    subject: 'Angalia mafanikio yako',
                    content: `<h2>{{user.first_name}}, angalia mafanikio yako</h2><p>Una akiba ya TZS {{stats.total_saved}}. Endelea!</p>`
                }
            },
            {
                step_order: 2,
                step_type: 'message',
                delay_hours: 360, // siku 15
                condition_type: 'days_since_last_contribution',
                condition_config: { operator: '>', days: 45 },
                action_type: 'assign_task',
                action_config: {
                    leaderRole: 'katibu',
                    task: 'Call inactive member'
                }
            }
        ]
    },

    // ============================================================
    // BIRTHDAY CAMPAIGN
    // ============================================================
    {
        name: 'Birthday Wishes',
        description: 'Tuma ujumbe wa siku ya kuzaliwa',
        trigger_type: 'birthday',
        trigger_config: {},
        goal: 'engagement',
        steps: [
            {
                step_order: 0,
                step_type: 'message',
                delay_hours: 0,
                action_type: 'whatsapp',
                action_config: {
                    content: `🎉 *Hongera kwa Siku Yako, {{user.first_name}}!* 🎂\n\nTimu ya THAMANI YANGU inakutakia siku njema ya kuzaliwa!\n\nKaribu tuchangie kwa furaha ya siku hii!`
                }
            },
            {
                step_order: 1,
                step_type: 'message',
                delay_hours: 2,
                action_type: 'add_points',
                action_config: {
                    points: 100
                }
            },
            {
                step_order: 2,
                step_type: 'message',
                delay_hours: 3,
                action_type: 'email',
                action_config: {
                    subject: '🎉 Hongera kwa Siku Yako!',
                    content: `
                        <h1>🎉 Hongera, {{user.first_name}}!</h1>
                        <p>Timu nzima ya THAMANI YANGU inakutakia siku njema ya kuzaliwa!</p>
                        <p>Tunakupa <strong>pointi 100 za bure</strong> kama zawadi.</p>
                    `
                }
            }
        ]
    },

    // ============================================================
    // MILESTONE CAMPAIGN
    // ============================================================
    {
        name: 'Savings Milestone',
        description: 'Hongera wanachama wanaofikia malengo',
        trigger_type: 'savings_milestone',
        trigger_config: {},
        goal: 'celebration',
        steps: [
            {
                step_order: 0,
                step_type: 'message',
                delay_hours: 0,
                action_type: 'whatsapp',
                action_config: {
                    content: `🏆 *HONGERA SANA, {{user.first_name}}!* 🎉\n\nUmefikia milestone ya akiba ya TZS {{milestone}}!\n\nEndelea hivyo, unaweza zaidi! 💪`
                }
            },
            {
                step_order: 1,
                step_type: 'message',
                delay_hours: 1,
                action_type: 'add_points',
                action_config: { points: 500 }
            },
            {
                step_order: 2,
                step_type: 'message',
                delay_hours: 1,
                action_type: 'send_notification',
                action_config: {
                    subject: '🏆 Milestone Imefikiwa!',
                    content: 'Umefikia lengo lako la akiba. Hongera!'
                }
            }
        ]
    },

    // ============================================================
    // PAYMENT REMINDER
    // ============================================================
    {
        name: 'Payment Reminder',
        description: 'Kumbusha malipo ya ada na mikopo',
        trigger_type: 'payment_due',
        trigger_config: { daysBefore: 3 },
        goal: 'payment',
        steps: [
            {
                step_order: 0,
                step_type: 'message',
                delay_hours: 0,
                action_type: 'email',
                action_config: {
                    subject: 'Kumbusho la Malipo',
                    content: `
                        <h2>Kumbusho la Malipo</h2>
                        <p>Habari {{user.first_name}},</p>
                        <p>Unakumbushwa kulipa ada yako ya mwezi huu kabla ya {{due_date}}.</p>
                    `
                }
            },
            {
                step_order: 1,
                step_type: 'message',
                delay_hours: 48, // siku 2
                condition_type: 'has_unpaid_fees',
                condition_config: {},
                action_type: 'whatsapp',
                action_config: {
                    content: `Kumbusho: {{user.first_name}}, ada yako ya mwezi bado haijalipwa. Tafadhali lipa kabla ya kesho.`
                }
            },
            {
                step_order: 2,
                step_type: 'message',
                delay_hours: 72,
                condition_type: 'has_unpaid_fees',
                condition_config: {},
                action_type: 'assign_task',
                action_config: {
                    leaderRole: 'mhazini',
                    task: 'Follow up unpaid fees'
                }
            }
        ]
    }
];