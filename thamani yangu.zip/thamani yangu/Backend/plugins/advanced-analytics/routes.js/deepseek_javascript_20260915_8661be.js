const express = require('express');
const analyticsController = require('./controllers/analyticsController');
const { authenticate } = require('../../src/middleware/auth');

const router = express.Router();

router.use(authenticate);

router.get('/dashboard', analyticsController.getDashboard);
router.get('/predictions', analyticsController.getPredictions);
router.post('/etl/run', analyticsController.runETL);
router.get('/members/:userId', analyticsController.getMemberAnalytics);
router.get('/anomalies', analyticsController.getAnomalies);
router.post('/anomalies/:anomalyId/resolve', analyticsController.resolveAnomaly);
router.post('/reports/generate', analyticsController.generateReport);
router.get('/reports', analyticsController.listReports);

module.exports = router;