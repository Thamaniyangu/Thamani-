const cron = require('node-cron');
const etlService = require('./services/etlService');
const predictionService = require('./services/predictionService');

module.exports = () => {
    // Aggregate daily stats (daily at 1 AM)
    cron.schedule('0 1 * * *', async () => {
        try {
            await etlService.aggregateDailyStats();
            console.log('✅ Daily aggregation complete');
        } catch (err) {
            console.error('Aggregation cron error:', err);
        }
    });

    // Update member analytics (every 6 hours)
    cron.schedule('0 */6 * * *', async () => {
        try {
            await etlService.updateMemberAnalytics();
            console.log('✅ Member analytics updated');
        } catch (err) {
            console.error('Member analytics cron error:', err);
        }
    });

    // Detect anomalies (every hour)
    cron.schedule('0 * * * *', async () => {
        try {
            await etlService.detectAnomalies();
        } catch (err) {
            console.error('Anomaly detection error:', err);
        }
    });

    // Generate predictions (daily at 2 AM)
    cron.schedule('0 2 * * *', async () => {
        try {
            await predictionService.predictFutureContributions(3);
            await predictionService.forecastLoanDemand(4);
            console.log('✅ Predictions updated');
        } catch (err) {
            console.error('Prediction cron error:', err);
        }
    });

    console.log('✅ Advanced Analytics crons registered');
};