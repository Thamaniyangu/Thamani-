-- ============================================================
-- ADVANCED ANALYTICS - Data Warehouse Tables
-- ============================================================

-- Daily aggregated stats
CREATE TABLE IF NOT EXISTS an_daily_stats (
    id CHAR(36) PRIMARY KEY,
    stat_date DATE UNIQUE NOT NULL,
    total_members INT DEFAULT 0,
    active_members INT DEFAULT 0,
    new_members INT DEFAULT 0,
    total_contributions DECIMAL(15,2) DEFAULT 0,
    total_loans DECIMAL(15,2) DEFAULT 0,
    total_repayments DECIMAL(15,2) DEFAULT 0,
    total_fees DECIMAL(15,2) DEFAULT 0,
    active_calls INT DEFAULT 0,
    chat_messages INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stat_date (stat_date)
) ENGINE=InnoDB;

-- Member analytics
CREATE TABLE IF NOT EXISTS an_member_analytics (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) UNIQUE NOT NULL,
    total_contributed DECIMAL(15,2) DEFAULT 0,
    total_loans DECIMAL(15,2) DEFAULT 0,
    contribution_count INT DEFAULT 0,
    avg_monthly_contribution DECIMAL(15,2) DEFAULT 0,
    consistency_score DECIMAL(5,2) DEFAULT 0,
    engagement_score DECIMAL(5,2) DEFAULT 0,
    risk_score DECIMAL(5,2) DEFAULT 0,
    lifetime_value DECIMAL(15,2) DEFAULT 0,
    segment VARCHAR(50),
    churn_probability DECIMAL(5,2) DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_segment (segment),
    INDEX idx_risk (risk_score),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Predictions
CREATE TABLE IF NOT EXISTS an_predictions (
    id CHAR(36) PRIMARY KEY,
    prediction_type VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id CHAR(36),
    predicted_value DECIMAL(15,2),
    confidence DECIMAL(5,2),
    model_version VARCHAR(20),
    valid_until DATE,
    features JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type (prediction_type),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created (created_at DESC)
) ENGINE=InnoDB;

-- Cohorts (user groups)
CREATE TABLE IF NOT EXISTS an_cohorts (
    id CHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    segment_type VARCHAR(50),
    filters JSON,
    member_count INT DEFAULT 0,
    avg_contribution DECIMAL(15,2) DEFAULT 0,
    retention_rate DECIMAL(5,2) DEFAULT 0,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_segment_type (segment_type)
) ENGINE=InnoDB;

-- Anomalies detected
CREATE TABLE IF NOT EXISTS an_anomalies (
    id CHAR(36) PRIMARY KEY,
    anomaly_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) DEFAULT 'low',
    entity_type VARCHAR(50),
    entity_id CHAR(36),
    description TEXT,
    expected_value DECIMAL(15,2),
    actual_value DECIMAL(15,2),
    deviation DECIMAL(10,2),
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    resolved_by CHAR(36),
    INDEX idx_type (anomaly_type),
    INDEX idx_severity (severity),
    INDEX idx_detected (detected_at DESC)
) ENGINE=InnoDB;

-- Reports
CREATE TABLE IF NOT EXISTS an_reports (
    id CHAR(36) PRIMARY KEY,
    report_type VARCHAR(50) NOT NULL,
    title VARCHAR(255),
    period_start DATE,
    period_end DATE,
    generated_by CHAR(36),
    data JSON,
    file_url TEXT,
    status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type (report_type),
    INDEX idx_period (period_start, period_end)
) ENGINE=InnoDB;