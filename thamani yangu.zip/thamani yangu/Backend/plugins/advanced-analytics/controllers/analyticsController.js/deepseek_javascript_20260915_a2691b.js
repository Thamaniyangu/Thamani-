const etlService = require('../services/etlService');
const predictionService = require('../services/predictionService');
const mysql = require('../../../src/config/mysql');

// ============================================================
// GET DASHBOARD
// ============================================================
exports.getDashboard = async (req, res) => {
    if (!['mwenyekiti', 'katibu', 'mhazini'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        const today = await mysql.queryOne(`
            SELECT * FROM an_daily_stats ORDER BY stat_date DESC LIMIT 1
        `);

        const last30 = await mysql.query(`
            SELECT * FROM an_daily_stats 
            WHERE stat_date > DATE_SUB(NOW(), INTERVAL 30 DAY)
            ORDER BY stat_date ASC
        `);

        const segments = await predictionService.runSegmentation();

        const atRisk = await predictionService.getAtRiskMembers(70);

        const anomalies = await mysql.query(`
            SELECT * FROM an_anomalies 
            WHERE resolved = FALSE 
            ORDER BY detected_at DESC LIMIT 10
        `);

        res.json({
            today,
            last30,
            segments,
            atRisk: atRisk.slice(0, 10),
            anomalies
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET PREDICTIONS
// ============================================================
exports.getPredictions = async (req, res) => {
    try {
        const contributions = await predictionService.predictFutureContributions(6);
        const loans = await predictionService.forecastLoanDemand(4);
        const atRisk = await predictionService.getAtRiskMembers();

        res.json({
            contributions,
            loans,
            atRisk
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// TRIGGER ETL
// ============================================================
exports.runETL = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await etlService.aggregateDailyStats();
        await etlService.updateMemberAnalytics();
        await etlService.detectAnomalies();

        res.json({ message: 'ETL imekamilika' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET MEMBER ANALYTICS
// ============================================================
exports.getMemberAnalytics = async (req, res) => {
    const { userId } = req.params;

    // Members can only see their own
    if (req.user.role === 'mwanachama' && userId !== req.user.id) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    const analytics = await mysql.queryOne(`
        SELECT * FROM an_member_analytics WHERE user_id = ?
    `, [userId]);

    if (!analytics) {
        return res.status(404).json({ error: 'Haipatikani' });
    }

    res.json(analytics);
};

// ============================================================
// GET ANOMALIES
// ============================================================
exports.getAnomalies = async (req, res) => {
    const anomalies = await mysql.query(`
        SELECT * FROM an_anomalies 
        WHERE resolved = FALSE 
        ORDER BY detected_at DESC LIMIT 50
    `);
    res.json(anomalies);
};

// ============================================================
// RESOLVE ANOMALY
// ============================================================
exports.resolveAnomaly = async (req, res) => {
    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    const { anomalyId } = req.params;

    await mysql.query(`
        UPDATE an_anomalies 
        SET resolved = TRUE, resolved_at = NOW(), resolved_by = ?
        WHERE id = ?
    `, [req.user.id, anomalyId]);

    res.json({ message: 'Imesuluhishwa' });
};

// ============================================================
// REPORTS
// ============================================================
exports.generateReport = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { type, year, month } = req.body;

    const reportGenerator = require('../services/reportGenerator');

    try {
        let result;
        if (type === 'monthly') {
            result = await reportGenerator.generateMonthlyReport(year, month);
        } else if (type === 'annual') {
            result = await reportGenerator.generateAnnualReport(year);
        } else {
            return res.status(400).json({ error: 'Type haijulikani' });
        }

        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.listReports = async (req, res) => {
    const reports = await mysql.query(`
        SELECT * FROM an_reports ORDER BY created_at DESC LIMIT 50
    `);
    res.json(reports);
};