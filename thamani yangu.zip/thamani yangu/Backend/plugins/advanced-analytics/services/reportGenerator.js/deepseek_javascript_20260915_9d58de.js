const mysql = require('../../../src/config/mysql');
const { generatePDFWithWatermark } = require('../../../src/utils/documentGenerator');
const { uploadToStorage } = require('../../../src/utils/localStorage');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// 1. GENERATE MONTHLY REPORT
// ============================================================
exports.generateMonthlyReport = async (year, month) => {
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = new Date(year, month, 0).toISOString().split('T')[0];

    try {
        // Get data
        const contributions = await mysql.query(`
            SELECT type, COUNT(*) as count, SUM(amount) as total
            FROM contributions
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY type
        `, [startDate, endDate]);

        const loans = await mysql.queryOne(`
            SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total
            FROM loans WHERE DATE(created_at) BETWEEN ? AND ?
        `, [startDate, endDate]);

        const members = await mysql.queryOne(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN DATE(created_at) BETWEEN ? AND ? THEN 1 ELSE 0 END) as new
            FROM users
        `, [startDate, endDate]);

        const daily = await mysql.query(`
            SELECT * FROM an_daily_stats 
            WHERE stat_date BETWEEN ? AND ?
            ORDER BY stat_date ASC
        `, [startDate, endDate]);

        // Build report HTML
        const html = buildMonthlyReportHTML({
            year, month, startDate, endDate,
            contributions, loans, members, daily
        });

        // Generate PDF
        const pdfBuffer = await generatePDFWithWatermark(
            `Ripoti ya Mwezi - ${month}/${year}`,
            html,
            'MONTHLY REPORT',
            'THAMANI YANGU SYSTEM',
            'SYSTEM'
        );

        // Save
        const filename = `monthly-report-${year}-${month}-${Date.now()}.pdf`;
        const pdfUrl = await uploadToStorage(pdfBuffer, 'reports', filename);

        // Log
        await mysql.query(`
            INSERT INTO an_reports 
            (id, report_type, title, period_start, period_end, data, file_url, status)
            VALUES (?, 'monthly', ?, ?, ?, ?, ?, 'completed')
        `, [
            uuidv4(),
            `Ripoti ya Mwezi ${month}/${year}`,
            startDate,
            endDate,
            JSON.stringify({ contributions, loans, members }),
            pdfUrl
        ]);

        return { pdfUrl, filename };
    } catch (err) {
        console.error('Generate monthly report error:', err);
        throw err;
    }
};

// ============================================================
// 2. HTML BUILDER
// ============================================================
const buildMonthlyReportHTML = (data) => {
    const { year, month, startDate, endDate, contributions, loans, members, daily } = data;
    
    const totalContrib = contributions.reduce((s, c) => s + parseFloat(c.total), 0);

    return `
        <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h1 style="color: #0D6B6B; text-align: center;">
                RIPOTI YA MWEZI ${month}/${year}
            </h1>
            <p style="text-align: center; color: #666;">
                ${startDate} - ${endDate}
            </p>

            <h2 style="color: #D4AF37;">📊 Muhtasari</h2>
            <table style="width: 100%; border-collapse: collapse;">
                <tr style="background: #0D6B6B; color: white;">
                    <th style="padding: 8px; text-align: left;">Kipengele</th>
                    <th style="padding: 8px; text-align: right;">Thamani</th>
                </tr>
                <tr><td style="padding: 8px;">Wanachama Wapya</td><td style="padding: 8px; text-align: right;">${members.new}</td></tr>
                <tr><td style="padding: 8px;">Jumla ya Wanachama</td><td style="padding: 8px; text-align: right;">${members.total}</td></tr>
                <tr><td style="padding: 8px;">Jumla ya Michango</td><td style="padding: 8px; text-align: right;">TZS ${totalContrib.toLocaleString()}</td></tr>
                <tr><td style="padding: 8px;">Mikopo Iliyotolewa</td><td style="padding: 8px; text-align: right;">TZS ${parseFloat(loans.total).toLocaleString()}</td></tr>
            </table>

            <h2 style="color: #D4AF37; margin-top: 30px;">💰 Mchanganuo wa Michango</h2>
            <table style="width: 100%; border-collapse: collapse;">
                <tr style="background: #0D6B6B; color: white;">
                    <th style="padding: 8px; text-align: left;">Aina</th>
                    <th style="padding: 8px; text-align: right;">Idadi</th>
                    <th style="padding: 8px; text-align: right;">Kiasi</th>
                </tr>
                ${contributions.map(c => `
                    <tr>
                        <td style="padding: 8px; text-transform: capitalize;">${c.type}</td>
                        <td style="padding: 8px; text-align: right;">${c.count}</td>
                        <td style="padding: 8px; text-align: right;">TZS ${parseFloat(c.total).toLocaleString()}</td>
                    </tr>
                `).join('')}
            </table>

            <h2 style="color: #D4AF37; margin-top: 30px;">📈 Mwenendo wa Kila Siku</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                <tr style="background: #0D6B6B; color: white;">
                    <th style="padding: 6px;">Tarehe</th>
                    <th style="padding: 6px; text-align: right;">Michango</th>
                </tr>
                ${daily.slice(-15).map(d => `
                    <tr>
                        <td style="padding: 6px;">${d.stat_date}</td>
                        <td style="padding: 6px; text-align: right;">TZS ${parseFloat(d.total_contributions).toLocaleString()}</td>
                    </tr>
                `).join('')}
            </table>
        </div>
    `;
};

// ============================================================
// 3. GENERATE ANNUAL REPORT (with interest breakdown)
// ============================================================
exports.generateAnnualReport = async (year) => {
    const startDate = `${year}-01-01`;
    const endDate = `${year}-12-31`;

    try {
        const contributions = await mysql.query(`
            SELECT type, SUM(amount) as total
            FROM contributions
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY type
        `, [startDate, endDate]);

        const loans = await mysql.query(`
            SELECT SUM(amount) as total, AVG(interest_rate) as avg_rate
            FROM loans
            WHERE DATE(created_at) BETWEEN ? AND ?
        `, [startDate, endDate]);

        const totalLoanAmount = parseFloat(loans[0]?.total || 0);
        const totalInterest = totalLoanAmount * 0.10;

        const interestBreakdown = {
            '10%': totalInterest,
            '8%': totalInterest * 0.8,
            '1.5%': totalInterest * 0.15,
            '0.5%': totalInterest * 0.05
        };

        const html = buildAnnualReportHTML({
            year, startDate, endDate,
            contributions, loans, interestBreakdown
        });

        const pdfBuffer = await generatePDFWithWatermark(
            `Ripoti ya Mwaka ${year}`,
            html,
            'ANNUAL REPORT',
            'THAMANI YANGU SYSTEM',
            'SYSTEM'
        );

        const filename = `annual-report-${year}-${Date.now()}.pdf`;
        const pdfUrl = await uploadToStorage(pdfBuffer, 'reports', filename);

        await mysql.query(`
            INSERT INTO an_reports 
            (id, report_type, title, period_start, period_end, data, file_url, status)
            VALUES (?, 'annual', ?, ?, ?, ?, ?, 'completed')
        `, [
            uuidv4(),
            `Ripoti ya Mwaka ${year}`,
            startDate, endDate,
            JSON.stringify({ contributions, loans, interestBreakdown }),
            pdfUrl
        ]);

        return { pdfUrl, filename };
    } catch (err) {
        console.error('Generate annual report error:', err);
        throw err;
    }
};

const buildAnnualReportHTML = (data) => {
    const { year, contributions, loans, interestBreakdown } = data;
    const totalContrib = contributions.reduce((s, c) => s + parseFloat(c.total), 0);

    return `
        <div style="font-family: Arial, sans-serif; padding: 30px;">
            <h1 style="color: #D4AF37; text-align: center; font-size: 32px;">
                RIPOTI YA MWAKA ${year}
            </h1>
            
            <div style="background: linear-gradient(135deg, #D4AF37, #F5E5C0); 
                        padding: 20px; border-radius: 10px; margin: 30px 0; text-align: center;">
                <h2 style="color: white; margin: 0; font-size: 24px;">
                    Jumla ya Michango: TZS ${totalContrib.toLocaleString()}
                </h2>
            </div>

            <h2 style="color: #0D6B6B;">💰 Mchanganuo wa Michango kwa Aina</h2>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <tr style="background: #0D6B6B; color: white;">
                    <th style="padding: 10px; text-align: left;">Aina</th>
                    <th style="padding: 10px; text-align: right;">Jumla (TZS)</th>
                </tr>
                ${contributions.map(c => `
                    <tr>
                        <td style="padding: 10px; text-transform: capitalize; border-bottom: 1px solid #eee;">${c.type}</td>
                        <td style="padding: 10px; text-align: right; border-bottom: 1px solid #eee;">${parseFloat(c.total).toLocaleString()}</td>
                    </tr>
                `).join('')}
            </table>

            <h2 style="color: #0D6B6B;">📊 Mchanganuo wa Riba</h2>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div style="background: #FDF2E9; padding: 15px; border-radius: 8px; border-left: 4px solid #D4AF37;">
                    <p style="font-size: 14px; font-weight: bold;">10% (Riba Kamili)</p>
                    <p style="font-size: 20px; color: #D4AF37; margin: 5px 0;">
                        TZS ${interestBreakdown['10%'].toLocaleString()}
                    </p>
                </div>
                <div style="background: #E8F5F5; padding: 15px; border-radius: 8px; border-left: 4px solid #0D6B6B;">
                    <p style="font-size: 14px; font-weight: bold;">8% (Gharama ya Mkopaji)</p>
                    <p style="font-size: 20px; color: #0D6B6B; margin: 5px 0;">
                        TZS ${interestBreakdown['8%'].toLocaleString()}
                    </p>
                </div>
                <div style="background: #EBF5FB; padding: 15px; border-radius: 8px; border-left: 4px solid #2E86C1;">
                    <p style="font-size: 14px; font-weight: bold;">1.5% (Wanachama Wote)</p>
                    <p style="font-size: 20px; color: #2E86C1; margin: 5px 0;">
                        TZS ${interestBreakdown['1.5%'].toLocaleString()}
                    </p>
                </div>
                <div style="background: #F4ECF7; padding: 15px; border-radius: 8px; border-left: 4px solid #8E44AD;">
                    <p style="font-size: 14px; font-weight: bold;">0.5% (Inabaki Kikundi)</p>
                    <p style="font-size: 20px; color: #8E44AD; margin: 5px 0;">
                        TZS ${interestBreakdown['0.5%'].toLocaleString()}
                    </p>
                </div>
            </div>
        </div>
    `;
};