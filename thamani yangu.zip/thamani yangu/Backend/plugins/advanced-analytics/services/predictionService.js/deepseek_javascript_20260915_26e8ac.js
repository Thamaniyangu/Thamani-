const mysql = require('../../../src/config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// 1. PREDICT CONTRIBUTIONS (Simple Linear Regression)
// ============================================================
exports.predictFutureContributions = async (months = 6) => {
    try {
        // Get historical data
        const history = await mysql.query(`
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                SUM(amount) as total
            FROM contributions
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY month ASC
        `);

        if (history.length < 3) {
            return { error: 'Data haitoshi' };
        }

        // Simple linear regression
        const n = history.length;
        const x = history.map((_, i) => i);
        const y = history.map(h => parseFloat(h.total));

        const sumX = x.reduce((a, b) => a + b, 0);
        const sumY = y.reduce((a, b) => a + b, 0);
        const sumXY = x.reduce((a, b, i) => a + b * y[i], 0);
        const sumX2 = x.reduce((a, b) => a + b * b, 0);

        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;

        // Predict
        const predictions = [];
        for (let i = 1; i <= months; i++) {
            const futureX = n + i - 1;
            const predicted = slope * futureX + intercept;
            const futureDate = new Date();
            futureDate.setMonth(futureDate.getMonth() + i);

            predictions.push({
                month: futureDate.toISOString().slice(0, 7),
                predicted: Math.max(0, Math.round(predicted)),
                confidence: 0.85 - (i * 0.05) // Decreasing confidence
            });

            // Save prediction
            await mysql.query(`
                INSERT INTO an_predictions 
                (id, prediction_type, entity_type, predicted_value, confidence, features)
                VALUES (?, 'monthly_contribution', 'system', ?, ?, ?)
            `, [
                uuidv4(),
                Math.max(0, Math.round(predicted)),
                0.85 - (i * 0.05),
                JSON.stringify({ month: futureDate.toISOString().slice(0, 7) })
            ]);
        }

        return {
            history,
            trend: slope > 0 ? 'increasing' : slope < 0 ? 'decreasing' : 'stable',
            slope,
            predictions
        };
    } catch (err) {
        console.error('Predict contributions error:', err);
        throw err;
    }
};

// ============================================================
// 2. PREDICT MEMBER CHURN
// ============================================================
exports.predictChurn = async (userId) => {
    try {
        const analytics = await mysql.queryOne(`
            SELECT * FROM an_member_analytics WHERE user_id = ?
        `, [userId]);

        if (!analytics) return null;

        // Already has churn probability
        return {
            userId,
            churnProbability: parseFloat(analytics.churn_probability),
            segment: analytics.segment,
            riskScore: parseFloat(analytics.risk_score),
            factors: {
                consistency: analytics.consistency_score,
                engagement: analytics.engagement_score,
                daysSinceActivity: await getDaysSinceActivity(userId)
            }
        };
    } catch (err) {
        console.error('Predict churn error:', err);
        return null;
    }
};

const getDaysSinceActivity = async (userId) => {
    const result = await mysql.queryOne(`
        SELECT DATEDIFF(NOW(), MAX(created_at)) as days 
        FROM contributions WHERE user_id = ?
    `, [userId]);
    return result?.days || 999;
};

// ============================================================
// 3. IDENTIFY AT-RISK MEMBERS
// ============================================================
exports.getAtRiskMembers = async (threshold = 70) => {
    return await mysql.query(`
        SELECT 
            u.id, u.member_id, u.first_name, u.last_name, u.phone, u.email,
            a.risk_score, a.churn_probability, a.segment,
            a.engagement_score, a.total_contributed
        FROM an_member_analytics a
        JOIN users u ON a.user_id = u.id
        WHERE a.risk_score >= ? AND u.status = 'active'
        ORDER BY a.risk_score DESC
        LIMIT 50
    `, [threshold]);
};

// ============================================================
// 4. FORECAST LOAN DEMAND
// ============================================================
exports.forecastLoanDemand = async (weeks = 4) => {
    try {
        const history = await mysql.query(`
            SELECT 
                DATE_FORMAT(created_at, '%Y-%u') as week,
                COUNT(*) as count,
                SUM(amount) as total
            FROM loans
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 8 WEEK)
            GROUP BY DATE_FORMAT(created_at, '%Y-%u')
            ORDER BY week ASC
        `);

        if (history.length < 3) {
            return { error: 'Data haitoshi' };
        }

        const avgCount = history.reduce((s, h) => s + h.count, 0) / history.length;
        const avgTotal = history.reduce((s, h) => s + parseFloat(h.total), 0) / history.length;

        const forecast = [];
        for (let i = 1; i <= weeks; i++) {
            forecast.push({
                week: `Week ${i}`,
                expectedLoans: Math.round(avgCount * (1 + (Math.random() - 0.5) * 0.3)),
                expectedAmount: Math.round(avgTotal * (1 + (Math.random() - 0.5) * 0.3))
            });
        }

        return { history, forecast, avgWeekly: avgCount };
    } catch (err) {
        console.error('Forecast loan demand error:', err);
        return { error: err.message };
    }
};

// ============================================================
// 5. SEGMENTATION
// ============================================================
exports.runSegmentation = async () => {
    const segments = await mysql.query(`
        SELECT 
            segment,
            COUNT(*) as count,
            AVG(total_contributed) as avg_contributed,
            AVG(engagement_score) as avg_engagement,
            AVG(risk_score) as avg_risk
        FROM an_member_analytics
        GROUP BY segment
    `);

    return segments;
};