const mysql = require('../../../src/config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// 1. AGGREGATE DAILY STATS
// ============================================================
exports.aggregateDailyStats = async (date = null) => {
    const targetDate = date || new Date().toISOString().split('T')[0];

    try {
        // Total members
        const members = await mysql.queryOne(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN DATE(created_at) = ? THEN 1 ELSE 0 END) as new
            FROM users
        `, [targetDate]);

        // Contributions
        const contributions = await mysql.queryOne(`
            SELECT COALESCE(SUM(amount), 0) as total
            FROM contributions 
            WHERE DATE(created_at) = ?
        `, [targetDate]);

        // Loans
        const loans = await mysql.queryOne(`
            SELECT COALESCE(SUM(amount), 0) as total
            FROM loans 
            WHERE DATE(created_at) = ?
        `, [targetDate]);

        // Repayments
        const repayments = await mysql.queryOne(`
            SELECT COALESCE(SUM(amount), 0) as total
            FROM contributions 
            WHERE type = 'marejesho' AND DATE(created_at) = ?
        `, [targetDate]);

        // Fees
        const fees = await mysql.queryOne(`
            SELECT COALESCE(SUM(amount), 0) as total
            FROM membership_fees 
            WHERE status = 'paid' AND DATE(paid_date) = ?
        `, [targetDate]);

        // Upsert
        await mysql.query(`
            INSERT INTO an_daily_stats 
            (id, stat_date, total_members, active_members, new_members, 
             total_contributions, total_loans, total_repayments, total_fees)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                total_members = VALUES(total_members),
                active_members = VALUES(active_members),
                new_members = VALUES(new_members),
                total_contributions = VALUES(total_contributions),
                total_loans = VALUES(total_loans),
                total_repayments = VALUES(total_repayments),
                total_fees = VALUES(total_fees)
        `, [
            uuidv4(), targetDate,
            members.total, members.active, members.new,
            contributions.total, loans.total, repayments.total, fees.total
        ]);

        console.log(`✅ Daily stats aggregated for ${targetDate}`);
        return { date: targetDate };
    } catch (err) {
        console.error('Aggregate daily stats error:', err);
        throw err;
    }
};

// ============================================================
// 2. UPDATE MEMBER ANALYTICS
// ============================================================
exports.updateMemberAnalytics = async (userId = null) => {
    const whereClause = userId ? `WHERE u.id = '${userId}'` : '';

    try {
        const users = await mysql.query(`
            SELECT u.id FROM users u ${whereClause}
        `);

        for (const user of users) {
            await exports.updateSingleMemberAnalytics(user.id);
        }

        console.log(`✅ Updated ${users.length} members analytics`);
        return { count: users.length };
    } catch (err) {
        console.error('Update member analytics error:', err);
        throw err;
    }
};

const updateSingleMemberAnalytics = async (userId) => {
    // Contribution stats
    const contribStats = await mysql.queryOne(`
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total,
            COALESCE(AVG(amount), 0) as avg_amount,
            MAX(created_at) as last_contribution
        FROM contributions WHERE user_id = ?
    `, [userId]);

    // Loan stats
    const loanStats = await mysql.queryOne(`
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total
        FROM loans WHERE user_id = ?
    `, [userId]);

    // Consistency score (based on months with contributions)
    const consistencyResult = await mysql.queryOne(`
        SELECT 
            COUNT(DISTINCT DATE_FORMAT(created_at, '%Y-%m')) as months,
            DATEDIFF(NOW(), MIN(created_at)) / 30 as total_months
        FROM contributions WHERE user_id = ?
    `, [userId]);

    const consistency = consistencyResult.total_months > 0
        ? (consistencyResult.months / consistencyResult.total_months) * 100
        : 0;

    // Engagement score (0-100)
    const engagement = Math.min(100, 
        (contribStats.count * 5) + 
        (consistency * 0.5)
    );

    // Churn probability (based on inactivity)
    const daysSince = contribStats.last_contribution
        ? Math.floor((Date.now() - new Date(contribStats.last_contribution).getTime()) / (1000 * 60 * 60 * 24))
        : 999;
    
    const churnProb = Math.min(100, (daysSince / 90) * 100);

    // Risk score
    const riskScore = Math.min(100, (churnProb * 0.7) + ((100 - engagement) * 0.3));

    // Lifetime value
    const ltv = contribStats.total + loanStats.total * 0.1;

    // Segment
    let segment = 'new';
    if (ltv > 1000000) segment = 'vip';
    else if (ltv > 500000) segment = 'premium';
    else if (ltv > 100000) segment = 'regular';
    else if (riskScore > 70) segment = 'at_risk';
    else if (churnProb > 60) segment = 'dormant';

    // Upsert
    await mysql.query(`
        INSERT INTO an_member_analytics 
        (id, user_id, total_contributed, total_loans, contribution_count,
         avg_monthly_contribution, consistency_score, engagement_score,
         risk_score, lifetime_value, segment, churn_probability)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            total_contributed = VALUES(total_contributed),
            total_loans = VALUES(total_loans),
            contribution_count = VALUES(contribution_count),
            avg_monthly_contribution = VALUES(avg_monthly_contribution),
            consistency_score = VALUES(consistency_score),
            engagement_score = VALUES(engagement_score),
            risk_score = VALUES(risk_score),
            lifetime_value = VALUES(lifetime_value),
            segment = VALUES(segment),
            churn_probability = VALUES(churn_probability)
    `, [
        uuidv4(), userId,
        contribStats.total, loanStats.total, contribStats.count,
        contribStats.avg_amount, consistency, engagement,
        riskScore, ltv, segment, churnProb
    ]);
};

// ============================================================
// 3. DETECT ANOMALIES
// ============================================================
exports.detectAnomalies = async () => {
    try {
        // Check contributions vs 30-day average
        const avg = await mysql.queryOne(`
            SELECT AVG(daily_total) as avg_total, STDDEV(daily_total) as std
            FROM (
                SELECT DATE(created_at) as date, SUM(amount) as daily_total
                FROM contributions
                WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at)
            ) t
        `);

        const today = await mysql.queryOne(`
            SELECT COALESCE(SUM(amount), 0) as total
            FROM contributions WHERE DATE(created_at) = CURDATE()
        `);

        if (avg.avg_total && avg.std) {
            const deviation = (today.total - avg.avg_total) / avg.std;

            if (Math.abs(deviation) > 3) {
                await mysql.query(`
                    INSERT INTO an_anomalies 
                    (id, anomaly_type, severity, entity_type, description, 
                     expected_value, actual_value, deviation)
                    VALUES (?, 'contribution_spike', ?, 'system', ?, ?, ?, ?)
                `, [
                    uuidv4(),
                    Math.abs(deviation) > 5 ? 'high' : 'medium',
                    `Michango ya leo ni ${deviation > 0 ? 'juu' : 'chini'} ya kawaida`,
                    avg.avg_total,
                    today.total,
                    deviation
                ]);
            }
        }

        return { detected: 1 };
    } catch (err) {
        console.error('Detect anomalies error:', err);
        return { detected: 0 };
    }
};