-- ============================================================
-- SIP VOICE CALLS
-- ============================================================

-- SIP accounts za wanachama
CREATE TABLE IF NOT EXISTS sip_accounts (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) UNIQUE NOT NULL,
    sip_username VARCHAR(50) UNIQUE NOT NULL,
    sip_password VARCHAR(100) NOT NULL,
    sip_domain VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    last_registered_at TIMESTAMP NULL,
    device_info JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_sip_username (sip_username),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Simu zote
CREATE TABLE IF NOT EXISTS voice_calls (
    id CHAR(36) PRIMARY KEY,
    caller_id CHAR(36) NOT NULL,
    receiver_id CHAR(36),
    call_type VARCHAR(20) DEFAULT 'direct',
    status VARCHAR(20) DEFAULT 'initiated',
    asterisk_channel_id VARCHAR(100),
    asterisk_unique_id VARCHAR(100),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    answered_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    duration_seconds INT DEFAULT 0,
    recording_url TEXT,
    recording_status VARCHAR(20) DEFAULT 'none',
    quality_score DECIMAL(5,2),
    metadata JSON,
    INDEX idx_caller_id (caller_id),
    INDEX idx_receiver_id (receiver_id),
    INDEX idx_status (status),
    INDEX idx_created_at (started_at DESC)
) ENGINE=InnoDB;

-- Conference calls (simu za viongozi)
CREATE TABLE IF NOT EXISTS voice_conferences (
    id CHAR(36) PRIMARY KEY,
    room_number VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(255),
    host_id CHAR(36) NOT NULL,
    max_participants INT DEFAULT 20,
    status VARCHAR(20) DEFAULT 'active',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    recording_url TEXT,
    participants JSON,
    created_by CHAR(36),
    INDEX idx_room_number (room_number),
    INDEX idx_status (status),
    FOREIGN KEY (host_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Voicemail
CREATE TABLE IF NOT EXISTS voicemails (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    caller_id CHAR(36),
    caller_name VARCHAR(200),
    duration INT DEFAULT 0,
    file_url TEXT NOT NULL,
    transcription TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- SIP call logs (analytics)
CREATE TABLE IF NOT EXISTS sip_call_logs (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36),
    event VARCHAR(50),
    details JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_event (event),
    INDEX idx_created_at (created_at DESC)
) ENGINE=InnoDB;