const axios = require('axios');
const WebSocket = require('ws');
const mysql = require('../../../src/config/mysql');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

// ============================================================
// CONFIG
// ============================================================
const ARI_URL = process.env.ASTERISK_ARI_URL || 'http://asterisk:8088/ari';
const ARI_USER = process.env.ASTERISK_ARI_USER || 'admin';
const ARI_PASSWORD = process.env.ASTERISK_ARI_PASSWORD || 'thamani_ari_secret_2024';
const ARI_WS_URL = process.env.ASTERISK_ARI_WS || 'ws://asterisk:8088/ari/events';

const ARI_AUTH = {
    username: ARI_USER,
    password: ARI_PASSWORD
};

// ============================================================
// 1. ARI REQUEST
// ============================================================
const ariRequest = async (method, path, data = null) => {
    try {
        const response = await axios({
            method,
            url: `${ARI_URL}${path}`,
            auth: ARI_AUTH,
            data,
            params: {
                api_key: `${ARI_USER}:${ARI_PASSWORD}`
            },
            timeout: 10000
        });
        return response.data;
    } catch (err) {
        console.error('ARI Error:', err.response?.data || err.message);
        throw err;
    }
};

// ============================================================
// 2. CREATE SIP ACCOUNT (Kwa kila mwanachama)
// ============================================================
exports.createSIPAccount = async (userId) => {
    try {
        // Check if exists
        const existing = await mysql.queryOne(
            `SELECT * FROM sip_accounts WHERE user_id = ?`,
            [userId]
        );

        if (existing) return existing;

        // Generate credentials
        const sipUsername = `thm${userId.slice(0, 8)}`;
        const sipPassword = crypto.randomBytes(16).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 20);

        // Save to DB
        const id = uuidv4();
        await mysql.query(`
            INSERT INTO sip_accounts (id, user_id, sip_username, sip_password, sip_domain)
            VALUES (?, ?, ?, ?, ?)
        `, [id, userId, sipUsername, sipPassword, process.env.SIP_DOMAIN || 'sip.thamaniyangu.com']);

        // Create Asterisk config files
        await exports.writeAsteriskConfig(sipUsername, sipPassword);

        // Reload Asterisk
        await exports.reloadAsterisk();

        return {
            id,
            user_id: userId,
            sip_username: sipUsername,
            sip_password: sipPassword,
            sip_domain: process.env.SIP_DOMAIN || 'sip.thamaniyangu.com'
        };
    } catch (err) {
        console.error('Create SIP account error:', err);
        throw err;
    }
};

// ============================================================
// 3. WRITE ASTERISK CONFIG
// ============================================================
exports.writeAsteriskConfig = async (username, password) => {
    const fs = require('fs');
    const path = require('path');
    
    const configPath = process.env.ASTERISK_CONFIG_PATH || '/etc/asterisk/pjsip.d';
    
    if (!fs.existsSync(configPath)) {
        fs.mkdirSync(configPath, { recursive: true });
    }

    const config = `
[${username}](member-template)
[${username}-auth](member-auth)
username=${username}
password=${password}
[${username}-aor](member-aor)
`;

    fs.writeFileSync(
        path.join(configPath, `${username}.conf`),
        config
    );
};

// ============================================================
// 4. RELOAD ASTERISK
// ============================================================
exports.reloadAsterisk = async () => {
    try {
        // Use AMI or ARI to reload
        await ariRequest('POST', '/asterisk/modules/res_pjsip.so/reload');
    } catch (err) {
        console.error('Asterisk reload error:', err.message);
    }
};

// ============================================================
// 5. INITIATE CALL
// ============================================================
exports.initiateCall = async (callerId, receiverId, options = {}) => {
    try {
        // Get SIP accounts
        const caller = await mysql.queryOne(
            `SELECT * FROM sip_accounts WHERE user_id = ? AND status = 'active'`,
            [callerId]
        );
        const receiver = await mysql.queryOne(
            `SELECT * FROM sip_accounts WHERE user_id = ? AND status = 'active'`,
            [receiverId]
        );

        if (!caller || !receiver) {
            throw new Error('SIP accounts hazipatikani');
        }

        // Create call record
        const callId = uuidv4();
        await mysql.query(`
            INSERT INTO voice_calls 
            (id, caller_id, receiver_id, call_type, status)
            VALUES (?, ?, ?, 'direct', 'initiated')
        `, [callId, callerId, receiverId]);

        // Create channel via ARI
        const channel = await ariRequest('POST', '/channels', null, {
            params: {
                endpoint: `PJSIP/${receiver.sip_username}`,
                app: 'thamani-app',
                appArgs: `callId=${callId},callerId=${callerId},receiverId=${receiverId}`,
                callerId: `"${caller.sip_username}" <${caller.sip_username}>`
            }
        });

        // Update call with channel info
        await mysql.query(`
            UPDATE voice_calls 
            SET asterisk_channel_id = ?, asterisk_unique_id = ?
            WHERE id = ?
        `, [channel.id, channel.id, callId]);

        // Notify receiver via socket
        if (global.io) {
            global.io.to(`user-${receiverId}`).emit('incoming-call', {
                callId,
                callerId,
                callerName: options.callerName || 'Mwanachama',
                channelId: channel.id
            });
        }

        return {
            callId,
            channelId: channel.id,
            status: 'ringing'
        };
    } catch (err) {
        console.error('Initiate call error:', err);
        throw err;
    }
};

// ============================================================
// 6. ANSWER CALL
// ============================================================
exports.answerCall = async (callId) => {
    const call = await mysql.queryOne(
        `SELECT * FROM voice_calls WHERE id = ?`,
        [callId]
    );

    if (!call) throw new Error('Call haipatikani');

    try {
        await ariRequest('POST', `/channels/${call.asterisk_channel_id}/answer`);

        await mysql.query(`
            UPDATE voice_calls 
            SET status = 'answered', answered_at = NOW()
            WHERE id = ?
        `, [callId]);

        return { success: true };
    } catch (err) {
        console.error('Answer error:', err);
        throw err;
    }
};

// ============================================================
// 7. END CALL
// ============================================================
exports.endCall = async (callId) => {
    const call = await mysql.queryOne(
        `SELECT * FROM voice_calls WHERE id = ?`,
        [callId]
    );

    if (!call) throw new Error('Call haipatikani');

    try {
        // Hangup channel
        await ariRequest('DELETE', `/channels/${call.asterisk_channel_id}`);

        // Update DB
        const duration = call.answered_at 
            ? Math.floor((Date.now() - new Date(call.answered_at).getTime()) / 1000)
            : 0;

        await mysql.query(`
            UPDATE voice_calls 
            SET status = 'ended', ended_at = NOW(), duration_seconds = ?
            WHERE id = ?
        `, [duration, callId]);

        // Notify both parties
        if (global.io) {
            [call.caller_id, call.receiver_id].forEach(uid => {
                global.io.to(`user-${uid}`).emit('call-ended', { callId, duration });
            });
        }

        return { success: true, duration };
    } catch (err) {
        console.error('End call error:', err);
        throw err;
    }
};

// ============================================================
// 8. START RECORDING
// ============================================================
exports.startRecording = async (callId) => {
    const call = await mysql.queryOne(
        `SELECT * FROM voice_calls WHERE id = ?`,
        [callId]
    );

    if (!call) throw new Error('Call haipatikani');

    try {
        const recordingName = `recording-${callId}-${Date.now()}`;
        
        await ariRequest('POST', `/channels/${call.asterisk_channel_id}/record`, null, {
            params: {
                name: recordingName,
                format: 'wav',
                ifExists: 'overwrite'
            }
        });

        await mysql.query(`
            UPDATE voice_calls SET recording_status = 'recording' WHERE id = ?
        `, [callId]);

        return { success: true, recordingName };
    } catch (err) {
        console.error('Recording error:', err);
        throw err;
    }
};

// ============================================================
// 9. CREATE CONFERENCE
// ============================================================
exports.createConference = async (hostId, title, options = {}) => {
    try {
        const roomNumber = `8${Math.floor(100 + Math.random() * 900)}`; // 8XX
        const id = uuidv4();

        await mysql.query(`
            INSERT INTO voice_conferences 
            (id, room_number, title, host_id, max_participants, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [id, roomNumber, title, hostId, options.maxParticipants || 20, hostId]);

        // Create bridge in Asterisk
        const bridge = await ariRequest('POST', '/bridges', null, {
            params: {
                type: 'mixing',
                name: `conf-${id}`
            }
        });

        // Notify participants
        if (global.io && options.participants) {
            options.participants.forEach(pid => {
                global.io.to(`user-${pid}`).emit('conference-invite', {
                    conferenceId: id,
                    roomNumber,
                    title,
                    hostId
                });
            });
        }

        return {
            id,
            roomNumber,
            title,
            bridgeId: bridge.id,
            participants: options.participants || []
        };
    } catch (err) {
        console.error('Create conference error:', err);
        throw err;
    }
};

// ============================================================
// 10. JOIN CONFERENCE
// ============================================================
exports.joinConference = async (conferenceId, userId) => {
    try {
        const conference = await mysql.queryOne(
            `SELECT * FROM voice_conferences WHERE id = ? AND status = 'active'`,
            [conferenceId]
        );

        if (!conference) throw new Error('Conference haipatikani');

        const sipAccount = await mysql.queryOne(
            `SELECT * FROM sip_accounts WHERE user_id = ?`,
            [userId]
        );

        if (!sipAccount) throw new Error('SIP account haipatikani');

        // Create channel to join conference
        const channel = await ariRequest('POST', '/channels', null, {
            params: {
                endpoint: `PJSIP/${sipAccount.sip_username}`,
                app: 'thamani-app',
                appArgs: `conferenceId=${conferenceId},userId=${userId}`,
                callerId: `"${sipAccount.sip_username}" <${sipAccount.sip_username}>`
            }
        });

        // Add to bridge
        await ariRequest('POST', `/bridges/${conference.bridge_id}/addChannel`, null, {
            params: { channel: channel.id }
        });

        // Update participants
        const participants = JSON.parse(conference.participants || '[]');
        if (!participants.includes(userId)) {
            participants.push(userId);
            await mysql.query(`
                UPDATE voice_conferences SET participants = ? WHERE id = ?
            `, [JSON.stringify(participants), conferenceId]);
        }

        return { success: true, channelId: channel.id };
    } catch (err) {
        console.error('Join conference error:', err);
        throw err;
    }
};

// ============================================================
// 11. END CONFERENCE
// ============================================================
exports.endConference = async (conferenceId, userId) => {
    try {
        const conference = await mysql.queryOne(
            `SELECT * FROM voice_conferences WHERE id = ?`,
            [conferenceId]
        );

        if (!conference) throw new Error('Conference haipatikani');
        if (conference.host_id !== userId && !['mwenyekiti'].includes(userId)) {
            throw new Error('Ni host pekee anayeweza kumaliza');
        }

        // Delete bridge
        await ariRequest('DELETE', `/bridges/${conference.bridge_id}`);

        // Update DB
        await mysql.query(`
            UPDATE voice_conferences SET status = 'ended', ended_at = NOW() WHERE id = ?
        `, [conferenceId]);

        // Notify participants
        if (global.io) {
            const participants = JSON.parse(conference.participants || '[]');
            participants.forEach(pid => {
                global.io.to(`user-${pid}`).emit('conference-ended', { conferenceId });
            });
        }

        return { success: true };
    } catch (err) {
        console.error('End conference error:', err);
        throw err;
    }
};

// ============================================================
// 12. LISTEN TO ARI EVENTS (WebSocket)
// ============================================================
exports.setupEventListeners = () => {
    const wsUrl = `${ARI_WS_URL}?api_key=${ARI_USER}:${ARI_PASSWORD}&subscribeAll=true`;
    
    let ws;
    let reconnectTimeout;

    const connect = () => {
        console.log('📡 Connecting to Asterisk ARI...');
        ws = new WebSocket(wsUrl);

        ws.on('open', () => {
            console.log('✅ Asterisk ARI connected');
        });

        ws.on('message', async (data) => {
            try {
                const event = JSON.parse(data);

                switch (event.type) {
                    case 'ChannelStateChange':
                        await handleChannelStateChange(event);
                        break;
                    case 'ChannelHangupRequest':
                        await handleChannelHangup(event);
                        break;
                    case 'ChannelDtmfReceived':
                        await handleDTMF(event);
                        break;
                    case 'RecordingFinished':
                        await handleRecordingFinished(event);
                        break;
                    case 'StasisStart':
                        await handleStasisStart(event);
                        break;
                }
            } catch (err) {
                console.error('ARI event error:', err);
            }
        });

        ws.on('close', () => {
            console.log('❌ Asterisk ARI disconnected, reconnecting...');
            clearTimeout(reconnectTimeout);
            reconnectTimeout = setTimeout(connect, 5000);
        });

        ws.on('error', (err) => {
            console.error('ARI WebSocket error:', err.message);
        });
    };

    connect();
};

const handleChannelStateChange = async (event) => {
    const channelId = event.channel.id;
    const state = event.channel.state;

    const call = await mysql.queryOne(`
        SELECT id FROM voice_calls WHERE asterisk_channel_id = ?
    `, [channelId]);

    if (call) {
        if (state === 'Up') {
            await mysql.query(`
                UPDATE voice_calls 
                SET status = 'answered', answered_at = NOW()
                WHERE id = ? AND answered_at IS NULL
            `, [call.id]);
        }
    }
};

const handleChannelHangup = async (event) => {
    const channelId = event.channel.id;

    const call = await mysql.queryOne(`
        SELECT * FROM voice_calls WHERE asterisk_channel_id = ?
    `, [channelId]);

    if (call && call.status !== 'ended') {
        const duration = call.answered_at
            ? Math.floor((Date.now() - new Date(call.answered_at).getTime()) / 1000)
            : 0;

        await mysql.query(`
            UPDATE voice_calls 
            SET status = 'ended', ended_at = NOW(), duration_seconds = ?
            WHERE id = ?
        `, [duration, call.id]);

        if (global.io) {
            [call.caller_id, call.receiver_id].forEach(uid => {
                if (uid) {
                    global.io.to(`user-${uid}`).emit('call-ended', {
                        callId: call.id,
                        duration
                    });
                }
            });
        }
    }
};

const handleDTMF = async (event) => {
    // Handle DTMF tones (for IVR, etc.)
    console.log('DTMF:', event.digit);
};

const handleRecordingFinished = async (event) => {
    const recordingName = event.recording.name;
    // Move file from temp to permanent storage
    console.log('Recording finished:', recordingName);
};

const handleStasisStart = async (event) => {
    // Handle new channel in Stasis
    console.log('StasisStart:', event.channel.id);
};

// ============================================================
// 13. GET USER CALL HISTORY
// ============================================================
exports.getCallHistory = async (userId, options = {}) => {
    const { limit = 50, offset = 0 } = options;

    const calls = await mysql.query(`
        SELECT 
            vc.*,
            caller.first_name as caller_first_name,
            caller.last_name as caller_last_name,
            receiver.first_name as receiver_first_name,
            receiver.last_name as receiver_last_name
        FROM voice_calls vc
        LEFT JOIN users caller ON vc.caller_id = caller.id
        LEFT JOIN users receiver ON vc.receiver_id = receiver.id
        WHERE vc.caller_id = ? OR vc.receiver_id = ?
        ORDER BY vc.started_at DESC
        LIMIT ? OFFSET ?
    `, [userId, userId, parseInt(limit), parseInt(offset)]);

    return calls;
};

// ============================================================
// 14. GET ACTIVE CALLS
// ============================================================
exports.getActiveCalls = async () => {
    return await mysql.query(`
        SELECT * FROM voice_calls 
        WHERE status IN ('initiated', 'ringing', 'answered')
        ORDER BY started_at DESC
    `);
};

// ============================================================
// 15. LOG SIP EVENT
// ============================================================
exports.logSIPEvent = async (userId, event, details) => {
    await mysql.query(`
        INSERT INTO sip_call_logs (id, user_id, event, details)
        VALUES (UUID(), ?, ?, ?)
    `, [userId, event, JSON.stringify(details)]);
};

// Initialize event listeners
exports.setupEventListeners();