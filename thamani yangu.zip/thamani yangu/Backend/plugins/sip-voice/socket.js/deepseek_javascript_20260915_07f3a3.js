module.exports = (io) => {
    io.on('connection', (socket) => {
        socket.on('sip-register', async (data) => {
            socket.join(`sip-${data.userId}`);
            console.log(`SIP user ${data.userId} registered via socket`);
        });

        socket.on('sip-call-answer', async ({ callId }) => {
            const asteriskService = require('./services/asteriskService');
            try {
                await asteriskService.answerCall(callId);
            } catch (err) {
                console.error('Socket answer error:', err);
            }
        });

        socket.on('sip-call-end', async ({ callId }) => {
            const asteriskService = require('./services/asteriskService');
            try {
                await asteriskService.endCall(callId);
            } catch (err) {
                console.error('Socket end error:', err);
            }
        });
    });
};