const asteriskService = require('../services/asteriskService');

// ============================================================
// CREATE CONFERENCE
// ============================================================
exports.createConference = async (req, res) => {
    const { title, participants, maxParticipants } = req.body;
    const hostId = req.user.id;

    if (!title) {
        return res.status(400).json({ error: 'title inahitajika' });
    }

    try {
        const result = await asteriskService.createConference(hostId, title, {
            participants: participants || [],
            maxParticipants: maxParticipants || 20
        });

        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// JOIN CONFERENCE
// ============================================================
exports.joinConference = async (req, res) => {
    const { conferenceId } = req.params;

    try {
        const result = await asteriskService.joinConference(conferenceId, req.user.id);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// END CONFERENCE
// ============================================================
exports.endConference = async (req, res) => {
    const { conferenceId } = req.params;

    try {
        const result = await asteriskService.endConference(conferenceId, req.user.id);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// LIST ACTIVE CONFERENCES
// ============================================================
exports.listConferences = async (req, res) => {
    try {
        const conferences = await require('../../../src/config/mysql').query(`
            SELECT vc.*, u.first_name, u.last_name
            FROM voice_conferences vc
            LEFT JOIN users u ON vc.host_id = u.id
            WHERE vc.status = 'active'
            ORDER BY vc.started_at DESC
        `);
        res.json(conferences);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};