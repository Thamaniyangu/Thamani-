const asteriskService = require('../services/asteriskService');
const mysql = require('../../../src/config/mysql');

// ============================================================
// INITIATE CALL
// ============================================================
exports.initiateCall = async (req, res) => {
    const { receiverId, callerName } = req.body;
    const callerId = req.user.id;

    if (!receiverId) {
        return res.status(400).json({ error: 'receiverId inahitajika' });
    }

    if (receiverId === callerId) {
        return res.status(400).json({ error: 'Hauwezi kujipigia mwenyewe' });
    }

    try {
        // Ensure receiver has SIP account
        await asteriskService.createSIPAccount(receiverId);

        const result = await asteriskService.initiateCall(callerId, receiverId, { callerName });

        // Log
        await asteriskService.logSIPEvent(callerId, 'call_initiated', {
            receiverId,
            callId: result.callId
        });

        res.json(result);
    } catch (err) {
        console.error('Initiate call error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// ANSWER CALL
// ============================================================
exports.answerCall = async (req, res) => {
    const { callId } = req.params;

    try {
        const result = await asteriskService.answerCall(callId);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// END CALL
// ============================================================
exports.endCall = async (req, res) => {
    const { callId } = req.params;

    try {
        const result = await asteriskService.endCall(callId);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET CALL HISTORY
// ============================================================
exports.getCallHistory = async (req, res) => {
    try {
        const calls = await asteriskService.getCallHistory(req.user.id, req.query);
        res.json(calls);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET SIP CREDENTIALS
// ============================================================
exports.getSIPCredentials = async (req, res) => {
    try {
        const account = await asteriskService.createSIPAccount(req.user.id);
        res.json({
            sip_username: account.sip_username,
            sip_password: account.sip_password,
            sip_domain: account.sip_domain,
            wss_url: process.env.SIP_WSS_URL || 'wss://sip.thamaniyangu.com:8089/ws'
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// START RECORDING
// ============================================================
exports.startRecording = async (req, res) => {
    const { callId } = req.params;

    try {
        const result = await asteriskService.startRecording(callId);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ACTIVE CALLS (Admin)
// ============================================================
exports.getActiveCalls = async (req, res) => {
    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        const calls = await asteriskService.getActiveCalls();
        res.json(calls);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};