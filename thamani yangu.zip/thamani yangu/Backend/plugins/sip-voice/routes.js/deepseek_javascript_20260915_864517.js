const express = require('express');
const callController = require('./controllers/callController');
const conferenceController = require('./controllers/conferenceController');
const { authenticate } = require('../../src/middleware/auth');
const { requireMwenyekiti } = require('../../src/middleware/mwenyekitiOnly');

const router = express.Router();

// All routes: auth + Mwenyekiti only
router.use(authenticate);
router.use(requireMwenyekiti);

// Calls
router.post('/calls/initiate', callController.initiateCall);
router.post('/calls/:callId/answer', callController.answerCall);
router.post('/calls/:callId/end', callController.endCall);
router.get('/calls/history', callController.getCallHistory);
router.get('/calls/active', callController.getActiveCalls);
router.get('/sip/credentials', callController.getSIPCredentials);
router.post('/calls/:callId/record', callController.startRecording);

// Conferences
router.post('/conferences', conferenceController.createConference);
router.post('/conferences/:conferenceId/join', conferenceController.joinConference);
router.post('/conferences/:conferenceId/end', conferenceController.endConference);
router.get('/conferences', conferenceController.listConferences);

module.exports = router;