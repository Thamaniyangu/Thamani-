# 1. Unda folder la plugin
cd backend/plugins
mkdir my-new-feature

# 2. Unda plugin.json
cat > my-new-feature/plugin.json << 'EOF'
{
    "name": "my-new-feature",
    "version": "1.0.0",
    "description": "Kipengele kipya cha baadaye",
    "author": "THAMANI IT Team",
    "dependencies": [],
    "basePath": "/api/plugins/my-feature",
    "entry": {
        "routes": "routes.js",
        "socket": "socket.js"
    }
}
EOF

# 3. Unda routes.js
cat > my-new-feature/routes.js << 'EOF'
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.json({ message: 'Plugin inafanya kazi!' });
});

module.exports = router;
EOF

# 4. Unda migrations (optional)
mkdir my-new-feature/migrations
cat > my-new-feature/migrations/001_init.sql << 'EOF'
CREATE TABLE IF NOT EXISTS my_feature_data (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36),
    data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
EOF