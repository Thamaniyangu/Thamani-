CREATE TABLE IF NOT EXISTS ip_whitelist (
    id CHAR(36) PRIMARY KEY,
    ip VARCHAR(45) NOT NULL UNIQUE,
    description VARCHAR(255),
    user_id CHAR(36),
    role VARCHAR(20),
    active BOOLEAN DEFAULT TRUE,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    INDEX idx_ip (ip),
    INDEX idx_active (active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ip_blacklist (
    id CHAR(36) PRIMARY KEY,
    ip VARCHAR(45) NOT NULL UNIQUE,
    reason TEXT,
    blocked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip)
) ENGINE=InnoDB;