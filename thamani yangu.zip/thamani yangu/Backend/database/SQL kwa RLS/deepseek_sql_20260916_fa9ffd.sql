-- RLS policy kwa ai-profiles bucket
-- Nenda kwenye Supabase → Storage → ai-profiles → Policies

-- Read: Public
CREATE POLICY "Anyone can view AI profiles"
ON storage.objects FOR SELECT
USING (bucket_id = 'ai-profiles');

-- Write: Mwenyekiti pekee
CREATE POLICY "Only Mwenyekiti can upload AI profiles"
ON storage.objects FOR INSERT
WITH CHECK (
    bucket_id = 'ai-profiles' AND
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'mwenyekiti')
);

-- Update/Delete: Mwenyekiti pekee
CREATE POLICY "Only Mwenyekiti can update AI profiles"
ON storage.objects FOR UPDATE
USING (
    bucket_id = 'ai-profiles' AND
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'mwenyekiti')
);

CREATE POLICY "Only Mwenyekiti can delete AI profiles"
ON storage.objects FOR DELETE
USING (
    bucket_id = 'ai-profiles' AND
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'mwenyekiti')
);