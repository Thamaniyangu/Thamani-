-- ============================================================
-- WHITEBOARD
-- ============================================================
CREATE TABLE IF NOT EXISTS whiteboards (
    id CHAR(36) PRIMARY KEY,
    meeting_id CHAR(36),
    room_id CHAR(36),
    name VARCHAR(100) DEFAULT 'Whiteboard',
    background_color VARCHAR(20) DEFAULT '#FFFFFF',
    status VARCHAR(20) DEFAULT 'active',
    created_by CHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_meeting_id (meeting_id),
    INDEX idx_room_id (room_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS whiteboard_strokes (
    id CHAR(36) PRIMARY KEY,
    whiteboard_id CHAR(36) NOT NULL,
    user_id CHAR(36),
    tool VARCHAR(20) DEFAULT 'pen',
    color VARCHAR(20) DEFAULT '#000000',
    width INT DEFAULT 2,
    points JSON NOT NULL,
    text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_whiteboard_id (whiteboard_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB;