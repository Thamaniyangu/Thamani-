-- AI PROFILES
CREATE TABLE IF NOT EXISTS ai_profiles (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    photo_url TEXT,
    updated_by UUID REFERENCES users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO ai_profiles (id, name, description) VALUES
    ('ai-buddy', 'THAMANI AI BUDDY', 'Msaidizi wa jumla'),
    ('ai-financial', 'THAMANI FINANCIAL ADVISOR', 'Mshauri wa kifedha'),
    ('ai-leadership', 'THAMANI LEADERSHIP MENTOR', 'Mshauri wa uongozi')
ON CONFLICT (id) DO NOTHING;

-- AI USAGE LOGS
CREATE TABLE IF NOT EXISTS ai_usage_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    user_role VARCHAR(20) NOT NULL,
    ai_type VARCHAR(20),
    message TEXT,
    provider VARCHAR(50),
    attempted_providers JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MEDIA LOGS
CREATE TABLE IF NOT EXISTS media_generation_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    media_type VARCHAR(20) NOT NULL,
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS media_analysis_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    media_type VARCHAR(20) NOT NULL,
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    file_name VARCHAR(255),
    file_size BIGINT,
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_provider ON ai_usage_logs(provider);
CREATE INDEX IF NOT EXISTS idx_ai_usage_created ON ai_usage_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_generation_user ON media_generation_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_media_analysis_user ON media_analysis_logs(user_id);