-- ============================================================
-- MEETING POLLS
-- ============================================================
CREATE TABLE IF NOT EXISTS meeting_polls (
    id CHAR(36) PRIMARY KEY,
    meeting_id CHAR(36),
    room_id CHAR(36),
    question TEXT NOT NULL,
    options JSON NOT NULL,
    allow_multiple BOOLEAN DEFAULT FALSE,
    is_anonymous BOOLEAN DEFAULT TRUE,
    status VARCHAR(20) DEFAULT 'active',
    ends_at TIMESTAMP NULL,
    created_by CHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP NULL,
    INDEX idx_meeting_id (meeting_id),
    INDEX idx_room_id (room_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS poll_votes (
    id CHAR(36) PRIMARY KEY,
    poll_id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    option_index INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_poll_option (poll_id, user_id, option_index),
    INDEX idx_poll_id (poll_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB;