-- ============================================================
-- ADVANCED AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36),
    user_role VARCHAR(20),
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id CHAR(36),
    details JSON,
    ip VARCHAR(45),
    user_agent TEXT,
    method VARCHAR(10),
    path VARCHAR(500),
    status_code INT,
    duration_ms INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_resource (resource_type, resource_id),
    INDEX idx_created_at (created_at DESC),
    INDEX idx_ip (ip)
) ENGINE=InnoDB;

-- Sensitive actions
CREATE TABLE IF NOT EXISTS sensitive_actions (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36),
    action VARCHAR(100),
    resource_id CHAR(36),
    before_state JSON,
    after_state JSON,
    reason TEXT,
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action)
) ENGINE=InnoDB;