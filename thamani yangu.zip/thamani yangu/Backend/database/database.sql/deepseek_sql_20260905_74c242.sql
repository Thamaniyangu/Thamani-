-- ============================================================
-- THAMANI YANGU - POSTGRESQL SCHEMA (PRIMARY)
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- USERS
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    member_id VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash TEXT NOT NULL,
    role VARCHAR(20) DEFAULT 'mwanachama',
    first_name VARCHAR(100),
    middle_name VARCHAR(100),
    last_name VARCHAR(100),
    profile_photo_url TEXT,
    status VARCHAR(20) DEFAULT 'active',
    region VARCHAR(100),
    district VARCHAR(100),
    ward_street TEXT,
    emergency_contact_name1 VARCHAR(200),
    emergency_contact_name2 VARCHAR(200),
    emergency_relationship VARCHAR(50),
    emergency_phone VARCHAR(20),
    emergency_region VARCHAR(100),
    emergency_district VARCHAR(100),
    emergency_ward_street TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- SIGNUP TOKENS
CREATE TABLE signup_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token TEXT UNIQUE NOT NULL,
    email VARCHAR(255) NOT NULL,
    member_id VARCHAR(20) NOT NULL,
    used BOOLEAN DEFAULT false,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- CONTRIBUTIONS
CREATE TABLE contributions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('hisa', 'jamii', 'faini', 'marejesho')),
    amount DECIMAL(15,2) NOT NULL,
    contribution_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    recorded_by UUID REFERENCES users(id),
    receipt_number VARCHAR(50) UNIQUE,
    receipt_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MEMBERSHIP FEES
CREATE TABLE membership_fees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    period VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'unpaid',
    paid_date TIMESTAMP WITH TIME ZONE,
    recorded_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- LOANS
CREATE TABLE loans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    amount DECIMAL(15,2) NOT NULL,
    interest_rate DECIMAL(5,2) DEFAULT 10.00,
    total_payable DECIMAL(15,2),
    due_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    approved_by UUID REFERENCES users(id),
    recorded_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- CHAT ROOMS
CREATE TABLE chat_rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100),
    type VARCHAR(20) NOT NULL CHECK (type IN ('community', 'leaders_only', 'members_only', 'private')),
    created_by UUID REFERENCES users(id),
    participants JSONB DEFAULT '[]'::jsonb,
    last_message JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- CHAT MESSAGES
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES chat_rooms(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES users(id),
    sender_name VARCHAR(200),
    sender_member_id VARCHAR(20),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    reply_to UUID REFERENCES chat_messages(id),
    edited BOOLEAN DEFAULT false,
    deleted BOOLEAN DEFAULT false,
    read_by JSONB DEFAULT '[]'::jsonb,
    active_users JSONB DEFAULT '[]'::jsonb,
    media_deleted BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- DOCUMENTS
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    document_name VARCHAR(255) DEFAULT 'Untitled',
    content TEXT,
    type VARCHAR(20) NOT NULL CHECK (type IN ('excel', 'word')),
    created_by UUID REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'draft',
    file_url TEXT,
    file_path TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    share_with JSONB DEFAULT '[]'::jsonb,
    auto_save_draft BOOLEAN DEFAULT true,
    last_auto_save_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- SUPPORT CHATS
CREATE TABLE support_chats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visitor_name VARCHAR(100) NOT NULL,
    visitor_email VARCHAR(255),
    visitor_phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    assigned_to UUID REFERENCES users(id),
    assigned_at TIMESTAMP WITH TIME ZONE,
    assigned_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    scheduled_delete_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '5 days'),
    closed_at TIMESTAMP WITH TIME ZONE
);

-- SUPPORT MESSAGES
CREATE TABLE support_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chat_id UUID REFERENCES support_chats(id) ON DELETE CASCADE,
    sender_type VARCHAR(10) NOT NULL CHECK (sender_type IN ('visitor', 'leader')),
    sender_id UUID REFERENCES users(id),
    sender_name VARCHAR(100),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- SETTINGS
CREATE TABLE settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(100) UNIQUE NOT NULL,
    value JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ABUSE REPORTS
CREATE TABLE abuse_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id VARCHAR(255),
    room_id VARCHAR(255),
    reporter_id UUID REFERENCES users(id),
    reported_user_id UUID REFERENCES users(id),
    message_content TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    reported_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- PROFILE CHANGE REQUESTS
CREATE TABLE profile_change_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    request_type VARCHAR(20) NOT NULL CHECK (request_type IN ('email', 'phone', 'both')),
    new_email VARCHAR(255),
    new_phone VARCHAR(20),
    reason TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    approved_by_mwenyekiti BOOLEAN DEFAULT false,
    approved_by_katibu BOOLEAN DEFAULT false,
    approved_by_mhazini BOOLEAN DEFAULT false,
    approved_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    token VARCHAR(255) UNIQUE,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_users_member_id ON users(member_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_contributions_user_id ON contributions(user_id);
CREATE INDEX idx_contributions_receipt_number ON contributions(receipt_number);
CREATE INDEX idx_chat_messages_room_id ON chat_messages(room_id);
CREATE INDEX idx_chat_messages_created_at ON chat_messages(created_at DESC);
CREATE INDEX idx_documents_created_by ON documents(created_by);
CREATE INDEX idx_documents_type ON documents(type);
CREATE INDEX idx_support_chats_created_at ON support_chats(created_at);

-- DEFAULT SETTINGS
INSERT INTO settings (key, value) VALUES
('interest_rate', '{"rate": 10.0}'),
('group_contacts', '{"phone1": "+255700000000", "phone2": "+255700000001", "phone3": "+255700000002", "email": "thamaniyangu@gmail.com"}'),
('group_logo', '{"url": "", "updated_by": "", "updated_at": ""}')
ON CONFLICT (key) DO NOTHING;

-- ENABLE RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE contributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE membership_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE profile_change_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE abuse_reports ENABLE ROW LEVEL SECURITY;

-- RLS POLICIES
CREATE POLICY "Users view themselves or leaders view all" ON users
    FOR SELECT USING (
        auth.uid() = id OR
        EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('mwenyekiti', 'katibu', 'mhazini'))
    );

CREATE POLICY "Leaders manage contributions" ON contributions
    USING (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('mwenyekiti', 'mhazini')));

CREATE POLICY "Members view own contributions" ON contributions
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Leaders can manage documents" ON documents
    USING (EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('mwenyekiti', 'katibu', 'mhazini')));

CREATE POLICY "Leaders can view all documents" ON documents
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('mwenyekiti', 'katibu', 'mhazini')) OR
        (auth.uid() = created_by)
    );

CREATE POLICY "Anyone can create support chat" ON support_chats
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Leaders can view all support chats" ON support_chats
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('mwenyekiti', 'katibu', 'mhazini'))
    );