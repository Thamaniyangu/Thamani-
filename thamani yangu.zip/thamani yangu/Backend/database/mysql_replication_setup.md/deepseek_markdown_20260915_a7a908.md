# MySQL Master-Slave Replication Setup

## 1. Master Server Setup (192.168.1.10)

### Kwenye `my.cnf` (Master):
```ini
[mysqld]
server-id = 1
log-bin = mysql-bin
binlog-format = ROW
binlog-do-db = thamani_yangu
expire_logs_days = 7
max_binlog_size = 100M