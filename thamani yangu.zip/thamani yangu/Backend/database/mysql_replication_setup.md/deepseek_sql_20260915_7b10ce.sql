CREATE USER 'replicator'@'%' IDENTIFIED BY 'StrongReplPass2024!';
GRANT REPLICATION SLAVE ON *.* TO 'replicator'@'%';
FLUSH PRIVILEGES;

-- Pata position
FLUSH TABLES WITH READ LOCK;
SHOW MASTER STATUS;
-- Kumbuka: File = mysql-bin.000001, Position = 1234
UNLOCK TABLES;

-- Backup master
mysqldump -u root -p --all-databases --master-data=2 > master_backup.sql