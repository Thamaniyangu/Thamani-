-- ============================================================
-- FINANCIAL TRAINING SCHEDULES
-- ============================================================
CREATE TABLE IF NOT EXISTS financial_training_schedules (
    id CHAR(36) PRIMARY KEY,
    week_number INT NOT NULL,
    topic VARCHAR(255) NOT NULL,
    description TEXT,
    day_of_week VARCHAR(20),
    scheduled_date DATE NOT NULL,
    scheduled_time TIME DEFAULT '19:00:00',
    status VARCHAR(20) DEFAULT 'pending',
    approved_by CHAR(36),
    approved_at TIMESTAMP NULL,
    created_by CHAR(36) DEFAULT '00000000-0000-0000-0000-000000000000',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_scheduled_date (scheduled_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS financial_qa (
    id CHAR(36) PRIMARY KEY,
    schedule_id CHAR(36),
    user_id CHAR(36),
    question TEXT NOT NULL,
    answer TEXT,
    answered_by CHAR(36) DEFAULT '00000000-0000-0000-0000-000000000000',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    answered_at TIMESTAMP NULL,
    INDEX idx_schedule_id (schedule_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB;