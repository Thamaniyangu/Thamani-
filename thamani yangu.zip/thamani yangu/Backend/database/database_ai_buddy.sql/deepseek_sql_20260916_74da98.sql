-- ============================================================
-- AI BUDDY - MEDIA ANALYSIS LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS media_analysis_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    media_type VARCHAR(20) NOT NULL CHECK (media_type IN ('image', 'video', 'audio', 'document')),
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    file_name VARCHAR(255),
    file_size BIGINT,
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- MEDIA GENERATION LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS media_generation_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    media_type VARCHAR(20) NOT NULL CHECK (media_type IN ('image', 'video')),
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_media_analysis_user_id ON media_analysis_logs(user_id);
CREATE INDEX idx_media_analysis_created ON media_analysis_logs(created_at DESC);
CREATE INDEX idx_media_generation_user_id ON media_generation_logs(user_id);
CREATE INDEX idx_media_generation_created ON media_generation_logs(created_at DESC);

-- NOTE: Hakuna column ya file_url, file_path, au blob!
-- Faili hazihifadhiwi kwenye database.