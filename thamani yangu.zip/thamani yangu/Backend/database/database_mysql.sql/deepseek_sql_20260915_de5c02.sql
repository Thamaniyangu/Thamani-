-- ============================================================
-- THAMANI YANGU - MYSQL COMPLETE SCHEMA v5.0
-- ============================================================

CREATE DATABASE IF NOT EXISTS thamani_yangu 
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

USE thamani_yangu;

-- ============================================================
-- 1. USERS
-- ============================================================
CREATE TABLE users (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    member_id VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    whatsapp_number VARCHAR(20),
    whatsapp_preferences JSON,
    password_hash TEXT NOT NULL,
    role VARCHAR(20) DEFAULT 'mwanachama',
    first_name VARCHAR(100),
    middle_name VARCHAR(100),
    last_name VARCHAR(100),
    profile_photo_url TEXT,
    status VARCHAR(20) DEFAULT 'active',
    region VARCHAR(100),
    district VARCHAR(100),
    ward_street TEXT,
    emergency_contact_name1 VARCHAR(200),
    emergency_contact_name2 VARCHAR(200),
    emergency_relationship VARCHAR(50),
    emergency_phone VARCHAR(20),
    emergency_region VARCHAR(100),
    emergency_district VARCHAR(100),
    emergency_ward_street TEXT,
    preferred_language VARCHAR(5) DEFAULT 'sw',
    theme_preferences JSON,
    points INT DEFAULT 0,
    level INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_member_id (member_id),
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ============================================================
-- 2. SIGNUP TOKENS
-- ============================================================
CREATE TABLE signup_tokens (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    token VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) NOT NULL,
    whatsapp_number VARCHAR(20),
    member_id VARCHAR(20) NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ============================================================
-- 3. CONTRIBUTIONS
-- ============================================================
CREATE TABLE contributions (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) NOT NULL,
    type VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    contribution_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by CHAR(36),
    receipt_number VARCHAR(50) UNIQUE,
    receipt_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_receipt (receipt_number),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 4. MEMBERSHIP FEES
-- ============================================================
CREATE TABLE membership_fees (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) NOT NULL,
    period VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'unpaid',
    paid_date TIMESTAMP NULL,
    recorded_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 5. LOANS
-- ============================================================
CREATE TABLE loans (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    interest_rate DECIMAL(5,2) DEFAULT 10.00,
    total_payable DECIMAL(15,2),
    due_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    approved_by CHAR(36),
    recorded_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ============================================================
-- 6. CHAT ROOMS
-- ============================================================
CREATE TABLE chat_rooms (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    name VARCHAR(100),
    type VARCHAR(20) NOT NULL,
    created_by CHAR(36),
    participants JSON,
    last_message JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type (type)
) ENGINE=InnoDB;

-- ============================================================
-- 7. CHAT MESSAGES
-- ============================================================
CREATE TABLE chat_messages (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    room_id CHAR(36) NOT NULL,
    sender_id CHAR(36),
    sender_name VARCHAR(200),
    sender_member_id VARCHAR(20),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    reply_to CHAR(36),
    edited BOOLEAN DEFAULT FALSE,
    deleted BOOLEAN DEFAULT FALSE,
    read_by JSON,
    active_users JSON,
    media_deleted BOOLEAN DEFAULT FALSE,
    is_ai BOOLEAN DEFAULT FALSE,
    ai_type VARCHAR(20),
    is_notice BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_room_id (room_id),
    INDEX idx_created_at (created_at DESC),
    INDEX idx_sender_id (sender_id),
    FOREIGN KEY (room_id) REFERENCES chat_rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 8. SUPPORT CHATS
-- ============================================================
CREATE TABLE support_chats (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    visitor_name VARCHAR(100) NOT NULL,
    visitor_email VARCHAR(255),
    visitor_phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    assigned_to CHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by CHAR(36),
    scheduled_delete_at TIMESTAMP DEFAULT (DATE_ADD(NOW(), INTERVAL 5 DAY)),
    closed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_delete (scheduled_delete_at)
) ENGINE=InnoDB;

-- ============================================================
-- 9. SUPPORT MESSAGES
-- ============================================================
CREATE TABLE support_messages (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    chat_id CHAR(36) NOT NULL,
    sender_type VARCHAR(10) NOT NULL,
    sender_id CHAR(36),
    sender_name VARCHAR(100),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_chat_id (chat_id),
    FOREIGN KEY (chat_id) REFERENCES support_chats(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 10. DOCUMENTS
-- ============================================================
CREATE TABLE documents (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    title VARCHAR(255) NOT NULL,
    document_name VARCHAR(255) DEFAULT 'Untitled',
    content LONGTEXT,
    type VARCHAR(20) NOT NULL,
    created_by CHAR(36),
    status VARCHAR(20) DEFAULT 'draft',
    metadata JSON,
    share_with JSON,
    last_auto_save_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_created_by (created_by),
    INDEX idx_type (type)
) ENGINE=InnoDB;

-- ============================================================
-- 11. APPLICATIONS
-- ============================================================
CREATE TABLE applications (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    whatsapp_number VARCHAR(20),
    status VARCHAR(20) DEFAULT 'pending',
    reviewed_by CHAR(36),
    reviewed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ============================================================
-- 12. REFERRALS
-- ============================================================
CREATE TABLE referrals (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) UNIQUE NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 13. PROFILE CHANGE REQUESTS
-- ============================================================
CREATE TABLE profile_change_requests (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) NOT NULL,
    request_type VARCHAR(20) NOT NULL,
    new_email VARCHAR(255),
    new_phone VARCHAR(20),
    reason TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    approved_by_mwenyekiti BOOLEAN DEFAULT FALSE,
    approved_by_katibu BOOLEAN DEFAULT FALSE,
    approved_by_mhazini BOOLEAN DEFAULT FALSE,
    approved_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    token VARCHAR(255) UNIQUE,
    token_expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 14. SETTINGS
-- ============================================================
CREATE TABLE settings (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    `key` VARCHAR(100) UNIQUE NOT NULL,
    value JSON,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- 15. AI PROFILES
-- ============================================================
CREATE TABLE ai_profiles (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    photo_url TEXT,
    updated_by CHAR(36),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- 16. AI USAGE LOGS
-- ============================================================
CREATE TABLE ai_usage_logs (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36),
    user_role VARCHAR(20),
    ai_type VARCHAR(20),
    message TEXT,
    provider VARCHAR(50),
    attempted_providers JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_provider (provider),
    INDEX idx_created_at (created_at DESC)
) ENGINE=InnoDB;

-- ============================================================
-- 17. MEDIA LOGS
-- ============================================================
CREATE TABLE media_generation_logs (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36),
    media_type VARCHAR(20) NOT NULL,
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE media_analysis_logs (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36),
    media_type VARCHAR(20) NOT NULL,
    prompt TEXT NOT NULL,
    provider VARCHAR(50),
    file_name VARCHAR(255),
    file_size BIGINT,
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- 18. USER PRESENCE
-- ============================================================
CREATE TABLE user_presence (
    user_id CHAR(36) PRIMARY KEY,
    online BOOLEAN DEFAULT FALSE,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    socket_id VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 19. AUDIT LOGS
-- ============================================================
CREATE TABLE audit_logs (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36),
    action VARCHAR(255),
    details JSON,
    ip VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action)
) ENGINE=InnoDB;

-- ============================================================
-- 20. EXTERNAL HOSTS
-- ============================================================
CREATE TABLE external_hosts (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    host_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    whatsapp_number VARCHAR(20),
    password_hash TEXT NOT NULL,
    profile_photo_url TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    approved_by CHAR(36),
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_host_id (host_id),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ============================================================
-- 21. HOST MEETING REQUESTS
-- ============================================================
CREATE TABLE host_meeting_requests (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    host_id CHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    proposed_start TIMESTAMP NOT NULL,
    proposed_end TIMESTAMP NOT NULL,
    expected_participants INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'pending',
    review_notes TEXT,
    processed_by CHAR(36),
    processed_at TIMESTAMP NULL,
    meeting_link TEXT,
    custom_slug VARCHAR(100) UNIQUE,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_host_id (host_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ============================================================
-- 22. HOST MEETINGS
-- ============================================================
CREATE TABLE host_meetings (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    request_id CHAR(36),
    host_id CHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'scheduled',
    room_id VARCHAR(100) UNIQUE,
    settings JSON,
    co_host_id CHAR(36),
    paused BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_room_id (room_id),
    INDEX idx_start_time (start_time)
) ENGINE=InnoDB;

-- ============================================================
-- 23. HOST MEETING GUESTS
-- ============================================================
CREATE TABLE host_meeting_guests (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    meeting_id CHAR(36),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    whatsapp_number VARCHAR(20),
    otp VARCHAR(6),
    otp_sent_at TIMESTAMP NULL,
    joined_at TIMESTAMP NULL,
    left_at TIMESTAMP NULL,
    duration INT,
    feedback JSON,
    ip VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_meeting_id (meeting_id),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ============================================================
-- 24. HOST CHAT MESSAGES
-- ============================================================
CREATE TABLE host_chat_messages (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    room_id CHAR(36) NOT NULL,
    sender_type VARCHAR(20) NOT NULL,
    sender_id CHAR(36) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    reply_to CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_room_id (room_id)
) ENGINE=InnoDB;

-- ============================================================
-- 25. THEMES (Per-user, per-area)
-- ============================================================
CREATE TABLE user_themes (
    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id CHAR(36) NOT NULL,
    area VARCHAR(50) NOT NULL, -- 'dashboard', 'chat', 'contributions', etc.
    theme_data JSON NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_area (user_id, area),
    INDEX idx_user_id (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- DEFAULT SETTINGS
-- ============================================================
INSERT INTO settings (`key`, value) VALUES
('group_logo', '{"url": "", "updated_by": "", "updated_at": ""}'),
('interest_rate', '{"rate": 10.0}'),
('group_contacts', '{"phone1": "", "phone2": "", "phone3": "", "email": "thamaniyangu2024@gmail.com"}'),
('theme_default', '{
  "primary": "#0D6B6B",
  "secondary": "#D4AF37",
  "accent": "#F5E5C0",
  "background": "#F8F9FA",
  "surface": "#FFFFFF",
  "text": "#1A1A1A",
  "textMuted": "#6B7280",
  "success": "#10B981",
  "warning": "#F59E0B",
  "error": "#EF4444"
}')
ON DUPLICATE KEY UPDATE `key` = `key`;

INSERT INTO ai_profiles (id, name, description) VALUES
    ('ai-buddy', 'THAMANI AI BUDDY', 'Msaidizi wa jumla'),
    ('ai-financial', 'THAMANI FINANCIAL ADVISOR', 'Mshauri wa kifedha'),
    ('ai-leadership', 'THAMANI LEADERSHIP MENTOR', 'Mshauri wa uongozi')
ON DUPLICATE KEY UPDATE id = id;