CREATE DATABASE IF NOT EXISTS thamani_yangu;
USE thamani_yangu;

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    member_id VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash TEXT NOT NULL,
    role VARCHAR(20) DEFAULT 'mwanachama',
    first_name VARCHAR(100),
    middle_name VARCHAR(100),
    last_name VARCHAR(100),
    profile_photo_url TEXT,
    status VARCHAR(20) DEFAULT 'active',
    region VARCHAR(100),
    district VARCHAR(100),
    ward_street TEXT,
    emergency_contact_name1 VARCHAR(200),
    emergency_contact_name2 VARCHAR(200),
    emergency_relationship VARCHAR(50),
    emergency_phone VARCHAR(20),
    emergency_region VARCHAR(100),
    emergency_district VARCHAR(100),
    emergency_ward_street TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contributions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    type VARCHAR(20),
    amount DECIMAL(15,2),
    contribution_date TIMESTAMP,
    recorded_by VARCHAR(36),
    receipt_number VARCHAR(50) UNIQUE,
    receipt_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id VARCHAR(36) PRIMARY KEY,
    room_id VARCHAR(36),
    sender_id VARCHAR(36),
    sender_name VARCHAR(200),
    sender_member_id VARCHAR(20),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    reply_to VARCHAR(36),
    edited BOOLEAN DEFAULT false,
    deleted BOOLEAN DEFAULT false,
    read_by JSON,
    active_users JSON,
    media_deleted BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS documents (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    document_name VARCHAR(255) DEFAULT 'Untitled',
    content TEXT,
    type VARCHAR(20),
    created_by VARCHAR(36),
    status VARCHAR(20) DEFAULT 'draft',
    file_url TEXT,
    file_path TEXT,
    metadata JSON,
    share_with JSON,
    auto_save_draft BOOLEAN DEFAULT true,
    last_auto_save_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS support_chats (
    id VARCHAR(36) PRIMARY KEY,
    visitor_name VARCHAR(100) NOT NULL,
    visitor_email VARCHAR(255),
    visitor_phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP,
    assigned_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scheduled_delete_at TIMESTAMP,
    closed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS support_messages (
    id VARCHAR(36) PRIMARY KEY,
    chat_id VARCHAR(36),
    sender_type VARCHAR(10),
    sender_id VARCHAR(36),
    sender_name VARCHAR(100),
    text TEXT,
    type VARCHAR(20) DEFAULT 'text',
    file_url TEXT,
    file_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    id VARCHAR(36) PRIMARY KEY,
    `key` VARCHAR(100) UNIQUE NOT NULL,
    value JSON,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);