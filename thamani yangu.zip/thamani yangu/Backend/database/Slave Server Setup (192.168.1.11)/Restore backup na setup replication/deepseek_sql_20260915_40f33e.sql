mysql -u root -p < master_backup.sql

CHANGE MASTER TO
    MASTER_HOST = '192.168.1.10',
    MASTER_USER = 'replicator',
    MASTER_PASSWORD = 'StrongReplPass2024!',
    MASTER_LOG_FILE = 'mysql-bin.000001',
    MASTER_LOG_POS = 1234;

START SLAVE;

-- Check status
SHOW SLAVE STATUS\G