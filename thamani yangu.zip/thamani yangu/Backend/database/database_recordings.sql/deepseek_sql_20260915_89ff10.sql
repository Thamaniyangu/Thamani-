-- ============================================================
-- MEETING RECORDINGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS meeting_recordings (
    id CHAR(36) PRIMARY KEY,
    meeting_id CHAR(36) NOT NULL,
    room_id VARCHAR(100),
    started_by CHAR(36) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT DEFAULT 0,
    duration INT DEFAULT 0,
    mime_type VARCHAR(100) DEFAULT 'video/webm',
    status VARCHAR(20) DEFAULT 'recording',
    transcript TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    INDEX idx_meeting_id (meeting_id),
    INDEX idx_started_by (started_by),
    INDEX idx_status (status)
) ENGINE=InnoDB;