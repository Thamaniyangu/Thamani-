-- ============================================================
-- AI TRAINING
-- ============================================================
CREATE TABLE IF NOT EXISTS ai_training_datasets (
    id CHAR(36) PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    total_samples INT DEFAULT 0,
    train_samples INT DEFAULT 0,
    val_samples INT DEFAULT 0,
    test_samples INT DEFAULT 0,
    path TEXT,
    status VARCHAR(20) DEFAULT 'collecting',
    accuracy DECIMAL(5,2),
    loss DECIMAL(10,6),
    epochs INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    trained_at TIMESTAMP NULL,
    INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_training_jobs (
    id CHAR(36) PRIMARY KEY,
    dataset_id CHAR(36),
    model_name VARCHAR(100),
    base_model VARCHAR(100) DEFAULT 'llama3.1:8b',
    method VARCHAR(50) DEFAULT 'lora',
    hyperparameters JSON,
    status VARCHAR(20) DEFAULT 'pending',
    progress INT DEFAULT 0,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    error_message TEXT,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_model_versions (
    id CHAR(36) PRIMARY KEY,
    job_id CHAR(36),
    version VARCHAR(20),
    model_path TEXT,
    accuracy DECIMAL(5,2),
    size_mb INT,
    deployed BOOLEAN DEFAULT FALSE,
    deployed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_deployed (deployed)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_feedback (
    id CHAR(36) PRIMARY KEY,
    message_id CHAR(36),
    user_id CHAR(36),
    ai_response TEXT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rating (rating)
) ENGINE=InnoDB;