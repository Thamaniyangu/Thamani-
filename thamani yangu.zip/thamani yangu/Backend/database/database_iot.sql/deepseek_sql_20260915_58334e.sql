-- ============================================================
-- IoT DEVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS iot_devices (
    id CHAR(36) PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    device_id VARCHAR(100) UNIQUE NOT NULL,
    device_type VARCHAR(50) NOT NULL,
    device_info JSON,
    status VARCHAR(20) DEFAULT 'active',
    api_key VARCHAR(100) UNIQUE,
    last_sync_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_device_id (device_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- IoT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS iot_logs (
    id CHAR(36) PRIMARY KEY,
    device_id VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    data JSON NOT NULL,
    processed BOOLEAN DEFAULT FALSE,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_device_id (device_id),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at DESC)
) ENGINE=InnoDB;

-- ============================================================
-- Add source column to contributions
-- ============================================================
ALTER TABLE contributions ADD COLUMN IF NOT EXISTS source VARCHAR(50) DEFAULT 'manual';