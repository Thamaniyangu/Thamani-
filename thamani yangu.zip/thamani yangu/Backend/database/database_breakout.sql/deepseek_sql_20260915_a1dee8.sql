-- ============================================================
-- BREAKOUT ROOMS
-- ============================================================
CREATE TABLE IF NOT EXISTS breakout_rooms (
    id CHAR(36) PRIMARY KEY,
    meeting_id CHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    room_id VARCHAR(100) UNIQUE NOT NULL,
    max_participants INT DEFAULT 10,
    assigned_users JSON DEFAULT ('[]'),
    status VARCHAR(20) DEFAULT 'active',
    created_by CHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP NULL,
    INDEX idx_meeting_id (meeting_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS breakout_assignments (
    id CHAR(36) PRIMARY KEY,
    breakout_id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    joined_at TIMESTAMP NULL,
    left_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_breakout_id (breakout_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB;