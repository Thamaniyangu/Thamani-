-- ============================================================
-- AI PROFILE PHOTOS (Mwenyekiti pekee anaweka)
-- ============================================================

CREATE TABLE IF NOT EXISTS ai_profiles (
    id VARCHAR(50) PRIMARY KEY, -- 'ai-buddy', 'ai-financial', 'ai-leadership'
    name VARCHAR(100) NOT NULL,
    description TEXT,
    photo_url TEXT,
    updated_by UUID REFERENCES users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default AI profiles
INSERT INTO ai_profiles (id, name, description) VALUES
    ('ai-buddy', 'THAMANI AI BUDDY', 'Msaidizi wa jumla - jamii, utamaduni, masuala ya jumla'),
    ('ai-financial', 'THAMANI FINANCIAL ADVISOR', 'Mshauri wa kifedha - akiba, mikopo, riba, bajeti'),
    ('ai-leadership', 'THAMANI LEADERSHIP MENTOR', 'Mshauri wa uongozi - maamuzi, majukumu, mikakati')
ON CONFLICT (id) DO NOTHING;

-- Index
CREATE INDEX IF NOT EXISTS idx_ai_profiles_id ON ai_profiles(id);