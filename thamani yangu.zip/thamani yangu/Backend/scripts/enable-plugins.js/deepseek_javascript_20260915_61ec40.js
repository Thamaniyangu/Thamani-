const mysql = require('../src/config/mysql');

const pluginsToEnable = [
    'sip-voice',
    'marketing-automation',
    'advanced-analytics'
];

async function enableAll() {
    for (const name of pluginsToEnable) {
        await mysql.query(`
            INSERT INTO plugin_registry 
            (id, plugin_name, version, enabled, enabled_at)
            VALUES (UUID(), ?, '1.0.0', TRUE, NOW())
            ON DUPLICATE KEY UPDATE
                enabled = TRUE,
                enabled_at = NOW()
        `, [name]);
        console.log(`✅ Enabled: ${name}`);
    }
    process.exit(0);
}

enableAll().catch(err => {
    console.error(err);
    process.exit(1);
});