#!/bin/bash
# /usr/local/bin/check-replication.sh

STATUS=$(mysql -u root -p$DB_PASS -e "SHOW SLAVE STATUS\G" | grep -E "Slave_IO_Running|Slave_SQL_Running")

echo "$STATUS" | grep -q "Yes.*Yes" && echo "✅ Replication OK" || echo "❌ Replication FAILED"