# Test 1: Auth flow
k6 run backend/load-tests/auth-test.js

# Test 2: Chat with WebSocket
k6 run backend/load-tests/chat-test.js

# Test 3: Spike test
k6 run backend/load-tests/spike-test.js

# With custom BASE_URL
BASE_URL=https://thamaniyangu.com k6 run backend/load-tests/auth-test.js

# Output to InfluxDB + Grafana
k6 run --out influxdb=http://localhost:8086/k6 backend/load-tests/auth-test.js