// ============================================================
// THAMANI YANGU - WHATSAPP SERVICE (Self-Hosted, Baileys)
// ============================================================

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    delay
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// ============================================================
// CONFIG
// ============================================================
const AUTH_FOLDER = path.join(__dirname, '../../whatsapp-auth');
const MAX_RETRIES = 5;
const RECONNECT_DELAY = 3000;

// ============================================================
// STATE
// ============================================================
let sock = null;
let isConnected = false;
let currentQR = null;
let phoneNumber = null;
let connectionStatus = 'disconnected';
let reconnectAttempts = 0;
let messageQueue = [];
let isProcessingQueue = false;

// Store ya messages
const store = makeInMemoryStore({
    logger: pino({ level: 'silent' })
});

// Tengeneza folder la auth
if (!fs.existsSync(AUTH_FOLDER)) {
    fs.mkdirSync(AUTH_FOLDER, { recursive: true });
}

// ============================================================
// 1. ANZISHA WHATSAPP
// ============================================================
async function startWhatsApp() {
    try {
        connectionStatus = 'connecting';
        console.log('📱 Inaanzisha WhatsApp...');

        const { version, isLatest } = await fetchLatestBaileysVersion();
        console.log(`📦 WhatsApp version: ${version.join('.')}, isLatest: ${isLatest}`);

        const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER);

        sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            auth: state,
            browser: ['THAMANI YANGU', 'Chrome', '1.0.0'],
            generateHighQualityLinkPreview: true,
            markOnlineOnConnect: false,
            syncFullHistory: false
        });

        store.bind(sock.ev);

        // Creds update
        sock.ev.on('creds.update', saveCreds);

        // Connection update
        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            // QR Code
            if (qr) {
                currentQR = qr;
                connectionStatus = 'connecting';
                console.log('📱 QR Code imetokea - inahitaji kuskana');

                try {
                    const qrDataURL = await QRCode.toDataURL(qr, {
                        width: 400,
                        margin: 2,
                        color: {
                            dark: '#0D6B6B',
                            light: '#FFFFFF'
                        }
                    });
                    global.qrCodeDataURL = qrDataURL;

                    if (global.io) {
                        global.io.emit('whatsapp-qr', { qr: qrDataURL });
                    }
                } catch (err) {
                    console.error('QR generation error:', err);
                }
            }

            // Closed
            if (connection === 'close') {
                const statusCode = (lastDisconnect?.error)?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

                console.log(`❌ Muunganisho umekatika. Status: ${statusCode}`);

                isConnected = false;
                phoneNumber = null;

                if (global.io) {
                    global.io.emit('whatsapp-status', {
                        status: shouldReconnect ? 'reconnecting' : 'logged_out',
                        message: shouldReconnect ? 'Inajaribu kuunganisha tena...' : 'Umetolewa kwenye akaunti'
                    });
                }

                if (shouldReconnect && reconnectAttempts < MAX_RETRIES) {
                    connectionStatus = 'reconnecting';
                    reconnectAttempts++;
                    console.log(`🔄 Kujaribu tena (${reconnectAttempts}/${MAX_RETRIES})...`);

                    setTimeout(() => {
                        startWhatsApp();
                    }, RECONNECT_DELAY);
                } else {
                    connectionStatus = 'disconnected';
                    console.log('❌ Imeshindwa kuunganisha. Tafadhali skana QR code mpya.');
                }
            }
            // Opened
            else if (connection === 'open') {
                console.log('✅ WhatsApp imeunganishwa!');
                isConnected = true;
                connectionStatus = 'connected';
                currentQR = null;
                reconnectAttempts = 0;

                try {
                    const jid = sock.user?.id;
                    if (jid) {
                        phoneNumber = jid.split(':')[0].split('@')[0];
                        console.log(`📞 Namba: +${phoneNumber}`);
                    }
                } catch (err) {
                    console.error('Get phone error:', err);
                }

                if (global.io) {
                    global.io.emit('whatsapp-status', {
                        status: 'connected',
                        phoneNumber,
                        message: 'WhatsApp imeunganishwa!'
                    });
                }

                processMessageQueue();
            }
        });

        // Messages
        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const msg of messages) {
                if (!msg.message) continue;

                const from = msg.key.remoteJid;
                const isGroup = from.endsWith('@g.us');

                console.log(`📩 Ujumbe kutoka ${from}`);

                if (global.io) {
                    global.io.emit('whatsapp-incoming', {
                        from,
                        isGroup,
                        text: msg.message?.conversation || msg.message?.extendedTextMessage?.text || '[Media]',
                        timestamp: msg.messageTimestamp
                    });
                }
            }
        });

        return sock;
    } catch (err) {
        console.error('❌ WhatsApp start error:', err);
        connectionStatus = 'disconnected';
        throw err;
    }
}

// ============================================================
// 2. TUMA UJUMBE
// ============================================================
async function sendWhatsAppMessage(to, message, options = {}) {
    const cleanNumber = to.replace(/[^0-9]/g, '');
    const jid = `${cleanNumber}@s.whatsapp.net`;

    if (!sock || !isConnected) {
        console.log('⏳ WhatsApp haijaunganishwa. Ujumbe umewekwa kwenye queue.');
        messageQueue.push({ to: jid, message, options, retries: 0 });
        return { success: false, queued: true };
    }

    try {
        let messageContent;
        if (typeof message === 'string') {
            messageContent = { text: message };
        } else {
            messageContent = message;
        }

        const result = await sock.sendMessage(jid, messageContent, {
            quoted: options.quoted || null,
            mentions: options.mentions || []
        });

        console.log(`✅ Ujumbe umetumwa kwa ${cleanNumber}`);
        return { success: true, result };
    } catch (err) {
        console.error(`❌ Hitilafu kutuma kwa ${cleanNumber}:`, err.message);

        if (messageQueue.length < 1000) {
            messageQueue.push({ to: jid, message, options, retries: 0 });
        }

        return { success: false, error: err.message };
    }
}

// ============================================================
// 3. TUMA KWA KIKUNDI
// ============================================================
async function sendToGroup(groupJid, message) {
    if (!sock || !isConnected) {
        throw new Error('WhatsApp haijaunganishwa');
    }

    try {
        await sock.sendMessage(groupJid, { text: message });
        console.log(`✅ Ujumbe umetumwa kwa kikundi ${groupJid}`);
        return { success: true };
    } catch (err) {
        console.error('Group send error:', err);
        throw err;
    }
}

// ============================================================
// 4. PROCESS QUEUE
// ============================================================
async function processMessageQueue() {
    if (isProcessingQueue || messageQueue.length === 0) return;

    isProcessingQueue = true;
    console.log(`📬 Processing ${messageQueue.length} messages from queue...`);

    const queue = [...messageQueue];
    messageQueue = [];

    for (const item of queue) {
        try {
            await sock.sendMessage(item.to,
                typeof item.message === 'string' ? { text: item.message } : item.message,
                item.options
            );
            await delay(1000);
        } catch (err) {
            console.error('Queue send error:', err);
            if (item.retries < 3) {
                item.retries++;
                messageQueue.push(item);
            }
        }
    }

    isProcessingQueue = false;
    console.log('✅ Queue processed');
}

// ============================================================
// 5. TUMA PICHA
// ============================================================
async function sendImage(to, imagePath, caption = '') {
    const cleanNumber = to.replace(/[^0-9]/g, '');
    const jid = `${cleanNumber}@s.whatsapp.net`;

    if (!sock || !isConnected) throw new Error('WhatsApp haijaunganishwa');

    try {
        await sock.sendMessage(jid, {
            image: fs.readFileSync(imagePath),
            caption
        });
        return { success: true };
    } catch (err) {
        console.error('Send image error:', err);
        throw err;
    }
}

// ============================================================
// 6. TUMA DOCUMENT
// ============================================================
async function sendDocument(to, filePath, filename, caption = '') {
    const cleanNumber = to.replace(/[^0-9]/g, '');
    const jid = `${cleanNumber}@s.whatsapp.net`;

    if (!sock || !isConnected) throw new Error('WhatsApp haijaunganishwa');

    try {
        await sock.sendMessage(jid, {
            document: fs.readFileSync(filePath),
            fileName: filename,
            caption,
            mimetype: 'application/pdf'
        });
        return { success: true };
    } catch (err) {
        console.error('Send document error:', err);
        throw err;
    }
}

// ============================================================
// 7. LOGOUT
// ============================================================
async function logoutWhatsApp() {
    try {
        if (sock) {
            await sock.logout();
            sock = null;
        }
        isConnected = false;
        phoneNumber = null;
        connectionStatus = 'disconnected';

        if (fs.existsSync(AUTH_FOLDER)) {
            fs.rmSync(AUTH_FOLDER, { recursive: true, force: true });
            fs.mkdirSync(AUTH_FOLDER, { recursive: true });
        }

        console.log('✅ WhatsApp imetolewa');
        return { success: true };
    } catch (err) {
        console.error('Logout error:', err);
        throw err;
    }
}

// ============================================================
// 8. RESTART
// ============================================================
async function restartWhatsApp() {
    console.log('🔄 Inaanzisha upya WhatsApp...');
    try {
        if (sock) {
            try { sock.end(); } catch (e) {}
            sock = null;
        }
        isConnected = false;
        connectionStatus = 'disconnected';
        await startWhatsApp();
        return { success: true };
    } catch (err) {
        console.error('Restart error:', err);
        throw err;
    }
}

// ============================================================
// 9. STATUS
// ============================================================
function getStatus() {
    return {
        status: connectionStatus,
        connected: isConnected,
        phoneNumber,
        hasQR: !!currentQR,
        qrCode: currentQR ? global.qrCodeDataURL : null,
        queueSize: messageQueue.length,
        reconnectAttempts
    };
}

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
    startWhatsApp,
    sendWhatsAppMessage,
    sendToGroup,
    sendImage,
    sendDocument,
    logoutWhatsApp,
    restartWhatsApp,
    getStatus,
    isConnected: () => isConnected,
    getSock: () => sock
};

// Auto-start kama session ipo
if (fs.existsSync(path.join(AUTH_FOLDER, 'creds.json'))) {
    console.log('📱 Session ya WhatsApp imepatikana. Inaanzisha...');
    startWhatsApp().catch(err => {
        console.error('Auto-start error:', err);
    });
} else {
    console.log('📱 Hakuna session. Subiri Mwenyekiti kuskana QR code.');
}