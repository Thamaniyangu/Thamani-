const webpush = require('web-push');
const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CONFIGURE VAPID
// ============================================================
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    webpush.setVapidDetails(
        'mailto:' + (process.env.EMAIL_USER || 'thamaniyangu2024@gmail.com'),
        process.env.VAPID_PUBLIC_KEY,
        process.env.VAPID_PRIVATE_KEY
    );
}

// ============================================================
// SUBSCRIBE
// ============================================================
exports.subscribe = async (userId, subscription, deviceInfo = '') => {
    try {
        await mysql.query(`
            INSERT INTO push_subscriptions 
            (id, user_id, endpoint, keys_p256dh, keys_auth, device_info)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                keys_p256dh = VALUES(keys_p256dh),
                keys_auth = VALUES(keys_auth),
                active = TRUE,
                last_used_at = NOW()
        `, [
            uuidv4(),
            userId,
            subscription.endpoint,
            subscription.keys.p256dh,
            subscription.keys.auth,
            deviceInfo
        ]);

        return true;
    } catch (err) {
        console.error('Push subscribe error:', err);
        return false;
    }
};

// ============================================================
// UNSUBSCRIBE
// ============================================================
exports.unsubscribe = async (userId, endpoint) => {
    try {
        await mysql.query(`
            UPDATE push_subscriptions 
            SET active = FALSE 
            WHERE user_id = ? AND endpoint = ?
        `, [userId, endpoint]);
        return true;
    } catch (err) {
        return false;
    }
};

// ============================================================
// SEND TO USER
// ============================================================
exports.sendToUser = async (userId, notification) => {
    if (!process.env.VAPID_PUBLIC_KEY) return false;

    try {
        const subs = await mysql.query(
            `SELECT * FROM push_subscriptions 
             WHERE user_id = ? AND active = TRUE`,
            [userId]
        );

        const payload = JSON.stringify({
            title: notification.title || 'THAMANI YANGU',
            body: notification.body,
            icon: notification.icon || '/logo192.png',
            badge: '/logo192.png',
            data: notification.data || {},
            url: notification.url || '/dashboard',
            tag: notification.tag || 'default',
            requireInteraction: notification.requireInteraction || false,
            actions: notification.actions || []
        });

        const results = await Promise.allSettled(
            subs.map(sub => 
                webpush.sendNotification({
                    endpoint: sub.endpoint,
                    keys: {
                        p256dh: sub.keys_p256dh,
                        auth: sub.keys_auth
                    }
                }, payload)
            )
        );

        // Handle failed subscriptions
        for (let i = 0; i < results.length; i++) {
            if (results[i].status === 'rejected') {
                const statusCode = results[i].reason?.statusCode;
                if (statusCode === 410 || statusCode === 404) {
                    // Unsubscribe dead endpoint
                    await mysql.query(
                        `UPDATE push_subscriptions SET active = FALSE WHERE id = ?`,
                        [subs[i].id]
                    );
                }
            }
        }

        return results.filter(r => r.status === 'fulfilled').length;
    } catch (err) {
        console.error('Push send error:', err);
        return 0;
    }
};

// ============================================================
// SEND TO MANY
// ============================================================
exports.sendToMany = async (userIds, notification) => {
    const results = await Promise.allSettled(
        userIds.map(uid => exports.sendToUser(uid, notification))
    );
    return results.reduce((sum, r) => sum + (r.value || 0), 0);
};

// ============================================================
// SEND TO ROLE
// ============================================================
exports.sendToRole = async (role, notification) => {
    const users = await mysql.query(
        `SELECT id FROM users WHERE role = ? AND status = 'active'`,
        [role]
    );
    return await exports.sendToMany(users.map(u => u.id), notification);
};

// ============================================================
// SEND TO ALL
// ============================================================
exports.sendToAll = async (notification) => {
    const users = await mysql.query(
        `SELECT id FROM users WHERE status = 'active'`
    );
    return await exports.sendToMany(users.map(u => u.id), notification);
};