const mysql = require('../config/mysql');
const fs = require('fs');
const path = require('path');

const TRAINING_DATA_DIR = path.join(__dirname, '../../ai-training/data');

if (!fs.existsSync(TRAINING_DATA_DIR)) {
    fs.mkdirSync(TRAINING_DATA_DIR, { recursive: true });
}

// ============================================================
// 1. COLLECT TRAINING DATA
// ============================================================
exports.collectTrainingData = async (options = {}) => {
    const {
        fromDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        toDate = new Date(),
        minRating = 4 // Only collect highly-rated answers
    } = options;

    try {
        // Get Q&A pairs from chat
        const qaPairs = await mysql.query(`
            SELECT 
                cm.sender_id,
                cm.text as question,
                r.text as answer,
                cm.room_id,
                cm.created_at
            FROM chat_messages cm
            JOIN chat_messages r 
                ON r.reply_to = cm.id 
                AND r.is_ai = TRUE
            WHERE cm.created_at BETWEEN ? AND ?
                AND cm.is_ai = FALSE
                AND r.is_ai = TRUE
                AND cm.text IS NOT NULL
                AND r.text IS NOT NULL
                AND LENGTH(cm.text) > 10
                AND LENGTH(r.text) > 20
        `, [fromDate, toDate]);

        // Get financial Q&A
        const financialQA = await mysql.query(`
            SELECT question, answer
            FROM financial_qa
            WHERE answer IS NOT NULL
                AND LENGTH(answer) > 20
                AND created_at BETWEEN ? AND ?
        `, [fromDate, toDate]);

        // Get AI usage logs with positive feedback
        const aiLogs = await mysql.query(`
            SELECT message as question, provider, ai_type
            FROM ai_usage_logs
            WHERE created_at BETWEEN ? AND ?
                AND message IS NOT NULL
        `, [fromDate, toDate]);

        // Combine all data
        const allData = [
            ...qaPairs.map(q => ({
                instruction: q.question,
                response: q.answer,
                source: 'chat',
                language: detectLanguage(q.question)
            })),
            ...financialQA.map(q => ({
                instruction: q.question,
                response: q.answer,
                source: 'financial_qa',
                language: detectLanguage(q.question)
            }))
        ];

        return allData;
    } catch (err) {
        console.error('Collect training data error:', err);
        throw err;
    }
};

// ============================================================
// 2. FORMAT FOR TRAINING (Alpaca-style)
// ============================================================
exports.formatForTraining = (data) => {
    return data.map(item => ({
        instruction: item.instruction,
        input: '',
        output: item.response,
        system: `Wewe ni THAMANI AI BUDDY, msaidizi wa kikundi cha THAMANI YANGU M-KOBA. 
                 Unajibu masuala ya kijamii, kiuchumi, na kiutamaduni kwa Kiswahili. 
                 Unakataa masuala ya kisiasa.`
    }));
};

// ============================================================
// 3. SAVE TRAINING DATASET
// ============================================================
exports.saveTrainingDataset = async (data, datasetName = null) => {
    const timestamp = Date.now();
    const name = datasetName || `dataset-${timestamp}`;
    
    const formatted = exports.formatForTraining(data);

    // Shuffle
    formatted.sort(() => Math.random() - 0.5);

    // Split (90% train, 5% val, 5% test)
    const trainEnd = Math.floor(formatted.length * 0.9);
    const valEnd = Math.floor(formatted.length * 0.95);

    const trainData = formatted.slice(0, trainEnd);
    const valData = formatted.slice(trainEnd, valEnd);
    const testData = formatted.slice(valEnd);

    const datasetDir = path.join(TRAINING_DATA_DIR, name);
    if (!fs.existsSync(datasetDir)) {
        fs.mkdirSync(datasetDir, { recursive: true });
    }

    // Save as JSONL (for Llama training)
    fs.writeFileSync(
        path.join(datasetDir, 'train.jsonl'),
        trainData.map(d => JSON.stringify(d)).join('\n')
    );
    fs.writeFileSync(
        path.join(datasetDir, 'val.jsonl'),
        valData.map(d => JSON.stringify(d)).join('\n')
    );
    fs.writeFileSync(
        path.join(datasetDir, 'test.jsonl'),
        testData.map(d => JSON.stringify(d)).join('\n')
    );

    // Save metadata
    fs.writeFileSync(
        path.join(datasetDir, 'metadata.json'),
        JSON.stringify({
            name,
            total: formatted.length,
            train: trainData.length,
            val: valData.length,
            test: testData.length,
            created: new Date().toISOString()
        }, null, 2)
    );

    // Save to DB
    await mysql.query(`
        INSERT INTO ai_training_datasets 
        (id, name, total_samples, train_samples, val_samples, test_samples, path, status, created_at)
        VALUES (UUID(), ?, ?, ?, ?, ?, ?, 'ready', NOW())
    `, [name, formatted.length, trainData.length, valData.length, testData.length, datasetDir]);

    return {
        name,
        path: datasetDir,
        stats: {
            total: formatted.length,
            train: trainData.length,
            val: valData.length,
            test: testData.length
        }
    };
};

// ============================================================
// 4. LANGUAGE DETECTION
// ============================================================
const detectLanguage = (text) => {
    const swahiliWords = ['na', 'ya', 'kwa', 'wa', 'ni', 'la', 'za', 'hii', 'hiyo', 'kama'];
    const words = text.toLowerCase().split(/\s+/);
    const swahiliCount = words.filter(w => swahiliWords.includes(w)).length;
    return swahiliCount / words.length > 0.1 ? 'sw' : 'en';
};