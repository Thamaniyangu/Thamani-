const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const path = require('path');
const fs = require('fs');

let sock = null;
let isConnected = false;
const AUTH_FOLDER = path.join(__dirname, '../../whatsapp-auth');

// Tengeneza folder la auth
if (!fs.existsSync(AUTH_FOLDER)) {
    fs.mkdirSync(AUTH_FOLDER, { recursive: true });
}

// ============================================================
// ANZISHA WHATSAPP CONNECTION
// ============================================================
async function startWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER);

    sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        logger: pino({ level: 'silent' }),
        browser: ['THAMANI YANGU', 'Chrome', '1.0.0']
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            console.log('📱 Skana QR code hii kwa WhatsApp yako:');
            // QR code itaonekana kwenye terminal
        }

        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('❌ Muunganisho umekatika. Kujaribu tena...', shouldReconnect);
            isConnected = false;
            if (shouldReconnect) {
                setTimeout(startWhatsApp, 5000);
            }
        } else if (connection === 'open') {
            console.log('✅ WhatsApp imeunganishwa!');
            isConnected = true;
        }
    });

    return sock;
}

// ============================================================
// TUMA UJUMBE
// ============================================================
async function sendWhatsAppMessage(to, message) {
    if (!sock || !isConnected) {
        console.error('WhatsApp haijaunganishwa bado');
        throw new Error('WhatsApp not connected');
    }

    // Safisha namba (ondoa +, spaces, n.k.)
    const cleanNumber = to.replace(/[^0-9]/g, '');
    const jid = `${cleanNumber}@s.whatsapp.net`;

    try {
        await sock.sendMessage(jid, { text: message });
        console.log(`✅ Ujumbe umetumwa kwa ${to}`);
        return true;
    } catch (err) {
        console.error('WhatsApp send error:', err);
        throw err;
    }
}

// ============================================================
// ANZISHA MARA MOJA
// ============================================================
startWhatsApp();

module.exports = {
    sendWhatsApp: async ({ to, message }) => {
        return await sendWhatsAppMessage(to, message);
    },
    sendSignUpLinkWhatsApp: async ({ to, link, name }) => {
        const msg = `*THAMANI YANGU*\n\nHabari ${name}!\n\nBonyeza link:\n${link}\n\nLink inaisha siku 5.`;
        return await sendWhatsAppMessage(to, msg);
    },
    sendWhatsAppOTP: async (to, otp) => {
        const msg = `*THAMANI YANGU*\n\nMsimbo wako wa OTP: *${otp}*\n\nUsishiriki na mtu yeyote.`;
        return await sendWhatsAppMessage(to, msg);
    },
    isConnected: () => isConnected
};