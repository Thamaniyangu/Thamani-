const { PDFDocument, rgb, StandardFonts } = require('pdf-lib');
const QRCode = require('qrcode');

const hexToRgb = (hex) => {
    const r = parseInt(hex.slice(1,3),16)/255;
    const g = parseInt(hex.slice(3,5),16)/255;
    const b = parseInt(hex.slice(5,7),16)/255;
    return rgb(r,g,b);
};
const GOLD_LIGHT = hexToRgb('#F5E5C0');
const GOLD_MID = hexToRgb('#D4AF37');
const GOLD_DARK = hexToRgb('#C5A028');

exports.generateReceiptPDF = async (data) => {
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([300, 550]);
    const { width, height } = page.getSize();
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    let y = height - 30;
    page.drawText('THAMANI YANGU M-KOBA', { x: 30, y, size: 14, font: fontBold });
    y -= 18;
    page.drawText('TUNAJENGA TABASAMU LAKO', { x: 40, y, size: 9, font });
    y -= 25;
    page.drawLine({ start: { x: 10, y }, end: { x: width-10, y }, thickness:1, color:rgb(0.5,0.5,0.5), dashArray:[2,4] });
    y -= 15;
    page.drawText('RISITI YA MCHANGO', { x: 60, y, size:12, font:fontBold });
    y -= 18;
    page.drawText(`#${data.receiptNumber}`, { x: 100, y, size:10, font });
    y -= 25;
    page.drawText('THAMANI', { x: 50, y: 250, size:45, font:fontBold, color:rgb(0.9,0.9,0.9), opacity:0.3 });

    const details = [
        ['Mwanachama', data.memberName],
        ['Member ID', data.memberId],
        ['Aina', data.type.toUpperCase()],
        ['Kiasi', `${Number(data.amount).toLocaleString()} TZS`],
        ['Tarehe', data.date],
        ['Muda', data.time]
    ];
    details.forEach(([label, value]) => {
        page.drawText(label, { x:20, y, size:10, font:fontBold });
        page.drawText(value, { x:140, y, size:10, font });
        y -= 22;
    });
    y -= 5;
    page.drawLine({ start: { x:10, y }, end: { x:width-10, y }, thickness:1 });
    y -= 18;
    page.drawText('JUMLA', { x:20, y, size:12, font:fontBold });
    page.drawText(`${Number(data.amount).toLocaleString()} TZS`, { x:150, y, size:12, font:fontBold });
    y -= 30;

    const qrData = JSON.stringify({ receipt: data.receiptNumber, amount: data.amount, member: data.memberId });
    const qrBuffer = await QRCode.toBuffer(qrData, { width:100 });
    const qrImage = await pdfDoc.embedPng(qrBuffer);
    page.drawImage(qrImage, { x:100, y: y-45, width:70, height:70 });
    y -= 80;
    page.drawText('Changana QR kuthibitisha uhalali', { x:40, y, size:8, font });
    y -= 18;
    page.drawText('Imetolewa na THAMANI YANGU', { x:25, y, size:7, font });

    return await pdfDoc.save();
};

exports.generateIdCardPDF = async (data) => {
    const pdfDoc = await PDFDocument.create();
    const cardWidth = 242, cardHeight = 153;
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    // Front
    const frontPage = pdfDoc.addPage([cardWidth, cardHeight]);
    const { width, height } = frontPage.getSize();
    frontPage.drawRectangle({ x:0, y:0, width, height, color:GOLD_LIGHT });
    frontPage.drawRectangle({ x:0, y:0, width, height:height/3, color:GOLD_MID, opacity:0.3 });
    frontPage.drawRectangle({ x:0, y:height*0.6, width, height:height/3, color:GOLD_DARK, opacity:0.2 });
    frontPage.drawRectangle({ x:2, y:2, width:width-4, height:height-4, borderColor:GOLD_DARK, borderWidth:2 });
    frontPage.drawText('THAMANI YANGU M-KOBA', { x:30, y:height-25, size:12, font:fontBold });
    frontPage.drawText('"TUNAJENGA TABASAMU LAKO"', { x:25, y:height-40, size:8, font });
    frontPage.drawLine({ start:{x:10, y:height-50}, end:{x:width-10, y:height-50}, thickness:1, color:GOLD_DARK });
    frontPage.drawText('KITAMBULISHO CHA MWANACHAMA', { x:30, y:height-65, size:9, font:fontBold });

    let yPos = height - 85;
    const fields = [
        ['TYM-2026-XXX', data.memberId],
        ['JINA LA KWANZA', data.firstName || '......'],
        ['JINA LA KATI', data.middleName || '......'],
        ['JINA LA MWISHO', data.lastName || '......'],
        ['NAMBA YA SIMU', data.phone || '......'],
        ['CHEO', data.role || '......'],
        ['MAKAZI', data.address || '......']
    ];
    fields.forEach(([label, value]) => {
        frontPage.drawText(label, { x:15, y:yPos, size:6, font });
        frontPage.drawText(value, { x:15, y:yPos-12, size:8, font:fontBold });
        frontPage.drawLine({ start:{x:15, y:yPos-14}, end:{x:120, y:yPos-14}, thickness:1, color:rgb(0.2,0.2,0.2), dashArray:[1,2] });
        yPos -= 28;
    });
    frontPage.drawRectangle({ x:width-75, y:height-120, width:60, height:70, borderColor:GOLD_DARK, borderWidth:2 });
    frontPage.drawText('PASSPORT', { x:width-65, y:height-85, size:7, font });
    frontPage.drawText('SIZE', { x:width-50, y:height-95, size:7, font });

    // Back
    const backPage = pdfDoc.addPage([cardWidth, cardHeight]);
    const { width:bw, height:bh } = backPage.getSize();
    backPage.drawRectangle({ x:0, y:0, width:bw, height:bh, color:GOLD_LIGHT });
    backPage.drawRectangle({ x:0, y:0, width:bw, height:bh/3, color:GOLD_MID, opacity:0.3 });
    backPage.drawRectangle({ x:0, y:bh*0.6, width:bw, height:bh/3, color:GOLD_DARK, opacity:0.2 });
    backPage.drawRectangle({ x:2, y:2, width:bw-4, height:bh-4, borderColor:GOLD_DARK, borderWidth:2 });
    backPage.drawText('THAMANI YANGU M-KOBA', { x:30, y:bh-25, size:12, font:fontBold });
    backPage.drawText('"TUNAJENGA TABASAMU LAKO"', { x:25, y:bh-40, size:8, font });
    backPage.drawLine({ start:{x:10, y:bh-50}, end:{x:bw-10, y:bh-50}, thickness:1, color:GOLD_DARK });
    backPage.drawText('TAARIFA ZA MTU WA KARIBU', { x:20, y:bh-65, size:9, font:fontBold });

    let yb = bh - 85;
    const emergencyFields = [
        ['JINA LA KWANZA', data.emergencyName1 || '......'],
        ['JINA LA MWISHO', data.emergencyName2 || '......'],
        ['NAMBA YA SIMU', data.emergencyPhone || '......'],
        ['UHUSIANO', data.emergencyRelation || '......'],
        ['MAKAZI', data.emergencyAddress || '......']
    ];
    emergencyFields.forEach(([label, value]) => {
        backPage.drawText(label, { x:15, y:yb, size:6, font });
        backPage.drawText(value, { x:15, y:yb-12, size:8, font:fontBold });
        backPage.drawLine({ start:{x:15, y:yb-14}, end:{x:120, y:yb-14}, thickness:1, color:rgb(0.2,0.2,0.2), dashArray:[1,2] });
        yb -= 28;
    });

    const qrDataBack = JSON.stringify({ memberId: data.memberId });
    const qrBufferBack = await QRCode.toBuffer(qrDataBack, { width:100 });
    const qrImageBack = await pdfDoc.embedPng(qrBufferBack);
    backPage.drawImage(qrImageBack, { x:bw-75, y:bh-105, width:60, height:60 });
    backPage.drawText('QR CODE', { x:bw-65, y:bh-115, size:6, font });
    backPage.drawText('___________________', { x:60, y:20, size:8, font });
    backPage.drawText('Katibu', { x:90, y:8, size:8, font:fontBold });

    return await pdfDoc.save();
};