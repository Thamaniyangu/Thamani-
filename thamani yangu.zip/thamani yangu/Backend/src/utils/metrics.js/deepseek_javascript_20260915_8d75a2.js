const client = require('prom-client');

// ============================================================
// REGISTER
// ============================================================
const register = new client.Registry();

// Default metrics
client.collectDefaultMetrics({ register, prefix: 'thamani_' });

// ============================================================
// CUSTOM METRICS
// ============================================================

// HTTP Request duration
const httpRequestDuration = new client.Histogram({
    name: 'thamani_http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10]
});
register.registerMetric(httpRequestDuration);

// HTTP Request total
const httpRequestTotal = new client.Counter({
    name: 'thamani_http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method', 'route', 'status_code']
});
register.registerMetric(httpRequestTotal);

// Active connections
const activeConnections = new client.Gauge({
    name: 'thamani_active_connections',
    help: 'Number of active connections'
});
register.registerMetric(activeConnections);

// Database queries
const dbQueryDuration = new client.Histogram({
    name: 'thamani_db_query_duration_seconds',
    help: 'Duration of database queries',
    labelNames: ['operation', 'table'],
    buckets: [0.001, 0.01, 0.1, 0.5, 1, 3]
});
register.registerMetric(dbQueryDuration);

// AI requests
const aiRequests = new client.Counter({
    name: 'thamani_ai_requests_total',
    help: 'Total AI requests',
    labelNames: ['provider', 'status']
});
register.registerMetric(aiRequests);

// Users online
const usersOnline = new client.Gauge({
    name: 'thamani_users_online',
    help: 'Number of users online'
});
register.registerMetric(usersOnline);

// Messages
const messagesTotal = new client.Counter({
    name: 'thamani_messages_total',
    help: 'Total messages sent',
    labelNames: ['type', 'room_type']
});
register.registerMetric(messagesTotal);

// ============================================================
// MIDDLEWARE
// ============================================================
const metricsMiddleware = (req, res, next) => {
    const start = Date.now();

    res.on('finish', () => {
        const duration = (Date.now() - start) / 1000;
        const route = req.route?.path || req.path;

        httpRequestDuration
            .labels(req.method, route, res.statusCode)
            .observe(duration);

        httpRequestTotal
            .labels(req.method, route, res.statusCode)
            .inc();
    });

    next();
};

// ============================================================
// METRICS ENDPOINT
// ============================================================
const metricsEndpoint = async (req, res) => {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
};

module.exports = {
    register,
    metricsMiddleware,
    metricsEndpoint,
    metrics: {
        httpRequestDuration,
        httpRequestTotal,
        activeConnections,
        dbQueryDuration,
        aiRequests,
        usersOnline,
        messagesTotal
    }
};