const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

const NO_REPLY_EMAIL = process.env.EMAIL_USER;
const NO_REPLY_NAME = 'THAMANI YANGU (NO-REPLY)';
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || process.env.EMAIL_USER;

exports.sendEmail = async ({ to, subject, html }) => {
    try {
        await transporter.sendMail({
            from: `"${NO_REPLY_NAME}" <${NO_REPLY_EMAIL}>`,
            to, subject, html,
            replyTo: SUPPORT_EMAIL,
            headers: {
                'X-Auto-Response-Suppress': 'All',
                'Auto-Submitted': 'auto-generated',
                'X-No-Reply': 'true'
            }
        });
        return true;
    } catch (err) {
        console.error('Email error:', err);
        return false;
    }
};