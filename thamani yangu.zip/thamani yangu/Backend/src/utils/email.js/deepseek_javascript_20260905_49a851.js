const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

const NO_REPLY_EMAIL = process.env.EMAIL_USER || 'thamaniyangu@gmail.com';
const NO_REPLY_NAME = 'THAMANI YANGU (NO-REPLY)';
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || 'thamaniyangu@gmail.com';

exports.sendEmail = async ({ to, subject, html, replyTo = null }) => {
    try {
        await transporter.sendMail({
            from: `"${NO_REPLY_NAME}" <${NO_REPLY_EMAIL}>`,
            to,
            subject,
            html,
            replyTo: replyTo || SUPPORT_EMAIL,
            headers: {
                'X-Auto-Response-Suppress': 'All',
                'Auto-Submitted': 'auto-generated',
                'X-No-Reply': 'true'
            }
        });
        console.log(`📧 NO-REPLY email sent to ${to}`);
        return true;
    } catch (err) {
        console.error('Email error:', err);
        return false;
    }
};

exports.sendEmailWithAttachment = async ({ to, subject, html, attachments, replyTo = null }) => {
    try {
        await transporter.sendMail({
            from: `"${NO_REPLY_NAME}" <${NO_REPLY_EMAIL}>`,
            to,
            subject,
            html,
            attachments: attachments || [],
            replyTo: replyTo || SUPPORT_EMAIL,
            headers: {
                'X-Auto-Response-Suppress': 'All',
                'Auto-Submitted': 'auto-generated',
                'X-No-Reply': 'true'
            }
        });
        console.log(`📧 NO-REPLY email with attachments sent to ${to}`);
        return true;
    } catch (err) {
        console.error('Email with attachment error:', err);
        return false;
    }
};