const { pgPool, getMySQLPool, getMongoDB, MongoDocument, MongoChatMessage, MongoAIHistory } = require('../config/databases');

const pg = {
    insert: async (table, data) => {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
        const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders}) RETURNING *`;
        const result = await pgPool.query(sql, values);
        return result.rows[0];
    },
    find: async (table, where = {}, limit = 100) => {
        const keys = Object.keys(where);
        let sql = `SELECT * FROM ${table}`;
        if (keys.length) {
            sql += ` WHERE ${keys.map((k, i) => `${k} = $${i + 1}`).join(' AND ')}`;
        }
        sql += ` LIMIT ${limit}`;
        const result = await pgPool.query(sql, Object.values(where));
        return result.rows;
    }
};

class UnifiedDB {
    static async insert(table, data) {
        try {
            const result = await pg.insert(table, data);
            return result;
        } catch (err) {
            console.error('DB insert error:', err);
            throw err;
        }
    }

    static async find(table, where = {}, limit = 100) {
        try {
            return await pg.find(table, where, limit);
        } catch (err) {
            console.error('DB find error:', err);
            return [];
        }
    }
}

module.exports = { pg, UnifiedDB };