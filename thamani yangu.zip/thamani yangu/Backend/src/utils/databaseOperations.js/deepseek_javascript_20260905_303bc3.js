const { pgPool, getMySQLPool, getMongoDB, MongoDocument, MongoChatMessage, MongoAIHistory } = require('../config/databases');

// ===== PostgreSQL Operations =====
const pg = {
    query: async (sql, params) => {
        const result = await pgPool.query(sql, params);
        return result.rows;
    },
    insert: async (table, data) => {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
        const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders}) RETURNING *`;
        const result = await pgPool.query(sql, values);
        return result.rows[0];
    },
    update: async (table, data, where) => {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const setClause = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');
        const whereKey = Object.keys(where)[0];
        const whereValue = Object.values(where)[0];
        const sql = `UPDATE ${table} SET ${setClause} WHERE ${whereKey} = $${keys.length + 1} RETURNING *`;
        const result = await pgPool.query(sql, [...values, whereValue]);
        return result.rows[0];
    },
    delete: async (table, where) => {
        const key = Object.keys(where)[0];
        const value = Object.values(where)[0];
        const sql = `DELETE FROM ${table} WHERE ${key} = $1 RETURNING *`;
        const result = await pgPool.query(sql, [value]);
        return result.rows[0];
    },
    find: async (table, where = {}, limit = 100) => {
        const keys = Object.keys(where);
        let sql = `SELECT * FROM ${table}`;
        if (keys.length) {
            const conditions = keys.map((k, i) => `${k} = $${i + 1}`).join(' AND ');
            sql += ` WHERE ${conditions}`;
        }
        sql += ` LIMIT ${limit}`;
        const result = await pgPool.query(sql, Object.values(where));
        return result.rows;
    }
};

// ===== MySQL Operations =====
const mysql = {
    query: async (sql, params) => {
        const pool = await getMySQLPool();
        const [rows] = await pool.execute(sql, params || []);
        return rows;
    },
    insert: async (table, data) => {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const placeholders = keys.map(() => '?').join(', ');
        const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
        const pool = await getMySQLPool();
        const [result] = await pool.execute(sql, values);
        return { id: result.insertId, ...data };
    },
    update: async (table, data, where) => {
        const keys = Object.keys(data);
        const setClause = keys.map(k => `${k} = ?`).join(', ');
        const whereKey = Object.keys(where)[0];
        const whereValue = Object.values(where)[0];
        const sql = `UPDATE ${table} SET ${setClause} WHERE ${whereKey} = ?`;
        const pool = await getMySQLPool();
        await pool.execute(sql, [...Object.values(data), whereValue]);
        return { ...data, [whereKey]: whereValue };
    },
    delete: async (table, where) => {
        const key = Object.keys(where)[0];
        const value = Object.values(where)[0];
        const sql = `DELETE FROM ${table} WHERE ${key} = ?`;
        const pool = await getMySQLPool();
        await pool.execute(sql, [value]);
        return { deleted: true };
    },
    find: async (table, where = {}, limit = 100) => {
        const keys = Object.keys(where);
        let sql = `SELECT * FROM ${table}`;
        if (keys.length) {
            sql += ` WHERE ${keys.map(k => `${k} = ?`).join(' AND ')}`;
        }
        sql += ` LIMIT ${limit}`;
        const pool = await getMySQLPool();
        const [rows] = await pool.execute(sql, Object.values(where));
        return rows;
    }
};

// ===== MongoDB Operations =====
const mongo = {
    insert: async (model, data) => {
        const doc = new model(data);
        await doc.save();
        return doc.toObject();
    },
    update: async (model, filter, data) => {
        const result = await model.findOneAndUpdate(filter, data, { new: true });
        return result ? result.toObject() : null;
    },
    delete: async (model, filter) => {
        await model.deleteOne(filter);
        return { deleted: true };
    },
    find: async (model, filter = {}, limit = 100) => {
        const docs = await model.find(filter).limit(limit).lean();
        return docs;
    }
};

// ===== UNIFIED DATABASE OPERATIONS (Auto-fallback) =====
class UnifiedDB {
    static async insert(table, data, options = {}) {
        const { replicate = true, primaryOnly = false } = options;
        try {
            // Primary: PostgreSQL
            const pgResult = await pg.insert(table, data);
            
            // Async replication to MySQL & MongoDB
            if (replicate && !primaryOnly) {
                setTimeout(async () => {
                    try { await mysql.insert(table, data); } catch (e) {}
                }, 0);
                setTimeout(async () => {
                    try {
                        const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                        const Model = modelMap[table];
                        if (Model) await mongo.insert(Model, data);
                    } catch (e) {}
                }, 0);
            }
            return pgResult;
        } catch (pgError) {
            console.error('PG insert failed, trying MySQL:', pgError.message);
            try {
                const mysqlResult = await mysql.insert(table, data);
                // Also try MongoDB
                setTimeout(async () => {
                    try {
                        const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                        const Model = modelMap[table];
                        if (Model) await mongo.insert(Model, data);
                    } catch (e) {}
                }, 0);
                return mysqlResult;
            } catch (mysqlError) {
                console.error('MySQL insert failed, trying MongoDB:', mysqlError.message);
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                    const Model = modelMap[table];
                    if (Model) {
                        return await mongo.insert(Model, data);
                    }
                    throw new Error('No database available');
                } catch (mongoError) {
                    console.error('All databases failed:', mongoError.message);
                    throw new Error('All databases failed');
                }
            }
        }
    }

    static async find(table, where = {}, limit = 100) {
        // Try PostgreSQL first
        try {
            return await pg.find(table, where, limit);
        } catch (pgError) {
            console.error('PG find failed, trying MySQL:', pgError.message);
            try {
                return await mysql.find(table, where, limit);
            } catch (mysqlError) {
                console.error('MySQL find failed, trying MongoDB:', mysqlError.message);
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                    const Model = modelMap[table];
                    if (Model) {
                        return await mongo.find(Model, where, limit);
                    }
                    return [];
                } catch (mongoError) {
                    console.error('All databases failed:', mongoError.message);
                    return [];
                }
            }
        }
    }

    static async update(table, data, where) {
        try {
            const pgResult = await pg.update(table, data, where);
            setTimeout(async () => {
                try { await mysql.update(table, data, where); } catch (e) {}
            }, 0);
            setTimeout(async () => {
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                    const Model = modelMap[table];
                    if (Model) await mongo.update(Model, where, data);
                } catch (e) {}
            }, 0);
            return pgResult;
        } catch (pgError) {
            console.error('PG update failed, trying MySQL:', pgError.message);
            try {
                const mysqlResult = await mysql.update(table, data, where);
                return mysqlResult;
            } catch (mysqlError) {
                console.error('MySQL update failed, trying MongoDB:', mysqlError.message);
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage, ai_history: MongoAIHistory };
                    const Model = modelMap[table];
                    if (Model) {
                        return await mongo.update(Model, where, data);
                    }
                    throw new Error('No database available');
                } catch (mongoError) {
                    throw new Error('All databases failed');
                }
            }
        }
    }

    static async delete(table, where) {
        try {
            const pgResult = await pg.delete(table, where);
            setTimeout(async () => {
                try { await mysql.delete(table, where); } catch (e) {}
            }, 0);
            setTimeout(async () => {
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage };
                    const Model = modelMap[table];
                    if (Model) await mongo.delete(Model, where);
                } catch (e) {}
            }, 0);
            return pgResult;
        } catch (pgError) {
            console.error('PG delete failed, trying MySQL:', pgError.message);
            try {
                return await mysql.delete(table, where);
            } catch (mysqlError) {
                console.error('MySQL delete failed, trying MongoDB:', mysqlError.message);
                try {
                    const modelMap = { documents: MongoDocument, chat_messages: MongoChatMessage };
                    const Model = modelMap[table];
                    if (Model) {
                        return await mongo.delete(Model, where);
                    }
                    throw new Error('No database available');
                } catch (mongoError) {
                    throw new Error('All databases failed');
                }
            }
        }
    }
}

module.exports = { pg, mysql, mongo, UnifiedDB };