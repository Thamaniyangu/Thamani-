const axios = require('axios');
require('dotenv').config();

// ===== 8 AI PROVIDERS WITH FALLBACK CHAIN =====
const AI_PROVIDERS = [
    {
        name: 'Claude',
        url: 'https://api.anthropic.com/v1/messages',
        headers: (key) => ({
            'x-api-key': key,
            'anthropic-version': '2023-06-01',
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'claude-3-haiku-20240307',
            max_tokens: 1024,
            messages: [{ role: 'user', content: prompt }]
        }),
        extract: (data) => data.content[0].text,
        apiKey: process.env.CLAUDE_API_KEY
    },
    {
        name: 'DeepSeek',
        url: 'https://api.deepseek.com/v1/chat/completions',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'deepseek-chat',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 1024
        }),
        extract: (data) => data.choices[0].message.content,
        apiKey: process.env.DEEPSEEK_API_KEY
    },
    {
        name: 'Gemini',
        url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',
        headers: () => ({ 'Content-Type': 'application/json' }),
        body: (prompt) => ({ contents: [{ parts: [{ text: prompt }] }] }),
        extract: (data) => data.candidates[0].content.parts[0].text,
        apiKey: process.env.GEMINI_API_KEY,
        urlAppend: (key) => `?key=${key}`
    },
    {
        name: 'ChatGPT',
        url: 'https://api.openai.com/v1/chat/completions',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 1024
        }),
        extract: (data) => data.choices[0].message.content,
        apiKey: process.env.OPENAI_API_KEY
    },
    {
        name: 'Cohere',
        url: 'https://api.cohere.ai/v1/generate',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'command-r',
            prompt: prompt,
            max_tokens: 1024
        }),
        extract: (data) => data.generations[0].text,
        apiKey: process.env.COHERE_API_KEY
    },
    {
        name: 'Mistral',
        url: 'https://api.mistral.ai/v1/chat/completions',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'mistral-small',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 1024
        }),
        extract: (data) => data.choices[0].message.content,
        apiKey: process.env.MISTRAL_API_KEY
    },
    {
        name: 'Llama',
        url: 'https://api.llama.ai/v1/chat/completions',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            model: 'llama-3-70b',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 1024
        }),
        extract: (data) => data.choices[0].message.content,
        apiKey: process.env.LLAMA_API_KEY
    },
    {
        name: 'HuggingFace',
        url: 'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1',
        headers: (key) => ({
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
        }),
        body: (prompt) => ({
            inputs: prompt,
            parameters: { max_new_tokens: 1024 }
        }),
        extract: (data) => data[0].generated_text,
        apiKey: process.env.HUGGINGFACE_API_KEY
    }
];

// ===== MAIN FALLBACK FUNCTION =====
exports.callAIWithFallback = async (prompt) => {
    let lastError = null;
    for (const provider of AI_PROVIDERS) {
        if (!provider.apiKey) {
            console.log(`Skipping ${provider.name}: No API key`);
            continue;
        }
        try {
            console.log(`🤖 Trying ${provider.name}...`);
            let url = provider.url;
            if (provider.urlAppend) {
                url += provider.urlAppend(provider.apiKey);
            }
            const response = await axios.post(url, provider.body(prompt), {
                headers: provider.headers(provider.apiKey),
                timeout: 15000
            });
            const result = provider.extract(response.data);
            console.log(`✅ ${provider.name} success!`);
            return { success: true, provider: provider.name, response: result };
        } catch (error) {
            console.error(`❌ ${provider.name} failed:`, error.response?.data?.error || error.message);
            lastError = error;
        }
    }
    return { success: false, error: 'All AI providers failed', details: lastError?.message };
};