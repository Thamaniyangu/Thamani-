const Sentry = require('@sentry/node');
const { ProfilingIntegration } = require('@sentry/profiling-node');

exports.initSentry = (app) => {
    if (!process.env.SENTRY_DSN) {
        console.log('⚠️ Sentry disabled (no DSN)');
        return;
    }

    Sentry.init({
        dsn: process.env.SENTRY_DSN,
        environment: process.env.NODE_ENV || 'development',
        integrations: [
            new Sentry.Integrations.Http({ tracing: true }),
            new Sentry.Integrations.Express({ app }),
            new ProfilingIntegration()
        ],
        tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
        profilesSampleRate: 0.1,
        beforeSend(event) {
            // Filter sensitive data
            if (event.request) {
                delete event.request.cookies;
                if (event.request.headers) {
                    delete event.request.headers.authorization;
                    delete event.request.headers.cookie;
                }
                if (event.request.data) {
                    delete event.request.data.password;
                    delete event.request.data.newPassword;
                }
            }
            return event;
        }
    });

    // Request handler
    app.use(Sentry.Handlers.requestHandler());
    app.use(Sentry.Handlers.tracingHandler());
    
    return Sentry;
};

exports.setupErrorHandler = (app) => {
    if (!process.env.SENTRY_DSN) return;
    
    app.use(Sentry.Handlers.errorHandler({
        shouldHandleError(error) {
            // Only log 5xx errors
            return error.status >= 500;
        }
    }));
};

exports.captureError = (error, context = {}) => {
    if (!process.env.SENTRY_DSN) {
        console.error('Error:', error, context);
        return;
    }

    Sentry.withScope(scope => {
        Object.entries(context).forEach(([key, value]) => {
            scope.setContext(key, value);
        });
        Sentry.captureException(error);
    });
};