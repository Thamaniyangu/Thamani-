const redis = require('redis');

let client = null;
let isConnected = false;

exports.connect = async () => {
    try {
        client = redis.createClient({
            url: process.env.REDIS_URL || 'redis://localhost:6379'
        });

        client.on('error', err => console.error('Redis error:', err));
        client.on('connect', () => {
            isConnected = true;
            console.log('✅ Redis connected');
        });

        await client.connect();
    } catch (err) {
        console.warn('⚠️ Redis not available, using memory cache');
        isConnected = false;
    }
};

// Cache functions
exports.set = async (key, value, ttl = 3600) => {
    if (!isConnected) return false;
    try {
        await client.setEx(key, ttl, JSON.stringify(value));
        return true;
    } catch (err) { return false; }
};

exports.get = async (key) => {
    if (!isConnected) return null;
    try {
        const data = await client.get(key);
        return data ? JSON.parse(data) : null;
    } catch (err) { return null; }
};

exports.del = async (key) => {
    if (!isConnected) return false;
    try {
        await client.del(key);
        return true;
    } catch (err) { return false; }
};

exports.isConnected = () => isConnected;