// ============================================================
// AI ORCHESTRATOR - FALLBACK CHAIN (26 PROVIDERS)
// ============================================================

const AI_PROVIDERS = require('./aiProviders');

// ============================================================
// MAIN FALLBACK FUNCTION
// ============================================================
exports.callAIWithFallback = async (userMessage, history = [], options = {}) => {
    const { preferredLanguage = 'sw' } = options;

    // System prompt
    const systemPrompt = {
        role: 'system',
        content: `Wewe ni THAMANI AI BUDDY, msaidizi wa kikundi cha THAMANI YANGU M-KOBA.
                  Unajibu masuala ya kijamii, kiuchumi, na kiutamaduni kwa Kiswahili na Kiingereza.
                  ${preferredLanguage === 'sw' 
                      ? 'Jibu kwa Kiswahili kwanza, lakini unaweza kutumia Kiingereza.' 
                      : 'Reply in English first, but you can use Swahili.'}
                  Unakataa masuala ya kisiasa. Jibu kwa lugha rahisi, yenye heshima, na mfupi.`
    };

    const messages = [systemPrompt, ...history, { role: 'user', content: userMessage }];

    // Sort providers by priority (1 → 26)
    const sortedProviders = [...AI_PROVIDERS].sort((a, b) => a.priority - b.priority);

    let lastError = null;
    const attemptedProviders = [];

    // Try each provider in order
    for (const provider of sortedProviders) {
        try {
            // Check if API key is available (except local Llama)
            const apiKey = provider.apiKey ? provider.apiKey() : null;

            if (!apiKey && !provider.isLocal) {
                // Skip providers without API key
                continue;
            }

            // For local Llama, check if Ollama is running (quick ping)
            if (provider.isLocal) {
                const isOllamaRunning = await checkOllamaRunning();
                if (!isOllamaRunning) {
                    console.log(`⏭️ Skipping ${provider.name} (Ollama not running)`);
                    continue;
                }
            }

            console.log(`🤖 Trying ${provider.name}...`);
            attemptedProviders.push(provider.name);

            const response = await provider.call(messages);

            if (response && response.length > 0) {
                console.log(`✅ ${provider.name} success!`);
                return {
                    success: true,
                    provider: provider.name,
                    response: response.trim(),
                    attemptedProviders
                };
            }
        } catch (error) {
            const errorMsg = error.response?.data?.error?.message || error.message;
            console.warn(`❌ ${provider.name} failed:`, errorMsg);
            lastError = error;
            // Continue to next provider (bila kukwama)
        }
    }

    // All providers failed
    console.error('❌ All AI providers failed');
    return {
        success: false,
        error: 'Hakuna AI inayopatikana kwa sasa. Tafadhali jaribu tena baada ya muda.',
        details: lastError?.message,
        attemptedProviders
    };
};

// ============================================================
// CHECK IF OLLAMA (Llama) IS RUNNING
// ============================================================
async function checkOllamaRunning() {
    try {
        const axios = require('axios');
        const res = await axios.get(
            `${process.env.OLLAMA_URL || 'http://localhost:11434'}/api/tags`,
            { timeout: 2000 }
        );
        return res.status === 200;
    } catch (err) {
        return false;
    }
}

// ============================================================
// GET PROVIDER STATUS (for debugging/admin)
// ============================================================
exports.getProviderStatus = () => {
    return AI_PROVIDERS.map(p => ({
        name: p.name,
        priority: p.priority,
        hasApiKey: p.isLocal ? 'local' : (p.apiKey && p.apiKey() ? 'yes' : 'no'),
        supportsSwahili: p.supportsSwahili || false,
        isLocal: p.isLocal || false
    })).sort((a, b) => a.priority - b.priority);
};