const AI_PROVIDERS = require('./aiProviders');

exports.callAIWithFallback = async (userMessage, history = [], options = {}) => {
    const { systemPrompt, preferredLanguage = 'sw' } = options;

    const finalSystemPrompt = systemPrompt || `Wewe ni THAMANI AI BUDDY. Jibu kwa Kiswahili na Kiingereza.`;

    const messages = [
        { role: 'system', content: finalSystemPrompt },
        ...history,
        { role: 'user', content: userMessage }
    ];

    const sortedProviders = [...AI_PROVIDERS].sort((a, b) => a.priority - b.priority);
    let lastError = null;
    const attemptedProviders = [];

    for (const provider of sortedProviders) {
        try {
            const apiKey = provider.apiKey ? provider.apiKey() : null;
            if (!apiKey && !provider.isLocal) continue;

            if (provider.isLocal) {
                const isRunning = await checkOllamaRunning();
                if (!isRunning) continue;
            }

            console.log(`🤖 Trying ${provider.name}...`);
            attemptedProviders.push(provider.name);

            const response = await provider.call(messages);

            if (response && response.length > 0) {
                console.log(`✅ ${provider.name} success!`);
                return {
                    success: true,
                    provider: provider.name,
                    response: response.trim(),
                    attemptedProviders
                };
            }
        } catch (error) {
            console.warn(`❌ ${provider.name} failed:`, error.message);
            lastError = error;
        }
    }

    return {
        success: false,
        error: 'Hakuna AI inayopatikana kwa sasa.',
        details: lastError?.message,
        attemptedProviders
    };
};

async function checkOllamaRunning() {
    try {
        const axios = require('axios');
        const res = await axios.get(
            `${process.env.OLLAMA_URL || 'http://localhost:11434'}/api/tags`,
            { timeout: 2000 }
        );
        return res.status === 200;
    } catch (err) {
        return false;
    }
}

exports.getProviderStatus = () => {
    return AI_PROVIDERS.map(p => ({
        name: p.name,
        priority: p.priority,
        hasApiKey: p.isLocal ? 'local' : (p.apiKey && p.apiKey() ? 'yes' : 'no'),
        supportsSwahili: p.supportsSwahili || false,
        isLocal: p.isLocal || false
    })).sort((a, b) => a.priority - b.priority);
};