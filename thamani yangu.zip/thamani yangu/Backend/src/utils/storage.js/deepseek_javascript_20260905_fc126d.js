const supabase = require('../config/supabase');

exports.uploadToStorage = async (fileBuffer, bucket, filename) => {
    const path = `${bucket}/${filename}`;
    const { error } = await supabase.storage
        .from(bucket)
        .upload(path, fileBuffer, {
            contentType: 'application/octet-stream',
            cacheControl: '3600',
            upsert: true
        });
    if (error) throw error;
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
};

exports.deleteFromStorage = async (bucket, path) => {
    const { error } = await supabase.storage.from(bucket).remove([path]);
    if (error) throw error;
};