const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

// ============================================================
// STORAGE CONFIG
// ============================================================
const UPLOAD_DIR = path.join(__dirname, '../../uploads');
const PUBLIC_URL = process.env.PUBLIC_URL || 'http://localhost:5000';

// Ensure upload directory exists
if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Buckets (folders)
const BUCKETS = [
    'receipts',
    'id-cards',
    'profiles',
    'chat-media',
    'support',
    'documents',
    'group-logo',
    'ai-profiles',
    'recordings'
];

BUCKETS.forEach(bucket => {
    const dir = path.join(UPLOAD_DIR, bucket);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ============================================================
// UPLOAD FILE
// ============================================================
exports.uploadToStorage = async (fileBuffer, bucket, filename) => {
    try {
        const bucketDir = path.join(UPLOAD_DIR, bucket);
        if (!fs.existsSync(bucketDir)) fs.mkdirSync(bucketDir, { recursive: true });

        const filePath = path.join(bucketDir, filename);
        fs.writeFileSync(filePath, fileBuffer);

        // Return public URL
        return `${PUBLIC_URL}/uploads/${bucket}/${filename}`;
    } catch (err) {
        console.error('Upload error:', err);
        throw err;
    }
};

// ============================================================
// UPLOAD IMAGE (with optimization)
// ============================================================
exports.uploadImage = async (fileBuffer, bucket, filename, options = {}) => {
    try {
        const { width = 800, height = 800, quality = 85 } = options;

        // Optimize image
        const optimized = await sharp(fileBuffer)
            .resize(width, height, { fit: 'inside', withoutEnlargement: true })
            .jpeg({ quality })
            .toBuffer();

        // Ensure .jpg extension
        const finalName = filename.replace(/\.(png|webp|jpeg|jpg)$/i, '.jpg');

        return await exports.uploadToStorage(optimized, bucket, finalName);
    } catch (err) {
        console.error('Image upload error:', err);
        throw err;
    }
};

// ============================================================
// DELETE FILE
// ============================================================
exports.deleteFromStorage = async (bucket, filename) => {
    try {
        const filePath = path.join(UPLOAD_DIR, bucket, filename);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            return true;
        }
        return false;
    } catch (err) {
        console.error('Delete error:', err);
        throw err;
    }
};

// ============================================================
// DELETE FILE BY URL
// ============================================================
exports.deleteByUrl = async (url) => {
    try {
        if (!url) return false;
        const parts = url.split('/uploads/');
        if (parts.length < 2) return false;

        const [bucket, ...rest] = parts[1].split('/');
        const filename = rest.join('/');

        return await exports.deleteFromStorage(bucket, filename);
    } catch (err) {
        console.error('Delete by URL error:', err);
        return false;
    }
};

// ============================================================
// GET FILE
// ============================================================
exports.getFile = (bucket, filename) => {
    const filePath = path.join(UPLOAD_DIR, bucket, filename);
    if (!fs.existsSync(filePath)) return null;
    return fs.readFileSync(filePath);
};

// ============================================================
// LIST FILES IN BUCKET
// ============================================================
exports.listFiles = (bucket) => {
    try {
        const bucketDir = path.join(UPLOAD_DIR, bucket);
        if (!fs.existsSync(bucketDir)) return [];

        return fs.readdirSync(bucketDir).map(filename => {
            const filePath = path.join(bucketDir, filename);
            const stats = fs.statSync(filePath);
            return {
                filename,
                size: stats.size,
                created_at: stats.birthtime,
                url: `${PUBLIC_URL}/uploads/${bucket}/${filename}`
            };
        });
    } catch (err) {
        return [];
    }
};

// ============================================================
// STORAGE QUOTA
// ============================================================
exports.getStorageStats = () => {
    const stats = {};
    let totalSize = 0;

    BUCKETS.forEach(bucket => {
        const files = exports.listFiles(bucket);
        const bucketSize = files.reduce((sum, f) => sum + f.size, 0);
        stats[bucket] = {
            files: files.length,
            size: bucketSize,
            sizeMB: (bucketSize / 1024 / 1024).toFixed(2)
        };
        totalSize += bucketSize;
    });

    return {
        totalSize,
        totalMB: (totalSize / 1024 / 1024).toFixed(2),
        totalGB: (totalSize / 1024 / 1024 / 1024).toFixed(3),
        buckets: stats
    };
};

// ============================================================
// CLEANUP OLD FILES
// ============================================================
exports.cleanupOldFiles = (bucket, daysOld) => {
    try {
        const cutoff = new Date(Date.now() - daysOld * 24 * 60 * 60 * 1000);
        const files = exports.listFiles(bucket);
        let deleted = 0;

        files.forEach(file => {
            if (new Date(file.created_at) < cutoff) {
                exports.deleteFromStorage(bucket, file.filename);
                deleted++;
            }
        });

        return deleted;
    } catch (err) {
        return 0;
    }
};