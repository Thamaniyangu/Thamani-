const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');

const BACKUP_DIR = path.join(__dirname, '../../backups');
const DB_NAME = process.env.MYSQL_DATABASE || 'thamani_yangu';
const DB_USER = process.env.MYSQL_USER || 'root';
const DB_PASS = process.env.MYSQL_PASSWORD || '';
const DB_HOST = process.env.MYSQL_HOST || 'localhost';
const MAX_BACKUPS = 30; // Keep last 30

// Ensure backup dir exists
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

// ============================================================
// CREATE BACKUP
// ============================================================
exports.createBackup = async () => {
    return new Promise((resolve, reject) => {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `backup-${DB_NAME}-${timestamp}.sql`;
        const filepath = path.join(BACKUP_DIR, filename);

        const passArg = DB_PASS ? `-p${DB_PASS}` : '';
        const command = `mysqldump -h ${DB_HOST} -u ${DB_USER} ${passArg} ${DB_NAME} > "${filepath}"`;

        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error('❌ Backup error:', error);
                return reject(error);
            }

            const stats = fs.statSync(filepath);
            console.log(`✅ Backup created: ${filename} (${(stats.size / 1024).toFixed(2)} KB)`);

            // Cleanup old backups
            cleanupOldBackups();

            resolve({
                filename,
                filepath,
                size: stats.size,
                createdAt: new Date()
            });
        });
    });
};

// ============================================================
// CLEANUP OLD BACKUPS
// ============================================================
const cleanupOldBackups = () => {
    const files = fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup-') && f.endsWith('.sql'))
        .map(f => ({
            name: f,
            path: path.join(BACKUP_DIR, f),
            time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime()
        }))
        .sort((a, b) => b.time - a.time);

    if (files.length > MAX_BACKUPS) {
        const toDelete = files.slice(MAX_BACKUPS);
        toDelete.forEach(f => {
            fs.unlinkSync(f.path);
            console.log(`🗑️ Deleted old backup: ${f.name}`);
        });
    }
};

// ============================================================
// RESTORE BACKUP
// ============================================================
exports.restoreBackup = async (filename) => {
    return new Promise((resolve, reject) => {
        const filepath = path.join(BACKUP_DIR, filename);
        if (!fs.existsSync(filepath)) {
            return reject(new Error('Backup haipatikani'));
        }

        const passArg = DB_PASS ? `-p${DB_PASS}` : '';
        const command = `mysql -h ${DB_HOST} -u ${DB_USER} ${passArg} ${DB_NAME} < "${filepath}"`;

        exec(command, (error) => {
            if (error) {
                console.error('❌ Restore error:', error);
                return reject(error);
            }
            console.log(`✅ Database restored from: ${filename}`);
            resolve({ success: true, filename });
        });
    });
};

// ============================================================
// LIST BACKUPS
// ============================================================
exports.listBackups = () => {
    if (!fs.existsSync(BACKUP_DIR)) return [];

    return fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup-') && f.endsWith('.sql'))
        .map(f => {
            const filepath = path.join(BACKUP_DIR, f);
            const stats = fs.statSync(filepath);
            return {
                filename: f,
                size: stats.size,
                sizeMB: (stats.size / 1024 / 1024).toFixed(2),
                createdAt: stats.mtime
            };
        })
        .sort((a, b) => b.createdAt - a.createdAt);
};

// ============================================================
// SCHEDULE - Daily at 2 AM
// ============================================================
cron.schedule('0 2 * * *', async () => {
    console.log('🕐 Running daily backup...');
    try {
        await exports.createBackup();
    } catch (err) {
        console.error('Scheduled backup failed:', err);
    }
});

// Weekly backup (Sunday 3 AM)
cron.schedule('0 3 * * 0', async () => {
    console.log('🕐 Running weekly backup...');
    try {
        await exports.createBackup();
    } catch (err) {
        console.error('Weekly backup failed:', err);
    }
});