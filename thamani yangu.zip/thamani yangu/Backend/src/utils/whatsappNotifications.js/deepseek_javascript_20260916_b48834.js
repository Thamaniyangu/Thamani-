const { sendWhatsApp } = require('./whatsapp');
const supabase = require('../config/supabase');

const sendWhatsAppIfAllowed = async (userId, notificationType, message) => {
    try {
        const { data: user } = await supabase
            .from('users')
            .select('whatsapp_number, whatsapp_preferences')
            .eq('id', userId)
            .single();

        if (!user?.whatsapp_number) return;

        const prefs = user.whatsapp_preferences || {};
        if (prefs[notificationType] === false) return;

        await sendWhatsApp({ to: user.whatsapp_number, message });
    } catch (err) {
        console.error('WhatsApp notification error:', err);
    }
};

exports.notifyMeeting = async (user, meeting) => {
    const msg = `📅 *Mkutano*\n${meeting.title}\n📌 ${new Date(meeting.start_time).toLocaleString()}\n🔗 ${process.env.FRONTEND_URL}/meeting/${meeting.id}`;
    await sendWhatsAppIfAllowed(user.id, 'meeting', msg);
};

exports.notifyFinancialReport = async (user, report) => {
    const msg = `📊 *Ripoti*\nJumla: TZS ${report.totalContributions?.toLocaleString()}\n🔗 ${process.env.FRONTEND_URL}/reports/${report.id}`;
    await sendWhatsAppIfAllowed(user.id, 'financial_report', msg);
};

exports.notifyAnnouncement = async (user, announcement) => {
    const msg = `📢 *Tangazo*\n${announcement.title}\n🔗 ${process.env.FRONTEND_URL}/announcements/${announcement.id}`;
    await sendWhatsAppIfAllowed(user.id, 'announcement', msg);
};