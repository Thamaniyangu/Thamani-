const { sendWhatsApp } = require('./whatsapp');
const supabase = require('../config/supabase');

// ============================================================
// SEND WHATSAPP IF USER ALLOWED
// ============================================================
const sendWhatsAppIfAllowed = async (userId, notificationType, message) => {
    try {
        const { data: user } = await supabase
            .from('users')
            .select('whatsapp_number, whatsapp_preferences')
            .eq('id', userId)
            .single();

        if (!user?.whatsapp_number) return;

        const prefs = user.whatsapp_preferences || {};
        if (prefs[notificationType] === false) return;

        await sendWhatsApp({ to: user.whatsapp_number, message });
    } catch (err) {
        console.error('WhatsApp notification error:', err);
    }
};

// ============================================================
// 1. MEETING NOTIFICATION
// ============================================================
exports.notifyMeeting = async (user, meeting) => {
    const msg = `📅 *Mkutano wa THAMANI YANGU*

${meeting.title}

📌 Muda: ${new Date(meeting.start_time).toLocaleString('sw-TZ')}
⏳ Muda: ${meeting.duration} dakika

🔗 Jiunge: ${process.env.FRONTEND_URL}/meeting/${meeting.id}`;

    await sendWhatsAppIfAllowed(user.id, 'meeting', msg);
};

// ============================================================
// 2. EXTERNAL MEETING NOTIFICATION
// ============================================================
exports.notifyExternalMeeting = async (user, meeting) => {
    const msg = `🌐 *Mkutano wa Nje*

${meeting.title}

📌 Muda: ${new Date(meeting.start_time).toLocaleString('sw-TZ')}
👤 Mwenyeji: ${meeting.host_name || 'THAMANI YANGU'}

🔗 Jiunge: ${meeting.external_link || process.env.FRONTEND_URL}`;

    await sendWhatsAppIfAllowed(user.id, 'external_meeting', msg);
};

// ============================================================
// 3. FINANCIAL REPORT
// ============================================================
exports.notifyFinancialReport = async (user, report) => {
    const msg = `📊 *Ripoti ya Kifedha*

📋 Aina: ${report.type}
💰 Jumla: TZS ${report.totalContributions?.toLocaleString() || '0'}

🔗 ${process.env.FRONTEND_URL}/reports/${report.id}`;

    await sendWhatsAppIfAllowed(user.id, 'financial_report', msg);
};

// ============================================================
// 4. ANNOUNCEMENT
// ============================================================
exports.notifyAnnouncement = async (user, announcement) => {
    const msg = `📢 *Tangazo*

${announcement.title}

📝 ${announcement.summary || 'Tazama maelezo kamili.'}

🔗 ${process.env.FRONTEND_URL}/announcements/${announcement.id}`;

    await sendWhatsAppIfAllowed(user.id, 'announcement', msg);
};

// ============================================================
// 5. ADVICE
// ============================================================
exports.notifyAdvice = async (user, advice) => {
    const msg = `💡 *Ushauri*

${advice.title || 'Ushauri Mpya'}

${advice.summary || 'Tazama maelezo kamili.'}

🔗 ${process.env.FRONTEND_URL}/advice/${advice.id}`;

    await sendWhatsAppIfAllowed(user.id, 'advice', msg);
};

// ============================================================
// 6. MEETING REMINDER
// ============================================================
exports.notifyMeetingReminder = async (user, meeting) => {
    const msg = `⏰ *KIKUMBUSHO: Mkutano*

${meeting.title}

📌 Muda: ${new Date(meeting.start_time).toLocaleString('sw-TZ')}

🔗 Jiunge: ${process.env.FRONTEND_URL}/meeting/${meeting.id}`;

    await sendWhatsAppIfAllowed(user.id, 'reminder', msg);
};