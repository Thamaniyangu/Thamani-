// ============================================================
// AI ROUTER - Smart Question Routing (@leader + Finance Handoff)
// ============================================================

const { callAIWithFallback } = require('./aiOrchestrator');

// ============================================================
// 1. DETECT AI TYPE FROM TAG
// ============================================================
exports.detectAIType = (message) => {
    const lowerMsg = message.toLowerCase();
    
    // Check for explicit tags (UPDATED: @leader badala ya @leadership)
    if (lowerMsg.includes('@finance') || lowerMsg.includes('@financial')) {
        return { ai: 'financial', cleanMessage: message.replace(/@finance(ial)?/gi, '').trim() };
    }
    if (lowerMsg.includes('@leader')) {
        return { ai: 'leadership', cleanMessage: message.replace(/@leader/gi, '').trim() };
    }
    if (lowerMsg.includes('@ai') || lowerMsg.includes('@buddy')) {
        return { ai: 'buddy', cleanMessage: message.replace(/@ai|@buddy/gi, '').trim() };
    }

    // Auto-detect based on keywords
    const financeKeywords = [
        'akiba', 'mkopo', 'riba', 'fedha', 'pesa', 'bajeti', 'hisa', 'jamii',
        'faida', 'gharama', 'mapato', 'matumizi', 'kiasi', 'malipo', 'deni',
        'wekeza', 'uwekezaji', 'benki', 'rejesho', 'faini', 'savings',
        'loan', 'interest', 'money', 'finance', 'budget', 'investment',
        'mchango', 'michango', 'ada', 'risiti', 'mapato', 'gharama'
    ];

    const leadershipKeywords = [
        'uongozi', 'kiongozi', 'mwenyekiti', 'katibu', 'mhazini',
        'maamuzi', 'mkutano', 'agenda', 'majukumu', 'wajibu',
        'timu', 'wajumbe', 'sheria', 'kanuni', 'utawala', 'mikataba',
        'leadership', 'leader', 'decision', 'meeting'
    ];

    const financeScore = financeKeywords.filter(k => lowerMsg.includes(k)).length;
    const leadershipScore = leadershipKeywords.filter(k => lowerMsg.includes(k)).length;

    if (financeScore > leadershipScore && financeScore > 0) {
        return { ai: 'financial', cleanMessage: message };
    }
    if (leadershipScore > financeScore && leadershipScore > 0) {
        return { ai: 'leadership', cleanMessage: message };
    }

    // Default to buddy
    return { ai: 'buddy', cleanMessage: message };
};

// ============================================================
// 2. CHECK IF QUESTION IS FINANCE-RELATED
// ============================================================
exports.isFinanceQuestion = (message) => {
    const lowerMsg = message.toLowerCase();
    const financeKeywords = [
        'akiba', 'mkopo', 'riba', 'fedha', 'pesa', 'bajeti', 'hisa', 'jamii',
        'faida', 'gharama', 'mapato', 'matumizi', 'kiasi', 'malipo', 'deni',
        'wekeza', 'uwekezaji', 'benki', 'rejesho', 'faini', 'savings',
        'loan', 'interest', 'money', 'finance', 'budget', 'investment',
        'mchango', 'michango', 'ada', 'risiti', 'kiasi', 'jumla',
        'savings', 'deposit', 'withdraw', 'transfer'
    ];
    return financeKeywords.some(k => lowerMsg.includes(k));
};

// ============================================================
// 3. GET SYSTEM PROMPT PER AI
// ============================================================
exports.getSystemPrompt = (aiType, language = 'sw') => {
    const prompts = {
        buddy: {
            sw: `Wewe ni THAMANI AI BUDDY, msaidizi wa kikundi cha THAMANI YANGU M-KOBA.
                 Unajibu masuala ya kijamii, kiutamaduni, na jumla kwa Kiswahili sanifu.
                 
                 KANUNI ZA USTAARABU:
                 - Tumia lugha ya heshima daima (tumia "tafadhali", "asante", "samahani")
                 - Anza jibu kwa salamu fupi (mfano: "Habari!", "Karibu!")
                 - Jibu kwa ufupi lakini kikamilifu (aya 1-3)
                 - Tumia alama za uandishi vizuri (vibonzo, nukta, namba)
                 - Kama hujui, sema "Samahani, sina uhakika. Tafadhali wasiliana na viongozi."
                 - Usijibu masuala ya kisiasa
                 - Usitoe ushauri wa kisheria
                 
                 MUUNDO WA JIBU:
                 1. Salamu fupi
                 2. Jibu kuu (aya 1-2)
                 3. Ushauri au hatua inayofuata (kama inafaa)`,
            en: `You are THAMANI AI BUDDY, assistant for THAMANI YANGU M-KOBA group.
                 POLITENESS RULES:
                 - Always use respectful language
                 - Start with brief greeting
                 - Answer briefly but completely (1-3 paragraphs)
                 - If unsure, say "Sorry, I'm not sure. Please contact leaders."
                 - Do not answer political matters`
        },
        financial: {
            sw: `Wewe ni THAMANI FINANCIAL ADVISOR, mshauri wa kifedha wa kikundi cha THAMANI YANGU M-KOBA.
                 Unajibu masuala yote ya kifedha: akiba, mikopo, riba, bajeti, uwekezaji, na mipango ya kifedha.
                 
                 KANUNI ZA USTAARABU:
                 - Tumia lugha ya heshima daima
                 - Anza kwa salamu fupi ("Habari!", "Karibu!")
                 - Toa ushauri wa vitendo unaoweza kutekelezeka
                 - Tumia mifano ya namba (TZS) inapofaa
                 - Tumia alama za uandishi vizuri
                 - Kama swali linahusu jambo lingine (jamii, utamaduni), sema "Swali hili si la kifedha. Tafadhali tumia @AI"
                 - Usitoe ushauri wa uwekezaji wenye hatari kubwa bila tahadhari
                 
                 MUUNDO WA JIBU:
                 1. Salamu fupi
                 2. Jibu la kifedha (aya 1-2)
                 3. Ushauri wa vitendo (hatua 2-3)
                 4. Tahadhari (kama inafaa)`,
            en: `You are THAMANI FINANCIAL ADVISOR, financial advisor for THAMANI YANGU.
                 You respond to all financial matters: savings, loans, interest, budgets, investments.`
        },
        leadership: {
            sw: `Wewe ni THAMANI LEADERSHIP MENTOR, mshauri wa uongozi kwa viongozi wa THAMANI YANGU M-KOBA.
                 Unajibu masuala ya uongozi, maamuzi, majukumu, na mikakati ya uongozi.
                 
                 KANUNI ZA USTAARABU:
                 - Tumia lugha ya heshima na ya kitaalamu
                 - Anza kwa salamu fupi ("Habari Mheshimiwa!", "Karibu!")
                 - Toa ushauri unaozingatia nafasi ya kiongozi (Mwenyekiti, Katibu, Mhazini)
                 - Tumia mifano halisi ya uongozi
                 - Tumia alama za uandishi vizuri
                 - Kama swali linahusu fedha, sema "Swali hili ni la kifedha. Linahitaji @Finance"
                 - Heshimu maadili ya uongozi (uadilifu, uwazi, uwajibikaji)
                 
                 MUUNDO WA JIBU:
                 1. Salamu ya heshima
                 2. Uchambuzi wa swali (aya 1)
                 3. Ushauri wa uongozi (hatua 2-4)
                 4. Ushauri wa ziada (kama inafaa)`,
            en: `You are THAMANI LEADERSHIP MENTOR, leadership advisor for THAMANI YANGU leaders.`
        }
    };

    return prompts[aiType]?.[language] || prompts.buddy.sw;
};

// ============================================================
// 4. ROUTE QUESTION TO CORRECT AI (with Smart Handoff)
// ============================================================
exports.routeQuestion = async (message, history = [], options = {}) => {
    const { requestedAI, userRole, language = 'sw' } = options;

    // Detect AI from tag/keywords
    const detection = exports.detectAIType(message);
    let aiType = requestedAI || detection.ai;
    let cleanMessage = detection.cleanMessage;
    let handoffNote = null;

    // ========================================================
    // PERMISSION CHECK: Leadership Mentor - Leaders chatroom only
    // ========================================================
    const isLeader = ['mwenyekiti', 'katibu', 'mhazini'].includes(userRole);

    if (aiType === 'leadership' && !isLeader) {
        return {
            success: false,
            error: 'Samahani, THAMANI LEADERSHIP MENTOR anapatikana kwa viongozi pekee. Tafadhali tumia @AI au @Finance.',
            aiType: 'leadership'
        };
    }

    // ========================================================
    // SMART HANDOFF 1: AI BUDDY tagged with Finance question → Financial Advisor
    // ========================================================
    if (aiType === 'buddy' && exports.isFinanceQuestion(cleanMessage)) {
        console.log('🔄 Handoff: AI Buddy → Financial Advisor (finance question detected)');
        aiType = 'financial';
        handoffNote = '🔀 Swali lako limepelekwa kwa THAMANI FINANCIAL ADVISOR kwa usahihi zaidi.';
    }

    // ========================================================
    // SMART HANDOFF 2: Leadership Mentor tagged with Finance question → Financial Advisor
    // ========================================================
    if (aiType === 'leadership' && exports.isFinanceQuestion(cleanMessage)) {
        console.log('🔄 Handoff: Leadership Mentor → Financial Advisor (finance question detected)');
        aiType = 'financial';
        handoffNote = '🔀 Swali lako limepelekwa kwa THAMANI FINANCIAL ADVISOR kwa usahihi zaidi.';
    }

    // ========================================================
    // SMART HANDOFF 3: AI Buddy tagged with Leadership question → Leadership Mentor (if leader)
    // ========================================================
    if (aiType === 'buddy' && isLeader) {
        const leadershipKeywords = ['uongozi', 'kiongozi', 'mwenyekiti', 'katibu', 'mhazini', 'maamuzi', 'majukumu', 'wajibu'];
        const hasLeadershipKeyword = leadershipKeywords.some(k => cleanMessage.toLowerCase().includes(k));
        
        if (hasLeadershipKeyword) {
            console.log('🔄 Handoff: AI Buddy → Leadership Mentor (leadership question detected)');
            aiType = 'leadership';
            handoffNote = '🔀 Swali lako limepelekwa kwa THAMANI LEADERSHIP MENTOR kwa usahihi zaidi.';
        }
    }

    // Get system prompt
    const systemPrompt = exports.getSystemPrompt(aiType, language);

    // Build messages
    const messages = [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: cleanMessage }
    ];

    // Call AI with fallback
    const result = await callAIWithFallback(cleanMessage, history, {
        systemPrompt,
        preferredLanguage: language
    });

    return {
        ...result,
        aiType,
        aiName: getAIName(aiType),
        cleanMessage,
        handoffNote
    };
};

// ============================================================
// 5. GET AI NAME
// ============================================================
function getAIName(aiType) {
    const names = {
        buddy: 'THAMANI AI BUDDY',
        financial: 'THAMANI FINANCIAL ADVISOR',
        leadership: 'THAMANI LEADERSHIP MENTOR'
    };
    return names[aiType] || 'THAMANI AI';
}

// ============================================================
// 6. FAST RESPONSE CACHE
// ============================================================
const responseCache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes

exports.getCachedResponse = (message, aiType) => {
    const key = `${aiType}:${message.toLowerCase().trim()}`;
    const cached = responseCache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.response;
    }
    return null;
};

exports.setCachedResponse = (message, aiType, response) => {
    const key = `${aiType}:${message.toLowerCase().trim()}`;
    responseCache.set(key, { response, timestamp: Date.now() });
    if (responseCache.size > 500) {
        const oldestKey = responseCache.keys().next().value;
        responseCache.delete(oldestKey);
    }
};