// ============================================================
// RESPONSE FORMATTER - Fast, Clean, Respectful
// ============================================================

// ============================================================
// 1. TRIM & CLEAN
// ============================================================
exports.cleanResponse = (text) => {
    if (!text) return '';
    
    let cleaned = text.trim();
    
    // Remove repeated whitespace
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
    cleaned = cleaned.replace(/ {2,}/g, ' ');
    
    // Remove markdown that might not render
    cleaned = cleaned.replace(/^#{1,6}\s+/gm, '');
    
    // Ensure proper spacing after punctuation
    cleaned = cleaned.replace(/([.!?])([A-Z])/g, '$1 $2');
    
    return cleaned;
};

// ============================================================
// 2. ADD RESPECTFUL TOUCH
// ============================================================
exports.addRespectfulTone = (text, aiType = 'buddy') => {
    // Ensure response starts with polite greeting if too short
    const greetings = {
        buddy: ['Habari', 'Karibu', 'Asante kwa swali'],
        financial: ['Habari', 'Asante kwa swali lako la kifedha'],
        leadership: ['Habari Mheshimiwa', 'Asante kwa swali lako']
    };
    
    const isShort = text.length < 100;
    const hasGreeting = /^(habari|karibu|asante|salama)/i.test(text);
    
    if (isShort && !hasGreeting) {
        const greeting = greetings[aiType]?.[0] || 'Habari';
        return `${greeting}! ${text}`;
    }
    
    return text;
};

// ============================================================
// 3. LIMIT LENGTH (for fast responses)
// ============================================================
exports.limitLength = (text, maxChars = 1500) => {
    if (text.length <= maxChars) return text;
    return text.substring(0, maxChars) + '...\n\n(Kwa maelezo zaidi, tafadhali uliza tena.)';
};

// ============================================================
// 4. FORMAT FOR CHATROOM (compact)
// ============================================================
exports.formatForChatroom = (text, aiType) => {
    let formatted = exports.cleanResponse(text);
    formatted = exports.addRespectfulTone(formatted, aiType);
    formatted = exports.limitLength(formatted);
    return formatted;
};