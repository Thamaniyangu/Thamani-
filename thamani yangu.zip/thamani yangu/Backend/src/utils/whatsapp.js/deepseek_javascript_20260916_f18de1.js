// ============================================================
// WHATSAPP - Inatumia Service yetu wenyewe
// ============================================================

const whatsappService = require('../services/whatsappService');

// ============================================================
// 1. TUMA UJUMBE WA KAWAIDA
// ============================================================
exports.sendWhatsApp = async ({ to, message }) => {
    return await whatsappService.sendWhatsAppMessage(to, message);
};

// ============================================================
// 2. TUMA SIGN-UP LINK
// ============================================================
exports.sendSignUpLinkWhatsApp = async ({ to, link, name }) => {
    const message = `*THAMANI YANGU - Mwaliko*

Habari ${name || 'Mwanachama'}!

Umekaribishwa kujiunga na THAMANI YANGU. Bonyeza link hapa chini kukamilisha usajili wako:

${link}

📌 Link inaisha baada ya siku 5.

Asante,
THAMANI YANGU MANAGEMENT SYSTEM
"TUNAJENGA TABASAMU LAKO"`;

    return await whatsappService.sendWhatsAppMessage(to, message);
};

// ============================================================
// 3. TUMA OTP
// ============================================================
exports.sendWhatsAppOTP = async (to, otp) => {
    const message = `*THAMANI YANGU*

Msimbo wako wa OTP ni: *${otp}*

📌 Usishiriki na mtu yeyote.
📌 Msimbo unaisha baada ya dakika 10.`;

    return await whatsappService.sendWhatsAppMessage(to, message);
};

// ============================================================
// 4. TUMA EMAIL LINK (Email)
// ============================================================
exports.sendEmailLink = async (email, link) => {
    const { sendEmail } = require('./email');
    return await sendEmail({
        to: email,
        subject: 'Mwaliko wa Mkutano - THAMANI YANGU',
        html: `
            <h2>Mwaliko wa Mkutano</h2>
            <p>Bonyeza link kujiunga:</p>
            <p><a href="${link}">${link}</a></p>
            <p>Imetolewa na THAMANI YANGU</p>
        `
    });
};

// ============================================================
// 5. STATUS
// ============================================================
exports.isConnected = () => whatsappService.isConnected();
exports.getStatus = () => whatsappService.getStatus();
exports.sendToGroup = (groupId, message) => whatsappService.sendToGroup(groupId, message);
exports.sendImage = (to, path, caption) => whatsappService.sendImage(to, path, caption);
exports.sendDocument = (to, path, name, caption) => whatsappService.sendDocument(to, path, name, caption);