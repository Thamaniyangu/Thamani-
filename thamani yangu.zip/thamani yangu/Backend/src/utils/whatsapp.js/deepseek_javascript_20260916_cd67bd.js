// ============================================================
// WHATSAPP - Sasa inatumia Service yetu wenyewe
// ============================================================

const whatsappService = require('../services/whatsappService');

exports.sendWhatsApp = async ({ to, message }) => {
    return await whatsappService.sendWhatsAppMessage(to, message);
};

exports.sendSignUpLinkWhatsApp = async ({ to, link, name }) => {
    const message = `*THAMANI YANGU - Mwaliko*

Habari ${name || 'Mwanachama'}!

Umekaribishwa kujiunga na THAMANI YANGU. Bonyeza link hapa chini kukamilisha usajili wako:

${link}

📌 Link inaisha baada ya siku 5.

Asante,
THAMANI YANGU MANAGEMENT SYSTEM
"TUNAJENGA TABASAMU LAKO"`;

    return await whatsappService.sendWhatsAppMessage(to, message);
};

exports.sendWhatsAppOTP = async (to, otp) => {
    const message = `*THAMANI YANGU*

Msimbo wako wa OTP ni: *${otp}*

📌 Usishiriki na mtu yeyote.
📌 Msimbo unaisha baada ya dakika 10.`;

    return await whatsappService.sendWhatsAppMessage(to, message);
};

exports.sendEmailLink = async (email, link) => {
    const { sendEmail } = require('./email');
    return await sendEmail({
        to: email,
        subject: 'Mwaliko wa Mkutano - THAMANI YANGU',
        html: `<h2>Mwaliko</h2><p>Bonyeza link kujiunga:</p><p><a href="${link}">${link}</a></p>`
    });
};

exports.isConnected = () => whatsappService.isConnected();
exports.getStatus = () => whatsappService.getStatus();