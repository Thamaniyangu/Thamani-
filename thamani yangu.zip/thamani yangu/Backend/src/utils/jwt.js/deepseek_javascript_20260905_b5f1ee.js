const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET;

exports.generateToken = (user) => {
    return jwt.sign(
        { id: user.id, role: user.role, member_id: user.member_id, email: user.email },
        SECRET,
        { expiresIn: '7d' }
    );
};

exports.verifyToken = (token) => {
    try {
        return jwt.verify(token, SECRET);
    } catch (e) {
        return null;
    }
};