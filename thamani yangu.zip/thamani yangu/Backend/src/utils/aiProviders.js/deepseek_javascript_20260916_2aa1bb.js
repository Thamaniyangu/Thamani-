// ============================================================
// AI PROVIDERS CONFIGURATION - 26 PROVIDERS (FREE TIERS)
// ORDER: Claude → HuggingFace → DeepSeek → Gemini → Wengine → Llama (MWISHO)
// ============================================================

module.exports = [
    // ========================================================
    // PRIORITY 1: CLAUDE (Anthropic)
    // ========================================================
    {
        name: 'Claude',
        priority: 1,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.95,
        apiKey: () => process.env.CLAUDE_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.anthropic.com/v1/messages',
                {
                    model: 'claude-3-haiku-20240307',
                    max_tokens: 1024,
                    messages: messages.filter(m => m.role !== 'system')
                },
                {
                    headers: {
                        'x-api-key': process.env.CLAUDE_API_KEY,
                        'anthropic-version': '2023-06-01',
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.content[0].text;
        }
    },

    // ========================================================
    // PRIORITY 2: HUGGING FACE
    // ========================================================
    {
        name: 'HuggingFace',
        priority: 2,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.85,
        apiKey: () => process.env.HUGGINGFACE_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n');
            const res = await axios.post(
                'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2',
                { inputs: prompt, parameters: { max_new_tokens: 1024 } },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data[0]?.generated_text || 'No response';
        }
    },

    // ========================================================
    // PRIORITY 3: DEEPSEEK
    // ========================================================
    {
        name: 'DeepSeek',
        priority: 3,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.90,
        apiKey: () => process.env.DEEPSEEK_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.deepseek.com/v1/chat/completions',
                {
                    model: 'deepseek-chat',
                    messages: messages,
                    max_tokens: 1024
                },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 4: GEMINI (Google)
    // ========================================================
    {
        name: 'Gemini',
        priority: 4,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.92,
        apiKey: () => process.env.GEMINI_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
                {
                    contents: messages.map(m => ({
                        parts: [{ text: m.content }],
                        role: m.role === 'assistant' ? 'model' : 'user'
                    }))
                },
                { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
            );
            return res.data.candidates[0].content.parts[0].text;
        }
    },

    // ========================================================
    // PRIORITY 5: GROQ
    // ========================================================
    {
        name: 'Groq',
        priority: 5,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.GROQ_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                { model: 'mixtral-8x7b-32768', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 6: TOGETHER AI
    // ========================================================
    {
        name: 'Together AI',
        priority: 6,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.TOGETHER_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.together.xyz/v1/chat/completions',
                { model: 'meta-llama/Llama-3-70b-chat-hf', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.TOGETHER_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 7: OPENROUTER
    // ========================================================
    {
        name: 'OpenRouter',
        priority: 7,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.OPENROUTER_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://openrouter.ai/api/v1/chat/completions',
                { model: 'mistralai/mistral-7b-instruct:free', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
                        'Content-Type': 'application/json',
                        'HTTP-Referer': 'https://thamaniyangu.com',
                        'X-Title': 'THAMANI YANGU'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 8: COHERE
    // ========================================================
    {
        name: 'Cohere',
        priority: 8,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.COHERE_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n');
            const res = await axios.post(
                'https://api.cohere.ai/v1/generate',
                { model: 'command-r', prompt: prompt, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.COHERE_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.generations[0].text;
        }
    },

    // ========================================================
    // PRIORITY 9: MISTRAL
    // ========================================================
    {
        name: 'Mistral',
        priority: 9,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.MISTRAL_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.mistral.ai/v1/chat/completions',
                { model: 'mistral-small', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.MISTRAL_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 10: CEREBRAS
    // ========================================================
    {
        name: 'Cerebras',
        priority: 10,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.CEREBRAS_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.cerebras.ai/v1/chat/completions',
                { model: 'llama3.1-70b', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.CEREBRAS_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 11: CLOUDFLARE WORKERS AI
    // ========================================================
    {
        name: 'Cloudflare AI',
        priority: 11,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.CLOUDFLARE_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n');
            const res = await axios.post(
                `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/meta/llama-3-8b-instruct`,
                { messages: [{ role: 'user', content: prompt }] },
                {
                    headers: { 'Authorization': `Bearer ${process.env.CLOUDFLARE_API_KEY}` },
                    timeout: 30000
                }
            );
            return res.data.result.response;
        }
    },

    // ========================================================
    // PRIORITY 12: GITHUB MODELS
    // ========================================================
    {
        name: 'GitHub Models',
        priority: 12,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.GITHUB_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://models.inference.ai.azure.com/chat/completions',
                { model: 'gpt-4o-mini', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.GITHUB_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 13: AYA DATA (Kiswahili Bora)
    // ========================================================
    {
        name: 'Aya Data',
        priority: 13,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.95,
        apiKey: () => process.env.AYA_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.cohere.com/v1/chat',
                { model: 'c4ai-aya-23-8b', message: messages[messages.length - 1].content },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.AYA_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.text;
        }
    },

    // ========================================================
    // PRIORITY 14: SARVAM AI
    // ========================================================
    {
        name: 'Sarvam AI',
        priority: 14,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.85,
        apiKey: () => process.env.SARVAM_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.sarvam.ai/v1/chat/completions',
                { model: 'sarvam-2b', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.SARVAM_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 15: LUMI AI
    // ========================================================
    {
        name: 'Lumi AI',
        priority: 15,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.90,
        apiKey: () => process.env.LUMI_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.lumi.ai/v1/chat/completions',
                { model: 'lumi-african', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.LUMI_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 16: BANTU AI
    // ========================================================
    {
        name: 'Bantu AI',
        priority: 16,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.88,
        apiKey: () => process.env.BANTU_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.bantu.ai/v1/chat/completions',
                { model: 'bantu-70b', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.BANTU_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 17: UBUNTU AI
    // ========================================================
    {
        name: 'Ubuntu AI',
        priority: 17,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.92,
        apiKey: () => process.env.UBUNTU_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.ubuntu.ai/v1/chat/completions',
                { model: 'ubuntu-african', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.UBUNTU_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 18: Z AI
    // ========================================================
    {
        name: 'Z AI',
        priority: 18,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.ZAI_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.z.ai/v1/chat/completions',
                { model: 'z-ai', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.ZAI_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 19: AI21 LABS
    // ========================================================
    {
        name: 'AI21 Labs',
        priority: 19,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.AI21_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.ai21.com/studio/v1/chat/completions',
                { model: 'jamba-instruct', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.AI21_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 20: NOVITA AI
    // ========================================================
    {
        name: 'Novita AI',
        priority: 20,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.NOVITA_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.novita.ai/v3/openai/chat/completions',
                { model: 'meta-llama/llama-3.1-8b-instruct', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.NOVITA_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 21: PERPLEXITY
    // ========================================================
    {
        name: 'Perplexity',
        priority: 21,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.PERPLEXITY_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.perplexity.ai/chat/completions',
                { model: 'llama-3.1-sonar-small-128k-online', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 22: YOU.COM
    // ========================================================
    {
        name: 'You.com',
        priority: 22,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.YOU_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.you.com/v1/chat/completions',
                { model: 'you-chat', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.YOU_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 23: FIREWORKS AI
    // ========================================================
    {
        name: 'Fireworks AI',
        priority: 23,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.FIREWORKS_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.fireworks.ai/inference/v1/chat/completions',
                { model: 'accounts/fireworks/models/llama-v3p1-8b-instruct', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.FIREWORKS_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 24: SCALEWAY
    // ========================================================
    {
        name: 'Scaleway',
        priority: 24,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.SCALEWAY_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.scaleway.ai/v1/chat/completions',
                { model: 'llama-3.1-8b-instruct', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.SCALEWAY_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 25: OVHCLOUD AI
    // ========================================================
    {
        name: 'OVHcloud AI',
        priority: 25,
        type: 'chat',
        supportsSwahili: true,
        apiKey: () => process.env.OVHCLOUD_API_KEY,
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                'https://api.endpoints.ovh.cloud/v1/chat/completions',
                { model: 'llama3-70b-instruct', messages: messages, max_tokens: 1024 },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.OVHCLOUD_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            return res.data.choices[0].message.content;
        }
    },

    // ========================================================
    // PRIORITY 26: LLAMA 3.1 (LOCAL) - YA MWISHO
    // ========================================================
    // Hii ni ya mwisho kwa sababu bado haijaanza kuwekwa.
    // Mfumo unajaribu zote zilizo juu kwanza, kisha hii.
    // Ikiwa haijaanza (Ollama haifanyi kazi), inaruka tu bila kukwama.
    {
        name: 'Llama 3.1 (Local)',
        priority: 26,
        type: 'chat',
        supportsSwahili: true,
        swahiliConfidence: 0.95,
        isLocal: true,
        apiKey: () => 'local', // Hauna API key - daima inaonekana
        call: async (messages) => {
            const axios = require('axios');
            const res = await axios.post(
                `${process.env.OLLAMA_URL || 'http://localhost:11434'}/api/chat`,
                { model: process.env.OLLAMA_MODEL || 'llama3.1:8b', messages: messages, stream: false },
                { timeout: 60000 }
            );
            return res.data.message.content;
        }
    }
];