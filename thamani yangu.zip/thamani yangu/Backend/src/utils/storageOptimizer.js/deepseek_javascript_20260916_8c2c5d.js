const supabase = require('../config/supabase');
const cron = require('node-cron');

const RETENTION_RULES = {
    'receipts': 365 * 2,
    'id-cards': 365 * 5,
    'profiles': 'permanent',
    'chat-media': 30,
    'documents': 365 * 3,
    'group-logo': 'permanent',
    'support': 5,
    'ai-profiles': 'permanent',
    'meeting-recordings': 90
};

exports.cleanupOldFiles = async () => {
    try {
        for (const [bucket, days] of Object.entries(RETENTION_RULES)) {
            if (days === 'permanent' || days === 0) continue;
            const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
            const { data: files } = await supabase.storage.from(bucket).list();
            if (!files) continue;
            const toDelete = files.filter(f => new Date(f.created_at) < cutoff).map(f => f.name);
            if (toDelete.length > 0) {
                await supabase.storage.from(bucket).remove(toDelete);
            }
        }
    } catch (err) {
        console.error('Cleanup error:', err);
    }
};

cron.schedule('0 2 * * *', async () => {
    await exports.cleanupOldFiles();
});