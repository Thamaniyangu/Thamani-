const supabase = require('../config/supabase');
const cron = require('node-cron');

// ============================================================
// 1. DEDUPLICATION - Kuepuka kuhifadhi faili zinazorudia
// ============================================================
const fileHashes = new Map();

exports.isDuplicate = (hash) => {
    return fileHashes.has(hash);
};

exports.markFile = (hash, fileId) => {
    fileHashes.set(hash, fileId);
};

// ============================================================
// 2. COMPRESSION - Kupunguza ukubwa wa faili
// ============================================================
const sharp = require('sharp');

exports.compressImage = async (buffer) => {
    return await sharp(buffer)
        .resize(1920, 1080, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 75 })
        .toBuffer();
};

// ============================================================
// 3. RETENTION POLICY - Sera ya kuhifadhi
// ============================================================
const RETENTION_RULES = {
    'receipts': 365 * 2,      // Miaka 2
    'id-cards': 365 * 5,      // Miaka 5
    'profiles': 'permanent',  // Bila kufuta
    'chat-media': 30,         // Siku 30
    'documents': 365 * 3,     // Miaka 3
    'group-logo': 'permanent',
    'support': 5,             // Siku 5
    'ai-generated': 0,        // Hifadhi zero (inatosha preview)
    'meeting-recordings': 90  // Siku 90
};

exports.cleanupOldFiles = async () => {
    try {
        const now = new Date();

        for (const [bucket, days] of Object.entries(RETENTION_RULES)) {
            if (days === 'permanent' || days === 0) continue;

            const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);

            const { data: files, error } = await supabase.storage
                .from(bucket)
                .list();

            if (error || !files) continue;

            const toDelete = [];
            for (const file of files) {
                const fileDate = new Date(file.created_at);
                if (fileDate < cutoff) {
                    toDelete.push(file.name);
                }
            }

            if (toDelete.length > 0) {
                await supabase.storage.from(bucket).remove(toDelete);
                console.log(`🗑️ Cleaned ${toDelete.length} files from ${bucket}`);
            }
        }
    } catch (err) {
        console.error('Cleanup error:', err);
    }
};

// ============================================================
// 4. QUOTA MONITORING - Kufuatilia matumizi
// ============================================================
exports.checkStorageQuota = async () => {
    try {
        const buckets = ['receipts', 'id-cards', 'profiles', 'chat-media', 'documents', 'group-logo', 'support', 'ai-generated'];

        let totalSize = 0;
        const stats = {};

        for (const bucket of buckets) {
            const { data: files } = await supabase.storage.from(bucket).list();
            const size = files?.reduce((sum, f) => sum + (f.metadata?.size || 0), 0) || 0;
            stats[bucket] = {
                files: files?.length || 0,
                size,
                sizeMB: (size / 1024 / 1024).toFixed(2)
            };
            totalSize += size;
        }

        return {
            totalSize,
            totalMB: (totalSize / 1024 / 1024).toFixed(2),
            totalGB: (totalSize / 1024 / 1024 / 1024).toFixed(3),
            quotaMB: parseInt(process.env.SUPABASE_STORAGE_QUOTA_MB) || 1024,
            usagePercent: ((totalSize / 1024 / 1024) / (parseInt(process.env.SUPABASE_STORAGE_QUOTA_MB) || 1024) * 100).toFixed(1),
            buckets: stats
        };
    } catch (err) {
        console.error('Quota check error:', err);
        return null;
    }
};

// ============================================================
// 5. SCHEDULE AUTO-CLEANUP
// ============================================================
cron.schedule('0 2 * * *', async () => {
    // Run daily at 2 AM
    console.log('🧹 Running storage cleanup...');
    await exports.cleanupOldFiles();
    const quota = await exports.checkStorageQuota();
    if (quota) {
        console.log(`📊 Storage usage: ${quota.totalMB} MB / ${quota.quotaMB} MB (${quota.usagePercent}%)`);
    }
});

// ============================================================
// 6. ALERT IF QUOTA EXCEEDED
// ============================================================
cron.schedule('0 */6 * * *', async () => {
    // Run every 6 hours
    const quota = await exports.checkStorageQuota();
    if (quota && parseFloat(quota.usagePercent) > 80) {
        console.warn(`⚠️ Storage quota at ${quota.usagePercent}%! Cleanup needed.`);
        // Send alert email to leaders
        // await sendEmail({ to: leader.email, subject: '⚠️ Storage Warning', ... });
    }
});