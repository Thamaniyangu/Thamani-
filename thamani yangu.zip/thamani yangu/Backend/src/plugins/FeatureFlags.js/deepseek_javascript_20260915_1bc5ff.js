const mysql = require('../config/mysql');
const redis = require('../config/redis');

// ============================================================
// FEATURE FLAGS SYSTEM (Enable/Disable features without restart)
// ============================================================
class FeatureFlags {
    constructor() {
        this.cache = new Map();
    }

    // Get flag
    async get(key, defaultValue = false) {
        // Check cache
        if (this.cache.has(key)) {
            const cached = this.cache.get(key);
            if (Date.now() - cached.timestamp < 60000) {
                return cached.value;
            }
        }

        // Check Redis
        if (redis.isConnected()) {
            const cached = await redis.get(`flag:${key}`);
            if (cached !== null) return cached;
        }

        // Get from DB
        const flag = await mysql.queryOne(`
            SELECT flag_value, enabled FROM feature_flags WHERE flag_key = ?
        `, [key]);

        const value = flag ? (flag.enabled ? flag.flag_value : defaultValue) : defaultValue;
        
        // Cache
        this.cache.set(key, { value, timestamp: Date.now() });
        if (redis.isConnected()) {
            await redis.set(`flag:${key}`, value, 60);
        }

        return value;
    }

    // Set flag
    async set(key, value, enabled = true) {
        await mysql.query(`
            INSERT INTO feature_flags (id, flag_key, flag_value, enabled)
            VALUES (UUID(), ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                flag_value = VALUES(flag_value),
                enabled = VALUES(enabled)
        `, [key, JSON.stringify(value), enabled]);

        this.cache.delete(key);
        if (redis.isConnected()) {
            await redis.del(`flag:${key}`);
        }

        // Notify all instances
        if (global.io) {
            global.io.emit('feature-flag-changed', { key, value, enabled });
        }

        return true;
    }

    // Toggle
    async toggle(key) {
        const flag = await mysql.queryOne(`
            SELECT enabled FROM feature_flags WHERE flag_key = ?
        `, [key]);

        if (flag) {
            await this.set(key, null, !flag.enabled);
        }
        return true;
    }
}

module.exports = new FeatureFlags();