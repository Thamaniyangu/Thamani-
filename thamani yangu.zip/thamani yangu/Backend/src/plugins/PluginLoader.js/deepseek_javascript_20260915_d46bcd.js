const fs = require('fs');
const path = require('path');
const mysql = require('../config/mysql');

// ============================================================
// PLUGIN LOADER - Core System
// ============================================================
class PluginLoader {
    constructor() {
        this.plugins = new Map();
        this.hooks = new Map(); // Event hooks
        this.routes = [];
        this.sockets = [];
        this.crons = [];
        this.pluginsDir = path.join(__dirname, '../../plugins');
        this.enabledPlugins = [];
    }

    // ============================================================
    // 1. DISCOVER PLUGINS
    // ============================================================
    async discover() {
        console.log('🔍 Discovering plugins...');

        if (!fs.existsSync(this.pluginsDir)) {
            fs.mkdirSync(this.pluginsDir, { recursive: true });
            console.log('📁 Created plugins directory');
            return;
        }

        const dirs = fs.readdirSync(this.pluginsDir).filter(f => {
            const fullPath = path.join(this.pluginsDir, f);
            return fs.statSync(fullPath).isDirectory();
        });

        for (const dir of dirs) {
            const pluginPath = path.join(this.pluginsDir, dir);
            const manifestPath = path.join(pluginPath, 'plugin.json');

            if (!fs.existsSync(manifestPath)) {
                console.warn(`⚠️ Plugin ${dir} missing plugin.json`);
                continue;
            }

            try {
                const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
                manifest.path = pluginPath;
                manifest.directory = dir;
                this.plugins.set(manifest.name, manifest);
                console.log(`✅ Found plugin: ${manifest.name} v${manifest.version}`);
            } catch (err) {
                console.error(`❌ Failed to load ${dir}:`, err.message);
            }
        }
    }

    // ============================================================
    // 2. LOAD ENABLED PLUGINS
    // ============================================================
    async loadEnabled() {
        console.log('🔌 Loading enabled plugins...');

        // Get enabled plugins from DB
        const enabled = await mysql.query(`
            SELECT plugin_name FROM plugin_registry WHERE enabled = TRUE
        `);

        this.enabledPlugins = enabled.map(p => p.plugin_name);

        for (const name of this.enabledPlugins) {
            await this.loadPlugin(name);
        }

        console.log(`✅ Loaded ${this.enabledPlugins.length} plugins`);
    }

    // ============================================================
    // 3. LOAD SINGLE PLUGIN
    // ============================================================
    async loadPlugin(name) {
        const plugin = this.plugins.get(name);
        if (!plugin) {
            console.warn(`⚠️ Plugin ${name} not found`);
            return false;
        }

        try {
            // Check dependencies
            if (plugin.dependencies) {
                for (const dep of plugin.dependencies) {
                    if (!this.enabledPlugins.includes(dep)) {
                        throw new Error(`Missing dependency: ${dep}`);
                    }
                }
            }

            // Run migrations
            await this.runMigrations(plugin);

            // Load routes
            if (plugin.entry && plugin.entry.routes) {
                const routesPath = path.join(plugin.path, plugin.entry.routes);
                if (fs.existsSync(routesPath)) {
                    const routes = require(routesPath);
                    this.routes.push({
                        basePath: plugin.basePath || `/api/plugins/${name}`,
                        router: routes
                    });
                    console.log(`  📍 Routes loaded: ${plugin.basePath || `/api/plugins/${name}`}`);
                }
            }

            // Load socket handlers
            if (plugin.entry && plugin.entry.socket) {
                const socketPath = path.join(plugin.path, plugin.entry.socket);
                if (fs.existsSync(socketPath)) {
                    this.sockets.push({
                        plugin: name,
                        handler: require(socketPath)
                    });
                    console.log(`  🔌 Socket handlers loaded`);
                }
            }

            // Load cron jobs
            if (plugin.entry && plugin.entry.crons) {
                const cronsPath = path.join(plugin.path, plugin.entry.crons);
                if (fs.existsSync(cronsPath)) {
                    const crons = require(cronsPath);
                    this.crons.push({ plugin: name, crons });
                    console.log(`  ⏰ Cron jobs loaded`);
                }
            }

            // Load hooks
            if (plugin.hooks) {
                for (const [event, handler] of Object.entries(plugin.hooks)) {
                    this.registerHook(event, handler, plugin);
                }
                console.log(`  🪝 Hooks registered`);
            }

            // Plugin's own init
            if (plugin.entry && plugin.entry.init) {
                const initPath = path.join(plugin.path, plugin.entry.init);
                if (fs.existsSync(initPath)) {
                    const init = require(initPath);
                    if (typeof init === 'function') {
                        await init();
                    }
                }
            }

            // Mark as loaded
            plugin.loaded = true;
            plugin.loadedAt = new Date();

            console.log(`✅ Plugin loaded: ${name}`);
            return true;
        } catch (err) {
            console.error(`❌ Failed to load plugin ${name}:`, err.message);
            return false;
        }
    }

    // ============================================================
    // 4. RUN MIGRATIONS
    // ============================================================
    async runMigrations(plugin) {
        const migrationsDir = path.join(plugin.path, 'migrations');
        if (!fs.existsSync(migrationsDir)) return;

        const migrationFiles = fs.readdirSync(migrationsDir)
            .filter(f => f.endsWith('.sql'))
            .sort();

        for (const file of migrationFiles) {
            const migrationId = `${plugin.name}:${file}`;

            // Check if already run
            const existing = await mysql.queryOne(`
                SELECT id FROM plugin_migrations WHERE migration_id = ?
            `, [migrationId]);

            if (existing) continue;

            console.log(`  🗄️ Running migration: ${file}`);

            const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
            const statements = sql.split(';').filter(s => s.trim());

            for (const stmt of statements) {
                if (stmt.trim()) {
                    await mysql.query(stmt);
                }
            }

            await mysql.query(`
                INSERT INTO plugin_migrations (id, migration_id, plugin_name, executed_at)
                VALUES (UUID(), ?, ?, NOW())
            `, [migrationId, plugin.name]);
        }
    }

    // ============================================================
    // 5. REGISTER HOOKS (Event System)
    // ============================================================
    registerHook(event, handler, plugin) {
        if (!this.hooks.has(event)) {
            this.hooks.set(event, []);
        }
        this.hooks.get(event).push({
            handler,
            plugin: plugin.name,
            priority: plugin.hookPriority || 10
        });

        // Sort by priority
        this.hooks.get(event).sort((a, b) => a.priority - b.priority);
    }

    // ============================================================
    // 6. TRIGGER HOOK
    // ============================================================
    async triggerHook(event, data) {
        const handlers = this.hooks.get(event) || [];

        for (const h of handlers) {
            try {
                if (typeof h.handler === 'string') {
                    // Handler is a file path
                    const plugin = this.plugins.get(h.plugin);
                    const handlerPath = path.join(plugin.path, h.handler);
                    const handler = require(handlerPath);
                    if (typeof handler === 'function') {
                        data = await handler(data) || data;
                    }
                } else if (typeof h.handler === 'function') {
                    data = await h.handler(data) || data;
                }
            } catch (err) {
                console.error(`Hook error [${event}] from ${h.plugin}:`, err);
            }
        }

        return data;
    }

    // ============================================================
    // 7. ENABLE PLUGIN
    // ============================================================
    async enable(name, userId = null) {
        const plugin = this.plugins.get(name);
        if (!plugin) throw new Error('Plugin not found');

        await mysql.query(`
            INSERT INTO plugin_registry 
            (id, plugin_name, version, enabled, enabled_by, enabled_at)
            VALUES (UUID(), ?, ?, TRUE, ?, NOW())
            ON DUPLICATE KEY UPDATE
                enabled = TRUE,
                enabled_by = VALUES(enabled_by),
                enabled_at = NOW()
        `, [name, plugin.version, userId]);

        await this.loadPlugin(name);

        if (!this.enabledPlugins.includes(name)) {
            this.enabledPlugins.push(name);
        }

        return true;
    }

    // ============================================================
    // 8. DISABLE PLUGIN
    // ============================================================
    async disable(name) {
        await mysql.query(`
            UPDATE plugin_registry SET enabled = FALSE WHERE plugin_name = ?
        `, [name]);

        this.enabledPlugins = this.enabledPlugins.filter(p => p !== name);
        
        // Remove routes
        this.routes = this.routes.filter(r => 
            !r.basePath.includes(name)
        );

        return true;
    }

    // ============================================================
    // 9. GET PLUGINS
    // ============================================================
    async getAll() {
        const plugins = [];
        const registry = await mysql.query(`
            SELECT * FROM plugin_registry
        `);

        const registryMap = new Map(
            registry.map(r => [r.plugin_name, r])
        );

        for (const [name, plugin] of this.plugins) {
            plugins.push({
                name,
                version: plugin.version,
                description: plugin.description,
                author: plugin.author,
                dependencies: plugin.dependencies || [],
                enabled: registryMap.get(name)?.enabled || false,
                loaded: plugin.loaded || false,
                installed_at: registryMap.get(name)?.installed_at,
                enabled_at: registryMap.get(name)?.enabled_at
            });
        }

        return plugins;
    }

    // ============================================================
    // 10. APPLY TO EXPRESS APP
    // ============================================================
    applyToApp(app) {
        for (const route of this.routes) {
            app.use(route.basePath, route.router);
            console.log(`📍 Applied route: ${route.basePath}`);
        }
    }

    // ============================================================
    // 11. APPLY TO SOCKET.IO
    // ============================================================
    applyToSocket(io) {
        for (const s of this.sockets) {
            if (typeof s.handler === 'function') {
                s.handler(io);
                console.log(`🔌 Applied socket handler from ${s.plugin}`);
            }
        }
    }
}

module.exports = new PluginLoader();