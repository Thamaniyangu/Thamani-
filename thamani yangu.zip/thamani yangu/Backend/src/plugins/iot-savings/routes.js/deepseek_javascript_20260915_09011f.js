const express = require('express');
const router = express.Router();

router.get('/devices', async (req, res) => {
    // Your code
    res.json({ devices: [] });
});

router.post('/data', async (req, res) => {
    // Receive IoT data
    res.json({ success: true });
});

module.exports = router;