module.exports = async (data) => {
    // Runs AFTER a contribution is recorded
    console.log('IoT: Contribution recorded', data);
    
    // Example: Check for auto-save trigger
    if (data.amount > 100000) {
        // Send special notification
    }
    
    return data;
};