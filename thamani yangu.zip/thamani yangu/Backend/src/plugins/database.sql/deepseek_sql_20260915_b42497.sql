-- ============================================================
-- PLUGIN REGISTRY
-- ============================================================
CREATE TABLE IF NOT EXISTS plugin_registry (
    id CHAR(36) PRIMARY KEY,
    plugin_name VARCHAR(100) UNIQUE NOT NULL,
    version VARCHAR(20) NOT NULL,
    enabled BOOLEAN DEFAULT FALSE,
    settings JSON,
    installed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    enabled_by CHAR(36),
    enabled_at TIMESTAMP NULL,
    INDEX idx_plugin_name (plugin_name),
    INDEX idx_enabled (enabled)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS plugin_migrations (
    id CHAR(36) PRIMARY KEY,
    migration_id VARCHAR(255) UNIQUE NOT NULL,
    plugin_name VARCHAR(100),
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_plugin_name (plugin_name)
) ENGINE=InnoDB;

-- ============================================================
-- FEATURE FLAGS (kwa ku-enable features bila kurestart)
-- ============================================================
CREATE TABLE IF NOT EXISTS feature_flags (
    id CHAR(36) PRIMARY KEY,
    flag_key VARCHAR(100) UNIQUE NOT NULL,
    flag_value JSON,
    enabled BOOLEAN DEFAULT FALSE,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_flag_key (flag_key)
) ENGINE=InnoDB;

-- ============================================================
-- SYSTEM HOOKS (kwa customization bila kubadilisha code)
-- ============================================================
CREATE TABLE IF NOT EXISTS system_hooks (
    id CHAR(36) PRIMARY KEY,
    hook_name VARCHAR(100) NOT NULL,
    hook_type VARCHAR(20) DEFAULT 'javascript',
    code TEXT,
    active BOOLEAN DEFAULT TRUE,
    priority INT DEFAULT 10,
    created_by CHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hook_name (hook_name),
    INDEX idx_active (active)
) ENGINE=InnoDB;