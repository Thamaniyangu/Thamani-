const redis = require('../config/redis');

// ============================================================
// RATE LIMIT CONFIGURATIONS
// ============================================================
const RATE_LIMITS = {
    // Authentication
    'auth:login': { max: 5, window: 60 },          // 5/min
    'auth:signup': { max: 3, window: 60 },         // 3/min
    'auth:forgot': { max: 3, window: 60 * 60 },    // 3/hour

    // General API
    'api:general': { max: 100, window: 60 },       // 100/min
    'api:read': { max: 200, window: 60 },          // 200/min
    'api:write': { max: 50, window: 60 },          // 50/min

    // AI
    'ai:chat': { max: 20, window: 60 },            // 20/min
    'ai:image': { max: 5, window: 60 },            // 5/min
    'ai:video': { max: 2, window: 60 * 5 },        // 2/5min

    // Media
    'media:upload': { max: 10, window: 60 },       // 10/min
    'media:download': { max: 30, window: 60 },     // 30/min

    // Chat
    'chat:message': { max: 30, window: 60 },       // 30/min

    // WhatsApp
    'whatsapp:send': { max: 50, window: 60 * 60 }, // 50/hour

    // Per-role multipliers
    'mwanachama': 1,
    'mhazini': 2,
    'katibu': 3,
    'mwenyekiti': 5
};

// ============================================================
// RATE LIMIT MIDDLEWARE
// ============================================================
exports.rateLimit = (endpoint) => {
    return async (req, res, next) => {
        // Skip kama Redis haipo
        if (!redis.isConnected()) return next();

        const userId = req.user?.id || req.ip;
        const role = req.user?.role || 'mwanachama';
        const config = RATE_LIMITS[endpoint] || RATE_LIMITS['api:general'];
        const multiplier = RATE_LIMITS[role] || 1;
        const max = config.max * multiplier;

        const key = `rate:${endpoint}:${userId}`;

        try {
            const count = await redis.incr(key, config.window);

            res.set({
                'X-RateLimit-Limit': max,
                'X-RateLimit-Remaining': Math.max(0, max - count),
                'X-RateLimit-Reset': Math.floor(Date.now() / 1000) + config.window
            });

            if (count > max) {
                return res.status(429).json({
                    error: 'Maombi mengi mno. Jaribu tena baadaye.',
                    retryAfter: config.window
                });
            }

            next();
        } catch (err) {
            console.error('Rate limit error:', err);
            next();
        }
    };
};

// ============================================================
// AUTO-DETECT MIDDLEWARE
// ============================================================
exports.autoRateLimit = (req, res, next) => {
    let endpoint = 'api:general';

    if (req.path.includes('/auth/')) {
        if (req.path.includes('/login')) endpoint = 'auth:login';
        else if (req.path.includes('/signup')) endpoint = 'auth:signup';
        else if (req.path.includes('/forgot')) endpoint = 'auth:forgot';
    } else if (req.path.includes('/ai/')) {
        if (req.path.includes('/chat')) endpoint = 'ai:chat';
        else if (req.path.includes('/image')) endpoint = 'ai:image';
        else if (req.path.includes('/video')) endpoint = 'ai:video';
    } else if (req.path.includes('/media/')) {
        if (req.method === 'POST') endpoint = 'media:upload';
        else endpoint = 'media:download';
    } else if (req.path.includes('/chat/') && req.method === 'POST') {
        endpoint = 'chat:message';
    } else if (req.path.includes('/whatsapp/')) {
        endpoint = 'whatsapp:send';
    } else if (req.method === 'GET') {
        endpoint = 'api:read';
    } else {
        endpoint = 'api:write';
    }

    return exports.rateLimit(endpoint)(req, res, next);
};

// ============================================================
// RESET USER RATE LIMIT (Mwenyekiti)
// ============================================================
exports.resetUserLimit = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { userId } = req.params;

    try {
        await redis.delPattern(`rate:*:${userId}`);
        res.json({ message: 'Rate limit imerejeshwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET USER RATE STATUS
// ============================================================
exports.getRateStatus = async (req, res) => {
    if (!redis.isConnected()) {
        return res.json({ redisAvailable: false });
    }

    const userId = req.params.userId || req.user.id;
    const status = {};

    for (const [endpoint, config] of Object.entries(RATE_LIMITS)) {
        if (typeof config !== 'object') continue;
        
        const key = `rate:${endpoint}:${userId}`;
        const count = await redis.get(key);
        status[endpoint] = {
            used: count || 0,
            max: config.max,
            window: config.window
        };
    }

    res.json(status);
};