// ============================================================
// INPUT SANITIZATION (SQL Injection Prevention)
// ============================================================

// Dangerous SQL patterns
const SQL_PATTERNS = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE|UNION|DECLARE)\b)/i,
    /(--|\;|\/\*|\*\/|xp_|sp_)/i,
    /(\bOR\b\s+\d+\s*=\s*\d+)/i,
    /(\bAND\b\s+\d+\s*=\s*\d+)/i,
    /('(\s|%20)*(OR|AND|UNION|SELECT|INSERT|UPDATE|DELETE|DROP)/i,
    /(\bCONCAT\s*\()/i,
    /(\bCHAR\s*\()/i,
    /(\bSLEEP\s*\()/i,
    /(\bBENCHMARK\s*\()/i,
    /(\bLOAD_FILE\s*\()/i,
    /(\bINTO\s+(OUTFILE|DUMPFILE))/i
];

// ============================================================
// SANITIZE STRING
// ============================================================
const sanitizeString = (str) => {
    if (typeof str !== 'string') return str;
    
    // Remove null bytes
    str = str.replace(/\0/g, '');
    
    // Escape dangerous characters
    str = str.replace(/[\x00\x1a\n\r\\'"\x1a]/g, '');
    
    // Trim whitespace
    return str.trim();
};

// ============================================================
// CHECK FOR SQL PATTERNS
// ============================================================
const hasSQLPattern = (str) => {
    if (typeof str !== 'string') return false;
    return SQL_PATTERNS.some(pattern => pattern.test(str));
};

// ============================================================
// RECURSIVE SANITIZE
// ============================================================
const sanitizeObject = (obj) => {
    if (obj === null || obj === undefined) return obj;
    
    if (typeof obj === 'string') {
        if (hasSQLPattern(obj)) {
            throw new Error('Input ina maandishi yanayotiliwa shaka');
        }
        return sanitizeString(obj);
    }
    
    if (Array.isArray(obj)) {
        return obj.map(item => sanitizeObject(item));
    }
    
    if (typeof obj === 'object') {
        const sanitized = {};
        for (const [key, value] of Object.entries(obj)) {
            // Sanitize key pia
            const safeKey = key.replace(/[^a-zA-Z0-9_]/g, '');
            sanitized[safeKey] = sanitizeObject(value);
        }
        return sanitized;
    }
    
    return obj;
};

// ============================================================
// MIDDLEWARE
// ============================================================
exports.sqlProtection = (req, res, next) => {
    try {
        // Sanitize body
        if (req.body && typeof req.body === 'object') {
            req.body = sanitizeObject(req.body);
        }
        
        // Sanitize query (preserve arrays)
        if (req.query && typeof req.query === 'object') {
            req.query = sanitizeObject(req.query);
        }
        
        // Sanitize params
        if (req.params && typeof req.params === 'object') {
            req.params = sanitizeObject(req.params);
        }
        
        next();
    } catch (err) {
        console.error('SQL protection error:', err.message);
        
        // Log suspicious input
        require('mysql').query(`
            INSERT INTO security_logs (id, event_type, details, created_at)
            VALUES (UUID(), 'sql_injection_attempt', ?, NOW())
        `, [JSON.stringify({
            ip: req.ip,
            path: req.originalUrl,
            method: req.method,
            body: req.body,
            error: err.message
        })]).catch(() => {});
        
        res.status(400).json({ 
            error: 'Input ina maandishi yanayotiliwa shaka' 
        });
    }
};

// ============================================================
// VALIDATION HELPERS
// ============================================================
exports.validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
};

exports.validatePhone = (phone) => {
    const regex = /^[+]?[0-9]{9,15}$/;
    return regex.test(phone.replace(/[\s\-()]/g, ''));
};

exports.validateUUID = (uuid) => {
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return regex.test(uuid);
};

exports.validateMemberId = (memberId) => {
    const regex = /^TYM-\d{4}-\d{3,4}$/;
    return regex.test(memberId);
};

exports.validateAmount = (amount) => {
    const num = parseFloat(amount);
    return !isNaN(num) && num > 0 && num < 1000000000;
};