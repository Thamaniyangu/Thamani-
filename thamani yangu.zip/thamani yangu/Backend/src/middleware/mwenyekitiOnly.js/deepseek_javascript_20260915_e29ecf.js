// ============================================================
// MWENYEKITI ONLY MIDDLEWARE
// Features za kipekee kwa Mwenyekiti tu
// ============================================================

exports.requireMwenyekiti = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ 
            error: 'Unahitaji kuingia' 
        });
    }

    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ 
            error: 'Kipengele hiki kinapatikana kwa Mwenyekiti pekee',
            code: 'MWENYEKITI_ONLY'
        });
    }

    next();
};

// ============================================================
// PLUGIN ENABLED CHECK
// Plugin lazima iwe enabled NA user awe Mwenyekiti
// ============================================================
exports.requirePluginAndMwenyekiti = (pluginName) => {
    return async (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Unahitaji kuingia' });
        }

        // Check Mwenyekiti role
        if (req.user.role !== 'mwenyekiti') {
            return res.status(403).json({
                error: 'Kipengele hiki kinapatikana kwa Mwenyekiti pekee',
                code: 'MWENYEKITI_ONLY'
            });
        }

        // Check plugin enabled
        try {
            const mysql = require('../config/mysql');
            const plugin = await mysql.queryOne(`
                SELECT enabled FROM plugin_registry WHERE plugin_name = ?
            `, [pluginName]);

            if (!plugin || !plugin.enabled) {
                return res.status(404).json({
                    error: 'Plugin haijawashwa',
                    code: 'PLUGIN_DISABLED'
                });
            }

            next();
        } catch (err) {
            console.error('Plugin check error:', err);
            res.status(500).json({ error: err.message });
        }
    };
};

// ============================================================
// LOG MWENYEKITI ACTION
// ============================================================
exports.logMwenyekitiAction = (actionName) => {
    return async (req, res, next) => {
        const mysql = require('../config/mysql');
        const { v4: uuidv4 } = require('uuid');

        try {
            await mysql.query(`
                INSERT INTO audit_logs 
                (id, user_id, user_role, action, details, ip, user_agent, path, method)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                uuidv4(),
                req.user.id,
                req.user.role,
                actionName,
                JSON.stringify({ body: req.body, params: req.params }),
                req.ip,
                req.headers['user-agent'],
                req.originalUrl,
                req.method
            ]);
        } catch (err) {
            console.error('Audit log error:', err);
        }

        next();
    };
};