const mysql = require('../config/mysql');

// ============================================================
// IP WHITELIST CHECK (Admins only by default)
// ============================================================
exports.ipWhitelistCheck = async (req, res, next) => {
    // Whitelist disabled kama hakuna entries
    const config = await mysql.queryOne(
        `SELECT value FROM settings WHERE \`key\` = 'ip_whitelist_enabled'`
    );
    
    const enabled = config ? JSON.parse(config.value).enabled : false;
    if (!enabled) return next();

    const ip = req.ip || req.connection.remoteAddress;

    try {
        // Check whitelist
        const whitelisted = await mysql.queryOne(
            `SELECT id FROM ip_whitelist 
             WHERE ip = ? AND active = TRUE 
             AND (expires_at IS NULL OR expires_at > NOW())`,
            [ip]
        );

        if (!whitelisted) {
            await logBlockedAttempt(ip, req.path, 'Not whitelisted');
            return res.status(403).json({ error: 'IP yako hairuhusiwi' });
        }

        next();
    } catch (err) {
        console.error('IP whitelist error:', err);
        next();
    }
};

// ============================================================
// IP BLACKLIST CHECK
// ============================================================
exports.ipBlacklistCheck = async (req, res, next) => {
    const ip = req.ip || req.connection.remoteAddress;

    try {
        const blocked = await mysql.queryOne(
            `SELECT * FROM ip_blacklist 
             WHERE ip = ? AND (blocked_until IS NULL OR blocked_until > NOW())`,
            [ip]
        );

        if (blocked) {
            await logBlockedAttempt(ip, req.path, 'Blacklisted');
            return res.status(403).json({ 
                error: 'IP yako imezuiwa',
                reason: blocked.reason 
            });
        }

        next();
    } catch (err) {
        next();
    }
};

// ============================================================
// ADD TO WHITELIST (Mwenyekiti)
// ============================================================
exports.addToWhitelist = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { ip, description, expiresAt } = req.body;

    if (!ip) return res.status(400).json({ error: 'IP inahitajika' });

    try {
        await mysql.query(`
            INSERT INTO ip_whitelist (id, ip, description, created_by, expires_at)
            VALUES (UUID(), ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                description = VALUES(description),
                active = TRUE,
                expires_at = VALUES(expires_at)
        `, [ip, description || null, req.user.id, expiresAt || null]);

        res.json({ message: 'IP imeongezwa kwenye whitelist' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// ADD TO BLACKLIST
// ============================================================
exports.addToBlacklist = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { ip, reason, durationHours } = req.body;

    if (!ip) return res.status(400).json({ error: 'IP inahitajika' });

    try {
        const blockedUntil = durationHours
            ? new Date(Date.now() + durationHours * 60 * 60 * 1000)
            : null;

        await mysql.query(`
            INSERT INTO ip_blacklist (id, ip, reason, blocked_until)
            VALUES (UUID(), ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                reason = VALUES(reason),
                blocked_until = VALUES(blocked_until)
        `, [ip, reason || 'Manual block', blockedUntil]);

        res.json({ message: 'IP imezuiwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// REMOVE FROM BLACKLIST
// ============================================================
exports.removeFromBlacklist = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await mysql.query(`DELETE FROM ip_blacklist WHERE ip = ?`, [req.params.ip]);
        res.json({ message: 'IP imeondolewa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// LIST WHITELIST / BLACKLIST
// ============================================================
exports.listWhitelist = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const list = await mysql.query(`SELECT * FROM ip_whitelist ORDER BY created_at DESC`);
    res.json(list);
};

exports.listBlacklist = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const list = await mysql.query(`SELECT * FROM ip_blacklist ORDER BY created_at DESC`);
    res.json(list);
};

// ============================================================
// AUTO-BLOCK AFTER FAILED ATTEMPTS
// ============================================================
const logBlockedAttempt = async (ip, path, reason) => {
    try {
        await mysql.query(`
            INSERT INTO security_logs (id, event_type, details, created_at)
            VALUES (UUID(), 'ip_blocked', ?, NOW())
        `, [JSON.stringify({ ip, path, reason })]);
    } catch (err) {}
};

// Track failed logins kwa auto-block
const failedAttempts = new Map();

exports.trackFailedLogin = async (ip) => {
    const count = (failedAttempts.get(ip) || 0) + 1;
    failedAttempts.set(ip, count);

    // Auto-block after 10 failures in 15 minutes
    if (count >= 10) {
        await mysql.query(`
            INSERT INTO ip_blacklist (id, ip, reason, blocked_until)
            VALUES (UUID(), ?, 'Auto-blocked: 10+ failed logins', DATE_ADD(NOW(), INTERVAL 1 HOUR))
            ON DUPLICATE KEY UPDATE blocked_until = VALUES(blocked_until)
        `, [ip]);

        failedAttempts.delete(ip);
    }

    // Auto-cleanup after 15 minutes
    setTimeout(() => {
        failedAttempts.delete(ip);
    }, 15 * 60 * 1000);
};