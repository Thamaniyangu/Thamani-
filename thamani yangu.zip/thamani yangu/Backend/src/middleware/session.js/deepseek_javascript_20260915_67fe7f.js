const redis = require('../config/redis');

const SESSION_TTL = 7 * 24 * 60 * 60; // 7 days

// ============================================================
// SAVE SESSION
// ============================================================
exports.saveSession = async (userId, token, metadata = {}) => {
    const key = `session:${userId}:${token.slice(-16)}`;
    await redis.set(key, {
        userId,
        token,
        ...metadata,
        createdAt: new Date().toISOString()
    }, SESSION_TTL);
    return true;
};

// ============================================================
// VALIDATE SESSION
// ============================================================
exports.validateSession = async (userId, token) => {
    const key = `session:${userId}:${token.slice(-16)}`;
    return await redis.get(key);
};

// ============================================================
// REVOKE SESSION
// ============================================================
exports.revokeSession = async (userId, token) => {
    const key = `session:${userId}:${token.slice(-16)}`;
    return await redis.del(key);
};

// ============================================================
// REVOKE ALL USER SESSIONS
// ============================================================
exports.revokeAllUserSessions = async (userId) => {
    return await redis.delPattern(`session:${userId}:*`);
};

// ============================================================
// SESSION MIDDLEWARE
// ============================================================
exports.sessionCheck = async (req, res, next) => {
    // Skip kama Redis haipo
    if (!redis.isConnected()) return next();

    const token = req.headers.authorization?.split(' ')[1];
    if (!token || !req.user) return next();

    try {
        const session = await exports.validateSession(req.user.id, token);
        if (!session) {
            return res.status(401).json({ error: 'Session imeisha. Ingia tena.' });
        }
        next();
    } catch (err) {
        next();
    }
};