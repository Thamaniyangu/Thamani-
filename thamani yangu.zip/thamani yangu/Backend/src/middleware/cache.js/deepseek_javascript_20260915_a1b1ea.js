const redis = require('../config/redis');

// ============================================================
// CACHE MIDDLEWARE
// ============================================================
exports.cache = (ttl = 300) => {
    return async (req, res, next) => {
        // Skip cache for non-GET requests
        if (req.method !== 'GET') return next();
        
        // Skip if user-specific
        if (req.user?.role === 'mwenyekiti' && req.query.noCache === 'true') return next();

        const key = `cache:${req.user?.id || 'public'}:${req.originalUrl}`;

        try {
            const cached = await redis.get(key);
            if (cached) {
                res.set('X-Cache', 'HIT');
                return res.json(cached);
            }

            // Override res.json to cache response
            const originalJson = res.json.bind(res);
            res.json = (data) => {
                if (res.statusCode === 200) {
                    redis.set(key, data, ttl).catch(() => {});
                }
                return originalJson(data);
            };

            res.set('X-Cache', 'MISS');
            next();
        } catch (err) {
            next();
        }
    };
};

// ============================================================
// CLEAR CACHE (for specific patterns)
// ============================================================
exports.clearCache = async (pattern) => {
    return await redis.delPattern(pattern);
};

// ============================================================
// CACHE HELPERS
// ============================================================
exports.getOrSet = async (key, ttl, fetchFn) => {
    try {
        const cached = await redis.get(key);
        if (cached) return cached;

        const data = await fetchFn();
        if (data) await redis.set(key, data, ttl);
        return data;
    } catch (err) {
        return await fetchFn();
    }
};