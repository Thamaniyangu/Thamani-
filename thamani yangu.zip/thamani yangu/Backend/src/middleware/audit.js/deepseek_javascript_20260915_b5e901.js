const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// AUDIT LOGGER
// ============================================================
const logAudit = async ({
    userId,
    userRole,
    action,
    resourceType,
    resourceId,
    details,
    req,
    statusCode,
    durationMs
}) => {
    try {
        await mysql.query(`
            INSERT INTO audit_logs 
            (id, user_id, user_role, action, resource_type, resource_id,
             details, ip, user_agent, method, path, status_code, duration_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            uuidv4(),
            userId || null,
            userRole || null,
            action,
            resourceType || null,
            resourceId || null,
            details ? JSON.stringify(details) : null,
            req?.ip || null,
            req?.headers['user-agent'] || null,
            req?.method || null,
            req?.originalUrl || null,
            statusCode || null,
            durationMs || null
        ]);
    } catch (err) {
        console.error('Audit log error:', err);
    }
};

// ============================================================
// AUTO AUDIT MIDDLEWARE
// ============================================================
exports.auditMiddleware = (options = {}) => {
    const {
        action,
        resourceType,
        getResourceId
    } = options;

    return async (req, res, next) => {
        const startTime = Date.now();

        // Override res.json to log after response
        const originalJson = res.json.bind(res);
        res.json = async (data) => {
            const duration = Date.now() - startTime;

            const shouldLog = 
                req.method !== 'GET' || 
                (req.method === 'GET' && options.logReads);

            if (shouldLog && (!res.statusCode || res.statusCode < 400 || options.logErrors)) {
                const resourceId = getResourceId 
                    ? getResourceId(req, data) 
                    : req.params.id;

                await logAudit({
                    userId: req.user?.id,
                    userRole: req.user?.role,
                    action: action || `${req.method} ${req.baseUrl}`,
                    resourceType,
                    resourceId,
                    details: {
                        body: req.body,
                        query: req.query,
                        status: res.statusCode
                    },
                    req,
                    statusCode: res.statusCode,
                    durationMs: duration
                });
            }

            return originalJson(data);
        };

        next();
    };
};

// ============================================================
// LOG SENSITIVE ACTION
// ============================================================
exports.logSensitiveAction = async ({
    userId,
    action,
    resourceId,
    beforeState,
    afterState,
    reason,
    req
}) => {
    try {
        await mysql.query(`
            INSERT INTO sensitive_actions 
            (id, user_id, action, resource_id, before_state, after_state, reason, ip)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            uuidv4(),
            userId,
            action,
            resourceId,
            beforeState ? JSON.stringify(beforeState) : null,
            afterState ? JSON.stringify(afterState) : null,
            reason || null,
            req?.ip || null
        ]);
    } catch (err) {
        console.error('Sensitive action log error:', err);
    }
};

// ============================================================
// GET AUDIT LOGS (Mwenyekiti)
// ============================================================
exports.getAuditLogs = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { 
        page = 1, 
        limit = 50, 
        action, 
        userId, 
        resourceType, 
        from, 
        to 
    } = req.query;

    const offset = (page - 1) * limit;

    try {
        let query = `SELECT * FROM audit_logs WHERE 1=1`;
        const params = [];

        if (action) { query += ` AND action LIKE ?`; params.push(`%${action}%`); }
        if (userId) { query += ` AND user_id = ?`; params.push(userId); }
        if (resourceType) { query += ` AND resource_type = ?`; params.push(resourceType); }
        if (from) { query += ` AND created_at >= ?`; params.push(from); }
        if (to) { query += ` AND created_at <= ?`; params.push(to); }

        query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
        params.push(parseInt(limit), parseInt(offset));

        const logs = await mysql.query(query, params);
        
        // Get count
        let countQuery = `SELECT COUNT(*) as total FROM audit_logs WHERE 1=1`;
        const countParams = params.slice(0, -2);
        // (rebuild count query)

        res.json({
            data: logs.map(l => ({
                ...l,
                details: l.details ? JSON.parse(l.details) : null
            })),
            pagination: { page: parseInt(page), limit: parseInt(limit) }
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET SENSITIVE ACTIONS (Mwenyekiti)
// ============================================================
exports.getSensitiveActions = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const actions = await mysql.query(`
            SELECT sa.*, u.first_name, u.last_name, u.member_id
            FROM sensitive_actions sa
            LEFT JOIN users u ON sa.user_id = u.id
            ORDER BY sa.created_at DESC
            LIMIT 100
        `);

        res.json(actions.map(a => ({
            ...a,
            before_state: a.before_state ? JSON.parse(a.before_state) : null,
            after_state: a.after_state ? JSON.parse(a.after_state) : null
        })));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// EXPORT STATS
// ============================================================
exports.getAuditStats = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const stats = await mysql.query(`
            SELECT 
                action, 
                COUNT(*) as count,
                DATE(created_at) as date
            FROM audit_logs
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY action, DATE(created_at)
            ORDER BY date DESC
        `);

        const topUsers = await mysql.query(`
            SELECT u.first_name, u.last_name, u.member_id, COUNT(*) as actions
            FROM audit_logs al
            JOIN users u ON al.user_id = u.id
            WHERE al.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY al.user_id
            ORDER BY actions DESC
            LIMIT 10
        `);

        const topIPs = await mysql.query(`
            SELECT ip, COUNT(*) as requests
            FROM audit_logs
            WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY ip
            ORDER BY requests DESC
            LIMIT 10
        `);

        res.json({ byAction: stats, topUsers, topIPs });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};