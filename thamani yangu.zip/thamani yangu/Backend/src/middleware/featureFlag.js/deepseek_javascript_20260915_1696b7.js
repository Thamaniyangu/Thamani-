const featureFlags = require('../plugins/FeatureFlags');

exports.requireFlag = (flagKey) => {
    return async (req, res, next) => {
        const enabled = await featureFlags.get(flagKey, false);

        if (!enabled) {
            return res.status(404).json({ 
                error: 'Kipengele hiki hakijawashwa'
            });
        }
        next();
    };
};