const multer = require('multer');

// Memory storage (hatuhifadhi kwenye disk mpaka tusafishe)
const memoryStorage = multer.memoryStorage();

// ============================================================
// FILE FILTERS
// ============================================================
const imageFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Picha tu zinaruhusiwa'), false);
};

const mediaFilter = (req, file, cb) => {
    const allowed = ['image/', 'video/', 'audio/', 'application/pdf', 
                     'application/msword', 'application/vnd.openxmlformats',
                     'application/vnd.ms-excel', 'application/zip',
                     'application/x-zip-compressed'];
    if (allowed.some(type => file.mimetype.startsWith(type))) cb(null, true);
    else cb(new Error('Aina ya faili hairuhusiwi'), false);
};

// ============================================================
// UPLOADERS
// ============================================================
exports.uploadImage = multer({
    storage: memoryStorage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: imageFilter
});

exports.uploadMedia = multer({
    storage: memoryStorage,
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
    fileFilter: mediaFilter
});

exports.uploadDocument = multer({
    storage: memoryStorage,
    limits: { fileSize: 30 * 1024 * 1024 }, // 30MB
    fileFilter: mediaFilter
});