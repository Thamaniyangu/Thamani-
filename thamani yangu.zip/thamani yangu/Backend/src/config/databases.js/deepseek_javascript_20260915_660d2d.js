const mysql = require('./mysql');

// ============================================================
// UNIFIED DB (MySQL Only)
// ============================================================
class UnifiedDB {
    static async insert(table, data) {
        return await mysql.insert(table, data);
    }

    static async find(table, where = {}, limit = 100, orderBy = 'created_at DESC') {
        const keys = Object.keys(where);
        let sql = `SELECT * FROM ${table}`;
        if (keys.length) {
            sql += ` WHERE ${keys.map(k => `${k} = ?`).join(' AND ')}`;
        }
        sql += ` ORDER BY ${orderBy} LIMIT ?`;
        return await mysql.query(sql, [...Object.values(where), limit]);
    }

    static async findOne(table, where = {}) {
        const keys = Object.keys(where);
        const sql = `SELECT * FROM ${table} WHERE ${keys.map(k => `${k} = ?`).join(' AND ')} LIMIT 1`;
        return await mysql.queryOne(sql, Object.values(where));
    }

    static async update(table, data, where) {
        return await mysql.update(table, data, where);
    }

    static async delete(table, where) {
        return await mysql.delete(table, where);
    }
}

module.exports = { UnifiedDB, mysql };