const mysql = require('mysql2/promise');
require('dotenv').config();

// ============================================================
// MYSQL CONNECTION POOL (500+ users)
// ============================================================
const pool = mysql.createPool({
    host: process.env.MYSQL_HOST || 'localhost',
    port: process.env.MYSQL_PORT || 3306,
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'thamani_yangu',
    waitForConnections: true,
    connectionLimit: 50,           // 500+ users
    queueLimit: 100,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    timezone: '+03:00',
    charset: 'utf8mb4_unicode_ci'
});

// Test connection
pool.getConnection()
    .then(conn => {
        console.log('✅ MySQL connected');
        conn.release();
    })
    .catch(err => console.error('❌ MySQL error:', err));

// ============================================================
// HELPER FUNCTIONS
// ============================================================
const query = async (sql, params = []) => {
    const [rows] = await pool.execute(sql, params);
    return rows;
};

const queryOne = async (sql, params = []) => {
    const rows = await query(sql, params);
    return rows[0] || null;
};

const insert = async (table, data) => {
    const keys = Object.keys(data);
    const values = Object.values(data);
    const placeholders = keys.map(() => '?').join(', ');
    const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
    const [result] = await pool.execute(sql, values);
    return result;
};

const update = async (table, data, where) => {
    const setKeys = Object.keys(data);
    const whereKeys = Object.keys(where);
    const setClause = setKeys.map(k => `${k} = ?`).join(', ');
    const whereClause = whereKeys.map(k => `${k} = ?`).join(' AND ');
    const sql = `UPDATE ${table} SET ${setClause} WHERE ${whereClause}`;
    const values = [...Object.values(data), ...Object.values(where)];
    const [result] = await pool.execute(sql, values);
    return result;
};

const deleteRecord = async (table, where) => {
    const whereKeys = Object.keys(where);
    const whereClause = whereKeys.map(k => `${k} = ?`).join(' AND ');
    const sql = `DELETE FROM ${table} WHERE ${whereClause}`;
    const [result] = await pool.execute(sql, Object.values(where));
    return result;
};

module.exports = {
    pool,
    query,
    queryOne,
    insert,
    update,
    delete: deleteRecord
};