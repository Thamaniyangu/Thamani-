const mysql = require('mysql2/promise');
require('dotenv').config();

// ============================================================
// MASTER POOL (Writes)
// ============================================================
const masterPool = mysql.createPool({
    host: process.env.MYSQL_MASTER_HOST || 'localhost',
    port: process.env.MYSQL_MASTER_PORT || 3306,
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'thamani_yangu',
    waitForConnections: true,
    connectionLimit: 30,
    queueLimit: 100,
    enableKeepAlive: true,
    timezone: '+03:00',
    charset: 'utf8mb4_unicode_ci'
});

// ============================================================
// SLAVE POOL (Reads)
// ============================================================
const slavePools = [];
const slaveHosts = (process.env.MYSQL_SLAVE_HOSTS || '').split(',').filter(Boolean);

if (slaveHosts.length > 0) {
    slaveHosts.forEach(host => {
        slavePools.push(mysql.createPool({
            host: host.trim(),
            port: process.env.MYSQL_SLAVE_PORT || 3306,
            user: process.env.MYSQL_USER || 'root',
            password: process.env.MYSQL_PASSWORD || '',
            database: process.env.MYSQL_DATABASE || 'thamani_yangu',
            waitForConnections: true,
            connectionLimit: 20,
            queueLimit: 100,
            timezone: '+03:00'
        }));
    });
}

// ============================================================
// LOAD BALANCER (Round Robin)
// ============================================================
let currentSlaveIndex = 0;

const getSlavePool = () => {
    if (slavePools.length === 0) return masterPool;
    const pool = slavePools[currentSlaveIndex];
    currentSlaveIndex = (currentSlaveIndex + 1) % slavePools.length;
    return pool;
};

// ============================================================
// WRITE (to master)
// ============================================================
const write = async (sql, params = []) => {
    const [result] = await masterPool.execute(sql, params);
    return result;
};

// ============================================================
// READ (from slave)
// ============================================================
const read = async (sql, params = []) => {
    const pool = getSlavePool();
    const [rows] = await pool.execute(sql, params);
    return rows;
};

// ============================================================
// READ ONE
// ============================================================
const readOne = async (sql, params = []) => {
    const rows = await read(sql, params);
    return rows[0] || null;
};

// ============================================================
// HIGH-LEVEL HELPERS
// ============================================================
const insert = async (table, data) => {
    const keys = Object.keys(data);
    const values = Object.values(data);
    const placeholders = keys.map(() => '?').join(', ');
    const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
    return await write(sql, values);
};

const update = async (table, data, where) => {
    const setKeys = Object.keys(data);
    const whereKeys = Object.keys(where);
    const setClause = setKeys.map(k => `${k} = ?`).join(', ');
    const whereClause = whereKeys.map(k => `${k} = ?`).join(' AND ');
    const sql = `UPDATE ${table} SET ${setClause} WHERE ${whereClause}`;
    return await write(sql, [...Object.values(data), ...Object.values(where)]);
};

const deleteRecord = async (table, where) => {
    const whereKeys = Object.keys(where);
    const whereClause = whereKeys.map(k => `${k} = ?`).join(' AND ');
    const sql = `DELETE FROM ${table} WHERE ${whereClause}`;
    return await write(sql, Object.values(where));
};

// ============================================================
// FIND
// ============================================================
const find = async (table, where = {}, limit = 100, orderBy = 'created_at DESC') => {
    const keys = Object.keys(where);
    let sql = `SELECT * FROM ${table}`;
    if (keys.length) {
        sql += ` WHERE ${keys.map(k => `${k} = ?`).join(' AND ')}`;
    }
    sql += ` ORDER BY ${orderBy} LIMIT ?`;
    return await read(sql, [...Object.values(where), limit]);
};

// ============================================================
// HEALTH CHECK
// ============================================================
const healthCheck = async () => {
    const result = { master: 'unknown', slaves: [] };
    try {
        await masterPool.query('SELECT 1');
        result.master = 'ok';
    } catch (err) {
        result.master = 'error: ' + err.message;
    }

    for (const pool of slavePools) {
        try {
            await pool.query('SELECT 1');
            result.slaves.push('ok');
        } catch (err) {
            result.slaves.push('error');
        }
    }

    return result;
};

module.exports = {
    masterPool,
    slavePools,
    write,
    read,
    readOne,
    insert,
    update,
    delete: deleteRecord,
    find,
    healthCheck
};