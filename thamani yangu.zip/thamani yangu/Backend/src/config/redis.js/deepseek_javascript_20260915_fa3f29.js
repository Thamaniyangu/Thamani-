const redis = require('redis');

let client = null;
let isConnected = false;
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;

// ============================================================
// CONNECT TO REDIS
// ============================================================
exports.connect = async () => {
    try {
        client = redis.createClient({
            url: process.env.REDIS_URL || 'redis://localhost:6379',
            socket: {
                reconnectStrategy: (retries) => {
                    if (retries > MAX_RECONNECT) {
                        console.error('❌ Redis: Max reconnection attempts reached');
                        return new Error('Max reconnections reached');
                    }
                    reconnectAttempts = retries;
                    return Math.min(retries * 100, 3000);
                }
            },
            password: process.env.REDIS_PASSWORD || undefined
        });

        client.on('error', (err) => {
            console.error('❌ Redis error:', err.message);
            isConnected = false;
        });

        client.on('connect', () => {
            console.log('✅ Redis: Connected');
        });

        client.on('ready', () => {
            isConnected = true;
            reconnectAttempts = 0;
            console.log('✅ Redis: Ready');
        });

        client.on('end', () => {
            isConnected = false;
            console.log('❌ Redis: Disconnected');
        });

        await client.connect();
    } catch (err) {
        console.warn('⚠️ Redis not available, using in-memory cache:', err.message);
        isConnected = false;
    }
};

// ============================================================
// SET (with TTL)
// ============================================================
exports.set = async (key, value, ttl = 3600) => {
    if (!isConnected) return false;
    try {
        await client.setEx(key, ttl, JSON.stringify(value));
        return true;
    } catch (err) {
        console.error('Redis SET error:', err);
        return false;
    }
};

// ============================================================
// GET
// ============================================================
exports.get = async (key) => {
    if (!isConnected) return null;
    try {
        const data = await client.get(key);
        return data ? JSON.parse(data) : null;
    } catch (err) {
        return null;
    }
};

// ============================================================
// DELETE
// ============================================================
exports.del = async (key) => {
    if (!isConnected) return false;
    try {
        await client.del(key);
        return true;
    } catch (err) {
        return false;
    }
};

// ============================================================
// DELETE PATTERN
// ============================================================
exports.delPattern = async (pattern) => {
    if (!isConnected) return false;
    try {
        const keys = await client.keys(pattern);
        if (keys.length > 0) await client.del(keys);
        return true;
    } catch (err) {
        return false;
    }
};

// ============================================================
// INCREMENT (Rate limiting)
// ============================================================
exports.incr = async (key, ttl = 60) => {
    if (!isConnected) return 0;
    try {
        const count = await client.incr(key);
        if (count === 1) await client.expire(key, ttl);
        return count;
    } catch (err) {
        return 0;
    }
};

// ============================================================
// PUBLISH / SUBSCRIBE (for Socket.io clustering)
// ============================================================
exports.publish = async (channel, message) => {
    if (!isConnected) return false;
    try {
        await client.publish(channel, JSON.stringify(message));
        return true;
    } catch (err) {
        return false;
    }
};

exports.subscribe = async (channel, callback) => {
    if (!isConnected) return false;
    try {
        const subscriber = client.duplicate();
        await subscriber.connect();
        await subscriber.subscribe(channel, (message) => {
            try {
                callback(JSON.parse(message));
            } catch (e) {
                callback(message);
            }
        });
        return true;
    } catch (err) {
        return false;
    }
};

// ============================================================
// INFO
// ============================================================
exports.info = async () => {
    if (!isConnected) return null;
    try {
        return await client.info();
    } catch (err) {
        return null;
    }
};

exports.isConnected = () => isConnected;
exports.getClient = () => client;