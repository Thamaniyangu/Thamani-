const express = require('express');
const {
    addToWhitelist,
    addToBlacklist,
    removeFromBlacklist,
    listWhitelist,
    listBlacklist
} = require('../middleware/ipFilter');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/whitelist', authenticate, authorize(['mwenyekiti']), listWhitelist);
router.post('/whitelist', authenticate, addToWhitelist);
router.get('/blacklist', authenticate, authorize(['mwenyekiti']), listBlacklist);
router.post('/blacklist', authenticate, addToBlacklist);
router.delete('/blacklist/:ip', authenticate, authorize(['mwenyekiti']), removeFromBlacklist);

module.exports = router;