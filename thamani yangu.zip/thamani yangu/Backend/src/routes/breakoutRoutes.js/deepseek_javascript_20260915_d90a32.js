const express = require('express');
const {
    createBreakoutRoom,
    getBreakoutRooms,
    joinBreakout,
    closeBreakout,
    updateAssignments
} = require('../controllers/breakoutController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/meeting/:meetingId', authenticate, createBreakoutRoom);
router.get('/meeting/:meetingId', authenticate, getBreakoutRooms);
router.post('/:breakoutId/join', authenticate, joinBreakout);
router.post('/:breakoutId/close', authenticate, closeBreakout);
router.put('/:breakoutId/assign', authenticate, updateAssignments);

module.exports = router;