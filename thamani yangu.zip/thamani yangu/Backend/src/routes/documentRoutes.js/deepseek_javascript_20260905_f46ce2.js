const express = require('express');
const {
    createDocument,
    autoSaveDocument,
    updateDocument,
    getDocuments,
    getDocument,
    downloadDocument,
    shareDocument,
    deleteDocument,
    uploadGroupLogo,
    getGroupLogo
} = require('../controllers/documentController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);
router.use(authorize(['mwenyekiti', 'katibu', 'mhazini']));

router.post('/', createDocument);
router.put('/:documentId/autosave', autoSaveDocument);
router.put('/:documentId', updateDocument);
router.get('/', getDocuments);
router.get('/:documentId', getDocument);
router.get('/:documentId/download', downloadDocument);
router.put('/:documentId/share', shareDocument);
router.delete('/:documentId', deleteDocument);

// Logo (Mwenyekiti pekee)
router.post('/logo', authenticate, authorize(['mwenyekiti']), uploadGroupLogo);
router.get('/logo', authenticate, getGroupLogo);

module.exports = router;