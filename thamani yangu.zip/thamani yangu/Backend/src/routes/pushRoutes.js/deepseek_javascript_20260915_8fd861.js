const express = require('express');
const pushService = require('../services/pushService');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/vapid-key', (req, res) => {
    res.json({ publicKey: process.env.VAPID_PUBLIC_KEY });
});

router.post('/subscribe', authenticate, async (req, res) => {
    const { subscription, deviceInfo } = req.body;
    const success = await pushService.subscribe(req.user.id, subscription, deviceInfo);
    res.json({ success });
});

router.post('/unsubscribe', authenticate, async (req, res) => {
    const { endpoint } = req.body;
    await pushService.unsubscribe(req.user.id, endpoint);
    res.json({ success: true });
});

router.post('/send-test', authenticate, async (req, res) => {
    const count = await pushService.sendToUser(req.user.id, {
        title: 'Test Notification',
        body: 'Hii ni test notification kutoka THAMANI YANGU',
        url: '/dashboard'
    });
    res.json({ sent: count });
});

// Mwenyekiti - send to all
router.post('/broadcast', authenticate, authorize(['mwenyekiti']), async (req, res) => {
    const { title, body, url } = req.body;
    const count = await pushService.sendToAll({ title, body, url });
    res.json({ sent: count });
});

module.exports = router;