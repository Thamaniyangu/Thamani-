const express = require('express');
const {
    getAuditLogs,
    getSensitiveActions,
    getAuditStats
} = require('../middleware/audit');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/logs', authenticate, authorize(['mwenyekiti']), getAuditLogs);
router.get('/sensitive', authenticate, authorize(['mwenyekiti']), getSensitiveActions);
router.get('/stats', authenticate, authorize(['mwenyekiti']), getAuditStats);

module.exports = router;