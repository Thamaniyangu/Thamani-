const express = require('express');
const { addMembershipFee, payMembershipFee, getMembershipFees } = require('../controllers/membershipController');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.post('/', authenticate, authorize(['mwenyekiti', 'mhazini', 'katibu']), addMembershipFee);
router.put('/:id/pay', authenticate, authorize(['mwenyekiti', 'mhazini']), payMembershipFee);
router.get('/:userId?', authenticate, getMembershipFees);

module.exports = router;