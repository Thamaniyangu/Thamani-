const express = require('express');
const {
    createCall,
    getCall,
    endCall,
    getUserCalls,
    updateCallSettings
} = require('../controllers/videoController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/calls', authenticate, createCall);
router.get('/calls', authenticate, getUserCalls);
router.get('/calls/:callId', authenticate, getCall);
router.put('/calls/:callId/end', authenticate, endCall);
router.put('/calls/:callId/settings', authenticate, updateCallSettings);

module.exports = router;