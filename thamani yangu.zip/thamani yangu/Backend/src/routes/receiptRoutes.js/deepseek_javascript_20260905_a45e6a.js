const express = require('express');
const { downloadReceipt } = require('../controllers/receiptController');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

router.get('/:receiptNumber', authenticate, downloadReceipt);

module.exports = router;