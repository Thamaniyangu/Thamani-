const express = require('express');
const {
    chatWithAI,
    getAIHistory,
    clearAIHistory,
    getAIProviderStatus
} = require('../controllers/aiController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.post('/chat', authenticate, chatWithAI);
router.get('/history', authenticate, getAIHistory);
router.delete('/history', authenticate, clearAIHistory);
router.get('/providers', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), getAIProviderStatus);

module.exports = router;