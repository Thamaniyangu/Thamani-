const express = require('express');
const {
    chatWithAI,
    getAIHistory,
    clearAIHistory,
    getAIUsageStats,
    getAIProviderStatus
} = require('../controllers/aiController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Chat (watumiaji wote)
router.post('/chat', authenticate, chatWithAI);
router.get('/history', authenticate, getAIHistory);
router.delete('/history', authenticate, clearAIHistory);

// Stats (Mwenyekiti pekee)
router.get('/usage-stats', authenticate, authorize(['mwenyekiti']), getAIUsageStats);
router.get('/providers', authenticate, authorize(['mwenyekiti']), getAIProviderStatus);

module.exports = router;