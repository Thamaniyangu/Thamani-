const express = require('express');
const {
    setup2FA,
    verify2FA,
    verifyLogin2FA,
    disable2FA,
    get2FAStatus
} = require('../controllers/twoFAController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Public (login step)
router.post('/verify-login', verifyLogin2FA);

// Authenticated
router.get('/status', authenticate, get2FAStatus);
router.post('/setup', authenticate, setup2FA);
router.post('/verify', authenticate, verify2FA);
router.post('/disable', authenticate, disable2FA);

module.exports = router;