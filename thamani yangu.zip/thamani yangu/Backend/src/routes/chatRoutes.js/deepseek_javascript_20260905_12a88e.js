const express = require('express');
const { createChatroom, getUserChatrooms, sendMessage, getMessages, editMessage, deleteMessage, reportAbuse } = require('../controllers/chatController');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

router.post('/rooms', authenticate, createChatroom);
router.get('/rooms', authenticate, getUserChatrooms);
router.post('/rooms/:roomId/messages', authenticate, sendMessage);
router.get('/rooms/:roomId/messages', authenticate, getMessages);
router.put('/rooms/:roomId/messages/:messageId', authenticate, editMessage);
router.delete('/rooms/:roomId/messages/:messageId', authenticate, deleteMessage);
router.post('/rooms/:roomId/messages/:messageId/report', authenticate, reportAbuse);

module.exports = router;