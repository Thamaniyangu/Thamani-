const express = require('express');
const { downloadIdCard } = require('../controllers/idCardController');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

router.get('/:userId?', authenticate, downloadIdCard);

module.exports = router;