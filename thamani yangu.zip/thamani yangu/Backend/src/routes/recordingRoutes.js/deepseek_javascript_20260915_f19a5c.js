const express = require('express');
const multer = require('multer');
const {
    startRecording,
    uploadRecordingChunk,
    stopRecording,
    getMeetingRecordings,
    deleteRecording
} = require('../controllers/recordingController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

router.post('/start', authenticate, startRecording);
router.post('/:recordingId/chunk', authenticate, upload.single('chunk'), uploadRecordingChunk);
router.post('/:recordingId/stop', authenticate, stopRecording);
router.get('/meeting/:meetingId', authenticate, getMeetingRecordings);
router.delete('/:recordingId', authenticate, deleteRecording);

module.exports = router;