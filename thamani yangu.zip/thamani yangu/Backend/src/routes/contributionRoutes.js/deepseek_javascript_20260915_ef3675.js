const express = require('express');
const { addContributions, getContributions, getContributionStats } = require('../controllers/contributionController');
const { authenticate, authorize } = require('../middleware/auth');
const { cache } = require('../middleware/cache');

const router = express.Router();

router.post('/', authenticate, authorize(['mwenyekiti', 'mhazini']), addContributions);

// Cache kwa dakika 5
router.get('/stats', authenticate, cache(300), getContributionStats);

// Cache kwa dakika 2
router.get('/:userId?', authenticate, cache(120), getContributions);

module.exports = router;