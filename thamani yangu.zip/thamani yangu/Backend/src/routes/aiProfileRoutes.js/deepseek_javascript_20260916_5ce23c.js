const express = require('express');
const multer = require('multer');
const {
    getAIProfiles,
    getAIProfile,
    updateAIProfilePhoto,
    deleteAIProfilePhoto
} = require('../controllers/aiProfileController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Multer config (memory storage)
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Faili la picha tu'), false);
        }
    }
});

// Public routes (watumiaji wote)
router.get('/', getAIProfiles);
router.get('/:aiId', getAIProfile);

// Mwenyekiti pekee
router.post('/:aiId/photo', authenticate, authorize(['mwenyekiti']), upload.single('photo'), updateAIProfilePhoto);
router.delete('/:aiId/photo', authenticate, authorize(['mwenyekiti']), deleteAIProfilePhoto);

module.exports = router;