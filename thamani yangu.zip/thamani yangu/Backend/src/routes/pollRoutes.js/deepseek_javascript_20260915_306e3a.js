const express = require('express');
const {
    createPoll,
    votePoll,
    getPollResults,
    getMeetingPolls,
    closePoll
} = require('../controllers/pollController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/', authenticate, createPoll);
router.post('/:pollId/vote', authenticate, votePoll);
router.get('/:pollId/results', authenticate, getPollResults);
router.get('/meeting/:meetingId', authenticate, getMeetingPolls);
router.post('/:pollId/close', authenticate, closePoll);

module.exports = router;