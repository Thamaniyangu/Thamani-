const express = require('express');
const {
    createWhiteboard,
    saveStroke,
    getStrokes,
    clearWhiteboard,
    undoLastStroke
} = require('../controllers/whiteboardController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/', authenticate, createWhiteboard);
router.post('/:whiteboardId/stroke', authenticate, saveStroke);
router.get('/:whiteboardId/strokes', authenticate, getStrokes);
router.delete('/:whiteboardId/clear', authenticate, clearWhiteboard);
router.delete('/:whiteboardId/undo', authenticate, undoLastStroke);

module.exports = router;