const express = require('express');
const {
    generateMonthlySchedule,
    getSchedules,
    approveSchedule,
    updateSchedule,
    answerQuestion
} = require('../controllers/financialAdvisorController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.post('/generate', authenticate, authorize(['mwenyekiti']), generateMonthlySchedule);
router.get('/schedules', authenticate, getSchedules);
router.put('/schedules/:scheduleId/approve', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), approveSchedule);
router.put('/schedules/:scheduleId', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), updateSchedule);
router.post('/ask', authenticate, answerQuestion);

module.exports = router;