const express = require('express');
const {
    createBackup,
    listBackups,
    downloadBackup,
    restoreBackup
} = require('../controllers/backupController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);
router.use(authorize(['mwenyekiti']));

router.post('/create', createBackup);
router.get('/list', listBackups);
router.get('/download/:filename', downloadBackup);
router.post('/restore', restoreBackup);

module.exports = router;