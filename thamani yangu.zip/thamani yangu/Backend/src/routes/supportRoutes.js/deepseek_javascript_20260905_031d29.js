const express = require('express');
const { createSupportChat, sendSupportMessage, getSupportMessages, getSupportChats, assignSupportChat, unassignSupportChat, closeSupportChat } = require('../controllers/supportController');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.post('/chats', createSupportChat);
router.post('/chats/:chatId/messages/visitor', sendSupportMessage);
router.get('/chats', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), getSupportChats);
router.get('/chats/:chatId/messages', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), getSupportMessages);
router.post('/chats/:chatId/messages/leader', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), sendSupportMessage);
router.put('/chats/:chatId/assign', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), assignSupportChat);
router.put('/chats/:chatId/unassign', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), unassignSupportChat);
router.put('/chats/:chatId/close', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), closeSupportChat);

module.exports = router;