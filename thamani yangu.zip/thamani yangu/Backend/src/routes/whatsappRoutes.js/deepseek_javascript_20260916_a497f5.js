const express = require('express');
const {
    getStatus,
    start,
    logout,
    restart,
    testSend
} = require('../controllers/whatsappController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Zote ni Mwenyekiti pekee
router.get('/status', authenticate, authorize(['mwenyekiti']), getStatus);
router.post('/start', authenticate, authorize(['mwenyekiti']), start);
router.post('/logout', authenticate, authorize(['mwenyekiti']), logout);
router.post('/restart', authenticate, authorize(['mwenyekiti']), restart);
router.post('/test-send', authenticate, authorize(['mwenyekiti']), testSend);

module.exports = router;