const express = require('express');
const { generateImage, generateVideo } = require('../controllers/mediaController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/generate-image', authenticate, generateImage);
router.post('/generate-video', authenticate, generateVideo);

module.exports = router;