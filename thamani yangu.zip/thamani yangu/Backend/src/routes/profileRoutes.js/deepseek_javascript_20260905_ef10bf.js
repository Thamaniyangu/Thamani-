const express = require('express');
const { requestChange, getChangeRequests, approveChangeRequest, rejectChangeRequest, completeChange } = require('../controllers/profileController');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.post('/request', authenticate, requestChange);
router.get('/requests', authenticate, getChangeRequests);
router.post('/complete/:token', completeChange);
router.put('/requests/:requestId/approve', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), approveChangeRequest);
router.put('/requests/:requestId/reject', authenticate, authorize(['mwenyekiti', 'katibu', 'mhazini']), rejectChangeRequest);

module.exports = router;