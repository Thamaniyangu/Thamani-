const express = require('express');
const {
    collectDataset,
    startTraining,
    getTrainingStatus,
    listDatasets,
    listJobs,
    listModels,
    deployModel,
    testModel
} = require('../controllers/aiTrainingController');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);
router.use(authorize(['mwenyekiti']));

router.post('/datasets/collect', collectDataset);
router.get('/datasets', listDatasets);
router.post('/train', startTraining);
router.get('/jobs/:jobId', getTrainingStatus);
router.get('/jobs', listJobs);
router.get('/models', listModels);
router.post('/models/:modelId/deploy', deployModel);
router.post('/test', testModel);

module.exports = router;