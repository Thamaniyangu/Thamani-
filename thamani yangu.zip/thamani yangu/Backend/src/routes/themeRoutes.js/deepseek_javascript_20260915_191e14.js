const express = require('express');
const {
    getUserTheme,
    saveUserTheme,
    getAllUserThemes,
    resetUserTheme
} = require('../controllers/themeController');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticate, getAllUserThemes);
router.get('/area', authenticate, getUserTheme);
router.post('/save', authenticate, saveUserTheme);
router.delete('/:area', authenticate, resetUserTheme);

module.exports = router;