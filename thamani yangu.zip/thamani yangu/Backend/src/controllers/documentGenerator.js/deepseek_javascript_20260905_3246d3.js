const ExcelJS = require('exceljs');
const { Document, Packer, Paragraph, TextRun, AlignmentType } = require('docx');
const puppeteer = require('puppeteer');
const supabase = require('../config/supabase');

const getGroupLogo = async () => {
    const { data, error } = await supabase
        .from('settings')
        .select('value')
        .eq('key', 'group_logo')
        .single();
    if (error || !data) return null;
    return data.value?.url || null;
};

const fetchLogoBuffer = async (url) => {
    if (!url) return null;
    try {
        const response = await fetch(url);
        return Buffer.from(await response.arrayBuffer());
    } catch (e) { return null; }
};

const generateWatermarkHTML = (logoUrl) => {
    if (!logoUrl) return '';
    return `<div style="position:fixed;top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;z-index:999;pointer-events:none;opacity:0.15;transform:rotate(-30deg);"><img src="${logoUrl}" style="max-width:70%;max-height:70%;object-fit:contain;" /></div>`;
};

exports.generatePDFWithWatermark = async (title, content, type, creatorName, creatorMemberId) => {
    const logoUrl = await getGroupLogo();
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB');
    const timeStr = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const html = `<!DOCTYPE html>
    <html><head><meta charset="UTF-8"><title>${title}</title>
    <style>body{font-family:'Times New Roman',serif;margin:40px 40px 120px 40px;color:#1a1a1a;}
    .header{text-align:center;border-bottom:3px solid #D4AF37;padding-bottom:20px;margin-bottom:30px;}
    .header h1{color:#0D6B6B;font-size:28px;margin:0;}
    .header p{color:#D4AF37;font-size:14px;margin:5px 0 0;}
    .content{font-size:12px;line-height:1.6;min-height:400px;}
    table{width:100%;border-collapse:collapse;margin:15px 0;}
    th,td{border:1px solid #ccc;padding:8px;text-align:left;}
    th{background-color:#D4AF37;color:white;}
    @page{margin:40px 40px 120px 40px;}
    .footer-container{position:fixed;bottom:20px;left:0;right:0;text-align:center;border-top:1px solid #ccc;padding-top:15px;font-size:11px;color:#333;background:white;}
    </style></head><body>
    ${generateWatermarkHTML(logoUrl)}
    <div class="header"><h1>THAMANI YANGU M-KOBA</h1><p>"TUNAJENGA TABASAMU LAKO"</p><p style="font-size:12px;color:#666;">${type||'DOCUMENT'}</p></div>
    <div class="content"><h2 style="text-align:center;">${title||'Document'}</h2>${content}</div>
    <div class="footer-container">
    <p><span>Muda: ${timeStr}</span> | <span>Tarehe: ${dateStr}</span> | <span>Imeandaliwa na: ${creatorName} (${creatorMemberId})</span></p>
    <p style="font-size:14px;font-weight:bold;letter-spacing:2px;color:#0D6B6B;">IMETOLEWA NA THAMANI YANGU MANAGEMENT SYSTEM</p>
    </div></body></html>`;

    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
    try {
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });
        return await page.pdf({ format: 'A4', printBackground: true, margin: { top: '40px', bottom: '120px', left: '40px', right: '40px' } });
    } finally { await browser.close(); }
};

exports.generateExcelWithWatermark = async (data, title, creatorName, creatorMemberId) => {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'THAMANI YANGU';
    const worksheet = workbook.addWorksheet('Sheet1');
    const logoUrl = await getGroupLogo();
    if (logoUrl) {
        try {
            const imgBuffer = await fetchLogoBuffer(logoUrl);
            if (imgBuffer) {
                const imageId = workbook.addImage({ buffer: imgBuffer, extension: 'png' });
                worksheet.addImage(imageId, { tl: { col: 0, row: 0 }, ext: { width: 800, height: 600 }, editAs: 'absolute' });
            }
        } catch(e) {}
    }
    worksheet.mergeCells('A1:E1');
    const titleCell = worksheet.getCell('A1');
    titleCell.value = title || 'THAMANI YANGU';
    titleCell.font = { bold: true, size: 16, color: { argb: 'FF0D6B6B' } };
    titleCell.alignment = { horizontal: 'center' };

    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB');
    const timeStr = now.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
    worksheet.mergeCells('A2:E2');
    const metaCell = worksheet.getCell('A2');
    metaCell.value = `Muda: ${timeStr} | Tarehe: ${dateStr} | Imeandaliwa na: ${creatorName} (${creatorMemberId})`;
    metaCell.font = { size: 9, color: { argb: 'FF666666' } };
    metaCell.alignment = { horizontal: 'center' };

    if (data && data.length) {
        const headers = Object.keys(data[0]);
        const headerRow = worksheet.addRow(headers);
        headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD4AF37' } };
        data.forEach(row => worksheet.addRow(Object.values(row)));
        worksheet.columns.forEach(column => {
            let maxLen = 10;
            column.eachCell({ includeEmpty: true }, cell => {
                const v = cell.value ? cell.value.toString() : '';
                if (v.length > maxLen) maxLen = v.length;
            });
            column.width = Math.min(maxLen + 2, 50);
        });
    }

    const footerRow = worksheet.addRow([]);
    const footerCell = footerRow.getCell(1);
    footerCell.value = 'IMETOLEWA NA THAMANI YANGU MANAGEMENT SYSTEM';
    footerCell.font = { bold: true, size: 12, color: { argb: 'FF0D6B6B' } };
    footerCell.alignment = { horizontal: 'center' };
    worksheet.mergeCells(`A${footerRow.number}:E${footerRow.number}`);
    return await workbook.xlsx.writeBuffer();
};

exports.generateWordWithWatermark = async (content, title, creatorName, creatorMemberId) => {
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB');
    const timeStr = now.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', second:'2-digit' });

    const watermarkParagraph = new Paragraph({
        children: [new TextRun({ text: 'THAMANI YANGU', size: 400, color: 'EEEEEE', bold: true, font: 'Arial' })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 100, after: 100 }
    });

    const doc = new Document({
        sections: [{
            properties: { page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } } },
            children: [
                watermarkParagraph,
                new Paragraph({ children: [new TextRun({ text: title || 'THAMANI YANGU', size: 36, bold: true, color: '0D6B6B', font: 'Times New Roman' })], alignment: AlignmentType.CENTER, spacing: { after: 400 } }),
                new Paragraph({ children: [new TextRun({ text: `Muda: ${timeStr} | Tarehe: ${dateStr} | Imeandaliwa na: ${creatorName} (${creatorMemberId})`, size: 20, color: '666666', font: 'Times New Roman' })], alignment: AlignmentType.RIGHT, spacing: { after: 400 } }),
                new Paragraph({ children: [new TextRun({ text: content || '', size: 24, font: 'Times New Roman' })], spacing: { after: 200 } }),
                new Paragraph({ children: [new TextRun({ text: 'IMETOLEWA NA THAMANI YANGU MANAGEMENT SYSTEM', size: 28, bold: true, color: '0D6B6B', font: 'Times New Roman' })], alignment: AlignmentType.CENTER, spacing: { before: 400, after: 100 } })
            ]
        }]
    });
    return await Packer.toBuffer(doc);
};