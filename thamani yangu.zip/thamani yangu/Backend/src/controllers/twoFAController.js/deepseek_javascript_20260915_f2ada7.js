const mysql = require('../config/mysql');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const { sendEmail } = require('../utils/email');

// ============================================================
// SETUP 2FA (Generate Secret + QR)
// ============================================================
exports.setup2FA = async (req, res) => {
    const userId = req.user.id;

    try {
        const user = await mysql.queryOne(
            `SELECT email, first_name FROM users WHERE id = ?`,
            [userId]
        );

        // Generate secret
        const secret = speakeasy.generateSecret({
            name: `THAMANI YANGU (${user.email})`,
            issuer: 'THAMANI YANGU',
            length: 20
        });

        // Save (temporarily disabled)
        await mysql.query(`
            INSERT INTO user_2fa (user_id, secret, enabled)
            VALUES (?, ?, FALSE)
            ON DUPLICATE KEY UPDATE secret = VALUES(secret), enabled = FALSE, verified_at = NULL
        `, [userId, secret.base32]);

        // Generate QR code
        const qrCode = await QRCode.toDataURL(secret.otpauth_url);

        res.json({
            secret: secret.base32,
            qrCode,
            manualEntry: secret.base32
        });
    } catch (err) {
        console.error('Setup 2FA error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// VERIFY & ENABLE 2FA
// ============================================================
exports.verify2FA = async (req, res) => {
    const { code } = req.body;
    const userId = req.user.id;

    if (!code || code.length !== 6) {
        return res.status(400).json({ error: 'Msimbo wa tarakimu 6 unahitajika' });
    }

    try {
        const twoFA = await mysql.queryOne(
            `SELECT * FROM user_2fa WHERE user_id = ?`,
            [userId]
        );

        if (!twoFA) {
            return res.status(404).json({ error: '2FA haijawekwa bado' });
        }

        // Verify code
        const verified = speakeasy.totp.verify({
            secret: twoFA.secret,
            encoding: 'base32',
            token: code,
            window: 2
        });

        if (!verified) {
            // Log failed attempt
            await mysql.query(`
                INSERT INTO 2fa_attempts (id, user_id, code, ip, success)
                VALUES (?, ?, ?, ?, FALSE)
            `, [uuidv4(), userId, code, req.ip]);

            return res.status(401).json({ error: 'Msimbo si sahihi' });
        }

        // Generate backup codes (10)
        const backupCodes = [];
        for (let i = 0; i < 10; i++) {
            backupCodes.push(crypto.randomBytes(4).toString('hex').toUpperCase());
        }

        // Hash backup codes
        const hashedBackupCodes = await Promise.all(
            backupCodes.map(code => bcrypt.hash(code, 10))
        );

        // Update
        await mysql.query(`
            UPDATE user_2fa 
            SET enabled = TRUE, 
                backup_codes = ?, 
                verified_at = NOW()
            WHERE user_id = ?
        `, [JSON.stringify(hashedBackupCodes), userId]);

        // Log success
        await mysql.query(`
            INSERT INTO 2fa_attempts (id, user_id, code, ip, success)
            VALUES (?, ?, ?, ?, TRUE)
        `, [uuidv4(), userId, code, req.ip]);

        // Send backup codes email
        const user = await mysql.queryOne(
            `SELECT email FROM users WHERE id = ?`, [userId]
        );

        await sendEmail({
            to: user.email,
            subject: '2FA Imewashwa - THAMANI YANGU',
            html: `
                <h2>2FA imewashwa!</h2>
                <p>Hizi ni backup codes zako (hifadhi mahali salama):</p>
                <ul>${backupCodes.map(c => `<li><strong>${c}</strong></li>`).join('')}</ul>
                <p>Kila code inatumika mara moja.</p>
            `
        });

        res.json({
            message: '2FA imewashwa!',
            backupCodes
        });
    } catch (err) {
        console.error('Verify 2FA error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// VERIFY 2FA CODE ON LOGIN
// ============================================================
exports.verifyLogin2FA = async (req, res) => {
    const { userId, code } = req.body;

    if (!userId || !code) {
        return res.status(400).json({ error: 'userId na code zinahitajika' });
    }

    try {
        const twoFA = await mysql.queryOne(
            `SELECT * FROM user_2fa WHERE user_id = ? AND enabled = TRUE`,
            [userId]
        );

        if (!twoFA) {
            return res.status(400).json({ error: '2FA haijawashwa' });
        }

        // Try TOTP
        const verified = speakeasy.totp.verify({
            secret: twoFA.secret,
            encoding: 'base32',
            token: code,
            window: 2
        });

        let backupUsed = false;

        if (!verified) {
            // Try backup code
            const backupCodes = JSON.parse(twoFA.backup_codes || '[]');
            for (let i = 0; i < backupCodes.length; i++) {
                const match = await bcrypt.compare(code.toUpperCase(), backupCodes[i]);
                if (match) {
                    // Remove used code
                    backupCodes.splice(i, 1);
                    await mysql.query(
                        `UPDATE user_2fa SET backup_codes = ? WHERE user_id = ?`,
                        [JSON.stringify(backupCodes), userId]
                    );
                    backupUsed = true;
                    break;
                }
            }
        }

        if (!verified && !backupUsed) {
            await mysql.query(`
                INSERT INTO 2fa_attempts (id, user_id, code, ip, success)
                VALUES (?, ?, ?, ?, FALSE)
            `, [uuidv4(), userId, code, req.ip]);

            return res.status(401).json({ error: 'Msimbo si sahihi' });
        }

        // Log success
        await mysql.query(`
            INSERT INTO 2fa_attempts (id, user_id, code, ip, success)
            VALUES (?, ?, ?, ?, TRUE)
        `, [uuidv4(), userId, code, req.ip]);

        // Generate JWT
        const { generateToken } = require('../utils/jwt');
        const user = await mysql.queryOne(
            `SELECT * FROM users WHERE id = ?`, [userId]
        );

        const token = generateToken({ ...user, mfaVerified: true });

        res.json({
            token,
            user: {
                id: user.id,
                member_id: user.member_id,
                role: user.role,
                first_name: user.first_name,
                email: user.email
            },
            backupUsed
        });
    } catch (err) {
        console.error('Verify login 2FA error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DISABLE 2FA
// ============================================================
exports.disable2FA = async (req, res) => {
    const { password } = req.body;
    const userId = req.user.id;

    try {
        const user = await mysql.queryOne(
            `SELECT password_hash FROM users WHERE id = ?`, [userId]
        );

        const valid = await bcrypt.compare(password, user.password_hash);
        if (!valid) return res.status(401).json({ error: 'Password si sahihi' });

        await mysql.query(`UPDATE user_2fa SET enabled = FALSE WHERE user_id = ?`, [userId]);

        res.json({ message: '2FA imezimwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET 2FA STATUS
// ============================================================
exports.get2FAStatus = async (req, res) => {
    try {
        const twoFA = await mysql.queryOne(
            `SELECT enabled, verified_at FROM user_2fa WHERE user_id = ?`,
            [req.user.id]
        );

        res.json({
            enabled: twoFA?.enabled || false,
            verifiedAt: twoFA?.verified_at || null
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};