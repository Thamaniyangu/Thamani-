const mysql = require('../config/mysql');
const axios = require('axios');

// ============================================================
// ANALYZE MEDIA
// ============================================================
exports.analyzeMedia = async (req, res) => {
    const { mediaType, prompt } = req.body;
    const userId = req.user.id;
    const file = req.file;

    if (!file) return res.status(400).json({ error: 'Faili linahitajika' });
    if (!prompt) return res.status(400).json({ error: 'Prompt inahitajika' });

    try {
        let analysis = null;
        let provider = null;

        if (mediaType === 'image' && process.env.GEMINI_API_KEY) {
            const base64 = file.buffer.toString('base64');
            const response = await axios.post(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
                {
                    contents: [{
                        parts: [
                            { text: prompt },
                            { inline_data: { mime_type: file.mimetype, data: base64 } }
                        ]
                    }]
                },
                { headers: { 'Content-Type': 'application/json' }, timeout: 60000 }
            );
            analysis = response.data.candidates[0].content.parts[0].text;
            provider = 'Gemini Vision';
        } else if (mediaType === 'document') {
            // Document analysis
            let text = '';
            if (file.mimetype.includes('pdf')) {
                const pdfParse = require('pdf-parse');
                text = (await pdfParse(file.buffer)).text;
            } else if (file.mimetype.includes('word')) {
                const mammoth = require('mammoth');
                text = (await mammoth.extractRawText({ buffer: file.buffer })).value;
            } else if (file.mimetype.includes('sheet')) {
                const XLSX = require('xlsx');
                const wb = XLSX.read(file.buffer, { type: 'buffer' });
                text = wb.SheetNames.map(s => XLSX.utils.sheet_to_csv(wb.Sheets[s])).join('\n');
            }
            
            const { callAIWithFallback } = require('../utils/aiOrchestrator');
            const result = await callAIWithFallback(
                `Nyaraka: ${text.substring(0, 5000)}\n\nOmbi: ${prompt}`,
                []
            );
            analysis = result.response;
            provider = result.provider;
        } else {
            analysis = 'Aina ya media haijulikani';
        }

        // Log
        await mysql.query(
            `INSERT INTO media_analysis_logs 
             (id, user_id, media_type, prompt, provider, file_name, file_size, status)
             VALUES (UUID(), ?, ?, ?, ?, ?, ?, 'success')`,
            [userId, mediaType, prompt, provider, file.originalname, file.size]
        );

        res.json({ success: true, provider, analysis });
    } catch (err) {
        console.error('Analyze media error:', err);
        res.status(500).json({ error: err.message });
    }
};