const mysql = require('../config/mysql');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const aiTraining = require('../services/aiTrainingService');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// COLLECT DATASET
// ============================================================
exports.collectDataset = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const data = await aiTraining.collectTrainingData(req.body);
        
        if (data.length < 50) {
            return res.status(400).json({ 
                error: `Data haitoshi (${data.length} samples). Unahitaji 50+` 
            });
        }

        const result = await aiTraining.saveTrainingDataset(data, req.body.name);
        
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// START TRAINING
// ============================================================
exports.startTraining = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { datasetId, epochs = 3, baseModel = 'llama3.1:8b' } = req.body;

    try {
        const dataset = await mysql.queryOne(`
            SELECT * FROM ai_training_datasets WHERE id = ?
        `, [datasetId]);

        if (!dataset) return res.status(404).json({ error: 'Dataset haipatikani' });

        const jobId = uuidv4();
        const modelName = `thamani-ai-v${Date.now()}`;

        await mysql.query(`
            INSERT INTO ai_training_jobs 
            (id, dataset_id, model_name, base_model, hyperparameters, status, created_by)
            VALUES (?, ?, ?, ?, ?, 'pending', ?)
        `, [
            jobId,
            datasetId,
            modelName,
            baseModel,
            JSON.stringify({ epochs, batchSize: 4, learningRate: 2e-4 }),
            req.user.id
        ]);

        // Start training in background
        const scriptPath = path.join(__dirname, '../../ai-training/train.py');
        const command = `cd ${path.dirname(scriptPath)} && DATASET_PATH="${dataset.path}" BASE_MODEL="${baseModel}" EPOCHS=${epochs} OUTPUT_DIR="./models/${modelName}" python3 ${scriptPath}`;

        const child = exec(command, { maxBuffer: 10 * 1024 * 1024 });

        child.stdout.on('data', async (data) => {
            const output = data.toString();
            console.log('[Training]', output);

            // Update progress
            const match = output.match(/step (\d+)\/(\d+)/);
            if (match) {
                const progress = Math.round((parseInt(match[1]) / parseInt(match[2])) * 100);
                await mysql.query(`
                    UPDATE ai_training_jobs SET progress = ?, status = 'training' WHERE id = ?
                `, [progress, jobId]);
            }
        });

        child.on('close', async (code) => {
            if (code === 0) {
                // Training successful
                await mysql.query(`
                    UPDATE ai_training_jobs 
                    SET status = 'completed', progress = 100, completed_at = NOW()
                    WHERE id = ?
                `, [jobId]);

                // Register model version
                const modelPath = path.join(__dirname, `../../ai-training/models/${modelName}`);
                const size = getDirSize(modelPath);

                await mysql.query(`
                    INSERT INTO ai_model_versions 
                    (id, job_id, version, model_path, size_mb, deployed)
                    VALUES (UUID(), ?, ?, ?, ?, FALSE)
                `, [jobId, modelName, modelPath, Math.round(size / 1024 / 1024)]);
            } else {
                await mysql.query(`
                    UPDATE ai_training_jobs 
                    SET status = 'failed', error_message = ?
                    WHERE id = ?
                `, [`Exit code: ${code}`, jobId]);
            }
        });

        res.json({
            message: 'Mafunzo yameanza',
            jobId,
            modelName
        });
    } catch (err) {
        console.error('Training error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET TRAINING STATUS
// ============================================================
exports.getTrainingStatus = async (req, res) => {
    try {
        const { jobId } = req.params;
        
        const job = await mysql.queryOne(`
            SELECT j.*, d.name as dataset_name
            FROM ai_training_jobs j
            LEFT JOIN ai_training_datasets d ON j.dataset_id = d.id
            WHERE j.id = ?
        `, [jobId]);

        if (!job) return res.status(404).json({ error: 'Job haipatikani' });

        res.json({
            ...job,
            hyperparameters: job.hyperparameters ? JSON.parse(job.hyperparameters) : null
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// LIST DATASETS & JOBS
// ============================================================
exports.listDatasets = async (req, res) => {
    const datasets = await mysql.query(`
        SELECT * FROM ai_training_datasets ORDER BY created_at DESC
    `);
    res.json(datasets);
};

exports.listJobs = async (req, res) => {
    const jobs = await mysql.query(`
        SELECT * FROM ai_training_jobs ORDER BY created_at DESC LIMIT 50
    `);
    res.json(jobs);
};

exports.listModels = async (req, res) => {
    const models = await mysql.query(`
        SELECT * FROM ai_model_versions ORDER BY created_at DESC
    `);
    res.json(models);
};

// ============================================================
// DEPLOY MODEL
// ============================================================
exports.deployModel = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { modelId } = req.params;

    try {
        const model = await mysql.queryOne(`
            SELECT * FROM ai_model_versions WHERE id = ?
        `, [modelId]);

        if (!model) return res.status(404).json({ error: 'Model haipatikani' });

        // Convert to Ollama format
        const ollamaPath = path.join(__dirname, '../../ai-training/models/ollama');
        if (!fs.existsSync(ollamaPath)) fs.mkdirSync(ollamaPath, { recursive: true });

        const modelfilePath = path.join(ollamaPath, `${model.version}.Modelfile`);
        fs.writeFileSync(modelfilePath, `
FROM ${model.model_path}
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER top_k 40

SYSTEM """
Wewe ni THAMANI AI BUDDY, msaidizi wa kikundi cha THAMANI YANGU M-KOBA.
Unajibu kwa Kiswahili sanifu, kwa heshima, na kwa ufupi.
"""
        `);

        // Create Ollama model
        await new Promise((resolve, reject) => {
            exec(`ollama create ${model.version} -f ${modelfilePath}`, (err) => {
                if (err) reject(err);
                else resolve();
            });
        });

        // Mark previous as not deployed
        await mysql.query(`
            UPDATE ai_model_versions SET deployed = FALSE WHERE deployed = TRUE
        `);

        // Deploy new model
        await mysql.query(`
            UPDATE ai_model_versions 
            SET deployed = TRUE, deployed_at = NOW()
            WHERE id = ?
        `, [modelId]);

        // Update AI provider to use new model
        await mysql.query(`
            UPDATE settings SET value = ? WHERE \`key\` = 'ollama_model'
        `, [JSON.stringify({ model: model.version })]);

        res.json({
            message: 'Model imepelekwa',
            model: model.version
        });
    } catch (err) {
        console.error('Deploy error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// TEST MODEL
// ============================================================
exports.testModel = async (req, res) => {
    const { modelVersion, prompt } = req.body;

    try {
        const axios = require('axios');
        const ollamaUrl = process.env.OLLAMA_URL || 'http://localhost:11434';

        const response = await axios.post(`${ollamaUrl}/api/chat`, {
            model: modelVersion,
            messages: [{ role: 'user', content: prompt }],
            stream: false
        });

        res.json({
            model: modelVersion,
            prompt,
            response: response.data.message.content
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// HELPERS
// ============================================================
const getDirSize = (dirPath) => {
    let size = 0;
    if (!fs.existsSync(dirPath)) return 0;
    
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);
        const stats = fs.statSync(filePath);
        if (stats.isDirectory()) {
            size += getDirSize(filePath);
        } else {
            size += stats.size;
        }
    }
    return size;
};