const mysql = require('../config/mysql');
const { generateIdCardPDF } = require('../utils/pdfGenerator');
const { uploadToStorage } = require('../utils/localStorage');

// ============================================================
// DOWNLOAD ID CARD
// ============================================================
exports.downloadIdCard = async (req, res) => {
    const { userId } = req.params;
    const targetId = userId || req.user.id;

    // Permission check
    if (req.user.role === 'mwanachama' && targetId !== req.user.id) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        const user = await mysql.queryOne(
            `SELECT * FROM users WHERE id = ?`,
            [targetId]
        );

        if (!user) return res.status(404).json({ error: 'Mwanachama hapatikani' });

        const pdfBuffer = await generateIdCardPDF({
            memberId: user.member_id,
            firstName: user.first_name,
            middleName: user.middle_name,
            lastName: user.last_name,
            phone: user.phone,
            role: user.role,
            address: `${user.region || ''} ${user.district || ''} ${user.ward_street || ''}`.trim() || '......',
            emergencyName1: user.emergency_contact_name1,
            emergencyName2: user.emergency_contact_name2,
            emergencyPhone: user.emergency_phone,
            emergencyRelation: user.emergency_relationship,
            emergencyAddress: `${user.emergency_region || ''} ${user.emergency_district || ''} ${user.emergency_ward_street || ''}`.trim() || '......'
        });

        const filename = `ID-${user.member_id}-${Date.now()}.pdf`;
        const pdfUrl = await uploadToStorage(pdfBuffer, 'id-cards', filename);

        res.redirect(pdfUrl);
    } catch (err) {
        console.error('Download ID card error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DOWNLOAD ALL ID CARDS (Leaders only - as single PDF)
// ============================================================
exports.downloadAllIdCards = async (req, res) => {
    if (req.user.role === 'mwanachama') {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        const users = await mysql.query(`SELECT * FROM users WHERE status = 'active'`);

        if (!users.length) {
            return res.status(404).json({ error: 'Hakuna wanachama' });
        }

        const { PDFDocument } = require('pdf-lib');
        const mergedPdf = await PDFDocument.create();

        for (const user of users) {
            const cardBuffer = await generateIdCardPDF({
                memberId: user.member_id,
                firstName: user.first_name,
                middleName: user.middle_name,
                lastName: user.last_name,
                phone: user.phone,
                role: user.role,
                address: `${user.region || ''} ${user.district || ''} ${user.ward_street || ''}`.trim() || '......',
                emergencyName1: user.emergency_contact_name1,
                emergencyName2: user.emergency_contact_name2,
                emergencyPhone: user.emergency_phone,
                emergencyRelation: user.emergency_relationship,
                emergencyAddress: `${user.emergency_region || ''} ${user.emergency_district || ''} ${user.emergency_ward_street || ''}`.trim() || '......'
            });

            const cardPdf = await PDFDocument.load(cardBuffer);
            const pages = await mergedPdf.copyPages(cardPdf, cardPdf.getPageIndices());
            pages.forEach(page => mergedPdf.addPage(page));
        }

        const mergedBuffer = await mergedPdf.save();
        const filename = `all-id-cards-${Date.now()}.pdf`;
        const pdfUrl = await uploadToStorage(mergedBuffer, 'id-cards', filename);

        res.redirect(pdfUrl);
    } catch (err) {
        console.error('Download all ID cards error:', err);
        res.status(500).json({ error: err.message });
    }
};