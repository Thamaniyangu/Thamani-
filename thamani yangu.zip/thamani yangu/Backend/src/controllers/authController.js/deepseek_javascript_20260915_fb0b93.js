const mysql = require('../config/mysql');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const { generateToken } = require('../utils/jwt');
const { sendEmail } = require('../utils/email');
const { sendSignUpLinkWhatsApp } = require('../utils/whatsapp');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// LEADER CREDENTIALS
// ============================================================
const LEADER_CREDENTIALS = {
    'mwenyekiti.thamaniyangu@gmail.com': { password: 'ThamaniM@1234', role: 'mwenyekiti' },
    'katibu.thamaniyangu@gmail.com': { password: 'Thamani@1234K', role: 'katibu' },
    'mhazini.thamaniyangu@gmail.com': { password: 'Thamani@M1234', role: 'mhazini' }
};

// ============================================================
// GENERATE GLOBAL SEQUENTIAL MEMBER ID
// ============================================================
const generateMemberId = async () => {
    const currentYear = new Date().getFullYear();

    // Pata namba kubwa zaidi ya mwaka huu
    const result = await mysql.queryOne(
        `SELECT member_id FROM users 
         WHERE member_id LIKE ? 
         ORDER BY CAST(SUBSTRING_INDEX(member_id, '-', -1) AS UNSIGNED) DESC 
         LIMIT 1`,
        [`TYM-${currentYear}-%`]
    );

    let nextNumber = 1;
    if (result) {
        const lastNumber = parseInt(result.member_id.split('-')[2]);
        if (!isNaN(lastNumber)) nextNumber = lastNumber + 1;
    }

    const paddedNumber = nextNumber < 1000
        ? String(nextNumber).padStart(3, '0')
        : String(nextNumber);

    return `TYM-${currentYear}-${paddedNumber}`;
};

// ============================================================
// GET CURRENT YEAR PREFIX
// ============================================================
exports.getCurrentYearPrefix = async (req, res) => {
    const year = new Date().getFullYear();
    res.json({ prefix: `TYM-${year}-` });
};

// ============================================================
// LOGIN
// ============================================================
exports.login = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Check if leader email
        if (username.includes('@')) {
            const leader = LEADER_CREDENTIALS[username];
            if (!leader || password !== leader.password) {
                return res.status(401).json({ error: 'Email au password sahihi' });
            }

            let user = await mysql.queryOne(
                `SELECT * FROM users WHERE email = ?`,
                [username]
            );

            if (!user) {
                // Create leader account
                const hashed = await bcrypt.hash(password, 10);
                const memberId = await generateMemberId();
                const id = uuidv4();

                await mysql.query(
                    `INSERT INTO users (id, email, member_id, password_hash, role, first_name, status)
                     VALUES (?, ?, ?, ?, ?, ?, 'active')`,
                    [id, username, memberId, hashed, leader.role,
                     leader.role.charAt(0).toUpperCase() + leader.role.slice(1)]
                );

                user = await mysql.queryOne(`SELECT * FROM users WHERE id = ?`, [id]);
            }

            const token = generateToken(user);
            return res.json({
                token,
                user: {
                    id: user.id,
                    member_id: user.member_id,
                    role: user.role,
                    first_name: user.first_name,
                    email: user.email
                }
            });
        }

        // Member login
        const user = await mysql.queryOne(
            `SELECT * FROM users WHERE member_id = ?`,
            [username]
        );

        if (!user) return res.status(401).json({ error: 'Member ID au password sahihi' });

        const match = await bcrypt.compare(password, user.password_hash);
        if (!match) return res.status(401).json({ error: 'Member ID au password sahihi' });

        const token = generateToken(user);
        res.json({
            token,
            user: {
                id: user.id,
                member_id: user.member_id,
                role: user.role,
                first_name: user.first_name,
                email: user.email,
                phone: user.phone
            }
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// REGISTER MEMBER (Leader initiates)
// ============================================================
exports.registerMember = async (req, res) => {
    const { email, whatsapp_number } = req.body;

    try {
        const existing = await mysql.queryOne(
            `SELECT id FROM users WHERE email = ?`,
            [email]
        );
        if (existing) return res.status(400).json({ error: 'Email tayari imesajiliwa' });

        const memberId = await generateMemberId();
        const token = crypto.randomBytes(32).toString('hex');
        const expires = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);

        await mysql.query(
            `INSERT INTO signup_tokens (id, token, email, member_id, whatsapp_number, expires_at)
             VALUES (UUID(), ?, ?, ?, ?, ?)`,
            [token, email, memberId, whatsapp_number || null, expires]
        );

        const signupLink = `${process.env.FRONTEND_URL}/signup?token=${token}`;

        await sendEmail({
            to: email,
            subject: 'Usajili THAMANI YANGU',
            html: `
                <h2>Karibu THAMANI YANGU!</h2>
                <p>Bonyeza link kukamilisha usajili:</p>
                <p><a href="${signupLink}">Sajili Sasa</a></p>
                <p><strong>Member ID: ${memberId}</strong></p>
                <p>Link inaisha baada ya siku 5.</p>
            `
        });

        if (whatsapp_number) {
            try {
                await sendSignUpLinkWhatsApp({
                    to: whatsapp_number,
                    link: signupLink,
                    name: 'Mwanachama'
                });
            } catch (e) { console.error('WhatsApp error:', e); }
        }

        res.json({ message: 'Link imetumwa', memberId });
    } catch (err) {
        console.error('Register error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SIGNUP (Member completes)
// ============================================================
exports.signup = async (req, res) => {
    const { token } = req.params;
    const {
        first_name, middle_name, last_name, phone, whatsapp_number,
        region, district, ward_street,
        emergency_contact_name1, emergency_contact_name2,
        emergency_relationship, emergency_phone,
        emergency_region, emergency_district, emergency_ward_street,
        profile_photo_url
    } = req.body;

    try {
        const tokenData = await mysql.queryOne(
            `SELECT * FROM signup_tokens 
             WHERE token = ? AND used = FALSE AND expires_at > NOW()`,
            [token]
        );

        if (!tokenData) {
            return res.status(400).json({ error: 'Token batili au imeisha muda' });
        }

        const existing = await mysql.queryOne(
            `SELECT id FROM users WHERE email = ?`,
            [tokenData.email]
        );
        if (existing) return res.status(400).json({ error: 'Email tayari imesajiliwa' });

        const defaultPass = `Thamani@${tokenData.member_id.slice(-3)}`;
        const hashed = await bcrypt.hash(defaultPass, 10);
        const userId = uuidv4();

        await mysql.query(
            `INSERT INTO users (
                id, member_id, email, first_name, middle_name, last_name, phone,
                whatsapp_number, region, district, ward_street,
                emergency_contact_name1, emergency_contact_name2, emergency_relationship,
                emergency_phone, emergency_region, emergency_district, emergency_ward_street,
                profile_photo_url, password_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                userId, tokenData.member_id, tokenData.email,
                first_name, middle_name, last_name, phone,
                whatsapp_number || tokenData.whatsapp_number, region, district, ward_street,
                emergency_contact_name1, emergency_contact_name2, emergency_relationship,
                emergency_phone, emergency_region, emergency_district, emergency_ward_street,
                profile_photo_url, hashed
            ]
        );

        await mysql.query(
            `UPDATE signup_tokens SET used = TRUE WHERE token = ?`,
            [token]
        );

        await sendEmail({
            to: tokenData.email,
            subject: 'Karibu THAMANI YANGU!',
            html: `
                <h2>Usajili umekamilika!</h2>
                <p>Member ID: <strong>${tokenData.member_id}</strong></p>
                <p>Password: <strong>${defaultPass}</strong></p>
                <p>Badili password baada ya kuingia.</p>
            `
        });

        res.json({
            message: 'Usajili umefanikiwa!',
            member_id: tokenData.member_id,
            defaultPassword: defaultPass
        });
    } catch (err) {
        console.error('Signup error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// RESEND SIGNUP LINK
// ============================================================
exports.resendSignupLink = async (req, res) => {
    const { email } = req.body;

    try {
        const existing = await mysql.queryOne(
            `SELECT id FROM users WHERE email = ?`, [email]
        );
        if (existing) return res.status(400).json({ error: 'Email tayari imesajiliwa' });

        let tokenData = await mysql.queryOne(
            `SELECT * FROM signup_tokens 
             WHERE email = ? AND used = FALSE AND expires_at > NOW()
             ORDER BY created_at DESC LIMIT 1`,
            [email]
        );

        let token, expires;
        if (tokenData) {
            token = tokenData.token;
            expires = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);
            await mysql.query(
                `UPDATE signup_tokens SET expires_at = ? WHERE id = ?`,
                [expires, tokenData.id]
            );
        } else {
            token = crypto.randomBytes(32).toString('hex');
            expires = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);
            const memberId = await generateMemberId();
            await mysql.query(
                `INSERT INTO signup_tokens (id, token, email, member_id, expires_at)
                 VALUES (UUID(), ?, ?, ?, ?)`,
                [token, email, memberId, expires]
            );
        }

        const signupLink = `${process.env.FRONTEND_URL}/signup?token=${token}`;

        await sendEmail({
            to: email,
            subject: 'Usajili THAMANI YANGU (Toleo Jipya)',
            html: `
                <h2>Link mpya ya usajili</h2>
                <p><a href="${signupLink}">Sajili Sasa</a></p>
                <p>Inaisha baada ya siku 5.</p>
            `
        });

        res.json({ message: 'Link imetumwa tena' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};