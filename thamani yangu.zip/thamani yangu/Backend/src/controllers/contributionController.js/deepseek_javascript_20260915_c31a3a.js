const mysql = require('../config/mysql');
const { generateReceiptPDF } = require('../utils/pdfGenerator');
const { uploadToStorage } = require('../utils/localStorage');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// ADD CONTRIBUTIONS (Multi-row)
// ============================================================
exports.addContributions = async (req, res) => {
    const { contributions } = req.body;
    const recordedBy = req.user.id;

    try {
        const inserted = [];

        for (const item of contributions) {
            const receiptNum = `RCT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 1000)}`;
            const contribId = uuidv4();

            // Insert contribution
            await mysql.query(
                `INSERT INTO contributions 
                 (id, user_id, type, amount, recorded_by, receipt_number)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [contribId, item.userId, item.type, item.amount, recordedBy, receiptNum]
            );

            // Get user details
            const userData = await mysql.queryOne(
                `SELECT first_name, last_name, member_id FROM users WHERE id = ?`,
                [item.userId]
            );

            if (!userData) continue;

            // Generate receipt PDF
            const pdfBuffer = await generateReceiptPDF({
                receiptNumber: receiptNum,
                memberName: `${userData.first_name} ${userData.last_name}`,
                memberId: userData.member_id,
                type: item.type,
                amount: item.amount,
                date: new Date().toLocaleDateString('en-GB'),
                time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
            });

            // Upload to local storage
            const pdfUrl = await uploadToStorage(
                pdfBuffer,
                'receipts',
                `${receiptNum}.pdf`
            );

            // Update receipt_url
            await mysql.query(
                `UPDATE contributions SET receipt_url = ? WHERE id = ?`,
                [pdfUrl, contribId]
            );

            inserted.push({
                id: contribId,
                user_id: item.userId,
                type: item.type,
                amount: item.amount,
                receipt_number: receiptNum,
                receipt_url: pdfUrl
            });
        }

        res.json({ message: 'Michango imehifadhiwa', receipts: inserted });
    } catch (err) {
        console.error('Add contributions error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET CONTRIBUTIONS
// ============================================================
exports.getContributions = async (req, res) => {
    const { userId } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    try {
        let query = `
            SELECT c.*, u.first_name, u.last_name, u.member_id
            FROM contributions c
            JOIN users u ON c.user_id = u.id
        `;
        let countQuery = `SELECT COUNT(*) as total FROM contributions c`;
        const params = [];

        if (req.user.role === 'mwanachama') {
            query += ` WHERE c.user_id = ?`;
            countQuery += ` WHERE c.user_id = ?`;
            params.push(req.user.id);
        } else if (userId) {
            query += ` WHERE c.user_id = ?`;
            countQuery += ` WHERE c.user_id = ?`;
            params.push(userId);
        }

        query += ` ORDER BY c.created_at DESC LIMIT ? OFFSET ?`;

        const contributions = await mysql.query(query, [...params, parseInt(limit), parseInt(offset)]);
        const totalResult = await mysql.queryOne(countQuery, params);

        res.json({
            data: contributions,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: totalResult.total,
                pages: Math.ceil(totalResult.total / limit)
            }
        });
    } catch (err) {
        console.error('Get contributions error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET CONTRIBUTION STATS
// ============================================================
exports.getContributionStats = async (req, res) => {
    try {
        const stats = await mysql.query(`
            SELECT 
                type,
                COUNT(*) as count,
                SUM(amount) as total
            FROM contributions
            GROUP BY type
        `);

        const totals = await mysql.queryOne(`
            SELECT 
                COUNT(*) as total_count,
                SUM(amount) as total_amount
            FROM contributions
        `);

        res.json({
            byType: stats,
            totals
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};