const mysql = require('../config/mysql');
const { sendEmail } = require('../utils/email');
const { uploadToStorage } = require('../utils/localStorage');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE SUPPORT CHAT
// ============================================================
exports.createSupportChat = async (req, res) => {
    const { visitor_name, visitor_email, visitor_phone } = req.body;

    if (!visitor_name) return res.status(400).json({ error: 'Jina linahitajika' });

    try {
        const id = uuidv4();

        await mysql.query(
            `INSERT INTO support_chats 
             (id, visitor_name, visitor_email, visitor_phone, status)
             VALUES (?, ?, ?, ?, 'active')`,
            [id, visitor_name, visitor_email || null, visitor_phone || null]
        );

        // Notify leaders
        const leaders = await mysql.query(
            `SELECT id, email, first_name FROM users WHERE role IN ('mwenyekiti', 'katibu', 'mhazini')`
        );

        for (const leader of leaders) {
            if (global.io) {
                global.io.to(`user-${leader.id}`).emit('new-support-chat', {
                    chatId: id,
                    visitorName: visitor_name
                });
            }

            try {
                await sendEmail({
                    to: leader.email,
                    subject: `Msaada mpya kutoka ${visitor_name}`,
                    html: `<h2>Msaada Mpya!</h2><p>${visitor_name} anahitaji msaada.</p>`
                });
            } catch (e) { /* ignore */ }
        }

        if (global.io) global.io.emit('new-support-chat', { chatId: id, visitorName: visitor_name });

        res.status(201).json({ id, visitor_name, status: 'active' });
    } catch (err) {
        console.error('Create support chat error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SEND SUPPORT MESSAGE
// ============================================================
exports.sendSupportMessage = async (req, res) => {
    const { chatId } = req.params;
    const { text, type, file_base64, file_name } = req.body;
    const userId = req.user?.id;
    const senderType = userId ? 'leader' : 'visitor';

    try {
        const chat = await mysql.queryOne(
            `SELECT status, visitor_name FROM support_chats WHERE id = ?`,
            [chatId]
        );

        if (!chat) return res.status(404).json({ error: 'Chat haipatikani' });
        if (chat.status === 'closed') return res.status(400).json({ error: 'Chat imefungwa' });

        let fileUrl = null;

        if (file_base64) {
            const buffer = Buffer.from(file_base64, 'base64');
            const filename = `support-${chatId}-${Date.now()}-${file_name || 'file'}`;
            fileUrl = await uploadToStorage(buffer, 'support', filename);
        }

        let senderName = chat.visitor_name;
        if (userId) {
            const user = await mysql.queryOne(
                `SELECT first_name, last_name FROM users WHERE id = ?`, [userId]
            );
            if (user) senderName = `${user.first_name} ${user.last_name}`;
        }

        const id = uuidv4();
        const messageType = fileUrl ? (type || 'image') : (type || 'text');

        await mysql.query(
            `INSERT INTO support_messages 
             (id, chat_id, sender_type, sender_id, sender_name, text, type, file_url)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, chatId, senderType, userId || null, senderName, text || '', messageType, fileUrl]
        );

        const newMessage = {
            id, chat_id: chatId, sender_type: senderType,
            sender_id: userId || null, sender_name: senderName,
            text: text || '', type: messageType, file_url: fileUrl,
            created_at: new Date().toISOString()
        };

        if (global.io) {
            global.io.to(`support-${chatId}`).emit('new-support-message', newMessage);
            global.io.emit('support-message-notification', {
                chatId,
                visitorName: chat.visitor_name,
                message: text || 'Media'
            });
        }

        res.status(201).json(newMessage);
    } catch (err) {
        console.error('Send support message error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET SUPPORT MESSAGES
// ============================================================
exports.getSupportMessages = async (req, res) => {
    const { chatId } = req.params;

    try {
        const messages = await mysql.query(
            `SELECT * FROM support_messages WHERE chat_id = ? ORDER BY created_at ASC`,
            [chatId]
        );
        res.json(messages);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL SUPPORT CHATS (Leaders only)
// ============================================================
exports.getSupportChats = async (req, res) => {
    const userId = req.user.id;

    try {
        const user = await mysql.queryOne(
            `SELECT role FROM users WHERE id = ?`, [userId]
        );

        if (!['mwenyekiti', 'katibu', 'mhazini'].includes(user.role)) {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        const cutoff = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000);

        const chats = await mysql.query(`
            SELECT * FROM support_chats
            WHERE status = 'active' 
               OR (status = 'closed' AND closed_at > ?)
            ORDER BY created_at DESC
        `, [cutoff]);

        res.json(chats);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// ASSIGN SUPPORT CHAT
// ============================================================
exports.assignSupportChat = async (req, res) => {
    const { chatId } = req.params;
    const { leaderId } = req.body;
    const userId = req.user.id;

    try {
        await mysql.query(
            `UPDATE support_chats 
             SET assigned_to = ?, assigned_at = NOW(), assigned_by = ?, status = 'assigned'
             WHERE id = ?`,
            [leaderId, userId, chatId]
        );
        res.json({ message: 'Imeteuliwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLOSE SUPPORT CHAT
// ============================================================
exports.closeSupportChat = async (req, res) => {
    const { chatId } = req.params;

    try {
        await mysql.query(
            `UPDATE support_chats 
             SET status = 'closed', closed_at = NOW()
             WHERE id = ?`,
            [chatId]
        );
        res.json({ message: 'Chat imefungwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE EXPIRED CHATS (Cron)
// ============================================================
exports.deleteExpiredChats = async () => {
    try {
        const expired = await mysql.query(
            `SELECT id FROM support_chats WHERE scheduled_delete_at < NOW()`
        );

        for (const chat of expired) {
            await mysql.query(`DELETE FROM support_messages WHERE chat_id = ?`, [chat.id]);
            await mysql.query(`DELETE FROM support_chats WHERE id = ?`, [chat.id]);
        }

        if (expired.length > 0) {
            console.log(`🗑️ Deleted ${expired.length} expired support chats`);
        }
    } catch (err) {
        console.error('Delete expired error:', err);
    }
};