const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE BREAKOUT ROOM
// ============================================================
exports.createBreakoutRoom = async (req, res) => {
    const { meetingId } = req.params;
    const { name, maxParticipants, assignedUsers } = req.body;
    const userId = req.user.id;

    try {
        // Verify user is host
        const meeting = await mysql.queryOne(
            `SELECT host_id FROM video_calls WHERE id = ?`,
            [meetingId]
        );

        if (!meeting || meeting.host_id !== userId) {
            return res.status(403).json({ error: 'Ni host pekee' });
        }

        const id = uuidv4();
        const roomId = `breakout-${id.slice(0, 8)}`;

        await mysql.query(
            `INSERT INTO breakout_rooms 
             (id, meeting_id, name, room_id, max_participants, assigned_users, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [id, meetingId, name, roomId, maxParticipants || 10,
             JSON.stringify(assignedUsers || []), userId]
        );

        // Create assignments
        if (assignedUsers && assignedUsers.length > 0) {
            for (const uid of assignedUsers) {
                await mysql.query(
                    `INSERT INTO breakout_assignments (id, breakout_id, user_id)
                     VALUES (?, ?, ?)`,
                    [uuidv4(), id, uid]
                );

                if (global.io) {
                    global.io.to(`user-${uid}`).emit('breakout-invite', {
                        breakoutId: id,
                        roomId,
                        name,
                        meetingId
                    });
                }
            }
        }

        res.json({ id, roomId, name, message: 'Breakout room imeundwa' });
    } catch (err) {
        console.error('Create breakout error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET BREAKOUT ROOMS
// ============================================================
exports.getBreakoutRooms = async (req, res) => {
    const { meetingId } = req.params;

    try {
        const rooms = await mysql.query(
            `SELECT br.*, u.first_name, u.last_name
             FROM breakout_rooms br
             LEFT JOIN users u ON br.created_by = u.id
             WHERE br.meeting_id = ? AND br.status = 'active'
             ORDER BY br.created_at DESC`,
            [meetingId]
        );

        res.json(rooms.map(r => ({
            ...r,
            assigned_users: JSON.parse(r.assigned_users || '[]')
        })));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// JOIN BREAKOUT
// ============================================================
exports.joinBreakout = async (req, res) => {
    const { breakoutId } = req.params;
    const userId = req.user.id;

    try {
        const breakout = await mysql.queryOne(
            `SELECT * FROM breakout_rooms WHERE id = ? AND status = 'active'`,
            [breakoutId]
        );

        if (!breakout) return res.status(404).json({ error: 'Breakout haipatikani' });

        const assignments = JSON.parse(breakout.assigned_users || '[]');
        
        if (!assignments.includes(userId)) {
            return res.status(403).json({ error: 'Hujateuliwa kwenye breakout hii' });
        }

        await mysql.query(
            `UPDATE breakout_assignments 
             SET joined_at = NOW() 
             WHERE breakout_id = ? AND user_id = ? AND joined_at IS NULL`,
            [breakoutId, userId]
        );

        res.json({ 
            roomId: breakout.room_id,
            name: breakout.name
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLOSE BREAKOUT
// ============================================================
exports.closeBreakout = async (req, res) => {
    const { breakoutId } = req.params;
    const userId = req.user.id;

    try {
        const breakout = await mysql.queryOne(
            `SELECT * FROM breakout_rooms WHERE id = ?`,
            [breakoutId]
        );

        if (!breakout) return res.status(404).json({ error: 'Haipatikani' });
        if (breakout.created_by !== userId && req.user.role !== 'mwenyekiti') {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        await mysql.update('breakout_rooms', {
            status: 'closed',
            closed_at: new Date()
        }, { id: breakoutId });

        // Notify
        const assignments = JSON.parse(breakout.assigned_users || '[]');
        if (global.io) {
            assignments.forEach(uid => {
                global.io.to(`user-${uid}`).emit('breakout-closed', { breakoutId });
            });
        }

        res.json({ message: 'Breakout imefungwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPDATE ASSIGNMENTS
// ============================================================
exports.updateAssignments = async (req, res) => {
    const { breakoutId } = req.params;
    const { assignedUsers } = req.body;
    const userId = req.user.id;

    try {
        const breakout = await mysql.queryOne(
            `SELECT * FROM breakout_rooms WHERE id = ?`,
            [breakoutId]
        );

        if (!breakout || breakout.created_by !== userId) {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        await mysql.update('breakout_rooms', {
            assigned_users: JSON.stringify(assignedUsers)
        }, { id: breakoutId });

        res.json({ message: 'Assignments zimehifadhiwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};