const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// 1. CREATE CALL
// ============================================================
exports.createCall = async (req, res) => {
    const { type, participants, host_id, title } = req.body;
    const userId = req.user.id;

    try {
        const id = uuidv4();
        const callData = {
            type: type || 'private',
            participants: participants ? [userId, ...participants] : [userId],
            host_id: host_id || userId,
            status: 'initiated',
            title: title || 'Mkutano wa Video'
        };

        await mysql.query(
            `INSERT INTO video_calls (id, type, participants, host_id, status, title, started_at)
             VALUES (?, ?, ?, ?, 'initiated', ?, NOW())`,
            [id, callData.type, JSON.stringify(callData.participants), callData.host_id, callData.title]
        );

        // Notify participants
        const allParticipants = callData.participants;
        allParticipants.forEach(pid => {
            if (pid !== userId && global.io) {
                global.io.to(`user-${pid}`).emit('incoming-call', {
                    callId: id,
                    from: userId,
                    fromName: `${req.user.first_name} ${req.user.last_name}`,
                    title: callData.title
                });
            }
        });

        res.status(201).json({
            id,
            ...callData,
            participants: callData.participants
        });
    } catch (err) {
        console.error('Create call error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 2. GET CALL
// ============================================================
exports.getCall = async (req, res) => {
    const { callId } = req.params;

    try {
        const call = await mysql.queryOne(
            `SELECT * FROM video_calls WHERE id = ?`, [callId]
        );

        if (!call) return res.status(404).json({ error: 'Mkutano haupatikani' });

        res.json({
            ...call,
            participants: call.participants ? JSON.parse(call.participants) : []
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 3. END CALL
// ============================================================
exports.endCall = async (req, res) => {
    const { callId } = req.params;

    try {
        await mysql.update('video_calls', {
            status: 'ended',
            ended_at: new Date()
        }, { id: callId });

        // Notify all participants
        const call = await mysql.queryOne(
            `SELECT participants FROM video_calls WHERE id = ?`, [callId]
        );

        if (call && global.io) {
            const participants = JSON.parse(call.participants || '[]');
            participants.forEach(pid => {
                global.io.to(`user-${pid}`).emit('call-ended', { callId });
            });
        }

        res.json({ message: 'Mkutano umefungwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 4. GET USER CALLS
// ============================================================
exports.getUserCalls = async (req, res) => {
    const userId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    try {
        const calls = await mysql.query(
            `SELECT * FROM video_calls 
             WHERE JSON_CONTAINS(participants, ?)
             ORDER BY created_at DESC
             LIMIT ? OFFSET ?`,
            [JSON.stringify(userId), parseInt(limit), parseInt(offset)]
        );

        res.json(calls.map(c => ({
            ...c,
            participants: c.participants ? JSON.parse(c.participants) : []
        })));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 5. UPDATE CALL SETTINGS (Host only)
// ============================================================
exports.updateCallSettings = async (req, res) => {
    const { callId } = req.params;
    const { settings } = req.body;
    const userId = req.user.id;

    try {
        const call = await mysql.queryOne(
            `SELECT host_id FROM video_calls WHERE id = ?`, [callId]
        );

        if (!call) return res.status(404).json({ error: 'Mkutano haupatikani' });
        if (call.host_id !== userId) return res.status(403).json({ error: 'Huna ruhusa' });

        await mysql.update('video_calls', {
            settings: JSON.stringify(settings)
        }, { id: callId });

        if (global.io) {
            global.io.to(`call-${callId}`).emit('settings-updated', settings);
        }

        res.json({ message: 'Mipangilio imehifadhiwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};