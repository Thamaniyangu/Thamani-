const mysql = require('../config/mysql');
const axios = require('axios');

// ============================================================
// IMAGE GENERATION (NO STORAGE - Preview only)
// ============================================================
exports.generateImage = async (req, res) => {
    const { prompt } = req.body;
    const userId = req.user.id;

    if (!prompt) return res.status(400).json({ error: 'Prompt inahitajika' });

    try {
        let imageBuffer = null;
        let provider = null;

        // Provider 1: Pollinations AI (Bure)
        try {
            const encodedPrompt = encodeURIComponent(prompt);
            const response = await axios.get(
                `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&nologo=true`,
                { responseType: 'arraybuffer', timeout: 60000 }
            );
            imageBuffer = Buffer.from(response.data);
            provider = 'Pollinations AI';
        } catch (err) {
            console.warn('Pollinations failed');
        }

        // Provider 2: Hugging Face
        if (!imageBuffer && process.env.HUGGINGFACE_API_KEY) {
            try {
                const response = await axios.post(
                    'https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0',
                    { inputs: prompt },
                    {
                        headers: { 'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}` },
                        responseType: 'arraybuffer',
                        timeout: 60000
                    }
                );
                imageBuffer = Buffer.from(response.data);
                provider = 'Hugging Face';
            } catch (err) {}
        }

        if (!imageBuffer) {
            return res.status(503).json({ error: 'Hakuna huduma ya picha' });
        }

        // Log (metadata pekee)
        await mysql.query(
            `INSERT INTO media_generation_logs (id, user_id, media_type, prompt, provider, status)
             VALUES (UUID(), ?, 'image', ?, ?, 'success')`,
            [userId, prompt, provider]
        );

        // Return as base64 (preview only)
        const base64Image = imageBuffer.toString('base64');

        res.json({
            success: true,
            provider,
            image: `data:image/png;base64,${base64Image}`,
            prompt,
            note: 'Picha ni preview pekee',
            filename: `thamani-image-${Date.now()}.png`
        });
    } catch (err) {
        await mysql.query(
            `INSERT INTO media_generation_logs (id, user_id, media_type, prompt, status, error_message)
             VALUES (UUID(), ?, 'image', ?, 'failed', ?)`,
            [userId, prompt, err.message]
        );
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// VIDEO GENERATION
// ============================================================
exports.generateVideo = async (req, res) => {
    const { prompt } = req.body;
    const userId = req.user.id;

    if (!prompt) return res.status(400).json({ error: 'Prompt inahitajika' });

    try {
        // Placeholder - video generation kwa kutumia services mbalimbali
        res.status(503).json({ 
            error: 'Video generation haipatikani kwa sasa. Tafadhali jaribu baadaye.',
            note: 'Tunafanya kazi kwenye hili'
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};