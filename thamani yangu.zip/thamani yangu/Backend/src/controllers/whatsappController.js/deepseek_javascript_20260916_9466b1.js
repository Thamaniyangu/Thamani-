const whatsappService = require('../services/whatsappService');

// ============================================================
// 1. GET STATUS (Mwenyekiti pekee)
// ============================================================
exports.getStatus = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const status = whatsappService.getStatus();
        res.json(status);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 2. START / ANZISHA (Mwenyekiti pekee)
// ============================================================
exports.start = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await whatsappService.startWhatsApp();
        res.json({ message: 'WhatsApp inaanzisha...', status: whatsappService.getStatus() });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 3. LOGOUT (Mwenyekiti pekee)
// ============================================================
exports.logout = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await whatsappService.logoutWhatsApp();
        res.json({ message: 'WhatsApp imetolewa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 4. RESTART (Mwenyekiti pekee)
// ============================================================
exports.restart = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await whatsappService.restartWhatsApp();
        res.json({ message: 'WhatsApp inaanzisha upya...' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// 5. TEST SEND (Mwenyekiti pekee)
// ============================================================
exports.testSend = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { phone, message } = req.body;

    if (!phone || !message) {
        return res.status(400).json({ error: 'Namba na ujumbe vinahitajika' });
    }

    try {
        const result = await whatsappService.sendWhatsAppMessage(phone, message);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};