const backup = require('../utils/backup');

// ============================================================
// CREATE BACKUP (Mwenyekiti only)
// ============================================================
exports.createBackup = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const result = await backup.createBackup();
        res.json({
            message: 'Backup imeundwa',
            ...result
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// LIST BACKUPS
// ============================================================
exports.listBackups = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const backups = backup.listBackups();
        res.json(backups);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DOWNLOAD BACKUP
// ============================================================
exports.downloadBackup = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { filename } = req.params;
    const filepath = require('path').join(__dirname, '../../backups', filename);

    if (!require('fs').existsSync(filepath)) {
        return res.status(404).json({ error: 'Backup haipatikani' });
    }

    res.download(filepath, filename);
};

// ============================================================
// RESTORE BACKUP
// ============================================================
exports.restoreBackup = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    const { filename } = req.body;

    if (!filename) return res.status(400).json({ error: 'Filename inahitajika' });

    try {
        const result = await backup.restoreBackup(filename);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};