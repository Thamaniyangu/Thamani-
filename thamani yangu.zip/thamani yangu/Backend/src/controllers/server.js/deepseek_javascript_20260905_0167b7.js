require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const { PeerServer } = require('peer');
const { syncDatabases } = require('./sync');

const authRoutes = require('./routes/authRoutes');
const contributionRoutes = require('./routes/contributionRoutes');
const membershipRoutes = require('./routes/membershipRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const idCardRoutes = require('./routes/idCardRoutes');
const chatRoutes = require('./routes/chatRoutes');
const videoRoutes = require('./routes/videoRoutes');
const supportRoutes = require('./routes/supportRoutes');
const profileRoutes = require('./routes/profileRoutes');
const documentRoutes = require('./routes/documentRoutes');
const aiRoutes = require('./routes/aiRoutes');

const socketHandler = require('./socket');
const supportController = require('./controllers/supportController');
const chatCleanupController = require('./controllers/chatCleanupController');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "http://localhost:3000", methods: ["GET", "POST"] }
});
global.io = io;
socketHandler(io);

PeerServer({ port: 9000, path: '/peerjs' });
console.log('✅ PeerJS running on port 9000');

app.use(cors());
app.use(express.json({ limit: '100mb' }));

app.use('/api/auth', authRoutes);
app.use('/api/contributions', contributionRoutes);
app.use('/api/membership-fees', membershipRoutes);
app.use('/api/receipts', receiptRoutes);
app.use('/api/id-card', idCardRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/video', videoRoutes);
app.use('/api/support', supportRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/ai', aiRoutes);

// Auto-delete jobs
setInterval(async () => { await supportController.deleteExpiredChats(); }, 60 * 60 * 1000);
supportController.deleteExpiredChats();

setInterval(async () => { await chatCleanupController.deleteOldChatMedia(); }, 24 * 60 * 60 * 1000);
chatCleanupController.deleteOldChatMedia();

// Run sync on startup
syncDatabases();

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Hybrid Server running on port ${PORT}`));