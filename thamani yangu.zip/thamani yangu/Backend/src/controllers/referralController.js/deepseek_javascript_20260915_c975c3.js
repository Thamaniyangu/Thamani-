const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// GET REFERRAL LINK
// ============================================================
exports.getReferralLink = async (req, res) => {
    const userId = req.user.id;

    try {
        let referral = await mysql.queryOne(
            `SELECT code FROM referrals WHERE user_id = ?`, [userId]
        );

        if (!referral) {
            const code = `REF-${userId.slice(0, 8)}-${Date.now().toString(36)}`;
            await mysql.query(
                `INSERT INTO referrals (id, user_id, code) VALUES (?, ?, ?)`,
                [uuidv4(), userId, code]
            );
            referral = { code };
        }

        const link = `${process.env.FRONTEND_URL}/join?ref=${referral.code}`;
        res.json({ referralLink: link });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};