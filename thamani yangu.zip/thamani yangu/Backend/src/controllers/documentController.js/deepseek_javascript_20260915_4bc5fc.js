const mysql = require('../config/mysql');
const { generatePDFWithWatermark, generateExcelWithWatermark, generateWordWithWatermark } = require('../utils/documentGenerator');
const { sendEmail } = require('../utils/email');
const { deleteFromStorage } = require('../utils/localStorage');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE DOCUMENT
// ============================================================
exports.createDocument = async (req, res) => {
    const { title, content, type, document_name, metadata } = req.body;
    const userId = req.user.id;

    if (!title || !type || !['excel', 'word'].includes(type)) {
        return res.status(400).json({ error: 'Title na type inahitajika' });
    }

    try {
        const user = await mysql.queryOne(
            `SELECT first_name, last_name, member_id FROM users WHERE id = ?`,
            [userId]
        );

        const id = uuidv4();
        const docMetadata = metadata || {};
        docMetadata.created_by_name = `${user.first_name} ${user.last_name}`;
        docMetadata.created_by_member_id = user.member_id;

        await mysql.query(
            `INSERT INTO documents 
             (id, title, document_name, content, type, created_by, status, metadata, share_with)
             VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?)`,
            [
                id, title, document_name || title, content || '',
                type, userId, JSON.stringify(docMetadata), JSON.stringify([])
            ]
        );

        const doc = await mysql.queryOne(`SELECT * FROM documents WHERE id = ?`, [id]);

        res.status(201).json({
            ...doc,
            metadata: JSON.parse(doc.metadata || '{}'),
            share_with: JSON.parse(doc.share_with || '[]')
        });
    } catch (err) {
        console.error('Create document error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// AUTO-SAVE DOCUMENT
// ============================================================
exports.autoSaveDocument = async (req, res) => {
    const { documentId } = req.params;
    const { content, title, document_name, metadata } = req.body;
    const userId = req.user.id;

    try {
        const doc = await mysql.queryOne(
            `SELECT created_by FROM documents WHERE id = ?`,
            [documentId]
        );

        if (!doc) return res.status(404).json({ error: 'Hati haipatikani' });
        if (doc.created_by !== userId) return res.status(403).json({ error: 'Huna ruhusa' });

        const updates = {
            content,
            last_auto_save_at: new Date(),
            status: 'draft'
        };
        if (title) updates.title = title;
        if (document_name) updates.document_name = document_name;
        if (metadata) updates.metadata = JSON.stringify(metadata);

        await mysql.update('documents', updates, { id: documentId });

        res.json({ message: 'Auto-save successful' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL DOCUMENTS
// ============================================================
exports.getDocuments = async (req, res) => {
    const { type, status } = req.query;

    try {
        let query = `
            SELECT d.*, u.first_name, u.last_name, u.member_id
            FROM documents d
            LEFT JOIN users u ON d.created_by = u.id
            WHERE 1=1
        `;
        const params = [];

        if (type) { query += ` AND d.type = ?`; params.push(type); }
        if (status) { query += ` AND d.status = ?`; params.push(status); }

        query += ` ORDER BY d.created_at DESC`;

        const docs = await mysql.query(query, params);

        res.json(docs.map(d => ({
            ...d,
            metadata: d.metadata ? JSON.parse(d.metadata) : {},
            share_with: d.share_with ? JSON.parse(d.share_with) : [],
            created_by_user: {
                first_name: d.first_name,
                last_name: d.last_name,
                member_id: d.member_id
            }
        })));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DOWNLOAD DOCUMENT
// ============================================================
exports.downloadDocument = async (req, res) => {
    const { documentId } = req.params;
    const { format } = req.query;
    const userId = req.user.id;

    try {
        const doc = await mysql.queryOne(
            `SELECT d.*, u.first_name, u.last_name, u.member_id
             FROM documents d
             LEFT JOIN users u ON d.created_by = u.id
             WHERE d.id = ?`,
            [documentId]
        );

        if (!doc) return res.status(404).json({ error: 'Hati haipatikani' });
        if (doc.created_by !== userId && !['mwenyekiti', 'katibu', 'mhazini'].includes(req.user.role)) {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        const creatorName = `${doc.first_name} ${doc.last_name}`;
        const creatorMemberId = doc.member_id;
        const targetFormat = format || doc.type;

        let buffer, contentType, filename;

        if (targetFormat === 'excel') {
            let data = [];
            try { data = JSON.parse(doc.content); } catch (e) {}
            buffer = await generateExcelWithWatermark(data, doc.title, creatorName, creatorMemberId);
            contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            filename = `${doc.document_name || doc.title}.xlsx`;
        } else if (targetFormat === 'word') {
            buffer = await generateWordWithWatermark(doc.content || '', doc.title, creatorName, creatorMemberId);
            contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            filename = `${doc.document_name || doc.title}.docx`;
        } else if (targetFormat === 'pdf') {
            let content = doc.content || '';
            try {
                const data = JSON.parse(content);
                if (Array.isArray(data) && data.length) {
                    let tableHTML = '<table style="width:100%;border-collapse:collapse;">';
                    const headers = Object.keys(data[0]);
                    tableHTML += '<thead><tr style="background:#D4AF37;color:white;">' +
                        headers.map(h => `<th style="padding:8px;">${h}</th>`).join('') +
                        '</tr></thead><tbody>';
                    data.forEach(row => {
                        tableHTML += '<tr>' + headers.map(h => 
                            `<td style="padding:8px;border:1px solid #ccc;">${row[h] || ''}</td>`
                        ).join('') + '</tr>';
                    });
                    tableHTML += '</tbody></table>';
                    content = tableHTML;
                }
            } catch (e) {}
            buffer = await generatePDFWithWatermark(doc.title, content, doc.type.toUpperCase(), creatorName, creatorMemberId);
            contentType = 'application/pdf';
            filename = `${doc.document_name || doc.title}.pdf`;
        } else {
            return res.status(400).json({ error: 'Format isiyotambulika' });
        }

        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(buffer);
    } catch (err) {
        console.error('Download document error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SHARE DOCUMENT
// ============================================================
exports.shareDocument = async (req, res) => {
    const { documentId } = req.params;
    const { share_with } = req.body;
    const userId = req.user.id;

    try {
        const doc = await mysql.queryOne(`SELECT * FROM documents WHERE id = ?`, [documentId]);
        if (!doc) return res.status(404).json({ error: 'Hati haipatikani' });
        if (doc.created_by !== userId) return res.status(403).json({ error: 'Huna ruhusa' });

        await mysql.update('documents', {
            share_with: JSON.stringify(share_with)
        }, { id: documentId });

        // Notify shared users
        const users = await mysql.query(
            `SELECT id, email, first_name, last_name FROM users WHERE id IN (?)`,
            [share_with]
        );

        const sender = await mysql.queryOne(
            `SELECT first_name, last_name FROM users WHERE id = ?`, [userId]
        );

        for (const user of users) {
            try {
                await sendEmail({
                    to: user.email,
                    subject: `Hati imeshirikiwa: ${doc.title}`,
                    html: `
                        <h2>Hati imeshirikiwa na wewe</h2>
                        <p><strong>${doc.title}</strong></p>
                        <p>Imeshirikiwa na ${sender.first_name} ${sender.last_name}</p>
                    `
                });
            } catch (e) {}
        }

        res.json({ message: 'Hati imeshirikiwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE DOCUMENT
// ============================================================
exports.deleteDocument = async (req, res) => {
    const { documentId } = req.params;
    const userId = req.user.id;

    try {
        const doc = await mysql.queryOne(
            `SELECT created_by FROM documents WHERE id = ?`, [documentId]
        );
        if (!doc) return res.status(404).json({ error: 'Hati haipatikani' });
        if (doc.created_by !== userId) return res.status(403).json({ error: 'Huna ruhusa' });

        await mysql.delete('documents', { id: documentId });
        res.json({ message: 'Hati imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPLOAD GROUP LOGO (Mwenyekiti only)
// ============================================================
exports.uploadGroupLogo = async (req, res) => {
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    if (!req.file) return res.status(400).json({ error: 'Hakuna picha' });

    try {
        const sharp = require('sharp');
        const optimized = await sharp(req.file.buffer)
            .resize(400, 400, { fit: 'inside', withoutEnlargement: true })
            .png({ quality: 90 })
            .toBuffer();

        const { uploadToStorage } = require('../utils/localStorage');
        const filename = `logo-${Date.now()}.png`;
        const logoUrl = await uploadToStorage(optimized, 'group-logo', filename);

        await mysql.query(
            `INSERT INTO settings (\`key\`, value) VALUES ('group_logo', ?)
             ON DUPLICATE KEY UPDATE value = VALUES(value)`,
            [JSON.stringify({ url: logoUrl, updated_by: req.user.id, updated_at: new Date() })]
        );

        res.json({ message: 'Logo imewekwa', url: logoUrl });
    } catch (err) {
        console.error('Upload logo error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET GROUP LOGO
// ============================================================
exports.getGroupLogo = async (req, res) => {
    try {
        const setting = await mysql.queryOne(
            `SELECT value FROM settings WHERE \`key\` = 'group_logo'`
        );

        if (!setting) return res.json({ url: null });
        const value = JSON.parse(setting.value || '{}');
        res.json({ url: value.url || null });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};