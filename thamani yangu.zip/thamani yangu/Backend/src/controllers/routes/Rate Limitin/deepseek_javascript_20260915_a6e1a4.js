// backend/src/middleware/rateLimiter.js
const rateLimit = require('express-rate-limit');

exports.apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { error: 'Maombi mengi. Jaribu tena baada ya dakika 15.' }
});

exports.authLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 10,
    message: { error: 'Majaribio mengi. Jaribu baada ya saa moja.' }
});

exports.aiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 20,
    message: { error: 'Maombi mengi kwa AI. Subiri sekunde 60.' }
});