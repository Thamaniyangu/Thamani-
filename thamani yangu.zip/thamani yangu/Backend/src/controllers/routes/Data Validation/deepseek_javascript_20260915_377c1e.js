// backend/src/middleware/validate.js
const { body, validationResult } = require('express-validator');

exports.validate = (rules) => async (req, res, next) => {
    await Promise.all(rules.map(rule => rule.run(req)));
    const errors = validationResult(req);
    if (errors.isEmpty()) return next();
    res.status(400).json({ errors: errors.array() });
};

exports.rules = {
    contribution: [
        body('contributions').isArray({ min: 1 }),
        body('contributions.*.userId').isUUID(),
        body('contributions.*.type').isIn(['hisa', 'jamii', 'faini', 'marejesho']),
        body('contributions.*.amount').isFloat({ min: 0.01 })
    ]
};