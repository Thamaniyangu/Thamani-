const express = require('express');
const { chatWithAI } = require('../controllers/aiController');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
router.post('/chat', authenticate, chatWithAI);
module.exports = router;