// backend/src/utils/logger.js
const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '../../logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

exports.info = (message, meta = {}) => {
    const log = `[INFO] ${new Date().toISOString()} ${message} ${JSON.stringify(meta)}\n`;
    console.log(log.trim());
    fs.appendFileSync(path.join(LOG_DIR, 'app.log'), log);
};

exports.error = (message, error = {}) => {
    const log = `[ERROR] ${new Date().toISOString()} ${message} ${error.message || JSON.stringify(error)}\n`;
    console.error(log.trim());
    fs.appendFileSync(path.join(LOG_DIR, 'error.log'), log);
};