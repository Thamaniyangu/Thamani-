// backend/src/utils/paginate.js
exports.paginate = (page = 1, limit = 20) => {
    const p = Math.max(1, parseInt(page) || 1);
    const l = Math.min(100, Math.max(1, parseInt(limit) || 20));
    return {
        limit: l,
        offset: (p - 1) * l,
        page: p
    };
};