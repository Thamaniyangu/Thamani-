// backend/src/routes/healthRoutes.js
const mysql = require('../config/mysql');
const redis = require('../utils/redis');

exports.healthCheck = async (req, res) => {
    const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        services: {
            mysql: 'unknown',
            redis: 'unknown',
            whatsapp: 'unknown'
        }
    };

    try {
        await mysql.query('SELECT 1');
        health.services.mysql = 'ok';
    } catch (e) { health.services.mysql = 'error'; health.status = 'degraded'; }

    health.services.redis = redis.isConnected() ? 'ok' : 'disabled';

    try {
        const wpp = require('../services/whatsappService');
        health.services.whatsapp = wpp.isConnected() ? 'ok' : 'disconnected';
    } catch (e) { health.services.whatsapp = 'error'; }

    res.status(health.status === 'healthy' ? 200 : 503).json(health);
};