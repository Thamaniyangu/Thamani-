const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE POLL
// ============================================================
exports.createPoll = async (req, res) => {
    const { meetingId, roomId, question, options, allowMultiple, isAnonymous, durationMinutes } = req.body;
    const userId = req.user.id;

    if (!question || !options || options.length < 2) {
        return res.status(400).json({ error: 'Swali na chaguo 2+ zinahitajika' });
    }

    try {
        const id = uuidv4();
        const endsAt = durationMinutes
            ? new Date(Date.now() + durationMinutes * 60 * 1000)
            : null;

        await mysql.query(
            `INSERT INTO meeting_polls 
             (id, meeting_id, room_id, question, options, allow_multiple, is_anonymous, ends_at, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, meetingId || null, roomId || null, question, JSON.stringify(options),
             allowMultiple || false, isAnonymous !== false, endsAt, userId]
        );

        const poll = {
            id,
            meeting_id: meetingId,
            room_id: roomId,
            question,
            options,
            allow_multiple: allowMultiple,
            is_anonymous: isAnonymous !== false,
            status: 'active',
            ends_at: endsAt,
            votes: options.map(() => 0),
            total_votes: 0,
            created_by: userId
        };

        // Notify via socket
        if (global.io) {
            const room = meetingId ? `meeting-${meetingId}` : `room-${roomId}`;
            global.io.to(room).emit('poll-created', poll);
        }

        res.json(poll);
    } catch (err) {
        console.error('Create poll error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// VOTE ON POLL
// ============================================================
exports.votePoll = async (req, res) => {
    const { pollId } = req.params;
    const { optionIndex } = req.body;
    const userId = req.user.id;

    try {
        const poll = await mysql.queryOne(
            `SELECT * FROM meeting_polls WHERE id = ? AND status = 'active'`,
            [pollId]
        );

        if (!poll) return res.status(404).json({ error: 'Poll haipatikani' });
        if (poll.ends_at && new Date(poll.ends_at) < new Date()) {
            return res.status(400).json({ error: 'Poll imeisha muda' });
        }

        const options = JSON.parse(poll.options);
        if (optionIndex < 0 || optionIndex >= options.length) {
            return res.status(400).json({ error: 'Chaguo batili' });
        }

        // Check if user already voted
        const existing = await mysql.queryOne(
            `SELECT id FROM poll_votes WHERE poll_id = ? AND user_id = ?`,
            [pollId, userId]
        );

        if (existing && !poll.allow_multiple) {
            return res.status(400).json({ error: 'Umeshapiga kura' });
        }

        await mysql.query(
            `INSERT INTO poll_votes (id, poll_id, user_id, option_index)
             VALUES (?, ?, ?, ?)`,
            [uuidv4(), pollId, userId, optionIndex]
        );

        // Get updated results
        const results = await exports.getPollResults(pollId);

        // Notify
        if (global.io) {
            const room = poll.meeting_id ? `meeting-${poll.meeting_id}` : `room-${poll.room_id}`;
            global.io.to(room).emit('poll-updated', results);
        }

        res.json({ success: true, results });
    } catch (err) {
        console.error('Vote error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET POLL RESULTS
// ============================================================
exports.getPollResults = async (pollId) => {
    const poll = await mysql.queryOne(
        `SELECT * FROM meeting_polls WHERE id = ?`,
        [pollId]
    );

    if (!poll) return null;

    const options = JSON.parse(poll.options);
    const votes = await mysql.query(
        `SELECT option_index, COUNT(*) as count
         FROM poll_votes WHERE poll_id = ?
         GROUP BY option_index`,
        [pollId]
    );

    const voteCounts = options.map(() => 0);
    let totalVotes = 0;

    votes.forEach(v => {
        voteCounts[v.option_index] = v.count;
        totalVotes += v.count;
    });

    return {
        id: poll.id,
        question: poll.question,
        options,
        votes: voteCounts,
        total_votes: totalVotes,
        status: poll.status,
        ends_at: poll.ends_at
    };
};

// ============================================================
// GET POLLS FOR MEETING
// ============================================================
exports.getMeetingPolls = async (req, res) => {
    const { meetingId } = req.params;

    try {
        const polls = await mysql.query(
            `SELECT * FROM meeting_polls WHERE meeting_id = ? ORDER BY created_at DESC`,
            [meetingId]
        );

        const results = await Promise.all(
            polls.map(p => exports.getPollResults(p.id))
        );

        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLOSE POLL
// ============================================================
exports.closePoll = async (req, res) => {
    const { pollId } = req.params;
    const userId = req.user.id;

    try {
        const poll = await mysql.queryOne(
            `SELECT * FROM meeting_polls WHERE id = ?`,
            [pollId]
        );

        if (!poll) return res.status(404).json({ error: 'Haipatikani' });
        if (poll.created_by !== userId && req.user.role !== 'mwenyekiti') {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        await mysql.update('meeting_polls', {
            status: 'closed',
            closed_at: new Date()
        }, { id: pollId });

        const results = await exports.getPollResults(pollId);

        if (global.io) {
            const room = poll.meeting_id ? `meeting-${poll.meeting_id}` : `room-${poll.room_id}`;
            global.io.to(room).emit('poll-closed', results);
        }

        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};