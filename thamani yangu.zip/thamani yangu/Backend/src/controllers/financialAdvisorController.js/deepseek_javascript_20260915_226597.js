const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');
const { callAIWithFallback } = require('../utils/aiOrchestrator');

// ============================================================
// TOPICS ROTATION
// ============================================================
const WEEKLY_TOPICS = [
    {
        week: 1,
        topic: 'Umuhimu wa Akiba ya Dharura',
        description: 'Kwa nini uwe na akiba ya dharura ya miezi 3-6 na jinsi ya kuanza'
    },
    {
        week: 2,
        topic: 'Kuepuka Deni la Gharama Kubwa',
        description: 'Jinsi ya kuepuka mikopo yenye riba kubwa na kujenga nidhamu ya kifedha'
    },
    {
        week: 3,
        topic: 'Kuwekeza kwa Busara',
        description: 'Njia salama za kuwekeza na jinsi ya kutambua fursa nzuri'
    },
    {
        week: 4,
        topic: 'Kupanga Bajeti ya Kila Mwezi',
        description: 'Jinsi ya kupanga bajeti, kufuatilia matumizi, na kuweka akiba'
    }
];

// ============================================================
// GENERATE MONTHLY SCHEDULE (Auto)
// ============================================================
exports.generateMonthlySchedule = async (req, res) => {
    try {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();

        const schedules = [];
        const dayNames = ['Jumapili', 'Jumatatu', 'Jumanne', 'Jumatano', 'Alhamisi', 'Ijumaa', 'Jumamosi'];

        for (let i = 0; i < WEEKLY_TOPICS.length; i++) {
            const topic = WEEKLY_TOPICS[i];
            const scheduledDate = new Date(currentYear, currentMonth, (i + 1) * 7);

            const id = uuidv4();
            const dayOfWeek = dayNames[scheduledDate.getDay()];

            await mysql.query(
                `INSERT INTO financial_training_schedules 
                 (id, week_number, topic, description, day_of_week, scheduled_date, scheduled_time, status)
                 VALUES (?, ?, ?, ?, ?, ?, '19:00:00', 'pending')`,
                [id, topic.week, topic.topic, topic.description, dayOfWeek,
                 scheduledDate.toISOString().split('T')[0]]
            );

            schedules.push({ id, ...topic, scheduled_date: scheduledDate });
        }

        // Send to leaders chatroom
        const leadersRoom = await mysql.queryOne(
            `SELECT id FROM chat_rooms WHERE type = 'leaders_only' LIMIT 1`
        );

        if (leadersRoom) {
            const scheduleMsg = `📅 *RATIBA YA MAFUNZO YA KIFEDHA - MWEZI*

${schedules.map(s => `🗓️ Wiki ${s.week}: ${s.topic}
   📆 ${s.day_of_week}, ${new Date(s.scheduled_date).toLocaleDateString('sw-TZ')}
   ⏰ 19:00
   📝 ${s.description}`).join('\n\n')}

Tafadhali pitia na mruhusu au kubadilisha.`;

            const msgId = uuidv4();
            await mysql.query(
                `INSERT INTO chat_messages 
                 (id, room_id, sender_id, sender_name, sender_member_id, text, is_ai, ai_type)
                 VALUES (?, ?, '00000000-0000-0000-0000-000000000000', 'THAMANI FINANCIAL ADVISOR', 'AI', ?, TRUE, 'financial')`,
                [msgId, leadersRoom.id, scheduleMsg]
            );

            if (global.io) {
                global.io.to(`room-${leadersRoom.id}`).emit('new-message', {
                    id: msgId,
                    room_id: leadersRoom.id,
                    sender_name: 'THAMANI FINANCIAL ADVISOR',
                    text: scheduleMsg,
                    is_ai: true,
                    ai_type: 'financial'
                });
            }
        }

        res.json({ schedules, message: 'Ratiba imetumwa kwa viongozi' });
    } catch (err) {
        console.error('Generate schedule error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL SCHEDULES
// ============================================================
exports.getSchedules = async (req, res) => {
    try {
        const { status, month } = req.query;
        let query = `SELECT * FROM financial_training_schedules WHERE 1=1`;
        const params = [];

        if (status) {
            query += ` AND status = ?`;
            params.push(status);
        }
        if (month) {
            query += ` AND MONTH(scheduled_date) = ?`;
            params.push(parseInt(month));
        }

        query += ` ORDER BY scheduled_date ASC`;

        const schedules = await mysql.query(query, params);
        res.json(schedules);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// APPROVE SCHEDULE (Leaders only)
// ============================================================
exports.approveSchedule = async (req, res) => {
    const { scheduleId } = req.params;
    const userId = req.user.id;

    if (!['mwenyekiti', 'katibu', 'mhazini'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Viongozi pekee' });
    }

    try {
        await mysql.update('financial_training_schedules', {
            status: 'approved',
            approved_by: userId,
            approved_at: new Date()
        }, { id: scheduleId });

        res.json({ message: 'Ratiba imekubaliwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPDATE SCHEDULE (Time, date)
// ============================================================
exports.updateSchedule = async (req, res) => {
    const { scheduleId } = req.params;
    const { scheduled_date, scheduled_time, topic, description } = req.body;
    const userId = req.user.id;

    if (!['mwenyekiti', 'katibu', 'mhazini'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Viongozi pekee' });
    }

    try {
        const updates = {};
        if (scheduled_date) updates.scheduled_date = scheduled_date;
        if (scheduled_time) updates.scheduled_time = scheduled_time;
        if (topic) updates.topic = topic;
        if (description) updates.description = description;

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'Hakuna mabadiliko' });
        }

        await mysql.update('financial_training_schedules', updates, { id: scheduleId });

        res.json({ message: 'Ratiba imebadilishwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// ANSWER FINANCIAL QUESTION (On training day only)
// ============================================================
exports.answerQuestion = async (req, res) => {
    const { question } = req.body;
    const userId = req.user.id;

    if (!question) return res.status(400).json({ error: 'Swali linahitajika' });

    try {
        // Get today's training
        const today = new Date().toISOString().split('T')[0];
        const todayTraining = await mysql.queryOne(
            `SELECT * FROM financial_training_schedules 
             WHERE scheduled_date = ? AND status = 'approved'
             LIMIT 1`,
            [today]
        );

        if (!todayTraining) {
            return res.status(400).json({
                error: 'Hakuna mafunzo leo. Mafunzo yapo siku zilizowekwa.'
            });
        }

        // Check similarity (simple check)
        const prompt = `Wewe ni THAMANI FINANCIAL ADVISOR. 
Mada ya leo: "${todayTraining.topic}" - ${todayTraining.description}
Swali la mwanachama: ${question}

Jibu kwa Kiswahili kwa ufupi. Kama swali halihusiani na mada ya leo, sema: "Samahani, swali lako halihusiani na mada ya leo: ${todayTraining.topic}. Tafadhali uliza kuhusu mada hii."

Jibu:`;

        const result = await callAIWithFallback(prompt, []);

        // Save Q&A
        const id = uuidv4();
        await mysql.query(
            `INSERT INTO financial_qa (id, schedule_id, user_id, question, answer, answered_at)
             VALUES (?, ?, ?, ?, ?, NOW())`,
            [id, todayTraining.id, userId, question, result.response]
        );

        res.json({
            question,
            answer: result.response,
            topic: todayTraining.topic,
            provider: result.provider
        });
    } catch (err) {
        console.error('Answer question error:', err);
        res.status(500).json({ error: err.message });
    }
};