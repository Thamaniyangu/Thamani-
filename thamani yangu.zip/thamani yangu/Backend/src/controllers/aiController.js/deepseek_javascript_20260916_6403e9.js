const { callAIWithFallback, getProviderStatus } = require('../utils/aiOrchestrator');
const { MongoAIHistory } = require('../config/databases');
const supabase = require('../config/supabase');

// ============================================================
// CHAT WITH AI (Fallback Chain)
// ============================================================
exports.chatWithAI = async (req, res) => {
    const { message, preferredLanguage } = req.body;
    const userId = req.user.id;

    if (!message) {
        return res.status(400).json({ error: 'Tafadhali andika ujumbe' });
    }

    try {
        // Get user's preferred language
        const { data: user } = await supabase
            .from('users')
            .select('preferred_language')
            .eq('id', userId)
            .single();

        const lang = preferredLanguage || user?.preferred_language || 'sw';

        // Get chat history
        let history = [];
        const existing = await MongoAIHistory.findOne({ user_id: userId });
        if (existing) history = existing.messages || [];

        // Call AI with fallback
        const result = await callAIWithFallback(message, history, { preferredLanguage: lang });

        if (result.success) {
            // Save to MongoDB history
            if (existing) {
                existing.messages.push({ role: 'user', content: message });
                existing.messages.push({ role: 'assistant', content: result.response });
                existing.updated_at = new Date();
                await existing.save();
            } else {
                const newDoc = new MongoAIHistory({
                    user_id: userId,
                    messages: [
                        { role: 'user', content: message },
                        { role: 'assistant', content: result.response }
                    ]
                });
                await newDoc.save();
            }

            res.json({
                success: true,
                provider: result.provider,
                response: result.response,
                _attempted: result.attemptedProviders // For debugging
            });
        } else {
            res.status(503).json({
                success: false,
                error: result.error,
                details: result.details
            });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET AI HISTORY
// ============================================================
exports.getAIHistory = async (req, res) => {
    const userId = req.user.id;
    try {
        const history = await MongoAIHistory.findOne({ user_id: userId });
        res.json(history || { messages: [] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLEAR AI HISTORY
// ============================================================
exports.clearAIHistory = async (req, res) => {
    const userId = req.user.id;
    try {
        await MongoAIHistory.deleteOne({ user_id: userId });
        res.json({ message: 'Historia imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET PROVIDER STATUS (Leaders only)
// ============================================================
exports.getAIProviderStatus = async (req, res) => {
    if (!['mwenyekiti', 'katibu', 'mhazini'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }
    res.json(getProviderStatus());
};