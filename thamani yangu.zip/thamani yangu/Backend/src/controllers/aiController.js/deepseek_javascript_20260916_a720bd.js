const { callAIWithFallback, getProviderStatus } = require('../utils/aiOrchestrator');
const { MongoAIHistory } = require('../config/databases');
const supabase = require('../config/supabase');

// ============================================================
// CHAT WITH AI - Provider Inafichwa Kwa Watumiaji Wote Isipokuwa Mwenyekiti
// ============================================================
exports.chatWithAI = async (req, res) => {
    const { message, preferredLanguage } = req.body;
    const userId = req.user.id;
    const userRole = req.user.role;

    if (!message) {
        return res.status(400).json({ error: 'Tafadhali andika ujumbe' });
    }

    try {
        // Get user's preferred language
        const { data: user } = await supabase
            .from('users')
            .select('preferred_language')
            .eq('id', userId)
            .single();

        const lang = preferredLanguage || user?.preferred_language || 'sw';

        // Get chat history
        let history = [];
        const existing = await MongoAIHistory.findOne({ user_id: userId });
        if (existing) history = existing.messages || [];

        // Call AI with fallback
        const result = await callAIWithFallback(message, history, { preferredLanguage: lang });

        if (result.success) {
            // Save to MongoDB history
            if (existing) {
                existing.messages.push({ role: 'user', content: message });
                existing.messages.push({ role: 'assistant', content: result.response });
                existing.updated_at = new Date();
                await existing.save();
            } else {
                const newDoc = new MongoAIHistory({
                    user_id: userId,
                    messages: [
                        { role: 'user', content: message },
                        { role: 'assistant', content: result.response }
                    ]
                });
                await newDoc.save();
            }

            // Log provider usage (kwa ajili ya Mwenyekiti pekee)
            await supabase.from('ai_usage_logs').insert({
                user_id: userId,
                user_role: userRole,
                message: message,
                provider: result.provider,
                attempted_providers: result.attemptedProviders || [],
                created_at: new Date().toISOString()
            });

            // ========================================================
            // MUHIMU: Ficha provider kwa watumiaji wote isipokuwa Mwenyekiti
            // ========================================================
            const responsePayload = {
                success: true,
                response: result.response
            };

            // Mwenyekiti PEKEE anaona provider
            if (userRole === 'mwenyekiti') {
                responsePayload.provider = result.provider;
                responsePayload._attempted = result.attemptedProviders;
            }

            res.json(responsePayload);
        } else {
            res.status(503).json({
                success: false,
                error: result.error
                // Hakuna details kwa mtumiaji
            });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET AI HISTORY
// ============================================================
exports.getAIHistory = async (req, res) => {
    const userId = req.user.id;
    try {
        const history = await MongoAIHistory.findOne({ user_id: userId });
        res.json(history || { messages: [] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLEAR AI HISTORY
// ============================================================
exports.clearAIHistory = async (req, res) => {
    const userId = req.user.id;
    try {
        await MongoAIHistory.deleteOne({ user_id: userId });
        res.json({ message: 'Historia imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET AI USAGE STATS - MWENYEKITI PEKEE
// ============================================================
exports.getAIUsageStats = async (req, res) => {
    // Mwenyekiti PEKEE anaweza kuona
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Huna ruhusa ya kuona taarifa hii' });
    }

    try {
        // Get usage stats by provider
        const { data: logs, error } = await supabase
            .from('ai_usage_logs')
            .select('provider, created_at, user_id, user_role')
            .order('created_at', { ascending: false })
            .limit(1000);

        if (error) throw error;

        // Aggregate
        const stats = {
            totalRequests: logs?.length || 0,
            byProvider: {},
            byRole: {},
            recentLogs: logs?.slice(0, 20) || []
        };

        for (const log of logs || []) {
            // Count by provider
            stats.byProvider[log.provider] = (stats.byProvider[log.provider] || 0) + 1;
            // Count by role
            stats.byRole[log.user_role] = (stats.byRole[log.user_role] || 0) + 1;
        }

        res.json(stats);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET PROVIDER STATUS - MWENYEKITI PEKEE
// ============================================================
exports.getAIProviderStatus = async (req, res) => {
    // Mwenyekiti PEKEE anaweza kuona
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Huna ruhusa ya kuona taarifa hii' });
    }

    try {
        const providers = getProviderStatus();
        
        // Add health check
        const providersWithHealth = await Promise.all(providers.map(async (p) => {
            let healthy = false;
            try {
                // Quick check if API key exists
                if (p.hasApiKey === 'yes' || p.hasApiKey === 'local') {
                    healthy = true;
                }
            } catch (e) {
                healthy = false;
            }
            return { ...p, healthy };
        }));

        res.json(providersWithHealth);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};