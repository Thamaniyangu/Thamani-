const { routeQuestion, getCachedResponse, setCachedResponse, getProviderStatus } = require('../utils/aiRouter');
const { MongoAIHistory } = require('../config/databases');
const supabase = require('../config/supabase');

// ============================================================
// CHAT WITH AI (Smart Routing + Cache)
// ============================================================
exports.chatWithAI = async (req, res) => {
    const { message, requestedAI, preferredLanguage } = req.body;
    const userId = req.user.id;
    const userRole = req.user.role;

    if (!message) {
        return res.status(400).json({ error: 'Tafadhali andika ujumbe' });
    }

    try {
        // Get user's preferred language
        const { data: user } = await supabase
            .from('users')
            .select('preferred_language')
            .eq('id', userId)
            .single();

        const lang = preferredLanguage || user?.preferred_language || 'sw';

        // Detect AI type
        const detection = require('../utils/aiRouter').detectAIType(message);
        const aiType = requestedAI || detection.ai;

        // Check cache (only for non-personalized questions)
        const cached = getCachedResponse(detection.cleanMessage, aiType);
        if (cached && !history?.length) {
            return res.json({
                success: true,
                response: cached,
                cached: true
            });
        }

        // Get chat history
        let history = [];
        const existing = await MongoAIHistory.findOne({ user_id: userId });
        if (existing) history = existing.messages || [];

        // Route question
        const result = await routeQuestion(message, history, {
            requestedAI,
            userRole,
            language: lang
        });

        if (result.success) {
            // Cache response
            if (result.response) {
                setCachedResponse(detection.cleanMessage, aiType, result.response);
            }

            // Save to MongoDB
            if (existing) {
                existing.messages.push({ role: 'user', content: message });
                existing.messages.push({ role: 'assistant', content: result.response });
                existing.updated_at = new Date();
                await existing.save();
            } else {
                const newDoc = new MongoAIHistory({
                    user_id: userId,
                    messages: [
                        { role: 'user', content: message },
                        { role: 'assistant', content: result.response }
                    ]
                });
                await newDoc.save();
            }

            // Log usage
            await supabase.from('ai_usage_logs').insert({
                user_id: userId,
                user_role: userRole,
                ai_type: result.aiType,
                message: message,
                provider: result.provider,
                attempted_providers: result.attemptedProviders || []
            });

            // Response payload (provider hidden except Mwenyekiti)
            const payload = {
                success: true,
                aiName: result.aiName,
                response: result.response
            };

            if (userRole === 'mwenyekiti') {
                payload.provider = result.provider;
                payload._attempted = result.attemptedProviders;
            }

            res.json(payload);
        } else {
            res.status(503).json({
                success: false,
                error: result.error
            });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ... (getAIHistory, clearAIHistory, getAIUsageStats, getAIProviderStatus - same as before)