const mysql = require('../config/mysql');
const { uploadToStorage, deleteByUrl } = require('../utils/localStorage');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

// ============================================================
// START RECORDING
// ============================================================
exports.startRecording = async (req, res) => {
    const { meetingId, roomId } = req.body;
    const userId = req.user.id;

    try {
        const id = uuidv4();
        
        await mysql.query(
            `INSERT INTO meeting_recordings 
             (id, meeting_id, room_id, started_by, filename, file_url, file_path, status)
             VALUES (?, ?, ?, ?, 'pending', 'pending', 'pending', 'recording')`,
            [id, meetingId, roomId || null, userId]
        );

        if (global.io) {
            global.io.to(`meeting-${meetingId}`).emit('recording-started', {
                recordingId: id,
                startedBy: userId
            });
        }

        res.json({ 
            recordingId: id,
            message: 'Recording imeanza' 
        });
    } catch (err) {
        console.error('Start recording error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPLOAD RECORDING (Chunk)
// ============================================================
exports.uploadRecordingChunk = async (req, res) => {
    const { recordingId } = req.params;
    const chunk = req.file;

    if (!chunk) return res.status(400).json({ error: 'Chunk inahitajika' });

    try {
        const recording = await mysql.queryOne(
            `SELECT * FROM meeting_recordings WHERE id = ? AND started_by = ?`,
            [recordingId, req.user.id]
        );

        if (!recording) return res.status(404).json({ error: 'Recording haipatikani' });

        // Append chunk to file
        const tempDir = path.join(__dirname, '../../uploads/recordings-temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const tempFile = path.join(tempDir, `${recordingId}.webm`);
        fs.appendFileSync(tempFile, chunk.buffer);

        res.json({ success: true });
    } catch (err) {
        console.error('Upload chunk error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// STOP RECORDING (Finalize)
// ============================================================
exports.stopRecording = async (req, res) => {
    const { recordingId } = req.params;
    const { duration } = req.body;

    try {
        const recording = await mysql.queryOne(
            `SELECT * FROM meeting_recordings WHERE id = ? AND started_by = ?`,
            [recordingId, req.user.id]
        );

        if (!recording) return res.status(404).json({ error: 'Recording haipatikani' });

        const tempFile = path.join(__dirname, '../../uploads/recordings-temp', `${recordingId}.webm`);
        if (!fs.existsSync(tempFile)) {
            return res.status(404).json({ error: 'Recording file haipatikani' });
        }

        const stats = fs.statSync(tempFile);
        const filename = `recording-${recordingId}-${Date.now()}.webm`;

        // Move to permanent storage
        const fileBuffer = fs.readFileSync(tempFile);
        const fileUrl = await uploadToStorage(fileBuffer, 'recordings', filename);

        // Update DB
        await mysql.update('meeting_recordings', {
            filename,
            file_url: fileUrl,
            file_path: `recordings/${filename}`,
            file_size: stats.size,
            duration: duration || 0,
            status: 'completed',
            completed_at: new Date()
        }, { id: recordingId });

        // Delete temp file
        fs.unlinkSync(tempFile);

        if (global.io && recording.meeting_id) {
            global.io.to(`meeting-${recording.meeting_id}`).emit('recording-stopped', {
                recordingId,
                fileUrl
            });
        }

        res.json({
            message: 'Recording imekamilika',
            fileUrl,
            filename,
            fileSize: stats.size
        });
    } catch (err) {
        console.error('Stop recording error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET MEETING RECORDINGS
// ============================================================
exports.getMeetingRecordings = async (req, res) => {
    const { meetingId } = req.params;

    try {
        const recordings = await mysql.query(
            `SELECT mr.*, u.first_name, u.last_name
             FROM meeting_recordings mr
             LEFT JOIN users u ON mr.started_by = u.id
             WHERE mr.meeting_id = ? AND mr.status = 'completed'
             ORDER BY mr.created_at DESC`,
            [meetingId]
        );

        res.json(recordings);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE RECORDING (Mwenyekiti only)
// ============================================================
exports.deleteRecording = async (req, res) => {
    const { recordingId } = req.params;
    const userId = req.user.id;

    try {
        const recording = await mysql.queryOne(
            `SELECT * FROM meeting_recordings WHERE id = ?`,
            [recordingId]
        );

        if (!recording) return res.status(404).json({ error: 'Recording haipatikani' });
        
        // Permission: creator or Mwenyekiti
        if (recording.started_by !== userId && req.user.role !== 'mwenyekiti') {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        // Delete file
        if (recording.file_url) {
            try { await deleteByUrl(recording.file_url); } catch (e) {}
        }

        await mysql.delete('meeting_recordings', { id: recordingId });

        res.json({ message: 'Recording imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};