const mysql = require('../config/mysql');
const { sendEmail } = require('../utils/email');
const { sendWhatsApp } = require('../utils/whatsapp');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// SUBMIT APPLICATION
// ============================================================
exports.submitApplication = async (req, res) => {
    const {
        first_name, middle_name, last_name, phone, email,
        whatsapp_number, acceptedTerms
    } = req.body;

    if (!first_name || !last_name || !phone || !email) {
        return res.status(400).json({ error: 'Jaza sehemu zote' });
    }
    if (!acceptedTerms) {
        return res.status(400).json({ error: 'Kubali masharti' });
    }

    try {
        // Check existing
        const existing = await mysql.queryOne(
            `SELECT id FROM applications WHERE email = ? AND status = 'pending'`,
            [email]
        );
        if (existing) return res.status(400).json({ error: 'Ombi lako tayari lipo' });

        const id = uuidv4();
        await mysql.query(
            `INSERT INTO applications (id, first_name, middle_name, last_name, phone, email, whatsapp_number)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [id, first_name, middle_name || null, last_name, phone, email, whatsapp_number || null]
        );

        // Notify leaders
        const leaders = await mysql.query(
            `SELECT id, email, first_name FROM users WHERE role IN ('mwenyekiti', 'katibu')`
        );

        for (const leader of leaders) {
            try {
                await sendEmail({
                    to: leader.email,
                    subject: 'Ombi Jipya la Uanachama',
                    html: `<h2>Ombi Jipya</h2><p>${first_name} ${last_name}</p><p>${email}</p>`
                });
            } catch (e) {}

            if (global.io) {
                global.io.to(`user-${leader.id}`).emit('new-application', {
                    applicationId: id,
                    name: `${first_name} ${last_name}`
                });
            }
        }

        // Confirm to applicant
        await sendEmail({
            to: email,
            subject: 'Ombi lako limepokelewa',
            html: `<h2>Asante!</h2><p>Ombi lako limepokelewa. Utapata jibu ndani ya saa 24.</p>`
        });

        res.json({ message: 'Ombi limetumwa', applicationId: id });
    } catch (err) {
        console.error('Submit application error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET APPLICATIONS (Leaders only)
// ============================================================
exports.getApplications = async (req, res) => {
    const { status } = req.query;

    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        let query = `SELECT * FROM applications`;
        const params = [];

        if (status) {
            query += ` WHERE status = ?`;
            params.push(status);
        }
        query += ` ORDER BY created_at DESC`;

        const apps = await mysql.query(query, params);
        res.json(apps);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// REVIEW APPLICATION
// ============================================================
exports.reviewApplication = async (req, res) => {
    const { applicationId } = req.params;
    const { action, notes } = req.body;

    if (!['approve', 'reject'].includes(action)) {
        return res.status(400).json({ error: 'Action batili' });
    }

    if (!['mwenyekiti', 'katibu'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Huna ruhusa' });
    }

    try {
        const app = await mysql.queryOne(
            `SELECT * FROM applications WHERE id = ?`, [applicationId]
        );
        if (!app) return res.status(404).json({ error: 'Ombi halipo' });
        if (app.status !== 'pending') return res.status(400).json({ error: 'Limekaguliwa' });

        const newStatus = action === 'approve' ? 'approved' : 'rejected';

        await mysql.update('applications', {
            status: newStatus,
            reviewed_by: req.user.id,
            reviewed_at: new Date()
        }, { id: applicationId });

        // Notify applicant
        const subject = newStatus === 'approved' ? 'Ombi lako limekubaliwa!' : 'Ombi lako limekataliwa';
        const html = newStatus === 'approved'
            ? `<h2>Hongera!</h2><p>Ombi lako limekubaliwa. Karibu!</p>`
            : `<h2>Samahani</h2><p>Ombi lako halikubaliwa. ${notes || ''}</p>`;

        try {
            await sendEmail({ to: app.email, subject, html });
        } catch (e) {}

        // WhatsApp if approved
        if (newStatus === 'approved' && app.whatsapp_number) {
            try {
                await sendWhatsApp({
                    to: app.whatsapp_number,
                    message: `🎉 *Hongera ${app.first_name}!*\n\nOmbi lako la kujiunga na THAMANI YANGU limekubaliwa!`
                });
            } catch (e) {}
        }

        res.json({ message: `Ombi lime${newStatus === 'approved' ? 'kubaliwa' : 'kataliwa'}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET CONSTITUTION
// ============================================================
exports.getConstitution = async (req, res) => {
    try {
        const setting = await mysql.queryOne(
            `SELECT value FROM settings WHERE \`key\` = 'constitution'`
        );

        if (!setting) {
            return res.json({
                title: 'Katiba ya THAMANI YANGU',
                content: '<h1>KATIBA YA THAMANI YANGU</h1><p>...</p>'
            });
        }

        res.json(JSON.parse(setting.value));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};