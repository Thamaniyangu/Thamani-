const mysql = require('../config/mysql');

// ============================================================
// DEFAULT THEME
// ============================================================
const DEFAULT_THEME = {
    primary: '#0D6B6B',
    secondary: '#D4AF37',
    accent: '#F5E5C0',
    background: '#F8F9FA',
    surface: '#FFFFFF',
    text: '#1A1A1A',
    textMuted: '#6B7280',
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444'
};

// ============================================================
// GET USER THEME (per area)
// ============================================================
exports.getUserTheme = async (req, res) => {
    const { area = 'global' } = req.query;
    const userId = req.user.id;

    try {
        const theme = await mysql.queryOne(
            `SELECT theme_data FROM user_themes WHERE user_id = ? AND area = ?`,
            [userId, area]
        );

        if (theme) {
            return res.json({ theme: JSON.parse(theme.theme_data || '{}') });
        }

        // Fallback to global default
        const defaultTheme = await mysql.queryOne(
            `SELECT value FROM settings WHERE \`key\` = 'theme_default'`
        );

        res.json({
            theme: defaultTheme ? JSON.parse(defaultTheme.value) : DEFAULT_THEME
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SAVE USER THEME
// ============================================================
exports.saveUserTheme = async (req, res) => {
    const { area = 'global', theme } = req.body;
    const userId = req.user.id;

    if (!theme || typeof theme !== 'object') {
        return res.status(400).json({ error: 'Theme data inahitajika' });
    }

    try {
        await mysql.query(
            `INSERT INTO user_themes (id, user_id, area, theme_data)
             VALUES (UUID(), ?, ?, ?)
             ON DUPLICATE KEY UPDATE theme_data = VALUES(theme_data)`,
            [userId, area, JSON.stringify(theme)]
        );

        res.json({ message: 'Theme imehifadhiwa', theme });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL USER THEMES
// ============================================================
exports.getAllUserThemes = async (req, res) => {
    const userId = req.user.id;

    try {
        const themes = await mysql.query(
            `SELECT area, theme_data FROM user_themes WHERE user_id = ?`,
            [userId]
        );

        const result = {};
        for (const t of themes) {
            result[t.area] = JSON.parse(t.theme_data || '{}');
        }

        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// RESET USER THEME
// ============================================================
exports.resetUserTheme = async (req, res) => {
    const { area } = req.params;
    const userId = req.user.id;

    try {
        await mysql.query(
            `DELETE FROM user_themes WHERE user_id = ? AND area = ?`,
            [userId, area]
        );
        res.json({ message: 'Theme imerejeshwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};