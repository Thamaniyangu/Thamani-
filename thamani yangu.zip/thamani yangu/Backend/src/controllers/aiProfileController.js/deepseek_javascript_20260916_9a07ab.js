const supabase = require('../config/supabase');
const { uploadToStorage } = require('../utils/storage');
const sharp = require('sharp');

// ============================================================
// GET ALL AI PROFILES (Public - kwa watumiaji wote)
// ============================================================
exports.getAIProfiles = async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('ai_profiles')
            .select('id, name, description, photo_url, updated_at')
            .order('id', { ascending: true });

        if (error) throw error;

        res.json(data || []);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET SINGLE AI PROFILE
// ============================================================
exports.getAIProfile = async (req, res) => {
    const { aiId } = req.params;

    try {
        const { data, error } = await supabase
            .from('ai_profiles')
            .select('*')
            .eq('id', aiId)
            .single();

        if (error || !data) {
            return res.status(404).json({ error: 'AI profile haipatikani' });
        }

        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPDATE AI PROFILE PHOTO (Mwenyekiti PEKEE)
// ============================================================
exports.updateAIProfilePhoto = async (req, res) => {
    const { aiId } = req.params;
    const userId = req.user.id;

    // Check if user is Mwenyekiti
    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee anayeweza kuweka picha za AI' });
    }

    if (!req.file) {
        return res.status(400).json({ error: 'Hakuna picha iliyopakiwa' });
    }

    // Validate AI ID
    const validAIIds = ['ai-buddy', 'ai-financial', 'ai-leadership'];
    if (!validAIIds.includes(aiId)) {
        return res.status(400).json({ error: 'AI ID batili' });
    }

    try {
        // Optimize image (resize to 400x400 max, convert to PNG)
        const optimizedBuffer = await sharp(req.file.buffer)
            .resize(400, 400, { fit: 'cover', position: 'center' })
            .png({ quality: 90 })
            .toBuffer();

        // Upload to Supabase Storage
        const filename = `${aiId}-${Date.now()}.png`;
        const path = `ai-profiles/${filename}`;

        const { error: uploadErr } = await supabase.storage
            .from('ai-profiles')
            .upload(path, optimizedBuffer, {
                contentType: 'image/png',
                cacheControl: '3600',
                upsert: true
            });

        if (uploadErr) throw uploadErr;

        const { data: urlData } = supabase.storage
            .from('ai-profiles')
            .getPublicUrl(path);

        // Get old photo to delete
        const { data: oldProfile } = await supabase
            .from('ai_profiles')
            .select('photo_url')
            .eq('id', aiId)
            .single();

        // Update database
        const { data, error } = await supabase
            .from('ai_profiles')
            .update({
                photo_url: urlData.publicUrl,
                updated_by: userId,
                updated_at: new Date().toISOString()
            })
            .eq('id', aiId)
            .select()
            .single();

        if (error) throw error;

        // Delete old photo (if exists)
        if (oldProfile?.photo_url) {
            try {
                const oldPath = oldProfile.photo_url.split('/ai-profiles/')[1];
                if (oldPath) {
                    await supabase.storage.from('ai-profiles').remove([`ai-profiles/${oldPath}`]);
                }
            } catch (e) {
                console.warn('Failed to delete old photo:', e);
            }
        }

        // Notify all users via socket
        if (global.io) {
            global.io.emit('ai-profile-updated', {
                aiId,
                photo_url: urlData.publicUrl
            });
        }

        res.json({
            message: 'Picha ya AI imewekwa!',
            profile: data
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE AI PROFILE PHOTO (Mwenyekiti PEKEE)
// ============================================================
exports.deleteAIProfilePhoto = async (req, res) => {
    const { aiId } = req.params;

    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        const { data: profile } = await supabase
            .from('ai_profiles')
            .select('photo_url')
            .eq('id', aiId)
            .single();

        if (profile?.photo_url) {
            try {
                const path = profile.photo_url.split('/ai-profiles/')[1];
                if (path) {
                    await supabase.storage.from('ai-profiles').remove([`ai-profiles/${path}`]);
                }
            } catch (e) {}
        }

        await supabase
            .from('ai_profiles')
            .update({
                photo_url: null,
                updated_by: req.user.id,
                updated_at: new Date().toISOString()
            })
            .eq('id', aiId);

        if (global.io) {
            global.io.emit('ai-profile-updated', { aiId, photo_url: null });
        }

        res.json({ message: 'Picha imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};