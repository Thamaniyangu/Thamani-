const mysql = require('../config/mysql');
const { uploadToStorage } = require('../utils/localStorage');
const sharp = require('sharp');

// ============================================================
// GET ALL AI PROFILES
// ============================================================
exports.getAIProfiles = async (req, res) => {
    try {
        const profiles = await mysql.query(
            `SELECT id, name, description, photo_url, updated_at FROM ai_profiles ORDER BY id`
        );
        res.json(profiles);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET SINGLE AI PROFILE
// ============================================================
exports.getAIProfile = async (req, res) => {
    const { aiId } = req.params;

    try {
        const profile = await mysql.queryOne(
            `SELECT * FROM ai_profiles WHERE id = ?`, [aiId]
        );
        if (!profile) return res.status(404).json({ error: 'AI profile haipatikani' });
        res.json(profile);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UPDATE AI PROFILE PHOTO (Mwenyekiti only)
// ============================================================
exports.updateAIProfilePhoto = async (req, res) => {
    const { aiId } = req.params;
    const userId = req.user.id;

    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    if (!req.file) return res.status(400).json({ error: 'Hakuna picha' });

    const validIds = ['ai-buddy', 'ai-financial', 'ai-leadership'];
    if (!validIds.includes(aiId)) {
        return res.status(400).json({ error: 'AI ID batili' });
    }

    try {
        // Optimize image
        const optimized = await sharp(req.file.buffer)
            .resize(400, 400, { fit: 'cover', position: 'center' })
            .png({ quality: 90 })
            .toBuffer();

        const filename = `${aiId}-${Date.now()}.png`;
        const photoUrl = await uploadToStorage(optimized, 'ai-profiles', filename);

        // Update profile
        await mysql.query(
            `UPDATE ai_profiles 
             SET photo_url = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ?`,
            [photoUrl, userId, aiId]
        );

        // Emit socket event
        if (global.io) {
            global.io.emit('ai-profile-updated', { aiId, photo_url: photoUrl });
        }

        res.json({ message: 'Picha imewekwa', photo_url: photoUrl });
    } catch (err) {
        console.error('Update AI photo error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE AI PROFILE PHOTO
// ============================================================
exports.deleteAIProfilePhoto = async (req, res) => {
    const { aiId } = req.params;

    if (req.user.role !== 'mwenyekiti') {
        return res.status(403).json({ error: 'Ni Mwenyekiti pekee' });
    }

    try {
        await mysql.query(
            `UPDATE ai_profiles SET photo_url = NULL, updated_at = NOW() WHERE id = ?`,
            [aiId]
        );

        if (global.io) {
            global.io.emit('ai-profile-updated', { aiId, photo_url: null });
        }

        res.json({ message: 'Picha imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};