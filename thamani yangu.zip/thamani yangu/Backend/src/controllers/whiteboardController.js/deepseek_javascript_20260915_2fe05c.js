const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// CREATE WHITEBOARD
// ============================================================
exports.createWhiteboard = async (req, res) => {
    const { meetingId, roomId, name, backgroundColor } = req.body;
    const userId = req.user.id;

    try {
        const id = uuidv4();

        await mysql.query(
            `INSERT INTO whiteboards (id, meeting_id, room_id, name, background_color, created_by)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [id, meetingId || null, roomId || null, name || 'Whiteboard',
             backgroundColor || '#FFFFFF', userId]
        );

        res.json({ id, name, message: 'Whiteboard imeundwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SAVE STROKE
// ============================================================
exports.saveStroke = async (req, res) => {
    const { whiteboardId } = req.params;
    const { tool, color, width, points, text } = req.body;
    const userId = req.user.id;

    try {
        const id = uuidv4();

        await mysql.query(
            `INSERT INTO whiteboard_strokes 
             (id, whiteboard_id, user_id, tool, color, width, points, text)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, whiteboardId, userId, tool || 'pen', color || '#000000',
             width || 2, JSON.stringify(points || []), text || null]
        );

        const stroke = { id, whiteboard_id: whiteboardId, user_id: userId, tool, color, width, points, text };

        if (global.io) {
            global.io.to(`whiteboard-${whiteboardId}`).emit('stroke-added', stroke);
        }

        res.json(stroke);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL STROKES
// ============================================================
exports.getStrokes = async (req, res) => {
    const { whiteboardId } = req.params;
    const { since } = req.query;

    try {
        let query = `SELECT * FROM whiteboard_strokes WHERE whiteboard_id = ?`;
        const params = [whiteboardId];

        if (since) {
            query += ` AND created_at > ?`;
            params.push(since);
        }

        query += ` ORDER BY created_at ASC`;

        const strokes = await mysql.query(query, params);

        res.json(strokes.map(s => ({
            ...s,
            points: JSON.parse(s.points || '[]')
        })));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// CLEAR WHITEBOARD
// ============================================================
exports.clearWhiteboard = async (req, res) => {
    const { whiteboardId } = req.params;
    const userId = req.user.id;

    try {
        const wb = await mysql.queryOne(
            `SELECT created_by FROM whiteboards WHERE id = ?`, [whiteboardId]
        );

        if (!wb) return res.status(404).json({ error: 'Haipatikani' });
        if (wb.created_by !== userId && req.user.role !== 'mwenyekiti') {
            return res.status(403).json({ error: 'Huna ruhusa' });
        }

        await mysql.query(
            `DELETE FROM whiteboard_strokes WHERE whiteboard_id = ?`,
            [whiteboardId]
        );

        if (global.io) {
            global.io.to(`whiteboard-${whiteboardId}`).emit('whiteboard-cleared', { whiteboardId });
        }

        res.json({ message: 'Whiteboard imefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// UNDO (Delete last stroke by user)
// ============================================================
exports.undoLastStroke = async (req, res) => {
    const { whiteboardId } = req.params;
    const userId = req.user.id;

    try {
        const last = await mysql.queryOne(
            `SELECT id FROM whiteboard_strokes 
             WHERE whiteboard_id = ? AND user_id = ?
             ORDER BY created_at DESC LIMIT 1`,
            [whiteboardId, userId]
        );

        if (!last) return res.status(404).json({ error: 'Hakuna stroke' });

        await mysql.delete('whiteboard_strokes', { id: last.id });

        if (global.io) {
            global.io.to(`whiteboard-${whiteboardId}`).emit('stroke-removed', { strokeId: last.id });
        }

        res.json({ message: 'Umefuta stroke' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};