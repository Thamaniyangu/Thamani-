// backend/src/controllers/iotController.js

// ============================================================
// REGISTER IoT DEVICE
// ============================================================
exports.registerDevice = async (req, res) => {
    const { deviceId, deviceType, deviceInfo } = req.body;
    const userId = req.user.id;

    try {
        await mysql.query(`
            INSERT INTO iot_devices 
            (id, user_id, device_id, device_type, device_info, status)
            VALUES (UUID(), ?, ?, ?, ?, 'active')
            ON DUPLICATE KEY UPDATE
                device_info = VALUES(device_info),
                status = 'active'
        `, [userId, deviceId, deviceType, JSON.stringify(deviceInfo)]);

        res.json({ 
            success: true,
            message: 'Kifaa kimewekwa',
            deviceId 
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// RECEIVE IoT DATA (SMS, POS, Sensors)
// ============================================================
exports.receiveIoTData = async (req, res) => {
    const { deviceId, signature } = req.headers;
    const { type, data } = req.body;

    try {
        // Verify device
        const device = await mysql.queryOne(`
            SELECT d.*, u.id as user_id 
            FROM iot_devices d
            JOIN users u ON d.user_id = u.id
            WHERE d.device_id = ? AND d.status = 'active'
        `, [deviceId]);

        if (!device) {
            return res.status(403).json({ error: 'Kifaa hakijasajiliwa' });
        }

        // Process based on type
        let result;

        switch (type) {
            case 'sms_payment':
                result = await processSMSPayment(device.user_id, data);
                break;
            case 'pos_sale':
                result = await processPOSSale(device.user_id, data);
                break;
            case 'smart_meter':
                result = await processSmartMeter(device.user_id, data);
                break;
            case 'vehicle_trip':
                result = await processVehicleTrip(device.user_id, data);
                break;
            default:
                return res.status(400).json({ error: 'Aina haijulikani' });
        }

        // Log IoT data
        await mysql.query(`
            INSERT INTO iot_logs (id, device_id, type, data, processed, created_at)
            VALUES (UUID(), ?, ?, ?, TRUE, NOW())
        `, [deviceId, type, JSON.stringify(data)]);

        res.json({ success: true, result });
    } catch (err) {
        console.error('IoT data error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// PROCESS SMS PAYMENT (M-Pesa, Tigo, Airtel)
// ============================================================
const processSMSPayment = async (userId, data) => {
    const { text, amount, sender, reference, transactionId } = data;

    // Parse SMS
    // Mfano: "You have received TZS 200,000 from ASH MWINYI..."
    
    // Create contribution
    const receiptNumber = `RCT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 1000)}`;
    
    const contributionId = require('uuid').v4();
    await mysql.query(`
        INSERT INTO contributions 
        (id, user_id, type, amount, recorded_by, receipt_number, 
         contribution_date, source)
        VALUES (?, ?, 'hisa', ?, NULL, ?, NOW(), 'iot_sms')
    `, [contributionId, userId, amount, receiptNumber]);

    // Generate receipt PDF
    const user = await mysql.queryOne(
        `SELECT first_name, last_name, member_id, email, whatsapp_number 
         FROM users WHERE id = ?`, [userId]
    );

    const { generateReceiptPDF } = require('../utils/pdfGenerator');
    const { uploadToStorage } = require('../utils/localStorage');

    const pdfBuffer = await generateReceiptPDF({
        receiptNumber,
        memberName: `${user.first_name} ${user.last_name}`,
        memberId: user.member_id,
        type: 'hisa',
        amount,
        date: new Date().toLocaleDateString('en-GB'),
        time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
    });

    const pdfUrl = await uploadToStorage(pdfBuffer, 'receipts', `${receiptNumber}.pdf`);

    await mysql.query(`
        UPDATE contributions SET receipt_url = ? WHERE id = ?
    `, [pdfUrl, contributionId]);

    // Notify user
    if (global.io) {
        global.io.to(`user-${userId}`).emit('contribution-recorded', {
            receiptNumber,
            amount,
            receiptUrl: pdfUrl
        });
    }

    // Send WhatsApp notification
    if (user.whatsapp_number) {
        const { sendWhatsApp } = require('../utils/whatsapp');
        await sendWhatsApp({
            to: user.whatsapp_number,
            message: `✅ *Mchango Umerekodiwa!*\n\nKiasi: TZS ${amount.toLocaleString()}\nRisiti: ${receiptNumber}\n\nAsante!`
        });
    }

    return { receiptNumber, amount, status: 'recorded' };
};

// ============================================================
// PROCESS POS SALE
// ============================================================
const processPOSSale = async (userId, data) => {
    const { saleAmount, autoSavePercent = 5 } = data;
    
    const savingsAmount = (saleAmount * autoSavePercent) / 100;

    // Record contribution
    const receiptNumber = `RCT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 1000)}`;
    const contributionId = require('uuid').v4();

    await mysql.query(`
        INSERT INTO contributions 
        (id, user_id, type, amount, receipt_number, contribution_date, source)
        VALUES (?, ?, 'hisa', ?, ?, NOW(), 'iot_pos')
    `, [contributionId, userId, savingsAmount, receiptNumber]);

    return {
        saleAmount,
        savingsAmount,
        autoSavePercent,
        receiptNumber,
        status: 'recorded'
    };
};

// ============================================================
// PROCESS SMART METER (Utility Savings)
// ============================================================
const processSmartMeter = async (userId, data) => {
    const { utilityType, currentUsage, previousUsage, savingsAmount } = data;

    if (savingsAmount > 0) {
        const receiptNumber = `RCT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 1000)}`;
        
        await mysql.query(`
            INSERT INTO contributions 
            (id, user_id, type, amount, receipt_number, contribution_date, source)
            VALUES (UUID(), ?, 'hisa', ?, ?, NOW(), 'iot_smart_meter')
        `, [userId, savingsAmount, receiptNumber]);

        return {
            utilityType,
            saved: savingsAmount,
            receiptNumber,
            status: 'recorded'
        };
    }

    return { status: 'no_savings' };
};

// ============================================================
// PROCESS VEHICLE TRIP
// ============================================================
const processVehicleTrip = async (userId, data) => {
    const { tripDistance, tripEarnings, autoSavePercent = 10 } = data;
    const savingsAmount = (tripEarnings * autoSavePercent) / 100;

    if (savingsAmount > 0) {
        const receiptNumber = `RCT-${Date.now().toString().slice(-5)}${Math.floor(Math.random() * 1000)}`;
        
        await mysql.query(`
            INSERT INTO contributions 
            (id, user_id, type, amount, receipt_number, contribution_date, source)
            VALUES (UUID(), ?, 'hisa', ?, ?, NOW(), 'iot_vehicle')
        `, [userId, savingsAmount, receiptNumber]);

        return {
            tripDistance,
            tripEarnings,
            saved: savingsAmount,
            receiptNumber
        };
    }

    return { status: 'no_savings' };
};

// ============================================================
// GET USER'S IoT DEVICES
// ============================================================
exports.getUserDevices = async (req, res) => {
    try {
        const devices = await mysql.query(`
            SELECT id, device_id, device_type, device_info, status, 
                   created_at, last_sync_at
            FROM iot_devices
            WHERE user_id = ?
            ORDER BY created_at DESC
        `, [req.user.id]);

        res.json(devices);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET IoT SAVINGS STATS
// ============================================================
exports.getIoTSavingsStats = async (req, res) => {
    try {
        const stats = await mysql.query(`
            SELECT 
                source,
                COUNT(*) as transactions,
                SUM(amount) as total_saved
            FROM contributions
            WHERE user_id = ? 
              AND source LIKE 'iot_%'
              AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY source
        `, [req.user.id]);

        const totalSaved = stats.reduce((sum, s) => sum + parseFloat(s.total_saved || 0), 0);

        res.json({
            bySource: stats,
            totalSaved,
            period: '30 days'
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};