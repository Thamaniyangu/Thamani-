const { UnifiedDB } = require('../utils/databaseOperations');
const { routeQuestion } = require('../utils/aiRouter');
const supabase = require('../config/supabase');

// ============================================================
// SEND MESSAGE (with AI Tag Detection + Smart Handoff)
// ============================================================
exports.sendMessage = async (req, res) => {
    const { roomId } = req.params;
    const { text, type, file_url, reply_to } = req.body;
    const senderId = req.user.id;

    try {
        const { data: user } = await supabase
            .from('users')
            .select('first_name, last_name, member_id, role')
            .eq('id', senderId)
            .single();

        // Save user message
        const messageData = {
            id: require('uuid').v4(),
            room_id: roomId,
            sender_id: senderId,
            sender_name: `${user.first_name} ${user.last_name}`,
            sender_member_id: user.member_id,
            text: text || '',
            type: type || 'text',
            file_url: file_url || null,
            reply_to: reply_to || null,
            created_at: new Date().toISOString()
        };

        await UnifiedDB.insert('chat_messages', messageData);

        if (global.io) {
            global.io.to(`room-${roomId}`).emit('new-message', { ...messageData, roomId });
        }

        res.status(201).json(messageData);

        // ========================================================
        // AI TAG DETECTION
        // ========================================================
        const lowerText = (text || '').toLowerCase();
        const hasAITag = lowerText.includes('@ai') || 
                        lowerText.includes('@finance') || 
                        lowerText.includes('@leader') ||
                        lowerText.includes('@buddy');

        if (hasAITag) {
            // Get room type
            const { data: room } = await supabase
                .from('chat_rooms')
                .select('type, name')
                .eq('id', roomId)
                .single();

            // Route question (includes smart handoff)
            const result = await routeQuestion(text, [], {
                userRole: user.role,
                language: 'sw'
            });

            if (result.success) {
                // If handoff occurred, send a notice first
                if (result.handoffNote) {
                    const noticeMessage = {
                        id: require('uuid').v4(),
                        room_id: roomId,
                        sender_id: '00000000-0000-0000-0000-000000000001',
                        sender_name: 'THAMANI AI SYSTEM',
                        sender_member_id: 'AI',
                        text: result.handoffNote,
                        type: 'system',
                        is_ai: true,
                        is_notice: true,
                        created_at: new Date().toISOString()
                    };

                    await UnifiedDB.insert('chat_messages', noticeMessage);

                    if (global.io) {
                        global.io.to(`room-${roomId}`).emit('new-message', { ...noticeMessage, roomId });
                    }
                }

                // Save AI response
                const aiMessage = {
                    id: require('uuid').v4(),
                    room_id: roomId,
                    sender_id: '00000000-0000-0000-0000-000000000000',
                    sender_name: result.aiName,
                    sender_member_id: 'AI',
                    text: result.response,
                    type: 'text',
                    is_ai: true,
                    ai_type: result.aiType,
                    created_at: new Date().toISOString()
                };

                await UnifiedDB.insert('chat_messages', aiMessage);

                if (global.io) {
                    global.io.to(`room-${roomId}`).emit('new-message', { ...aiMessage, roomId });
                }
            } else {
                // Send error
                const errorMessage = {
                    id: require('uuid').v4(),
                    room_id: roomId,
                    sender_id: '00000000-0000-0000-0000-000000000000',
                    sender_name: 'THAMANI AI',
                    sender_member_id: 'AI',
                    text: result.error,
                    type: 'text',
                    is_ai: true,
                    created_at: new Date().toISOString()
                };

                await UnifiedDB.insert('chat_messages', errorMessage);

                if (global.io) {
                    global.io.to(`room-${roomId}`).emit('new-message', { ...errorMessage, roomId });
                }
            }
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};