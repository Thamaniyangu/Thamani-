const mysql = require('../config/mysql');
const { routeQuestion } = require('../utils/aiRouter');
const { uploadToStorage } = require('../utils/localStorage');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// GET USER CHATROOMS
// ============================================================
exports.getUserChatrooms = async (req, res) => {
    const userId = req.user.id;

    try {
        const user = await mysql.queryOne(
            `SELECT role FROM users WHERE id = ?`, [userId]
        );

        let rooms;

        if (user.role === 'mwanachama') {
            rooms = await mysql.query(`
                SELECT * FROM chat_rooms 
                WHERE type IN ('community', 'members_only')
                   OR (type = 'private' AND JSON_CONTAINS(participants, ?))
                ORDER BY created_at DESC
            `, [JSON.stringify(userId)]);
        } else {
            rooms = await mysql.query(`
                SELECT * FROM chat_rooms 
                WHERE type IN ('community', 'leaders_only', 'members_only')
                   OR (type = 'private' AND JSON_CONTAINS(participants, ?))
                ORDER BY created_at DESC
            `, [JSON.stringify(userId)]);
        }

        res.json(rooms.map(r => ({
            ...r,
            participants: r.participants ? JSON.parse(r.participants) : [],
            last_message: r.last_message ? JSON.parse(r.last_message) : null
        })));
    } catch (err) {
        console.error('Get chatrooms error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET MESSAGES
// ============================================================
exports.getMessages = async (req, res) => {
    const { roomId } = req.params;
    const { limit = 50, before } = req.query;

    try {
        let query = `
            SELECT * FROM chat_messages
            WHERE room_id = ? AND deleted = FALSE
        `;
        const params = [roomId];

        if (before) {
            query += ` AND created_at < ?`;
            params.push(before);
        }

        query += ` ORDER BY created_at DESC LIMIT ?`;
        params.push(parseInt(limit));

        const messages = await mysql.query(query, params);

        res.json(messages.reverse().map(m => ({
            ...m,
            read_by: m.read_by ? JSON.parse(m.read_by) : [],
            active_users: m.active_users ? JSON.parse(m.active_users) : []
        })));
    } catch (err) {
        console.error('Get messages error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// SEND MESSAGE (with AI tag detection)
// ============================================================
exports.sendMessage = async (req, res) => {
    const { roomId } = req.params;
    const { text, type, file_url, reply_to } = req.body;
    const senderId = req.user.id;

    try {
        const user = await mysql.queryOne(
            `SELECT first_name, last_name, member_id, role FROM users WHERE id = ?`,
            [senderId]
        );

        const messageId = uuidv4();

        const messageData = {
            id: messageId,
            room_id: roomId,
            sender_id: senderId,
            sender_name: `${user.first_name} ${user.last_name}`,
            sender_member_id: user.member_id,
            text: text || '',
            type: type || 'text',
            file_url: file_url || null,
            reply_to: reply_to || null
        };

        await mysql.query(
            `INSERT INTO chat_messages 
             (id, room_id, sender_id, sender_name, sender_member_id, text, type, file_url, reply_to, read_by, active_users)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                messageData.id, messageData.room_id, messageData.sender_id,
                messageData.sender_name, messageData.sender_member_id,
                messageData.text, messageData.type, messageData.file_url,
                messageData.reply_to,
                JSON.stringify([senderId]),
                JSON.stringify([])
            ]
        );

        // Update last_message in room
        await mysql.query(
            `UPDATE chat_rooms SET last_message = ? WHERE id = ?`,
            [JSON.stringify({
                text: text || file_url || 'Media',
                sender_id: senderId,
                sender_name: `${user.first_name} ${user.last_name}`,
                sent_at: new Date().toISOString()
            }), roomId]
        );

        // Emit via socket
        if (global.io) {
            global.io.to(`room-${roomId}`).emit('new-message', { ...messageData, roomId });
        }

        res.status(201).json(messageData);

        // ============================================================
        // AI TAG DETECTION
        // ============================================================
        const lowerText = (text || '').toLowerCase();
        const hasAITag = /@(ai|finance|leader|buddy)/i.test(lowerText);

        if (hasAITag) {
            const room = await mysql.queryOne(
                `SELECT type FROM chat_rooms WHERE id = ?`, [roomId]
            );

            const result = await routeQuestion(text, [], {
                userRole: user.role,
                language: 'sw'
            });

            if (result.success) {
                // Send handoff notice if any
                if (result.handoffNote) {
                    const noticeId = uuidv4();
                    const noticeData = {
                        id: noticeId,
                        room_id: roomId,
                        sender_id: '00000000-0000-0000-0000-000000000001',
                        sender_name: 'THAMANI AI SYSTEM',
                        sender_member_id: 'AI',
                        text: result.handoffNote,
                        type: 'system',
                        is_ai: true,
                        is_notice: true
                    };

                    await mysql.query(
                        `INSERT INTO chat_messages 
                         (id, room_id, sender_id, sender_name, sender_member_id, text, type, is_ai, is_notice)
                         VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, TRUE)`,
                        [noticeData.id, noticeData.room_id, noticeData.sender_id,
                         noticeData.sender_name, noticeData.sender_member_id,
                         noticeData.text, noticeData.type]
                    );

                    if (global.io) {
                        global.io.to(`room-${roomId}`).emit('new-message', { ...noticeData, roomId });
                    }
                }

                // Send AI message
                const aiMessageId = uuidv4();
                const aiMessageData = {
                    id: aiMessageId,
                    room_id: roomId,
                    sender_id: '00000000-0000-0000-0000-000000000000',
                    sender_name: result.aiName,
                    sender_member_id: 'AI',
                    text: result.response,
                    type: 'text',
                    is_ai: true,
                    ai_type: result.aiType
                };

                await mysql.query(
                    `INSERT INTO chat_messages 
                     (id, room_id, sender_id, sender_name, sender_member_id, text, type, is_ai, ai_type)
                     VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, ?)`,
                    [aiMessageData.id, aiMessageData.room_id, aiMessageData.sender_id,
                     aiMessageData.sender_name, aiMessageData.sender_member_id,
                     aiMessageData.text, aiMessageData.type, aiMessageData.ai_type]
                );

                if (global.io) {
                    global.io.to(`room-${roomId}`).emit('new-message', { ...aiMessageData, roomId });
                }
            }
        }
    } catch (err) {
        console.error('Send message error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// EDIT MESSAGE
// ============================================================
exports.editMessage = async (req, res) => {
    const { roomId, messageId } = req.params;
    const { text } = req.body;
    const userId = req.user.id;

    try {
        const msg = await mysql.queryOne(
            `SELECT sender_id FROM chat_messages WHERE id = ? AND room_id = ?`,
            [messageId, roomId]
        );

        if (!msg) return res.status(404).json({ error: 'Ujumbe haupo' });
        if (msg.sender_id !== userId) {
            return res.status(403).json({ error: 'Huwezi kuhariri ujumbe wa mtu mwingine' });
        }

        await mysql.query(
            `UPDATE chat_messages SET text = ?, edited = TRUE WHERE id = ?`,
            [text, messageId]
        );

        if (global.io) {
            global.io.to(`room-${roomId}`).emit('message-edited', { messageId, text, roomId });
        }

        res.json({ message: 'Ujumbe umehaririwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// DELETE MESSAGE
// ============================================================
exports.deleteMessage = async (req, res) => {
    const { roomId, messageId } = req.params;
    const userId = req.user.id;

    try {
        const msg = await mysql.queryOne(
            `SELECT sender_id FROM chat_messages WHERE id = ? AND room_id = ?`,
            [messageId, roomId]
        );

        if (!msg) return res.status(404).json({ error: 'Ujumbe haupo' });
        if (msg.sender_id !== userId) {
            return res.status(403).json({ error: 'Huwezi kufuta ujumbe wa mtu mwingine' });
        }

        await mysql.query(
            `UPDATE chat_messages SET deleted = TRUE, text = 'Ujumbe huu umefutwa' WHERE id = ?`,
            [messageId]
        );

        if (global.io) {
            global.io.to(`room-${roomId}`).emit('message-deleted', { messageId, roomId });
        }

        res.json({ message: 'Ujumbe umefutwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};