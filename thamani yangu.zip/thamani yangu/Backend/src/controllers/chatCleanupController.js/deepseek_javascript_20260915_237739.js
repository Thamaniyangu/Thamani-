const mysql = require('../config/mysql');
const { deleteByUrl } = require('../utils/localStorage');

// ============================================================
// DELETE OLD CHAT MEDIA (Every month)
// ============================================================
exports.deleteOldChatMedia = async () => {
    try {
        const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

        const messages = await mysql.query(`
            SELECT cm.id, cm.file_url, cm.sender_name, cm.active_users, cm.room_id, cm.created_at,
                   cr.type as room_type
            FROM chat_messages cm
            JOIN chat_rooms cr ON cm.room_id = cr.id
            WHERE cm.type != 'text'
              AND cm.media_deleted = FALSE
              AND cm.created_at < ?
              AND cr.type IN ('community', 'leaders_only', 'members_only')
        `, [oneMonthAgo]);

        for (const msg of messages) {
            if (msg.file_url) {
                try {
                    await deleteByUrl(msg.file_url);
                } catch (e) {}
            }

            await mysql.update('chat_messages', {
                media_deleted: true,
                file_url: null,
                file_path: null
            }, { id: msg.id });
        }

        if (messages.length > 0) {
            console.log(`🗑️ Deleted ${messages.length} old chat media`);
        }
    } catch (err) {
        console.error('Delete old chat media error:', err);
    }
};