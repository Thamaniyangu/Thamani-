const mysql = require('../config/mysql');
const { generateReceiptPDF } = require('../utils/pdfGenerator');
const { uploadToStorage } = require('../utils/localStorage');

// ============================================================
// DOWNLOAD RECEIPT
// ============================================================
exports.downloadReceipt = async (req, res) => {
    const { receiptNumber } = req.params;

    try {
        const contribution = await mysql.queryOne(
            `SELECT c.*, u.first_name, u.last_name, u.member_id
             FROM contributions c
             JOIN users u ON c.user_id = u.id
             WHERE c.receipt_number = ?`,
            [receiptNumber]
        );

        if (!contribution) {
            return res.status(404).json({ error: 'Risiti haipatikani' });
        }

        // Generate PDF if not exists
        if (!contribution.receipt_url) {
            const pdfBuffer = await generateReceiptPDF({
                receiptNumber: contribution.receipt_number,
                memberName: `${contribution.first_name} ${contribution.last_name}`,
                memberId: contribution.member_id,
                type: contribution.type,
                amount: contribution.amount,
                date: new Date(contribution.created_at).toLocaleDateString('en-GB'),
                time: new Date(contribution.created_at).toLocaleTimeString('en-GB', {
                    hour: '2-digit', minute: '2-digit'
                })
            });

            const pdfUrl = await uploadToStorage(pdfBuffer, 'receipts', `${receiptNumber}.pdf`);
            
            await mysql.query(
                `UPDATE contributions SET receipt_url = ? WHERE id = ?`,
                [pdfUrl, contribution.id]
            );

            return res.redirect(pdfUrl);
        }

        res.redirect(contribution.receipt_url);
    } catch (err) {
        console.error('Download receipt error:', err);
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET ALL RECEIPTS (Paginated)
// ============================================================
exports.getAllReceipts = async (req, res) => {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    try {
        let query = `
            SELECT c.id, c.receipt_number, c.type, c.amount, c.receipt_url, c.created_at,
                   u.first_name, u.last_name, u.member_id
            FROM contributions c
            JOIN users u ON c.user_id = u.id
            WHERE c.receipt_number IS NOT NULL
        `;
        const params = [];

        if (req.user.role === 'mwanachama') {
            query += ` AND c.user_id = ?`;
            params.push(req.user.id);
        }

        query += ` ORDER BY c.created_at DESC LIMIT ? OFFSET ?`;
        params.push(parseInt(limit), parseInt(offset));

        const receipts = await mysql.query(query, params);
        res.json(receipts);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};