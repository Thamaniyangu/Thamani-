const { pgPool, getMySQLPool, getMongoDB, MongoDocument, MongoChatMessage, MongoAIHistory } = require('../config/databases');
const cron = require('node-cron');

async function syncDatabases() {
    console.log('🔄 Starting database sync at', new Date().toISOString());
    try {
        // Sync Users
        const pgUsers = await pgPool.query('SELECT * FROM users');
        const mysqlPool = await getMySQLPool();
        for (const user of pgUsers.rows) {
            await mysqlPool.execute(
                `INSERT INTO users (id, member_id, email, phone, password_hash, role, first_name, middle_name, last_name, profile_photo_url, status, region, district, ward_street, emergency_contact_name1, emergency_contact_name2, emergency_relationship, emergency_phone, emergency_region, emergency_district, emergency_ward_street, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE member_id=VALUES(member_id), email=VALUES(email), phone=VALUES(phone), password_hash=VALUES(password_hash), role=VALUES(role), first_name=VALUES(first_name), middle_name=VALUES(middle_name), last_name=VALUES(last_name), profile_photo_url=VALUES(profile_photo_url), status=VALUES(status), region=VALUES(region), district=VALUES(district), ward_street=VALUES(ward_street), emergency_contact_name1=VALUES(emergency_contact_name1), emergency_contact_name2=VALUES(emergency_contact_name2), emergency_relationship=VALUES(emergency_relationship), emergency_phone=VALUES(emergency_phone), emergency_region=VALUES(emergency_region), emergency_district=VALUES(emergency_district), emergency_ward_street=VALUES(emergency_ward_street), updated_at=VALUES(updated_at)`,
                [user.id, user.member_id, user.email, user.phone, user.password_hash, user.role, user.first_name, user.middle_name, user.last_name, user.profile_photo_url, user.status, user.region, user.district, user.ward_street, user.emergency_contact_name1, user.emergency_contact_name2, user.emergency_relationship, user.emergency_phone, user.emergency_region, user.emergency_district, user.emergency_ward_street, user.created_at, user.updated_at]
            );
        }
        console.log(`✅ Synced ${pgUsers.rows.length} users`);

        // Sync Contributions
        const pgContribs = await pgPool.query('SELECT * FROM contributions');
        for (const c of pgContribs.rows) {
            await mysqlPool.execute(
                `INSERT INTO contributions (id, user_id, type, amount, contribution_date, recorded_by, receipt_number, receipt_url, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), type=VALUES(type), amount=VALUES(amount), contribution_date=VALUES(contribution_date), recorded_by=VALUES(recorded_by), receipt_number=VALUES(receipt_number), receipt_url=VALUES(receipt_url)`,
                [c.id, c.user_id, c.type, c.amount, c.contribution_date, c.recorded_by, c.receipt_number, c.receipt_url, c.created_at]
            );
        }
        console.log(`✅ Synced ${pgContribs.rows.length} contributions`);

        // Sync Chat Messages to MongoDB
        const pgMessages = await pgPool.query('SELECT * FROM chat_messages');
        const mongo = await getMongoDB();
        for (const msg of pgMessages.rows) {
            await MongoChatMessage.findOneAndUpdate(
                { id: msg.id },
                {
                    id: msg.id,
                    room_id: msg.room_id,
                    sender_id: msg.sender_id,
                    sender_name: msg.sender_name,
                    sender_member_id: msg.sender_member_id,
                    text: msg.text,
                    type: msg.type,
                    file_url: msg.file_url,
                    file_path: msg.file_path,
                    reply_to: msg.reply_to,
                    edited: msg.edited,
                    deleted: msg.deleted,
                    read_by: msg.read_by,
                    active_users: msg.active_users,
                    media_deleted: msg.media_deleted,
                    created_at: msg.created_at
                },
                { upsert: true }
            );
        }
        console.log(`✅ Synced ${pgMessages.rows.length} chat messages to MongoDB`);

        console.log('✅ Sync completed successfully');
    } catch (error) {
        console.error('❌ Sync failed:', error);
    }
}

// Schedule: every 5 hours
cron.schedule('0 */5 * * *', async () => {
    console.log('⏰ Scheduled sync triggered');
    await syncDatabases();
});

// Run on startup
setTimeout(syncDatabases, 10000);

module.exports = { syncDatabases };