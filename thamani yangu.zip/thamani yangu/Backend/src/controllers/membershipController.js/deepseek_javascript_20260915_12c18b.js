const mysql = require('../config/mysql');
const { v4: uuidv4 } = require('uuid');

// ============================================================
// ADD MEMBERSHIP FEE
// ============================================================
exports.addMembershipFee = async (req, res) => {
    const { user_id, period, amount } = req.body;
    const recordedBy = req.user.id;

    try {
        const id = uuidv4();
        await mysql.query(
            `INSERT INTO membership_fees (id, user_id, period, amount, recorded_by)
             VALUES (?, ?, ?, ?, ?)`,
            [id, user_id, period, amount, recordedBy]
        );

        res.status(201).json({ id, user_id, period, amount, status: 'unpaid' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// PAY MEMBERSHIP FEE
// ============================================================
exports.payMembershipFee = async (req, res) => {
    const { id } = req.params;

    try {
        await mysql.update('membership_fees', {
            status: 'paid',
            paid_date: new Date()
        }, { id });

        res.json({ message: 'Ada imelipwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET MEMBERSHIP FEES
// ============================================================
exports.getMembershipFees = async (req, res) => {
    const { userId } = req.params;

    try {
        let query = `
            SELECT mf.*, u.first_name, u.last_name, u.member_id
            FROM membership_fees mf
            JOIN users u ON mf.user_id = u.id
        `;
        const params = [];

        if (req.user.role === 'mwanachama') {
            query += ` WHERE mf.user_id = ?`;
            params.push(req.user.id);
        } else if (userId) {
            query += ` WHERE mf.user_id = ?`;
            params.push(userId);
        }

        query += ` ORDER BY mf.created_at DESC`;

        const fees = await mysql.query(query, params);
        res.json(fees);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};