const mysql = require('../config/mysql');
const { sendEmail } = require('../utils/email');
const crypto = require('crypto');

// ============================================================
// REQUEST PROFILE CHANGE
// ============================================================
exports.requestChange = async (req, res) => {
    const userId = req.user.id;
    const { request_type, new_email, new_phone, reason } = req.body;

    if (!reason || reason.length < 10) {
        return res.status(400).json({ error: 'Sababu angalau herufi 10' });
    }

    try {
        const id = require('uuid').v4();
        await mysql.query(
            `INSERT INTO profile_change_requests 
             (id, user_id, request_type, new_email, new_phone, reason)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [id, userId, request_type, new_email || null, new_phone || null, reason]
        );

        // Notify leaders
        const leaders = await mysql.query(
            `SELECT id, email FROM users WHERE role IN ('mwenyekiti', 'katibu', 'mhazini')`
        );

        for (const leader of leaders) {
            try {
                await sendEmail({
                    to: leader.email,
                    subject: 'Ombi la Mabadiliko ya Taarifa',
                    html: `<h2>Ombi Jipya</h2><p>Aina: ${request_type}</p><p>Sababu: ${reason}</p>`
                });
            } catch (e) {}
        }

        res.json({ message: 'Ombi limetumwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// GET CHANGE REQUESTS
// ============================================================
exports.getChangeRequests = async (req, res) => {
    const userId = req.user.id;

    try {
        let query = `
            SELECT pcr.*, u.first_name, u.last_name, u.member_id
            FROM profile_change_requests pcr
            JOIN users u ON pcr.user_id = u.id
        `;
        const params = [];

        if (req.user.role === 'mwanachama') {
            query += ` WHERE pcr.user_id = ?`;
            params.push(userId);
        }

        query += ` ORDER BY pcr.created_at DESC`;

        const requests = await mysql.query(query, params);
        res.json(requests);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// APPROVE CHANGE REQUEST
// ============================================================
exports.approveChangeRequest = async (req, res) => {
    const { requestId } = req.params;
    const userId = req.user.id;

    try {
        const request = await mysql.queryOne(
            `SELECT * FROM profile_change_requests WHERE id = ?`,
            [requestId]
        );
        if (!request) return res.status(404).json({ error: 'Ombi halipo' });
        if (request.status !== 'pending') return res.status(400).json({ error: 'Limekaguliwa' });

        // Update approval based on role
        const updates = {};
        if (req.user.role === 'mwenyekiti') updates.approved_by_mwenyekiti = true;
        else if (req.user.role === 'katibu') updates.approved_by_katibu = true;
        else if (req.user.role === 'mhazini') updates.approved_by_mhazini = true;
        else return res.status(403).json({ error: 'Huna ruhusa' });

        await mysql.update('profile_change_requests', updates, { id: requestId });

        // Check if all approved
        const check = await mysql.queryOne(
            `SELECT * FROM profile_change_requests WHERE id = ?`, [requestId]
        );

        if (check.approved_by_mwenyekiti && check.approved_by_katibu && check.approved_by_mhazini) {
            const token = crypto.randomBytes(32).toString('hex');
            const expires = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000);

            await mysql.update('profile_change_requests', {
                status: 'approved',
                approved_at: new Date(),
                token,
                token_expires_at: expires
            }, { id: requestId });

            const user = await mysql.queryOne(
                `SELECT email FROM users WHERE id = ?`, [request.user_id]
            );

            if (user) {
                await sendEmail({
                    to: user.email,
                    subject: 'Mabadiliko yamekubaliwa',
                    html: `<h2>Mabadiliko yamekubaliwa!</h2>
                           <p><a href="${process.env.FRONTEND_URL}/complete-change?token=${token}">Kamilisha</a></p>
                           <p>Una siku 2.</p>`
                });
            }
        }

        res.json({ message: 'Imeidhinishwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// COMPLETE CHANGE
// ============================================================
exports.completeChange = async (req, res) => {
    const { token } = req.params;

    try {
        const request = await mysql.queryOne(
            `SELECT * FROM profile_change_requests 
             WHERE token = ? AND status = 'approved' AND token_expires_at > NOW()`,
            [token]
        );

        if (!request) return res.status(400).json({ error: 'Token batili' });

        const updates = {};
        if (request.request_type === 'email' || request.request_type === 'both') {
            updates.email = request.new_email;
        }
        if (request.request_type === 'phone' || request.request_type === 'both') {
            updates.phone = request.new_phone;
        }

        await mysql.update('users', updates, { id: request.user_id });
        await mysql.update('profile_change_requests', {
            status: 'completed',
            completed_at: new Date()
        }, { id: request.id });

        res.json({ message: 'Mabadiliko yamekamilika' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// ============================================================
// REJECT CHANGE REQUEST
// ============================================================
exports.rejectChangeRequest = async (req, res) => {
    const { requestId } = req.params;

    try {
        await mysql.update('profile_change_requests', {
            status: 'rejected'
        }, { id: requestId });
        res.json({ message: 'Imekataliwa' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};