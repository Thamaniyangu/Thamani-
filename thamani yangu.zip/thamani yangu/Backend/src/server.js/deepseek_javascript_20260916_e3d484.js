require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const { PeerServer } = require('peer');

const authRoutes = require('./routes/authRoutes');
const contributionRoutes = require('./routes/contributionRoutes');
const membershipRoutes = require('./routes/membershipRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const idCardRoutes = require('./routes/idCardRoutes');
const chatRoutes = require('./routes/chatRoutes');
const videoRoutes = require('./routes/videoRoutes');
const supportRoutes = require('./routes/supportRoutes');
const profileRoutes = require('./routes/profileRoutes');
const documentRoutes = require('./routes/documentRoutes');
const aiRoutes = require('./routes/aiRoutes');
const mediaRoutes = require('./routes/mediaRoutes');
const aiProfileRoutes = require('./routes/aiProfileRoutes');
const applicationRoutes = require('./routes/applicationRoutes');
const referralRoutes = require('./routes/referralRoutes');
const hostRoutes = require('./routes/hostRoutes');
const whatsappRoutes = require('./routes/whatsappRoutes');

const socketHandler = require('./socket');
const supportController = require('./controllers/supportController');
const whatsappService = require('./services/whatsappService');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*", methods: ["GET", "POST"] }
});
global.io = io;
socketHandler(io);

// PeerJS
PeerServer({ port: 9000, path: '/peerjs' });
console.log('✅ PeerJS running on port 9000');

app.use(cors());
app.use(express.json({ limit: '100mb' }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/contributions', contributionRoutes);
app.use('/api/membership-fees', membershipRoutes);
app.use('/api/receipts', receiptRoutes);
app.use('/api/id-card', idCardRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/video', videoRoutes);
app.use('/api/support', supportRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/ai-profiles', aiProfileRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/referrals', referralRoutes);
app.use('/api/host', hostRoutes);
app.use('/api/whatsapp', whatsappRoutes);

app.get('/health', (req, res) => res.json({ status: 'healthy', timestamp: new Date() }));

// Auto-delete support chats
setInterval(async () => {
    await supportController.deleteExpiredChats();
}, 60 * 60 * 1000);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);

    // Auto-start WhatsApp kama session ipo
    if (process.env.WHATSAPP_ENABLED === 'true') {
        setTimeout(() => {
            console.log('📱 Inaanzisha WhatsApp...');
            whatsappService.startWhatsApp().catch(err => {
                console.error('WhatsApp auto-start error:', err);
            });
        }, 3000);
    }
});