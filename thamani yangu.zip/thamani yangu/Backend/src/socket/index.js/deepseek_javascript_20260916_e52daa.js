const supabase = require('../config/supabase');
const whatsappService = require('../services/whatsappService');

module.exports = (io) => {
    io.on('connection', (socket) => {
        const userId = socket.handshake.query.userId;
        if (!userId) return socket.disconnect();

        socket.join(`user-${userId}`);
        console.log(`User ${userId} connected`);

        // Update presence
        supabase.from('user_presence').upsert({
            user_id: userId,
            online: true,
            last_seen: new Date().toISOString(),
            socket_id: socket.id
        }, { onConflict: 'user_id' }).then(() => 
            socket.broadcast.emit('user-online', { userId })
        );

        // Join chat room
        socket.on('join-room', (roomId) => {
            socket.join(`room-${roomId}`);
            socket.to(`room-${roomId}`).emit('user-joined', { userId });
        });

        socket.on('leave-room', (roomId) => {
            socket.leave(`room-${roomId}`);
            socket.to(`room-${roomId}`).emit('user-left', { userId });
        });

        // Send message
        socket.on('send-message', (data) => {
            io.to(`room-${data.roomId}`).emit('new-message', {
                ...data.message,
                roomId: data.roomId
            });
        });

        // Typing
        socket.on('typing', ({ roomId, userId, isTyping }) => {
            socket.to(`room-${roomId}`).emit('user-typing', { userId, isTyping });
        });

        // AI profile updated
        socket.on('ai-profile-updated', (data) => {
            io.emit('ai-profile-updated', data);
        });

        // ============================================================
        // WHATSAPP
        // ============================================================
        socket.on('whatsapp-request-status', () => {
            const status = whatsappService.getStatus();
            socket.emit('whatsapp-status', status);
        });

        // WebRTC
        socket.on('join-meeting', ({ meetingId, userId }) => {
            socket.join(`meeting-${meetingId}`);
            socket.to(`meeting-${meetingId}`).emit('user-joined-meeting', { userId });
        });

        socket.on('webrtc-offer', ({ targetUserId, offer }) => {
            io.to(`user-${targetUserId}`).emit('webrtc-offer', { from: userId, offer });
        });

        socket.on('webrtc-answer', ({ targetUserId, answer }) => {
            io.to(`user-${targetUserId}`).emit('webrtc-answer', { from: userId, answer });
        });

        socket.on('webrtc-ice', ({ targetUserId, ice }) => {
            io.to(`user-${targetUserId}`).emit('webrtc-ice', { from: userId, ice });
        });

        socket.on('reaction', ({ meetingId, emoji }) => {
            socket.to(`meeting-${meetingId}`).emit('reaction-received', { userId, emoji });
        });

        // Disconnect
        socket.on('disconnect', async () => {
            console.log(`User ${userId} disconnected`);
            await supabase.from('user_presence').update({
                online: false,
                last_seen: new Date().toISOString()
            }).eq('user_id', userId);
            io.emit('user-offline', { userId });
        });
    });
};