#!/usr/bin/env python3
"""
THAMANI YANGU - Custom Kiswahili AI Training
Uses LoRA for efficient fine-tuning on consumer GPU
"""

import os
import sys
import json
import torch
from pathlib import Path
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer

# ============================================================
# CONFIG
# ============================================================
BASE_MODEL = os.getenv('BASE_MODEL', 'meta-llama/Llama-3.1-8B-Instruct')
DATASET_PATH = os.getenv('DATASET_PATH', './data/dataset-latest')
OUTPUT_DIR = os.getenv('OUTPUT_DIR', './models/thamani-ai-v1')
EPOCHS = int(os.getenv('EPOCHS', '3'))
BATCH_SIZE = int(os.getenv('BATCH_SIZE', '4'))
LEARNING_RATE = float(os.getenv('LEARNING_RATE', '2e-4'))

print(f"🚀 Starting training")
print(f"   Base model: {BASE_MODEL}")
print(f"   Dataset: {DATASET_PATH}")
print(f"   Output: {OUTPUT_DIR}")

# ============================================================
# QUANTIZATION (4-bit for consumer GPU)
# ============================================================
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_use_double_quant=True,
)

# ============================================================
# LOAD MODEL
# ============================================================
print("📥 Loading model...")

model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
)

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

# ============================================================
# LoRA CONFIG
# ============================================================
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
)

model = prepare_model_for_kbit_training(model)
model = get_peft_model(model, lora_config)

model.print_trainable_parameters()

# ============================================================
# LOAD DATASET
# ============================================================
print("📚 Loading dataset...")

def format_prompt(sample):
    return f"""### Instruction:
{sample['instruction']}

### Response:
{sample['output']}"""

train_dataset = load_dataset('json', data_files=f'{DATASET_PATH}/train.jsonl', split='train')
val_dataset = load_dataset('json', data_files=f'{DATASET_PATH}/val.jsonl', split='train')

train_dataset = train_dataset.map(lambda x: {'text': format_prompt(x)})
val_dataset = val_dataset.map(lambda x: {'text': format_prompt(x)})

print(f"   Train: {len(train_dataset)} samples")
print(f"   Validation: {len(val_dataset)} samples")

# ============================================================
# TRAINING ARGS
# ============================================================
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    num_train_epochs=EPOCHS,
    per_device_train_batch_size=BATCH_SIZE,
    per_device_eval_batch_size=BATCH_SIZE,
    gradient_accumulation_steps=4,
    learning_rate=LEARNING_RATE,
    warmup_steps=100,
    logging_steps=10,
    save_steps=100,
    eval_steps=100,
    evaluation_strategy="steps",
    save_strategy="steps",
    save_total_limit=3,
    load_best_model_at_end=True,
    fp16=True,
    report_to="none",
    optim="paged_adamw_8bit",
)

# ============================================================
# TRAIN
# ============================================================
print("🎯 Training started...")

trainer = SFTTrainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    tokenizer=tokenizer,
    dataset_text_field="text",
    max_seq_length=2048,
    packing=False,
)

trainer.train()

# ============================================================
# SAVE
# ============================================================
print("💾 Saving model...")

trainer.save_model(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)

# Save training metadata
metadata = {
    'base_model': BASE_MODEL,
    'dataset': DATASET_PATH,
    'epochs': EPOCHS,
    'batch_size': BATCH_SIZE,
    'learning_rate': LEARNING_RATE,
    'final_loss': trainer.state.log_history[-1].get('loss'),
    'completed_at': str(torch.cuda.is_available() and torch.cuda.get_device_name() or 'CPU'),
}

with open(f'{OUTPUT_DIR}/metadata.json', 'w') as f:
    json.dump(metadata, f, indent=2)

print("✅ Training complete!")
print(f"   Model saved to: {OUTPUT_DIR}")